# -*- coding: utf-8 -*-
r"""test_deliver_verified.py —— ★461 tools/fry_deliver_verified.py 的闸，两个方向都验（不碰真算法仓：全在 tmp_path 里造）。

① 正常：verdict ✓ + 包完整 + 指纹 = 算法仓 ⇒ 交付到 <平台>_<与 win 变体同一时间戳>_<关键词>/，sdk_info 记下变体名与验收机器；
② 再跑一次 ⇒ 内容相同，跳过；
③ 反向：verdict ✗ / 在别的平台上验的 / 包被改（sha256 ≠ verdict）⇒ 拒绝，一个文件都不写。
需要 zstd（python zstandard 模块或 zstd 命令）造 .tar.zst；都没有就跳过。
"""
from __future__ import annotations

import hashlib
import io
import json
import shutil
import subprocess
import sys
import tarfile
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "tools"))
import fry_deliver_verified as DV  # noqa: E402
import fry_payload  # noqa: E402


def _zstd(raw: bytes) -> bytes:
    try:
        import zstandard
        return zstandard.ZstdCompressor().compress(raw)
    except ImportError:
        if not shutil.which("zstd"):
            pytest.skip("没有 zstd（pip install zstandard 或装 zstd 命令）")
        return subprocess.run(["zstd", "-q", "-c"], input=raw, capture_output=True, check=True).stdout


def _make(tmp: Path, tag="darwin-arm64", ok=True, host=None, tamper=False):
    algo = tmp / "algo"
    src = algo / fry_payload.SOURCE_SUBDIR_STR
    src.mkdir(parents=True)
    (src / "CMakeLists.txt").write_text("project(x)\n", encoding="utf-8")
    fp = fry_payload.tree_sha256(fry_payload.scan(src))
    win = algo / DV.TARGET_REL / "win32-x64_261027_0305_wt_unified"
    win.mkdir(parents=True)
    (win / "fry_halftone.dll").write_bytes(b"dll")
    (win / "params_schema.json").write_text(json.dumps({"params": [{"name": "wt_engine"}]}), encoding="utf-8")
    (win / "sdk_info.json").write_text(json.dumps({"version_str": "0.2.0"}), encoding="utf-8")
    lib = DV.LIB_NAME_DICT[tag]
    files = {"bin/" + lib: b"LIB", "include/fry_halftone.h": b"h", "params_schema.json": b"{}", "SDK_参数说明.md": b"m",
             "VERSION": b"0.2.0\n", "verify_delivery.py": b"#", "sdk_info.json": json.dumps({
                 "version_str": "0.2.0", "platform_str": tag, "algorithm_fingerprint_str": fp,
                 "library_sha256_str": hashlib.sha256(b"LIB").hexdigest()}).encode()}
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode="w") as t:
        for n, b in files.items():
            ti = tarfile.TarInfo("fry-halftone/" + n)
            ti.size = len(b)
            t.addfile(ti, io.BytesIO(b))
    pkg_bytes = _zstd(buf.getvalue())
    vroot = tmp / "verified"
    (vroot / tag).mkdir(parents=True)
    name = "fry-halftone-0.2.0-%s.tar.zst" % tag
    (vroot / tag / name).write_bytes(pkg_bytes)
    verdict = {"ok_bool": ok, "host_target_str": host or tag, "target_str": tag, "checks_list": [{}] * 6,
               "machine_dict": {"platform_str": "macOS-15"}, "version_dir_str": "_v",
               "deliverable_dict": {name: hashlib.sha256(pkg_bytes if not tamper else b"other").hexdigest()}}
    (vroot / tag / "verdict.json").write_text(json.dumps(verdict), encoding="utf-8")
    return algo, vroot


def test_deliver_then_skip(tmp_path):
    algo, vroot = _make(tmp_path)
    assert DV.main(["--algo-repo", str(algo), "--verified-dir", str(vroot)]) == 0
    dst = algo / DV.TARGET_REL / "darwin-arm64_261027_0305_wt_unified"
    assert (dst / "libfry_halftone.dylib").read_bytes() == b"LIB"
    info = json.loads((dst / "sdk_info.json").read_text(encoding="utf-8"))
    assert info["variant_str"] == "wt_unified" and info["delivered_dir_str"] == dst.name and info["verified_on_target_bool"] is True
    assert json.loads((dst / "github_verdict.json").read_text(encoding="utf-8"))["verified_bool"] is True
    assert DV.main(["--algo-repo", str(algo), "--verified-dir", str(vroot)]) == 0          # 再跑一次：内容相同 ⇒ 跳过


@pytest.mark.parametrize("kw", [{"ok": False}, {"host": "darwin-x64"}, {"tamper": True}])
def test_refuse_writes_nothing(tmp_path, kw):
    algo, vroot = _make(tmp_path, **kw)
    assert DV.main(["--algo-repo", str(algo), "--verified-dir", str(vroot)]) == 1
    assert not (algo / DV.TARGET_REL / "darwin-arm64_261027_0305_wt_unified").exists()
