#!/usr/bin/env bash
# build_linux_sdk.sh —— Linux 出包入口（CI 的 build:linux 和手工出包共用）
#
# 薄壳：五步流水线在 tools/fry_build.py（三平台同一份）。★384 起算法是 C++：不要 venv / pip / PyInstaller。
#
# 机器要求（CI 用 debian:bookworm 镜像，见 .gitlab-ci.yml）：build-essential cmake zstd binutils python3
#
# ★ 为什么选 bookworm（glibc 2.36）而不是更新的 trixie（glibc 2.41）：
#   Linux 上编出来的原生库**只能在 glibc 不比构建机旧的系统上跑**。构建机越老，能跑的机器越多。
#   libstdc++ / libgcc 另外静态链进库里（CMakeLists.txt），不依赖目标机 libstdc++ 的版本。
set -euo pipefail
REPO="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "$REPO"
VERSION="${VERSION:-0.0.0-dev}"
echo "== 水转印加网 SDK · Linux 出包（C++）· 版本 $VERSION =="

for tool in cmake c++ zstd nm; do
  command -v "$tool" >/dev/null 2>&1 || { echo "缺 $tool：请先安装（apt-get install build-essential cmake zstd binutils）" >&2; exit 1; }
done
PY="${FRY_SDK_PYTHON:-python3}"
command -v "$PY" >/dev/null 2>&1 || { echo "缺 python3（出包脚本只用标准库）" >&2; exit 1; }
echo "Python：$("$PY" -c 'import sys; print(sys.version.split()[0], sys.executable)')"

"$PY" tools/fry_build.py --version "$VERSION"

ARTIFACT="out/fry-halftone-${VERSION}-linux-x64.tar.zst"
[ -f "$ARTIFACT" ] || { echo "出包说成功了，但找不到产物 $ARTIFACT" >&2; exit 1; }
echo "产物：$ARTIFACT"
