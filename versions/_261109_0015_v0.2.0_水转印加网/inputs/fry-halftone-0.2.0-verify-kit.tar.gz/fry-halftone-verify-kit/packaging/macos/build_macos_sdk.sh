#!/usr/bin/env bash
# build_macos_sdk.sh —— macOS 出包入口（CI 的 build:macos 和手工出包共用）
#
# 薄壳：五步流水线在 tools/fry_build.py（三平台同一份）。★384 起算法是 C++：不要 venv / pip / PyInstaller。
#
# 机器要求：一台 Mac（macOS 的动态库只能用 Apple 的链接器编）：xcode-select --install ；brew install cmake zstd
#
# ★★ Apple Silicon 上逐位一致的关键：arm64 一定有 FMA 指令，clang 默认把 a*b+c 收缩成一条 FMA ⇒ 末位就变了。
#    CMakeLists.txt 里 -ffp-contract=off 专门管这件事（tests/test_build_helpers.py 钉住它不许被删）。
# ⚠ 签名：dylib 从浏览器下载会带隔离属性，消费方加载前可能需要 `xattr -dr com.apple.quarantine <解包目录>`。
set -euo pipefail
export PATH="/opt/homebrew/bin:/usr/local/bin:$PATH"     # CI 的 LaunchAgent shell 没有 Homebrew PATH
REPO="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "$REPO"
VERSION="${VERSION:-0.0.0-dev}"
echo "== 水转印加网 SDK · macOS 出包（C++）· 版本 $VERSION =="

for tool in cmake c++ zstd nm; do
  command -v "$tool" >/dev/null 2>&1 || { echo "缺 $tool：xcode-select --install ；brew install cmake zstd" >&2; exit 1; }
done
PY="${FRY_SDK_PYTHON:-python3}"
command -v "$PY" >/dev/null 2>&1 || { echo "缺 python3" >&2; exit 1; }

"$PY" tools/fry_build.py --version "$VERSION"

ARCH_TAG="darwin-arm64"; [ "$(uname -m)" = "arm64" ] || ARCH_TAG="darwin-x64"
ARTIFACT="out/fry-halftone-${VERSION}-${ARCH_TAG}.tar.zst"
[ -f "$ARTIFACT" ] || { echo "出包说成功了，但找不到产物 $ARTIFACT" >&2; exit 1; }
echo "产物：$ARTIFACT"
