# -*- coding: utf-8 -*-
r"""test_target_kit.py —— ★409 目标机验收包（tools/fry_target_kit.py）的闸，两个方向都验。

① 包里**不带算法源码**（cpp/ src/），但带全部判据（golden 数据、test_*.py、fry_build.py、头文件、锁文件）；
② 可执行位：run_on_target.sh 与预编二进制 0755（Windows 上打的 tar，权限必须显式写进去，否则目标机上跑不起来）；
③ ★ kit_info.verified_on_target **恒为 false**：包本身永远「未验证」，验没验过由目标机上的结果说了算；
④ 反向：预编件被动过（sha256 不符）/ 指纹 ≠ 锁文件 / 静态闸没过 ⇒ **拒绝打包**；auto 模式跳过红的、一个不剩也拒绝；
⑤ 验收脚本的契约：LF、set -euo pipefail、--prebuilt-dir、隔离属性、Rosetta、退出码 —— 并用 bash -n 做语法检查。
"""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
import sys
import tarfile
from pathlib import Path

import pytest

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO / "tools"))
import fry_target_kit as TK  # noqa: E402

FAKE_FILES = {"libfry_halftone.so": b"\x7fELF-lib", "FryVersionProbe": b"\x7fELF-probe",
              "FryHalftoneDemoC": b"\x7fELF-demo", "fry-halftone-cli": b"\x7fELF-cli"}


WRAPPER = "7" * 64


def _fake_cross(tmp_path, monkeypatch, tamper="", fingerprint="", ok=True, wrapper=WRAPPER, second_wrapper=None):
    """造一个最小的 out/cross：一个目标（linux-x64）、四个假二进制、sha256 对得上的 prebuilt_info.json。
    second_wrapper 给了就再造一个目标（linux-arm64），外壳指纹用它（★410 测「各目标外壳指纹不一致」）。"""
    lock_fp = json.loads((REPO / "cpp.lock.json").read_text(encoding="utf-8"))["tree_sha256_str"]
    cross = tmp_path / "cross"
    rows = []
    for target, wr in [("linux-x64", wrapper)] + ([("linux-arm64", second_wrapper)] if second_wrapper is not None else []):
        pre = cross / target / "prebuilt"
        pre.mkdir(parents=True)
        for name, data in FAKE_FILES.items():
            (pre / name).write_bytes(data)
        info = {"origin_str": "test", "zig_triple_str": "x86_64-linux-gnu.2.28",
                "algorithm_fingerprint_str": fingerprint or lock_fp, "version_str": "9.9.9-test",
                "files_dict": {n: hashlib.sha256(d).hexdigest() for n, d in FAKE_FILES.items()}}
        if wr:
            info["wrapper_sha256_str"] = wr
        (pre / "prebuilt_info.json").write_text(json.dumps(info), encoding="utf-8")
        rows.append({"target_str": target, "ok_bool": ok, "stage_str": "done", "min_os_str": "glibc 2.17",
                     "static_problems_list": [] if ok else ["fry-halftone-cli：rpath 里有构建机路径"]})
        if tamper:
            (pre / tamper).write_bytes(b"tampered after gating")
    (cross / "cross_info.json").write_text(json.dumps({"targets_list": rows}), encoding="utf-8")
    monkeypatch.setattr(TK, "CROSS", cross)
    monkeypatch.setattr(TK, "OUT", tmp_path / "kit")


def test_kit_content_two_sided(tmp_path, monkeypatch):
    _fake_cross(tmp_path, monkeypatch)
    path = TK.build_kit(TK.pick_targets("auto"))
    root = TK.KIT_DIR_NAME + "/"
    with tarfile.open(path) as tf:
        members = {m.name: m for m in tf.getmembers()}
        assert all(n.startswith(root) for n in members)
        rel = {n[len(root):] for n in members}
        # ① 不带源码、不带缓存
        leaked = sorted(r for r in rel if r.startswith(("cpp/", "src/")) or "__pycache__" in r or r.endswith(".pyc"))
        assert not leaked, leaked
        # ① 判据一样不少
        for need in ("tools/fry_build.py", "tools/fry_payload.py", "tools/fry_delivery_contract.py",
                     "tests/test_golden.py", "tests/test_c_abi.py", "tests/test_cli_contract.py", "tests/data/golden.json",
                     "include/fry_halftone.h", "cpp.lock.json", "packaging/verify_delivery.py", "docs/SDK_使用说明.md",
                     "run_on_target.sh", "kit_info.json", "README_验收.md", "prebuilt/linux-x64/fry-halftone-cli"):
            assert need in rel, need
        # ② 可执行位
        assert members[root + "run_on_target.sh"].mode == 0o755
        for name in FAKE_FILES:
            assert members[root + "prebuilt/linux-x64/" + name].mode == 0o755, name
        assert members[root + "prebuilt/linux-x64/prebuilt_info.json"].mode == 0o644
        # ③ 永远未验证
        kit_info = json.loads(tf.extractfile(members[root + "kit_info.json"]).read().decode("utf-8"))
        assert kit_info["verified_on_target_bool"] is False and kit_info["source_included_bool"] is False
        assert kit_info["version_str"] == "9.9.9-test" and set(kit_info["targets_dict"]) == {"linux-x64"}
        assert kit_info["wrapper_sha256_str"] == WRAPPER                       # ★410 外壳指纹随包走
        assert b"\r" not in tf.extractfile(members[root + "run_on_target.sh"]).read()


@pytest.mark.parametrize("kind", ["tampered", "fingerprint", "static_red", "no_wrapper", "wrapper_mismatch"])
def test_kit_refuses_what_was_not_gated(tmp_path, monkeypatch, kind):
    wanted = "linux-x64"
    if kind == "tampered":
        _fake_cross(tmp_path, monkeypatch, tamper="fry-halftone-cli")
    elif kind == "fingerprint":
        _fake_cross(tmp_path, monkeypatch, fingerprint="0" * 64)
    elif kind == "static_red":
        _fake_cross(tmp_path, monkeypatch, ok=False)
    elif kind == "no_wrapper":                                   # ★410 旧版交叉编译产物（没记外壳指纹）
        _fake_cross(tmp_path, monkeypatch, wrapper="")
    else:                                                        # ★410 两个目标是两份外壳源码编的
        _fake_cross(tmp_path, monkeypatch, second_wrapper="8" * 64)
        wanted = "linux-x64,linux-arm64"
        assert len(TK.pick_targets("linux-x64")) == 1            # 对照：单独挑一个是绿的（红的只因为「不一致」）
    with pytest.raises(SystemExit):
        TK.pick_targets(wanted)


def test_auto_skips_red_targets_and_refuses_when_none_left(tmp_path, monkeypatch):
    _fake_cross(tmp_path, monkeypatch, ok=False)
    with pytest.raises(SystemExit):
        TK.pick_targets("auto")


def test_runner_script_contract():
    s = TK.RUNNER_SH
    for needle in ("set -euo pipefail", "--prebuilt-dir", "com.apple.quarantine", "hw.optional.arm64",
                   "arch -x86_64", "arch -arm64", "exit 3", 'exit "$FAIL"', "target_env.txt", "build_report.json",
                   "xcode-select", "brew install zstd", "SHA256SUMS.txt", "shasum -a 256", "sha256sum"):
        assert needle in s, needle
    assert "\r" not in s


def _real_bash():
    """Windows 上 PATH 里的 bash 可能是 System32 的 WSL 启动器（没装发行版就报错）⇒ 优先 Git 自带的 bash。"""
    if os.name == "nt":
        found = shutil.which("bash")
        if found and "system32" not in found.lower():
            return found
        git = shutil.which("git")                   # git 可能在 Git/cmd、Git/mingw64/bin …：往上找 Git 根的 bin/bash.exe
        for parent in (Path(git).parents if git else []):
            for cand in (parent / "bin" / "bash.exe", parent / "usr" / "bin" / "bash.exe"):
                if cand.is_file():
                    return str(cand)
        return None
    return shutil.which("bash")


def test_runner_script_bash_syntax():
    bash = _real_bash()
    if not bash:
        pytest.skip("本机没有可用的 bash")
    r = subprocess.run([bash, "-n"], input=TK.RUNNER_SH.encode("utf-8"), capture_output=True)
    assert r.returncode == 0, r.stderr.decode("utf-8", "replace")
