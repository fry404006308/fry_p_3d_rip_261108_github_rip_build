# -*- coding: utf-8 -*-
r"""fry_integration_check.py —— ★411 交付说明里的集成命令**逐条原样真跑**（命令唯一真源 = tools/fry_integration_guide.py）。

【为什么】410 交付后查出：示例源码注释里的编译命令照抄会失败（Windows 导入库路径写错 ⇒ LNK1181；Linux / macOS 没写 `-o bin/…`
  ⇒ 一运行就找不到库）。说明里的命令不真跑，就是一句没验过的承诺 ⇒ 交付前把同一份字符串在两台真环境里执行一遍：
    Windows：把交付的 .zip 解到临时目录，在 `fry-halftone\` 里用 cmd 逐条执行（C 编译那条先 call vcvars64.bat）；
    Linux  ：把交付的 .tar.zst 在 WSL 里解开，在 `fry-halftone/` 里用 bash 逐条执行。
  每条记：返回码、耗时、输出末尾；出片类的步骤再数一遍输出目录里的 BMP；「版本」那条核对输出 = `fry-halftone-cli <版本>`。
  结果 JSON 记下两个包的 sha256 —— 全交付目录的闸核对「实测的就是交付的那两个包」。
【缺工具 ≠ 失败 ≠ 通过】本机没有 MSVC / .NET SDK / WSL 时，相关步骤记成「跳过 + 原因」（说明里显示「未实测」），
  **不算通过**；all_ok_bool = 跑了的步骤全过 且 两个平台的核心步骤（自检 / 版本 / 出片 / C 编译运行 / Python）都跑了。
【输出里的本机路径】临时目录一律替换成 `<解包目录>`（这份 JSON 会随交付给同事）。

用法：python tools/fry_integration_check.py --win-zip <.zip> --linux-archive <.tar.zst> --version X.Y.Z --out <结果.json>
      （模型默认 tests/data/ 里的示例件；fry_release.py --bundle 会自动跑它）
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import platform
import re
import shutil
import subprocess
import sys
import tempfile
import time
import zipfile
from pathlib import Path
from typing import Any, Dict, List, Optional

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO / "tools"))
import fry_integration_guide as G  # noqa: E402

OUT_DIR_OF = {"cli_slice": "out_cli", "c_run": "out_c", "py_run": "out_py", "cs_run": "out_cs"}
CORE_KEYS = ("verify", "cli_version", "cli_slice", "c_build", "c_run", "py_run")     # 两个平台都必须真跑过的
DEPENDS = {"c_run": "c_build", "cs_copy": "cs_new", "cs_build": "cs_copy", "cs_dll": "cs_build", "cs_run": "cs_dll"}


def sha256(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def text(b: bytes) -> str:
    for enc in ("utf-8", "gbk"):
        try:
            return b.decode(enc)
        except UnicodeDecodeError:
            continue
    return b.decode("utf-8", "replace")


def tail(s: str, n: int = 6) -> str:
    return "\n".join([ln for ln in s.strip().splitlines() if ln.strip()][-n:])


def find_vcvars() -> str:
    """vswhere 找装了 x64 C++ 工具的那一套 VS（Build Tools 也算）→ vcvars64.bat；找不到 = 空串（C 编译那条跳过）。"""
    base = os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")
    vw = Path(base) / "Microsoft Visual Studio" / "Installer" / "vswhere.exe"
    if not vw.is_file():
        return ""
    r = subprocess.run([str(vw), "-latest", "-products", "*", "-requires", "Microsoft.VisualStudio.Component.VC.Tools.x86.x64",
                        "-property", "installationPath"], capture_output=True)
    root = text(r.stdout).strip().splitlines()
    bat = Path(root[0]) / "VC" / "Auxiliary" / "Build" / "vcvars64.bat" if root else Path("-")
    return str(bat) if bat.is_file() else ""


def scrub(s: str, work: Path) -> str:
    """输出里的临时解包目录换成 <解包目录>（这份结果随交付给同事）：原样 / JSON 转义（双反斜杠）/ 正斜杠三种写法都换。"""
    forms = {str(work), str(work).replace("\\", "\\\\"), str(work).replace("\\", "/")}
    for form in sorted(forms, key=len, reverse=True):
        s = s.replace(form, "<解包目录>")
    return s


def _row_done(row: Dict[str, Any], key: str, version: str, stdout: str) -> None:
    row["ok"] = row["rc_int"] == 0 and row.get("bmp_count_int", 1) > 0
    if key == "cli_version":
        row["ok"] = row["ok"] and stdout.strip() == "fry-halftone-cli %s" % version


def run_windows(zip_path: Path, model: Path, version: str) -> Dict[str, Any]:
    work = Path(tempfile.mkdtemp(prefix="fry_integ_win_"))
    try:
        with zipfile.ZipFile(zip_path) as zf:
            zf.extractall(work)
        root = work / "fry-halftone"
        shutil.copy2(model, work / model.name)
        # 自检 / Python 示例要一个真 Python：用跑本脚本的这一个（本机裸 python 可能是 Windows 商店占位版）
        env = dict(os.environ, PATH=str(Path(sys.executable).parent) + os.pathsep + os.environ.get("PATH", ""))
        vcvars = find_vcvars()
        dn = subprocess.run("dotnet --version", shell=True, capture_output=True)
        has_dotnet = dn.returncode == 0 and bool(text(dn.stdout).strip())
        cl_line = "MSVC ?"
        if vcvars:      # vcvars 自己会往 stderr 打噪声（如 vswhere 找不到）⇒ 丢掉它的输出，只在 cl 的横幅里认版本号
            cb = subprocess.run('cmd.exe /d /s /c "call "%s" >nul 2>nul && cl"' % vcvars, capture_output=True)
            m = re.search(r"C/C\+\+\D*?(\d+\.\d+\.\d+)", text(cb.stderr))
            cl_line = "MSVC cl %s（x64）" % m.group(1) if m else "MSVC（版本没读出来）"
        res: Dict[str, Any] = {"where_str": "%s ｜ %s ｜ Python %s ｜ .NET SDK %s" % (
            platform.platform(), cl_line if vcvars else "没有 MSVC", platform.python_version(),
            text(dn.stdout).strip() if has_dotnet else "没有"), "steps_dict": {}}
        for s in G.STEPS["win32-x64"]["steps"]:
            key, need = s["key"], s.get("needs", "")
            why = ("本机没有 MSVC（vswhere 找不到 x64 C++ 工具）" if need == "msvc" and not vcvars else
                   "本机没有 .NET SDK" if need == "dotnet" and not has_dotnet else
                   "上一步 %s 没过" % DEPENDS[key] if key in DEPENDS and not (res["steps_dict"].get(DEPENDS[key]) or {}).get("ok") else "")
            shown = G.fill(s["cmd"], model="<模型>", version=version)
            if why:
                res["steps_dict"][key] = {"cmd_str": shown, "skipped_bool": True, "why_str": why, "ok": None}
                print("  [win]   %-12s 跳过：%s" % (key, why))
                continue
            cmd = G.fill(s["cmd"], model=str(work / model.name), version=version)
            full = ('call "%s" >nul && ' % vcvars + cmd) if need == "msvc" else cmd
            t0 = time.perf_counter()
            r = subprocess.run('cmd.exe /d /s /c "%s"' % full, cwd=str(root), capture_output=True, env=env)
            clean = lambda s_: scrub(tail(text(s_)), work)      # noqa: E731
            row = {"cmd_str": shown, "rc_int": r.returncode, "sec_float": round(time.perf_counter() - t0, 2),
                   "stdout_tail_str": clean(r.stdout), "stderr_tail_str": clean(r.stderr)}
            if key in OUT_DIR_OF:
                row["bmp_count_int"] = len(list((root / OUT_DIR_OF[key]).glob("*.bmp")))
            _row_done(row, key, version, text(r.stdout))
            res["steps_dict"][key] = row
            print("  [win]   %-12s rc=%-3d %6.2fs %s %s" % (key, r.returncode, row["sec_float"], "✓" if row["ok"] else "✗",
                                                        ("BMP %d 张" % row["bmp_count_int"]) if "bmp_count_int" in row else ""))
        return res
    finally:
        shutil.rmtree(work, ignore_errors=True)


def run_linux(tar_path: Path, model: Path, version: str, scratch: Path) -> Dict[str, Any]:
    import fry_build_linux_native as LN
    distro = LN.wsl_distro() if os.name == "nt" else ""
    steps = G.STEPS["linux-x64"]["steps"]
    if os.name == "nt" and not distro:
        return {"where_str": "没有 WSL 发行版", "steps_dict": {s["key"]: {"cmd_str": G.fill(s["cmd"], model="<模型>", version=version),
                "skipped_bool": True, "why_str": "本机没有 WSL 发行版", "ok": None} for s in steps}}
    to_path = LN.to_wsl_path if os.name == "nt" else (lambda p: str(p.resolve()))
    work = "$HOME/fry_integ411"
    lines = ["#!/usr/bin/env bash", "set -u", 'W="%s"' % work, 'rm -rf "$W" && mkdir -p "$W" && cd "$W"',
             'tar --zstd -xf "%s"' % to_path(tar_path), 'cp "%s" "$W/"' % to_path(model), 'cd "$W/fry-halftone"',
             'echo "@@WHERE $(. /etc/os-release; echo $PRETTY_NAME) ｜ $(ldd --version 2>&1 | head -1) ｜ '
             '$(cc --version 2>/dev/null | head -1) ｜ Python $(python3 -c \'import platform;print(platform.python_version())\')"']
    for s in steps:
        cmd = G.fill(s["cmd"], model="$W/" + model.name, version=version)
        out = OUT_DIR_OF.get(s["key"], "")
        lines += ['T0=$(date +%s.%N)', '{ %s ; } > "$W/%s.log" 2>&1; RC=$?' % (cmd, s["key"]), 'T1=$(date +%s.%N)',
                  'echo "@@STEP %s rc=$RC t0=$T0 t1=$T1 bmp=%s"' % (
                      s["key"], ('$(ls %s/*.bmp 2>/dev/null | wc -l)' % out) if out else "-"),
                  'tail -n 6 "$W/%s.log" | sed "s|$W|<解包目录>|g; s/^/@@OUT %s /"' % (s["key"], s["key"])]
    lines += ['cd / && rm -rf "$W"']
    sh = scratch / "fry_integration_linux.sh"
    sh.write_bytes(("\n".join(lines) + "\n").encode("utf-8"))
    argv = (["wsl", "-d", distro, "-u", "root", "--", "bash", to_path(sh)] if os.name == "nt" else ["bash", str(sh)])
    r = subprocess.run(argv, capture_output=True, env=LN.wsl_env() if os.name == "nt" else None)
    res: Dict[str, Any] = {"where_str": "", "steps_dict": {}}
    for ln in text(r.stdout).splitlines():
        if ln.startswith("@@WHERE "):
            res["where_str"] = ln[8:].strip()
        elif ln.startswith("@@STEP "):
            parts = dict(p.split("=", 1) for p in ln.split()[2:])
            key = ln.split()[1]
            row = {"cmd_str": G.fill(next(s["cmd"] for s in steps if s["key"] == key), model="<模型>", version=version),
                   "rc_int": int(parts["rc"]), "sec_float": round(float(parts["t1"]) - float(parts["t0"]), 2), "out_tail_str": ""}
            if parts["bmp"] != "-":
                row["bmp_count_int"] = int(parts["bmp"])
            res["steps_dict"][key] = row
        elif ln.startswith("@@OUT "):
            _, key, rest = (ln.split(" ", 2) + [""])[:3]
            if key in res["steps_dict"]:
                res["steps_dict"][key]["out_tail_str"] += rest + "\n"
    for key, row in res["steps_dict"].items():
        _row_done(row, key, version, row["out_tail_str"])
        print("  [linux] %-12s rc=%-3d %6.2fs %s %s" % (key, row["rc_int"], row["sec_float"], "✓" if row["ok"] else "✗",
                                                      ("BMP %d 张" % row["bmp_count_int"]) if "bmp_count_int" in row else ""))
    return res


def verdict(res: Dict[str, Any]) -> bool:
    """跑了的全过 + 两个平台的核心步骤都真跑了（跳过不算过）。"""
    for side, plat in (("windows", "win32-x64"), ("linux", "linux-x64")):
        steps = res.get(side, {}).get("steps_dict", {})
        if set(steps) != {s["key"] for s in G.STEPS[plat]["steps"]}:
            return False
        if any(r.get("ok") is False for r in steps.values()):
            return False
        if any(steps[k].get("ok") is not True for k in CORE_KEYS):
            return False
    return True


def run(win_zip: Path, lin_tar: Path, model: Path, version: str, out_json: Path) -> Dict[str, Any]:
    res: Dict[str, Any] = {"schema_str": "fry-halftone-integration-check/2", "version_str": version, "model_str": model.name,
                           "package_sha256_dict": {"win32-x64": sha256(win_zip), "linux-x64": sha256(lin_tar)},
                           "checked_at_str": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
                           "commands_source_str": "tools/fry_integration_guide.py（交付说明里的命令就是从这里生成的）"}
    print("★411 集成命令实测 · Windows：%s" % win_zip.name)
    res["windows"] = run_windows(win_zip, model, version)
    print("★411 集成命令实测 · Linux（WSL）：%s" % lin_tar.name)
    out_json.parent.mkdir(parents=True, exist_ok=True)
    res["linux"] = run_linux(lin_tar, model, version, out_json.parent)
    res["all_ok_bool"] = verdict(res)
    res["skipped_list"] = ["%s/%s：%s" % (side, k, r["why_str"]) for side in ("windows", "linux")
                           for k, r in res[side]["steps_dict"].items() if r.get("skipped_bool")]
    out_json.write_text(json.dumps(res, ensure_ascii=False, indent=1), encoding="utf-8")
    print("%s 集成命令实测：%s（跳过 %d 条）→ %s" % ("✓" if res["all_ok_bool"] else "✗", "全过" if res["all_ok_bool"] else "没全过",
                                               len(res["skipped_list"]), out_json))
    return res


def main(argv: Optional[List[str]] = None) -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    ap = argparse.ArgumentParser(description="★411 交付说明里的集成命令逐条真跑（Windows cmd + WSL bash）")
    ap.add_argument("--win-zip", required=True)
    ap.add_argument("--linux-archive", required=True)
    ap.add_argument("--version", required=True)
    ap.add_argument("--model", default=str(REPO / "tests" / "data" / G.SAMPLE_MODEL))
    ap.add_argument("--out", required=True)
    ns = ap.parse_args(argv)
    res = run(Path(ns.win_zip), Path(ns.linux_archive), Path(ns.model), ns.version, Path(ns.out))
    return 0 if res["all_ok_bool"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
