# -*- coding: utf-8 -*-
r"""fry_oneclick_release.py —— ★449 双击即出包：三平台全交付目录 + 新增一份 dll 进算法仓（原先的 dll 不动）。

【为什么要这一层】fry_release.py 的参数很多（--bundle / --bundle-topic / --deliver-variant / --linux …），
  而 .bat 里**只许 ASCII**（cmd 按 OEM 代码页解析 .bat，中文字节会把整行切坏 —— 算法仓 CLAUDE.md D.1-4），
  交付目录的中文主题词放不进 .bat ⇒ 默认值住在这里（UTF-8），.bat 只负责找到 python 并调它。
【它做什么】① 找算法仓（--algo-repo > 环境变量 FRY_ALGO_REPO > 打包仓同级的 fry_py_260604_c180_depth_dither_more）；
  ② 调 tools/fry_release.py --bundle --linux prebuilt --bundle-topic <主题> --deliver-variant <关键词>；
  ③ 全部输出同时写进 out/oneclick/_<YYMMDD_HHMM>_oneclick.log，结论写进同名 _result.json（不在电脑前也能事后查）。
【用法】双击 tools\fry_oneclick_release.bat；或
  python tools/fry_oneclick_release.py [--topic "...{version}..."] [--variant wt_unified] [--algo-repo <算法仓>] [其余参数原样传给 fry_release]
"""
from __future__ import annotations

import argparse
import os
import subprocess
import sys
import time
from pathlib import Path

REPO = Path(__file__).resolve().parents[1]
ALGO_DIRNAME_STR = "fry_py_260604_c180_depth_dither_more"
DEFAULT_TOPIC_STR = "水转印统一引擎HE500-510-520_v{version}_三平台交付"
DEFAULT_VARIANT_STR = "wt_unified"


def locate_algo(given: str) -> Path:
    for cand in (given, os.environ.get("FRY_ALGO_REPO", ""), str(REPO.parent / ALGO_DIRNAME_STR)):
        if cand and (Path(cand) / "fry_project_components_cpp" / "CMakeLists.txt").is_file():
            return Path(cand).resolve()
    raise SystemExit("✗ 找不到算法仓：用 --algo-repo 指定，或设环境变量 FRY_ALGO_REPO（查过：参数 / 环境变量 / %s）"
                     % (REPO.parent / ALGO_DIRNAME_STR))


def main(argv=None) -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    ap = argparse.ArgumentParser(description="双击即出包：三平台全交付目录 + 新增一份 dll 进算法仓")
    ap.add_argument("--algo-repo", default="")
    ap.add_argument("--topic", default=DEFAULT_TOPIC_STR, help="全交付目录的主题词（{version} = 这次的版本号）")
    ap.add_argument("--variant", default=DEFAULT_VARIANT_STR, help="交付进算法仓的变体关键词（ASCII）；空串 = 不交付")
    ap.add_argument("--linux", default="prebuilt")
    ns, rest = ap.parse_known_args(argv)
    algo = locate_algo(ns.algo_repo)
    stamp = time.strftime("%y%m%d_%H%M")
    log_dir = REPO / "out" / "oneclick"
    log_dir.mkdir(parents=True, exist_ok=True)
    log_path = log_dir / ("_%s_oneclick.log" % stamp)
    res_path = log_dir / ("_%s_oneclick_result.json" % stamp)
    cmd = [sys.executable, "-X", "utf8", str(REPO / "tools" / "fry_release.py"), "--algo-repo", str(algo),
           "--python", sys.executable, "--bundle", "--linux", ns.linux, "--bundle-topic", ns.topic,
           "--result-json", str(res_path)] + (["--deliver-variant", ns.variant] if ns.variant else []) + rest
    print("★ 一键出包：%s\n  日志 %s\n  结论 %s" % (" ".join(cmd), log_path, res_path), flush=True)
    t0 = time.perf_counter()
    with open(log_path, "w", encoding="utf-8", newline="\n") as log:
        log.write("$ %s\n" % " ".join(cmd))
        proc = subprocess.Popen(cmd, cwd=str(REPO), stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                env=dict(os.environ, PYTHONIOENCODING="utf-8", PYTHONUTF8="1"))
        for raw in proc.stdout:                              # 逐行同时写屏幕和日志
            line = raw.decode("utf-8", "replace")
            sys.stdout.write(line)
            sys.stdout.flush()
            log.write(line)
            log.flush()
        rc = proc.wait()
        log.write("\n[oneclick] rc=%d elapsed=%.1fs\n" % (rc, time.perf_counter() - t0))
    print("\n%s 一键出包结束（返回码 %d，%.1f 分钟）—— 日志 %s" % ("✓" if rc == 0 else "✗", rc, (time.perf_counter() - t0) / 60, log_path))
    return rc


if __name__ == "__main__":
    raise SystemExit(main())
