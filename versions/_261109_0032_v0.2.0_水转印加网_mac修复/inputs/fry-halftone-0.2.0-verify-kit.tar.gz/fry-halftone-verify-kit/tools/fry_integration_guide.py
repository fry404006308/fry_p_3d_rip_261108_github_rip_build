# -*- coding: utf-8 -*-
r"""fry_integration_guide.py —— ★411 三个平台的「集成命令」唯一真源：交付说明从这里生成，实测脚本从这里取命令逐条执行。

【为什么单独一个文件】410 交付后查出：示例源码注释里写的编译命令照抄会失败
  （Windows 写 `bin\fry_halftone.lib`，而导入库在 `lib\`；Linux / macOS 没写输出位置，exe 落在包根，
   rpath=$ORIGIN / install_name=@loader_path 都要求它与库在同一个目录 ⇒ 一运行就「找不到库」）。
  说明里的命令如果不真跑，就是一句没验过的承诺 ⇒ 命令只写一份（本文件），
  算法仓 docs 411 的 c411_integration_check.py 在 Windows（MSVC / Python / dotnet）与 WSL（cc / python3）上**逐条执行同一份字符串**，
  全过才写进交付目录（交付目录里附实测结果）。

【约定】每条命令都在**解包后的 `fry-halftone/` 目录里**执行；`{model}` = 一个 .glb 路径；`{version}` = 交付版本号。
  needs：msvc = 要先进「x64 Native Tools Command Prompt for VS」（或 call vcvars64.bat）；dotnet = 要装 .NET SDK。
  tested_on：本文件里每一步标明在哪个平台真跑过；macOS 那一列要等 Mac 验收（验收包会在 Mac 上跑预编的纯 C 示例与命令行）。
"""
from __future__ import annotations

from typing import Any, Dict, List

SAMPLE_MODEL = "gltf_modes_mix.glb"           # 示例输入（tests/data 里的标准件；最长边 12 mm = golden 的 gltf_modes_mix_l12）
SAMPLE_EDGE_MM = 12

STEPS: Dict[str, Dict[str, Any]] = {
    "win32-x64": {
        "title": "Windows x64", "shell": "cmd（Windows 命令提示符；PowerShell 里把 copy 换成 Copy-Item）", "lib": r"bin\fry_halftone.dll",
        "steps": [
            {"key": "verify", "title": "自检：包完整吗 / dll 能加载吗 / 版本号处处一致吗", "cmd": "python verify_delivery.py",
             "expect": "最后打印「✓ 自检通过：包完整、dll 能加载、版本号处处一致」，退出码 0"},
            {"key": "cli_version", "title": "命令行：版本", "cmd": r"bin\fry-halftone-cli.exe --version",
             "expect": "fry-halftone-cli {version}"},
            {"key": "cli_slice", "title": "命令行：出片（最长边 12 mm）",
             "cmd": r"bin\fry-halftone-cli.exe slice {model} --target-longest-edge 12 --out out_cli",
             "expect": "stderr 最后一行 [fry-halftone-cli] done. slices=N，out_cli\\ 里 N 张 BMP + slice_metadata.json"},
            {"key": "c_build", "title": "C：编译示例（在「x64 Native Tools Command Prompt for VS」里执行）", "needs": "msvc",
             "cmd": r"cl /nologo /utf-8 /I include examples\c\fry_halftone_demo.c lib\fry_halftone.lib /Fo:bin\ /Fe:bin\fry_halftone_demo.exe",
             "expect": "生成 bin\\fry_halftone_demo.exe（与 fry_halftone.dll 同目录，运行时就近加载）"},
            {"key": "c_run", "title": "C：运行（第 3 个参数 = 成品 z 高度 mm）", "cmd": r"bin\fry_halftone_demo.exe {model} out_c 1.6",
             "expect": "打印进度与「成功」，out_c\\ 里有 BMP"},
            {"key": "py_run", "title": "Python：ctypes 示例（不装第三方包；自动在 ..\\..\\bin 找 dll）",
             "cmd": r"python examples\python\fry_halftone_demo.py {model} out_py", "expect": "✓ 成功：N 张切片"},
            {"key": "cs_new", "title": "C#：新建控制台工程", "needs": "dotnet", "cmd": "dotnet new console -o FryDemo --force",
             "expect": "生成 FryDemo\\FryDemo.csproj"},
            {"key": "cs_copy", "title": "C#：用示例替换 Program.cs", "needs": "dotnet",
             "cmd": r"copy /Y examples\csharp\FryHalftoneDemo.cs FryDemo\Program.cs", "expect": "已复制 1 个文件"},
            {"key": "cs_build", "title": "C#：编译", "needs": "dotnet", "cmd": r"dotnet build FryDemo -c Release -o FryDemo\out",
             "expect": "Build succeeded（0 个错误）"},
            {"key": "cs_dll", "title": "C#：把 dll 放到 exe 旁边（DllImport(\"fry_halftone\") 就近加载）", "needs": "dotnet",
             "cmd": r"copy /Y bin\fry_halftone.dll FryDemo\out", "expect": "已复制 1 个文件"},
            {"key": "cs_run", "title": "C#：运行", "needs": "dotnet", "cmd": r"FryDemo\out\FryDemo.exe {model} out_cs",
             "expect": "✓ 成功：{…结果 JSON…}"},
        ]},
    "linux-x64": {
        "title": "Linux x86-64", "shell": "bash", "lib": "bin/libfry_halftone.so",
        "steps": [
            {"key": "verify", "title": "自检", "cmd": "python3 verify_delivery.py", "expect": "最后打印「✓ 自检通过：包完整、dll 能加载、版本号处处一致」，退出码 0"},
            {"key": "cli_version", "title": "命令行：版本", "cmd": "bin/fry-halftone-cli --version", "expect": "fry-halftone-cli {version}"},
            {"key": "cli_slice", "title": "命令行：出片（最长边 12 mm）",
             "cmd": "bin/fry-halftone-cli slice {model} --target-longest-edge 12 --out out_cli",
             "expect": "stderr 最后一行 [fry-halftone-cli] done. slices=N"},
            {"key": "c_build", "title": "C：编译示例（输出放进 bin/：RUNPATH=$ORIGIN 只认同目录的 .so）", "needs": "cc",
             "cmd": "cc examples/c/fry_halftone_demo.c -Iinclude -Lbin -lfry_halftone -Wl,-rpath,'$ORIGIN' -o bin/fry_halftone_demo",
             "expect": "生成 bin/fry_halftone_demo"},
            {"key": "c_run", "title": "C：运行（第 3 个参数 = 成品 z 高度 mm）", "cmd": "bin/fry_halftone_demo {model} out_c 1.6",
             "expect": "打印进度与「成功」，out_c/ 里有 BMP"},
            {"key": "py_run", "title": "Python：ctypes 示例", "cmd": "python3 examples/python/fry_halftone_demo.py {model} out_py",
             "expect": "✓ 成功：N 张切片"},
        ]},
    "darwin": {
        "title": "macOS（arm64 / x64，Mac 验收通过之后）", "shell": "zsh / bash", "lib": "bin/libfry_halftone.dylib",
        "steps": [
            {"key": "quarantine", "title": "解除下载隔离（从浏览器 / 聊天工具下载的才需要）", "cmd": "xattr -dr com.apple.quarantine .",
             "expect": "无输出"},
            {"key": "verify", "title": "自检", "cmd": "python3 verify_delivery.py", "expect": "最后打印「✓ 自检通过：包完整、dll 能加载、版本号处处一致」，退出码 0"},
            {"key": "cli_version", "title": "命令行：版本", "cmd": "bin/fry-halftone-cli --version", "expect": "fry-halftone-cli {version}"},
            {"key": "cli_slice", "title": "命令行：出片（最长边 12 mm）",
             "cmd": "bin/fry-halftone-cli slice {model} --target-longest-edge 12 --out out_cli",
             "expect": "stderr 最后一行 [fry-halftone-cli] done. slices=N"},
            {"key": "c_build", "title": "C：编译示例（输出放进 bin/：库的 install_name 是 @loader_path/，只认同目录）", "needs": "cc",
             "cmd": "cc examples/c/fry_halftone_demo.c -Iinclude -Lbin -lfry_halftone -o bin/fry_halftone_demo",
             "expect": "生成 bin/fry_halftone_demo"},
            {"key": "c_run", "title": "C：运行", "cmd": "bin/fry_halftone_demo {model} out_c 1.6", "expect": "打印进度与「成功」"},
            {"key": "py_run", "title": "Python：ctypes 示例", "cmd": "python3 examples/python/fry_halftone_demo.py {model} out_py",
             "expect": "✓ 成功：N 张切片"},
        ]},
}

NOTES: Dict[str, List[str]] = {
    "win32-x64": [
        "运行只需要 `bin\\fry_halftone.dll` 一个文件；**不用装 VC++ 运行库**（C++ 运行库已静态链入，UCRT 用系统自带的，Windows 10 起内置）。",
        "C/C++ 隐式链接用 `lib\\fry_halftone.lib`（导入库）；用 `LoadLibraryW` 动态加载则不需要它。",
        "调用约定是 `__stdcall`（头文件里的 `FRY_CALL`）：C# 写 `CallingConvention.StdCall`，Python 用 `ctypes.WinDLL`。",
        "中文路径：C/C++ 用宽字符版 `FryHalftone_SliceModel(const wchar_t*…)`（`wmain` 取参数），或 UTF-8 版 `…Utf8`；**不要**用本地代码页的 `char*`。",
        "dll 版本号还能右键看：属性 → 详细信息（文件版本 / 产品版本 = 交付版本号）。",
    ],
    "linux-x64": [
        "运行只需要 `bin/libfry_halftone.so`；libstdc++ / libgcc 已静态链入，实测只要求 **glibc ≥ 2.17**（CentOS 7 起）。",
        "你自己的程序链接它：`-L<包>/bin -lfry_halftone`，运行时让加载器找得到它 —— 三选一：程序与 .so 同目录 + `-Wl,-rpath,'$ORIGIN'`；"
        "或 `-Wl,-rpath,<.so 所在目录>`；或 `LD_LIBRARY_PATH=<.so 所在目录>`。",
        "Python 用 `ctypes.CDLL`（不是 WinDLL）；C# 在 Linux 上 `DllImport(\"fry_halftone\")` 会自动找 `libfry_halftone.so`（本机未实测 .NET on Linux）。",
        "逐字节一致在 glibc 2.41（WSL2 Debian 13）上实测；你们服务器的 glibc 不同时，建议用验收包在服务器上跑一次（见 macOS 目录里的验收包，它也带 Linux 目标）。",
    ],
    "darwin": [
        "**先在 Mac 上跑验收包**（`03_macOS_需在Mac上验收/macOS验收步骤.md`），通过后 `results/<目标>/` 里的 `.tar.zst` 才是 macOS 包；下面的命令在它解开的 `fry-halftone/` 里执行。",
        "库的 install_name 是 `@loader_path/libfry_halftone.dylib` ⇒ **你的可执行文件（或加载它的那个库）要与 dylib 在同一个目录**；放别处就用 `install_name_tool -change` 改。",
        "arm64 版是 ad-hoc 签名、未公证：只给同事内部用没问题；要发给外部客户需要公司的 Developer ID 签名 + 公证。",
        "Python 用 `ctypes.CDLL`；C# 在 macOS 上 `DllImport(\"fry_halftone\")` 会找 `libfry_halftone.dylib`（未实测）。",
        "本页命令还没在 Mac 上逐条跑过（Windows 上没有合法的 macOS 环境）；Mac 验收时 `run_on_target.sh` 会真跑预编的纯 C 示例、命令行契约（tests/test_cli_contract.py 全部用例）与交付清单。",
    ],
}


def fill(text: str, **kw: str) -> str:
    """只替换已知占位符 {model} / {version}（不用 str.format：「成功的样子」里有字面的花括号，format 会抛 KeyError）。"""
    for k, v in kw.items():
        text = text.replace("{%s}" % k, v)
    return text


def render_guide(platform: str, version: str, model_hint: str, tested: Dict[str, Any]) -> str:
    """一个平台的集成说明（markdown）。model_hint = 示例模型的写法（markdown，调用方自己加反引号）；
    tested = 实测结果（{key: {"ok": True/False/None, "note": str}, "_where": 实测机}；None = 跳过（note 写原因）；
    整个 tested 为空 = 这个平台没有实测）。"""
    spec = STEPS[platform]
    lines = ["# %s 集成说明（版本 %s）" % (spec["title"], version), "",
             "> 全部命令都在**解包后的 `fry-halftone/` 目录里**执行（shell：%s）。`<模型.glb>` 换成你的模型；"
             "想先用我们给的示例模型，就用 %s。" % (spec["shell"], model_hint), ""]
    if tested:
        rows = [tested.get(s["key"]) or {} for s in spec["steps"]]
        n_ok = sum(1 for r in rows if r.get("ok") is True)
        n_skip = sum(1 for r in rows if "ok" in r and r.get("ok") is None)
        lines += ["> ★ 下面的命令在真环境里**原样真跑过**（%s）：通过 %d 条 / 共 %d 条%s；逐条结果见 `06_验收证据/集成命令实测.json`。"
                  % (tested.get("_where", ""), n_ok, len(spec["steps"]),
                     "，另有 %d 条本机缺工具没跑（标「未实测」+ 原因）" % n_skip if n_skip else ""), ""]
    else:
        lines += ["> ⚠ 本页命令还没有逐条实测（见最后一节的说明）。", ""]
    lines += ["## 一、逐步执行", "", "| # | 做什么 | 命令 | 成功的样子 | 实测 |", "|---|---|---|---|---|"]
    for i, s in enumerate(spec["steps"], 1):
        t = tested.get(s["key"]) if tested else None
        mark = ("—" if t is None else "✅" if t.get("ok") is True else
                "— 未实测：" + t.get("note", "") if t.get("ok") is None else "❌ " + t.get("note", ""))
        cmd = fill(s["cmd"], model="<模型.glb>", version=version).replace("|", "\\|")
        lines.append("| %d | %s | `%s` | %s | %s |" % (i, s["title"], cmd, fill(s["expect"], version=version), mark))
    lines += ["", "## 二、要点", ""] + ["- " + n for n in NOTES[platform]] + [""]
    return "\n".join(lines)
