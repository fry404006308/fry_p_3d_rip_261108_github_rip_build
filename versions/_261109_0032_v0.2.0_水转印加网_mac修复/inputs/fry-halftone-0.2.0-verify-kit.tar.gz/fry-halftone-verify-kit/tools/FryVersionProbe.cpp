/*
 * FryVersionProbe.cpp —— CI 冒烟探针：**按消费方的姿势**把库加载一遍。
 *
 * 为什么要有它（这一条抄自 lmst，理由完全成立）：
 *   版本号的注入链路是「CI 变量 → -DFRY_SDK_VERSION → 编译期宏 → 运行期 GetVersion()」。
 *   这条链断在任何一环都不会让编译失败 —— 只会让消费方拿到一个写着 0.0.0-dev 的包。
 *   所以每次构建都要真的 dlopen 一次、真的调一次 GetVersion()，和流水线版本号比对。
 *   ★ 它同时顺带验证了两件很容易悄悄坏掉的事：
 *     ① 导出表里真的有这几个 C 符号（visibility / __declspec 被回退时当场现形）；
 *     ② 库能被**独立加载**（不靠构建目录里的任何东西）。
 *
 * 用法：FryVersionProbe <动态库路径> [期望版本号]
 *   不给期望版本号只打印；给了就比对，不符返回 1。
 */
#include <cstdio>
#include <cstring>
#include <string>

#ifdef _WIN32
#  define WIN32_LEAN_AND_MEAN
#  include <windows.h>
using Handle = HMODULE;
static Handle open_lib(const char* p) { return ::LoadLibraryA(p); }
static void* find_sym(Handle h, const char* n) { return reinterpret_cast<void*>(::GetProcAddress(h, n)); }
static std::string last_error() { return "GetLastError=" + std::to_string(::GetLastError()); }
#  define FRY_CALLCONV __stdcall
#else
#  include <dlfcn.h>
using Handle = void*;
static Handle open_lib(const char* p) { return ::dlopen(p, RTLD_NOW | RTLD_LOCAL); }
static void* find_sym(Handle h, const char* n) { return ::dlsym(h, n); }
static std::string last_error() { const char* e = ::dlerror(); return e ? e : "(no dlerror)"; }
#  define FRY_CALLCONV
#endif

typedef const char*(FRY_CALLCONV* GetStrFn)(void);

static const char* call_str(Handle lib, const char* name, int& bad) {
    void* fn = find_sym(lib, name);
    if (!fn) { std::fprintf(stderr, "✗ 导出表里没有 %s（%s）\n", name, last_error().c_str()); bad = 1; return ""; }
    return reinterpret_cast<GetStrFn>(fn)();
}

int main(int argc, char** argv) {
    if (argc < 2) { std::fprintf(stderr, "用法：FryVersionProbe <动态库> [期望版本号]\n"); return 2; }
    Handle lib = open_lib(argv[1]);
    if (!lib) { std::fprintf(stderr, "✗ 加载不了 %s：%s\n", argv[1], last_error().c_str()); return 1; }
    int bad = 0;
    const char* version = call_str(lib, "FryHalftone_GetVersion", bad);
    const char* fingerprint = call_str(lib, "FryHalftone_GetAlgorithmFingerprint", bad);
    const char* algorithm = call_str(lib, "FryHalftone_GetAlgorithmName", bad);
    const char* worker = call_str(lib, "FryHalftone_GetWorkerPathUtf8", bad);
    std::printf("%s\t%s\t%s\t%s\n", version, algorithm, fingerprint, worker);
    if (bad) return 1;
    if (std::strcmp(algorithm, "water_transfer_depth") != 0) {
        std::fprintf(stderr, "✗ 算法名不是 water_transfer_depth，收到 %s\n", algorithm);
        return 1;
    }
    if (argc >= 3 && std::strcmp(version, argv[2]) != 0) {
        std::fprintf(stderr, "✗ 产物自报版本 '%s' 与流水线版本 '%s' 不符\n", version, argv[2]);
        return 1;
    }
    if (argc >= 3 && (fingerprint == nullptr || fingerprint[0] == '\0')) {
        std::fprintf(stderr, "✗ 算法指纹是空的 —— 打包脚本没把 payload.lock.json 的 tree_sha256 注进来\n");
        return 1;
    }
    std::fprintf(stderr, "✓ 冒烟通过：%s 自报版本 %s，算法 %s，指纹 %.16s…\n", argv[1], version, algorithm, fingerprint);
    return 0;
}
