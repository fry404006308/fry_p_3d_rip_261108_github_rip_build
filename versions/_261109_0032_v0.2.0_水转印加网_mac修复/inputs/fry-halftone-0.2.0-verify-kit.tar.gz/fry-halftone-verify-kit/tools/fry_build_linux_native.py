# -*- coding: utf-8 -*-
r"""fry_build_linux_native.py —— ★394/★409 在**本机**出一个真正跑过验收的 Linux 包（WSL2 或 Docker 里真跑）。

【和 `fry_cross_build.py` 的区别（这是本篇最重要的一句）】
  · `fry_cross_build.py`：**交叉编译** —— 在 Windows 上编出 ELF，**本机跑不了** ⇒ 它自己只能说「编出来了」。
  · 本脚本：在**真 Linux 用户态**（WSL2 / 容器）里跑**与 CI 同一套**装配 + 冒烟 + 打包
    （导出面闸 → 版本探针 → C 接口用例 → **golden 逐字节** → 纯 C 示例 → ★409 命令行契约 → 交付清单闸）⇒ 产物可交付。

【两种模式（★409）】
  --mode native   （默认）Linux 里用 gcc 原生编：`packaging/linux/build_linux_sdk.sh`（= CI 的 build:linux 那一个脚本）。
                  ⚠ 产物要求的 glibc = 这个发行版的 glibc 附近（409 实测 WSL Debian 13 编出来的库要 GLIBC_2.38）。
  --mode prebuilt 不在 Linux 里编：拿 `fry_cross_build.py --target linux-x64` 编好的四个二进制（zig，glibc 基线默认 2.28），
                  在真 Linux 里跑 `fry_build.py --prebuilt-dir`（同一套冒烟 + 打包）。
                  ⇒ **「兼容老系统」与「真跑过验收」同时成立**（glibc 2.28 起都能加载，且在本机 Linux 上逐字节验过）。

【★409 修掉的四个问题（WSL 第一次真跑才暴露）】
  ① 原来直接在 /mnt/c 上**原地**构建：与 Windows 共用 out/cmake（CMake 缓存是 VS 生成器的）⇒ 配置当场被拒；
     还会覆盖 Windows 的 out/sdk、out/build_report.json。⇒ 现在先**复制进 Linux 自己的文件系统**再编（也快得多），
     产物拷回 `out/linux/<模式>/`。
  ② `(command -v cmake || sudo apt-get update && apt-get install …)` 的运算符优先级错了（&& 比 || 优先级低 ⇒
     apt-get install 永远不带 sudo 跑）。⇒ 现在**不替用户装包**（装包要下载、要密码）：缺什么就打印一行确切的命令、返回 3。
  ③ `wsl --list` 的输出是 UTF-16：设 WSL_UTF8=1 再读；没有发行版时 wsl 返回非 0（以前只看文字）。
  ④ Docker 同样不原地编（只读挂载源码，容器里复制一份再编）。

【用法】
  python tools/fry_build_linux_native.py                           # 自动挑 wsl > docker，native 模式
  python tools/fry_build_linux_native.py --engine wsl --mode prebuilt
  python tools/fry_build_linux_native.py --version 0.1.0
⚠ 两个引擎都没有时**不会假装成功**：打印安装办法并返回 3。
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import Dict, List, Optional

REPO = Path(__file__).resolve().parents[1]
IMAGE_STR = "debian:bookworm"          # ★ 与 ci/*.gitlab-ci.yml 的 build:linux 同一个镜像（口径一致）
APT_PKGS_STR = "build-essential cmake zstd binutils python3"
NEED_TOOLS = ("cmake", "c++", "zstd", "nm", "python3", "tar")
MODES = ("native", "prebuilt")
CROSS_TARGET_STR = "linux-x64"


def say(t: str) -> None:
    print("  " + t, flush=True)


def _run(cmd: List[str], timeout: int = 7200, env: Optional[Dict[str, str]] = None) -> int:
    print("$ " + " ".join(cmd), flush=True)
    try:
        return subprocess.run(cmd, timeout=timeout, env=env).returncode
    except subprocess.TimeoutExpired:
        say("✗ 超时（%d s）" % timeout)
        return 124


def wsl_env() -> Dict[str, str]:
    e = dict(os.environ)
    e["WSL_UTF8"] = "1"                 # wsl.exe 默认输出 UTF-16；设了它才是 UTF-8
    return e


def docker_ready() -> bool:
    exe = shutil.which("docker")
    if not exe:
        return False
    r = subprocess.run([exe, "info", "--format", "{{.OSType}}"], capture_output=True, text=True, timeout=60)
    return r.returncode == 0 and "linux" in (r.stdout or "").lower()


def wsl_distro() -> str:
    exe = shutil.which("wsl")
    if not exe:
        return ""
    r = subprocess.run([exe, "--list", "--quiet"], capture_output=True, timeout=60, env=wsl_env())
    text = r.stdout.decode("utf-8", "replace").replace("\x00", "").strip()
    if r.returncode != 0 or not text:
        return ""
    return text.splitlines()[0].strip()


def to_wsl_path(p: Path) -> str:
    s = str(p.resolve())
    return "/mnt/" + s[0].lower() + s[2:].replace("\\", "/")


def install_hint() -> None:
    print("""
  本机既没有可用的 WSL2 发行版也没有 Docker ⇒ **没法在本机出可交付的 Linux 包**（交叉编译的不算，见文件头）。
  三条路，挑一条：

  ① WSL2（推荐，免费、微软自带）
       PowerShell：  wsl --install -d Debian --no-launch
       装编译工具：  wsl -d Debian -u root -- apt-get install -y %s
       然后回到本仓库：python tools/fry_build_linux_native.py --engine wsl

  ② Docker Desktop（公司环境要确认许可；大企业商用需要付费订阅）
       装好后：python tools/fry_build_linux_native.py --engine docker

  ③ **不用本机**：把代码推上去，在 gitlab.com 网页点 Build → Pipelines → New pipeline
       Linux 包由共享 runner（debian:bookworm）出，产物在流水线的 artifacts 里下载。
""" % APT_PKGS_STR)


def write_runner_script(dest_dir: Path) -> Path:
    """生成在 Linux 里跑的那段 bash（WSL 与 Docker 共用；参数从环境变量来）。

    ⚠ 为什么写成文件而不是一长串 `bash -lc "..."`：Windows → wsl.exe → bash 三层引号，改一个字就会静默错位。
    """
    dest_dir.mkdir(parents=True, exist_ok=True)
    p = dest_dir / "_linux_run.sh"
    p.write_bytes(("""#!/usr/bin/env bash
# ★409 自动生成（fry_build_linux_native.py）：复制源码 → 在 Linux 自己的文件系统里出包 → 结果拷回
set -euo pipefail
: "${FRY_SRC:?}" "${FRY_MODE:?}" "${VERSION:?}" "${FRY_BACK:?}"
FRY_DST="${FRY_DST:-$HOME/.fry_sdk_build/$(basename "$FRY_SRC")}"     # 默认放在 Linux 自己的文件系统里（快，且不碰 Windows 的 out/）
if [ "${FRY_APT:-0}" = "1" ]; then
  apt-get update -qq && apt-get install -y --no-install-recommends %s ca-certificates >/dev/null
fi
missing=""
for t in %s; do command -v "$t" >/dev/null 2>&1 || missing="$missing $t"; done
if [ -n "$missing" ]; then
  echo "缺工具：$missing" >&2
  echo "请先装（以 root）：apt-get install -y %s" >&2
  exit 3
fi
rm -rf "$FRY_DST" && mkdir -p "$FRY_DST"
tar -C "$FRY_SRC" --exclude=./out --exclude=./.git --exclude=./.pytest_cache --exclude='*/__pycache__' -cf - . | tar -C "$FRY_DST" -xf -
cd "$FRY_DST"
if [ "$FRY_MODE" = "prebuilt" ]; then
  mkdir -p out/prebuilt
  cp -a "$FRY_SRC/out/cross/%s/prebuilt/." out/prebuilt/
  chmod +x out/prebuilt/FryVersionProbe out/prebuilt/FryHalftoneDemoC out/prebuilt/fry-halftone-cli
  python3 tools/fry_build.py --version "$VERSION" --prebuilt-dir out/prebuilt
else
  VERSION="$VERSION" bash packaging/linux/build_linux_sdk.sh
fi
# 本机环境事实（写进结果，别人一看就知道「在哪台 Linux 上验的」）
python3 - "$FRY_DST/out/linux_env.json" <<'PY'
import json, platform, subprocess, sys
def sh(c):
    try:
        return subprocess.run(c, shell=True, capture_output=True, text=True).stdout.strip().splitlines()[0]
    except Exception:
        return ""
os_name = ""
try:
    for line in open("/etc/os-release", encoding="utf-8"):
        if line.startswith("PRETTY_NAME="):
            os_name = line.split("=", 1)[1].strip().strip('"')
except OSError:
    pass
json.dump({"os_str": os_name, "kernel_str": platform.release(), "glibc_str": sh("ldd --version"),
           "gcc_str": sh("c++ --version"), "cmake_str": sh("cmake --version"), "python_str": platform.python_version()},
          open(sys.argv[1], "w", encoding="utf-8"), ensure_ascii=False, indent=1)
PY
rm -rf "$FRY_BACK" && mkdir -p "$FRY_BACK"
cp out/fry-halftone-"$VERSION"-linux-x64.tar.zst out/build_report.json out/linux_env.json "$FRY_BACK"/
cp -a out/sdk/fry-halftone-sdk "$FRY_BACK"/sdk
echo "结果已拷回：$FRY_BACK"
""" % (APT_PKGS_STR, " ".join(NEED_TOOLS), APT_PKGS_STR, CROSS_TARGET_STR)).encode("utf-8"))   # LF 换行：bash 不认 CRLF
    return p


def main(argv=None) -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    ap = argparse.ArgumentParser(description="在 WSL2 / Docker 里出一个真正跑过验收（golden + 命令行契约）的 Linux 包")
    ap.add_argument("--engine", default="auto", choices=["auto", "docker", "wsl"])
    ap.add_argument("--mode", default="native", choices=list(MODES))
    ap.add_argument("--version", default="0.0.0-dev")
    ns = ap.parse_args(argv)

    print("=" * 96)
    print("★394/★409 本机出 Linux 包（真跑验收）｜ 模式 %s" % ns.mode)
    print("=" * 96)
    if ns.mode == "prebuilt":
        pre = REPO / "out" / "cross" / CROSS_TARGET_STR / "prebuilt"
        if not (pre / "prebuilt_info.json").is_file():
            say("✗ 没有 %s —— 先跑：python tools/fry_cross_build.py --target %s" % (pre, CROSS_TARGET_STR))
            return 3
        info = json.loads((pre / "prebuilt_info.json").read_text(encoding="utf-8"))
        say("用现成二进制：%s" % info.get("origin_str", "?"))
    engine = ns.engine
    if engine == "auto":
        engine = "wsl" if wsl_distro() else ("docker" if docker_ready() else "")
    back = REPO / "out" / "linux" / ns.mode
    script = write_runner_script(REPO / "out" / "linux")
    t0 = time.time()

    if engine == "wsl":
        distro = wsl_distro()
        if not distro:
            say("✗ 没有可用的 WSL 发行版")
            install_hint()
            return 3
        say("引擎：WSL2（发行版 %s）—— 源码复制进 Linux 自己的文件系统再编，不碰 Windows 的 out/cmake" % distro)
        env = wsl_env()
        env["WSLENV"] = "FRY_SRC/u:FRY_MODE/u:VERSION/u:FRY_BACK/u"   # /u = 原样传进 Linux（不做路径翻译）
        env.update({"FRY_SRC": to_wsl_path(REPO), "FRY_MODE": ns.mode, "VERSION": ns.version, "FRY_BACK": to_wsl_path(back)})
        env.pop("FRY_DST", None)                           # 构建目录由 Linux 端决定：$HOME/.fry_sdk_build/<仓库名>
        rc = _run([shutil.which("wsl"), "-d", distro, "--", "bash", to_wsl_path(script)], env=env)
    elif engine == "docker":
        if not docker_ready():
            say("✗ Docker 没就绪（没装，或服务没起）")
            install_hint()
            return 3
        say("引擎：Docker（镜像 %s —— 与 CI 的 build:linux 同一个；源码只读挂载，容器里复制一份再编）" % IMAGE_STR)
        rc = _run([shutil.which("docker"), "run", "--rm", "-v", "%s:/src" % str(REPO.resolve()),
                   "-e", "FRY_SRC=/src", "-e", "FRY_DST=/build", "-e", "FRY_MODE=" + ns.mode, "-e", "VERSION=" + ns.version,
                   "-e", "FRY_BACK=/src/out/linux/" + ns.mode, "-e", "FRY_APT=1", IMAGE_STR, "bash", "/src/out/linux/_linux_run.sh"])
    else:
        say("✗ 本机既没有 WSL2 发行版也没有 Docker")
        install_hint()
        return 3

    dt = time.time() - t0
    art = back / ("fry-halftone-%s-linux-x64.tar.zst" % ns.version)
    report = back / "build_report.json"
    if rc != 0:
        say("✗ 构建失败（返回码 %d，用时 %.0f s）—— 上面的日志里有原因" % (rc, dt))
        return rc
    if not art.is_file():
        say("✗ 构建说成功了，但找不到产物 %s" % art)
        return 1
    rep = json.loads(report.read_text(encoding="utf-8")) if report.is_file() else {}
    env_facts = json.loads((back / "linux_env.json").read_text(encoding="utf-8")) if (back / "linux_env.json").is_file() else {}
    ok_smoke = bool(rep.get("smoke_bool")) and rep.get("smoke_dict", {}).get("cli_contract_str") == "ok"
    say("✓ 产物：%s（%.2f MB，用时 %.0f s）" % (art, art.stat().st_size / 1048576.0, dt))
    say("  来源：%s ｜ 最低系统：%s" % (rep.get("build_origin_str", "?"), rep.get("min_os_str", "?")))
    say("  验收机：%s ｜ %s ｜ 内核 %s" % (env_facts.get("os_str", "?"), env_facts.get("glibc_str", "?"), env_facts.get("kernel_str", "?")))
    say("✓ 冒烟（golden 逐字节 + C 接口 + 命令行契约 + 交付清单）：%s"
        % ("通过 ⇒ **可交付**" if ok_smoke else "⚠ build_report.json 里没写全部通过"))
    say("  下一步：python tools/fry_business_zip.py 打给业务的包（会按交付清单查全部项）")
    return 0 if ok_smoke else 1


if __name__ == "__main__":
    raise SystemExit(main())
