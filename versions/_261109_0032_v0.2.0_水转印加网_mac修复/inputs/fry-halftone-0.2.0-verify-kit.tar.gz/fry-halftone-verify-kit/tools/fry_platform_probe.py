# -*- coding: utf-8 -*-
r"""fry_platform_probe.py —— ★394 跨平台出包体检：**这台机器现在能出哪几个平台的包**，下一步该做什么。

【为什么要有它】「在 Windows 上能不能生成 Linux / macOS 的产物」这个问题，答案取决于**你机器上有什么**。
  与其猜，不如跑一遍：把四条路各自的前提条件逐条查出来，再按「能不能在目标平台跑 golden」排序给建议。

【四条路（按可信度从高到低）】
  ① **CI 托管 runner**：本仓 `.gitlab-ci.yml` 里 Linux 用 gitlab.com 共享 runner（debian:bookworm），
     **开箱即用**；Windows / macOS 要各自注册一台 runner。产物在目标平台**真编真跑 golden** ⇒ 可交付。
  ② **本机容器 / 子系统**（Docker Desktop 或 WSL2）：真 Linux 用户态，**能编也能跑测试** ⇒ Linux 可交付。
  ③ **交叉编译**（zig）：能编出真的 ELF / Mach-O，但**本机跑不了** ⇒ 只能当编译探针 / 应急件。
  ④ **真机**：一台 Mac / 一台 Linux ⇒ 最可靠，但要人、要机器。
  ⚠ macOS **没有**②：非苹果硬件上跑 macOS 违反 Apple 许可，也没有合法的 macOS 容器镜像。

【用法】python tools/fry_platform_probe.py [--json out.json]
"""
from __future__ import annotations

import argparse
import json
import os
import platform
import shutil
import socket
import subprocess
import sys
from pathlib import Path
from typing import Any, Dict, List

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO / "tools"))
import fry_build_linux_native as LN  # noqa: E402  ★409 WSL / Docker 判定只有这一份实现
TOOLCHAIN_DIR_LIST = [Path(r"D:/_300_3D_Rip/_toolchains"), Path.home() / "fry_toolchains"]


def run(cmd: List[str], timeout: int = 20) -> str:
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=timeout)
        return (r.stdout or r.stderr or "").strip().splitlines()[0] if (r.stdout or r.stderr) else ""
    except Exception:                                                   # noqa: BLE001
        return ""


def have(name: str) -> str:
    p = shutil.which(name)
    return p or ""


def probe_zig() -> str:
    env = os.environ.get("FRY_ZIG_EXE", "")
    if env and Path(env).is_file():
        return env
    for root in TOOLCHAIN_DIR_LIST:
        for c in sorted(root.glob("zig-*/zig.exe" if os.name == "nt" else "zig-*/zig")):
            return str(c)
    return have("zig")


def probe_ninja() -> str:
    for root in TOOLCHAIN_DIR_LIST:
        c = root / "ninja" / ("ninja.exe" if os.name == "nt" else "ninja")
        if c.is_file():
            return str(c)
    return have("ninja")


def online(host: str = "ziglang.org", port: int = 443, timeout: float = 5.0) -> bool:
    try:
        socket.create_connection((host, port), timeout=timeout).close()
        return True
    except OSError:
        return False


def main(argv=None) -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    ap = argparse.ArgumentParser()
    ap.add_argument("--json", default="")
    ns = ap.parse_args(argv)

    docker, wsl = have("docker"), have("wsl")
    # ★409 以前：`wsl --list` 的 UTF-16 输出按 UTF-8 读、只看文字里有没有 "not installed" ⇒ 没有发行版时
    #   它说的是 "has no installed distributions"，被**误判成可用**（409 开工时本机正是这个状态）。
    #   现在复用 fry_build_linux_native 的判定：WSL_UTF8=1 + 看返回码 + 要真有一个发行版名字
    docker_ok = LN.docker_ready() if docker else False
    wsl_name = LN.wsl_distro() if wsl else ""
    wsl_ok = bool(wsl_name)
    zig, ninja, cmake = probe_zig(), probe_ninja(), have("cmake")
    net = online()

    facts = [
        ("宿主系统", "%s %s" % (platform.system(), platform.machine()), ""),
        ("cmake", run([cmake, "--version"]) if cmake else "（没有）", "三平台出包都要它"),
        ("Visual Studio / MSVC", "有" if Path("C:/Program Files/Microsoft Visual Studio").is_dir() else "（没有）", "Windows 版 dll 靠它"),
        ("Docker", (run([docker, "--version"]) if docker else "（没装）") + ("" if docker_ok else "（装了但服务没起）" if docker else ""),
         "有它 = 本机能出**能跑测试**的 Linux 包"),
        ("WSL2", wsl_name or ("（装了 WSL，但没有发行版）" if wsl else "（没装）"),
         "同上；`wsl --install -d Debian` 需要管理员 + 重启"),
        ("zig（交叉工具链）", zig or "（没有）", "有它 = 能编出 Linux/macOS 产物，但**跑不了**"),
        ("ninja", ninja or "（没有）", "交叉编译用的生成器"),
        ("外网", "通" if net else "不通", "没网就装不了 zig / 拉不了镜像"),
    ]
    print("=" * 96)
    print("★394 跨平台出包体检")
    print("=" * 96)
    for k, v, why in facts:
        print("  %-22s %-46s %s" % (k, v[:46], why))

    # ── 每个平台现在能做到哪一步（★ 判据是「能不能在目标平台跑 golden」，不是「能不能编出来」）
    print("\n  平台            本机能做到                                  能交付吗    正式路径")
    print("  " + "-" * 92)
    rows = []
    for tag, native, cross_ok, official in (
        ("win32-x64", True, True, "本机 `python tools/fry_build.py`（已在用）"),
        ("linux-x64", docker_ok or wsl_ok, bool(zig and ninja), "CI 的 build:linux（gitlab.com 共享 runner，开箱即用）"),
        ("linux-arm64", False, bool(zig and ninja), "CI 上加一个 arm64 runner，或真机"),
        ("darwin-arm64", False, bool(zig and ninja), "**只能**真 Mac：★409 验收包 fry_target_kit.py → Mac 上一条命令；或 CI 的 macos runner"),
    ):
        if tag == "win32-x64":
            can, deliver = "真编真跑（含 golden）", "✅ 可以"
        elif native:
            can, deliver = "容器/WSL 里真编真跑", "✅ 可以"
        elif cross_ok:
            can, deliver = "交叉编译（编得出、跑不了）", "❌ 不行（未验证）"
        else:
            can, deliver = "什么都做不了（缺工具链）", "❌ 不行"
        print("  %-15s %-42s %-10s %s" % (tag, can, deliver, official))
        rows.append({"platform_str": tag, "local_ability_str": can, "deliverable_bool": deliver.startswith("✅"),
                     "official_path_str": official})

    print("\n  下一步建议（按性价比）：")
    tips: List[str] = []
    if docker_ok or wsl_ok:
        tips.append("① 本机就能出可交付的 Linux 包：`python tools/fry_cross_build.py --target linux-x64` + "
                    "`python tools/fry_build_linux_native.py --mode prebuilt`（★409 推荐：glibc 2.17 起可加载）；或界面「★Linux 包」")
    else:
        tips.append("① 想在**本机**出可交付的 Linux 包：装 WSL2 —— 管理员 PowerShell 跑 `wsl --install -d Debian`，重启后"
                    "`python tools/fry_build_linux_native.py`（会在 WSL 里真编真跑 golden）")
    tips.append("② 最省事的正式路径：把代码推上去，在 gitlab.com 网页点 Build → Pipelines → New pipeline —— "
                "Linux 包由共享 runner 出，**不需要你本机有 Linux**")
    tips.append("③ macOS：没有合法的「模拟」路 —— ★409 `python tools/fry_target_kit.py` 打验收包，拷到任意一台 Mac 上 "
                "`bash run_on_target.sh`（一条命令真跑 golden + 出包）；长期：在 CI 上注册一台 Mac runner（设 FRY_MACOS_RUNNER=1）")
    if not zig:
        tips.append("④ 想先看看 Linux/macOS 编不编得过：`python tools/fry_cross_build.py --install-toolchain --target all`")
    for t in tips:
        print("     " + t)

    data = {"facts_list": [{"name_str": k, "value_str": v, "why_str": w} for k, v, w in facts],
            "platforms_list": rows, "tips_list": tips,
            "docker_ok_bool": docker_ok, "wsl_ok_bool": wsl_ok, "zig_str": zig, "ninja_str": ninja, "online_bool": net}
    if ns.json:
        Path(ns.json).parent.mkdir(parents=True, exist_ok=True)
        Path(ns.json).write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8")
        print("\n  报告：%s" % ns.json)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
