# -*- coding: utf-8 -*-
r"""fry_cross_build.py —— ★394 在 **Windows 上**交叉编译出 Linux / macOS 的原生库（zig 当交叉工具链）。

【先说清最重要的一件事：交叉编译 ≠ 可交付】
  这个脚本能在 Windows 上编出**真正的** `libfry_halftone.so`（ELF x86-64）和 `libfry_halftone.dylib`（Mach-O），
  但它**编完跑不了** —— 本机没有 Linux / macOS 内核，加载不了那两个格式。
  而本 SDK 的验收判据是「**与 Python 生产线逐字节一致**」（golden 12 件）：
  ★★ 392 实测过，两边只差 **1 ulp** 就能让 **402 / 433 张 BMP 不同**；
  三个平台的 `libm`（`cos/sin/pow/atan2`）本来就是三份不同实现。
  ⇒ **没在目标平台真跑过 golden 的库，不知道它对不对** ⇒ 交叉产物一律标
     `verified_on_target_bool = false`，**不进正式交付**（正式交付走 CI 或真机，见 `docs/跨平台出包.md`）。

【那它有什么用】三件事，都是真的有价值：
  ① **编译探针**：Linux/macOS 用的是 clang + libstdc++/libc++，和 MSVC 挑的毛病不一样
     （比如 MSVC 放过的 `#include` 缺失、窄化转换）。在本机几十秒就能发现，不用等 CI 排队。
  ② **给领导看的可运行前的证据**：产物是**真的** ELF / Mach-O，本脚本用纯 Python 解析文件头 +
     导出符号表把这件事**证明**出来（不是「我觉得是」）。
  ③ **CI 断网 / 没 runner 时的应急件**：标着「未验证」交给对方先做集成联调（接口对不对、能不能 dlopen），
     真正出货仍要等目标平台跑过 golden。

【★409 起多一个用途：给目标机验收供货】四个二进制（库 / 版本探针 / 纯 C 示例 / 对外命令行）一起编，
  放进 `out/cross/<目标>/prebuilt/`（带 prebuilt_info.json）⇒ 目标机上 `python tools/fry_build.py --prebuilt-dir …`
  跑**同一套**装配 + 冒烟 + 打包（Linux：`fry_build_linux_native.py --mode prebuilt` 在 WSL 里自动做）。
  ⚠ 本脚本自己仍然**只**说「编出来了」（verified_on_target=false）；「验过了」由目标机那一步的冒烟报告来说。
  ★ Linux 的 glibc 基线默认 **2.28**（manylinux_2_28 口径：RHEL 8 / Debian 10 / Ubuntu 18.10 起都能加载），
    比 CI 的 bookworm（2.36）与 WSL Debian 13 原生编（409 实测要 2.38）都宽；`--glibc 2.36` 可改。

【用法】
  python tools/fry_cross_build.py --target linux-x64      # 交叉编译 + 校验 ELF
  python tools/fry_cross_build.py --target macos-arm64    # 交叉编译 + 校验 Mach-O（⚠ 见下面的许可提醒）
  python tools/fry_cross_build.py --target all
  python tools/fry_cross_build.py --install-toolchain     # 没有 zig/ninja 就下载（带 sha256 校验）
⚠ **macOS 的许可提醒**：Apple 的 SDK / 系统只允许在 Apple 硬件上使用。zig 自带的是**开源的 libSystem 存根**，
  能链出 Mach-O，但**对外发布 macOS 版本请走真 Mac**（CI 的 macos runner 或一台 Mac mini），别拿它出货。
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import platform
import re
import shutil
import struct
import subprocess
import sys
import time
import urllib.request
import zipfile
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

REPO = Path(__file__).resolve().parents[1]
OUT = REPO / "out" / "cross"
TOOLCHAIN_DIR_LIST = [Path(r"D:/_300_3D_Rip/_toolchains"), Path.home() / "fry_toolchains"]
ZIG_VERSION_STR = "0.16.0"

# 目标平台表：加一个平台 = 加一行
TARGET_DICT: Dict[str, Dict[str, str]] = {
    "linux-x64": {"zig_triple": "x86_64-linux-gnu.{glibc}", "cmake_system": "Linux", "cmake_proc": "x86_64",
                  "lib": "libfry_halftone.so", "fmt": "elf",
                  "why": "glibc 基线（默认 2.28 = manylinux_2_28）：目标机 glibc 不比它旧就能加载；基线越老，能跑的机器越多"},
    "linux-arm64": {"zig_triple": "aarch64-linux-gnu.{glibc}", "cmake_system": "Linux", "cmake_proc": "aarch64",
                    "lib": "libfry_halftone.so", "fmt": "elf", "why": "ARM 服务器 / 树莓派"},
    "macos-arm64": {"zig_triple": "aarch64-macos-none", "cmake_system": "Darwin", "cmake_proc": "arm64",
                    "lib": "libfry_halftone.dylib", "fmt": "macho", "why": "Apple Silicon（M 系列）"},
    "macos-x64": {"zig_triple": "x86_64-macos-none", "cmake_system": "Darwin", "cmake_proc": "x86_64",
                  "lib": "libfry_halftone.dylib", "fmt": "macho", "why": "Intel Mac"},
}


GLIBC_DEFAULT_STR = "2.28"
BIN_KEYS = ("lib", "probe", "demo", "cli")          # ★409 四个二进制一起编（目标机验收要用全四个）
EXE_NAMES = {"probe": "FryVersionProbe", "demo": "FryHalftoneDemoC", "cli": "fry-halftone-cli"}
NINJA_TARGETS = ("fry_halftone", "FryVersionProbe", "FryHalftoneDemoC", "fry_halftone_cli")


def resolve_triples(glibc: str) -> None:
    """把目标表里 linux 三元组的 {glibc} 填成本次的基线（只填一次；纯数据）。"""
    for row in TARGET_DICT.values():
        row["zig_triple"] = row["zig_triple"].replace("{glibc}", glibc)


def say(text: str) -> None:
    print("  " + text, flush=True)


# ───────────────────────────── 工具链：找 / 下载 ─────────────────────────────
def _download(url: str, dst: Path, want_sha: str = "") -> Path:
    dst.parent.mkdir(parents=True, exist_ok=True)
    if not dst.is_file():
        t0 = time.time()
        with urllib.request.urlopen(url, timeout=300) as r, dst.open("wb") as f:
            shutil.copyfileobj(r, f, 1 << 20)
        say("下载 %s（%.1f MB，%.0f s）" % (dst.name, dst.stat().st_size / 1048576.0, time.time() - t0))
    if want_sha:
        got = hashlib.sha256(dst.read_bytes()).hexdigest()
        if got != want_sha:
            raise SystemExit("✗ %s 的 sha256 不对：%s ≠ %s（下载损坏或被篡改）" % (dst.name, got[:16], want_sha[:16]))
    return dst


def find_zig(install: bool = False) -> Path:
    """zig 在哪：环境变量 > 工具链目录 > PATH > （允许时）下载。"""
    env = os.environ.get("FRY_ZIG_EXE", "").strip('"')
    if env and Path(env).is_file():
        return Path(env)
    for root in TOOLCHAIN_DIR_LIST:
        for cand in sorted(root.glob("zig-*/zig.exe" if os.name == "nt" else "zig-*/zig")):
            return cand
    which = shutil.which("zig")
    if which:
        return Path(which)
    if not install:
        raise SystemExit("✗ 找不到 zig —— 跑一次 `python tools/fry_cross_build.py --install-toolchain` 自动下载"
                         "（约 93 MB，不需要管理员、不写注册表）")
    root = TOOLCHAIN_DIR_LIST[0]
    idx = json.load(urllib.request.urlopen("https://ziglang.org/download/index.json", timeout=120))
    key = "x86_64-windows" if os.name == "nt" else "x86_64-linux"
    row = idx[ZIG_VERSION_STR][key]
    zp = _download(row["tarball"], root / ("zig-%s-%s.zip" % (ZIG_VERSION_STR, key)), row.get("shasum", ""))
    with zipfile.ZipFile(zp) as z:
        z.extractall(root)
    exe = next(root.glob("zig-*%s*/zig.exe" % ZIG_VERSION_STR if os.name == "nt" else "zig-*/zig"))
    say("zig 装好了：%s" % exe)
    return exe


def find_ninja(install: bool = False) -> Path:
    for root in TOOLCHAIN_DIR_LIST:
        cand = root / "ninja" / ("ninja.exe" if os.name == "nt" else "ninja")
        if cand.is_file():
            return cand
    which = shutil.which("ninja")
    if which:
        return Path(which)
    if not install:
        raise SystemExit("✗ 找不到 ninja —— 跑 `python tools/fry_cross_build.py --install-toolchain`（约 0.3 MB）")
    root = TOOLCHAIN_DIR_LIST[0] / "ninja"
    rel = json.load(urllib.request.urlopen("https://api.github.com/repos/ninja-build/ninja/releases/latest", timeout=120))
    url = [a["browser_download_url"] for a in rel["assets"] if a["name"] == "ninja-win.zip"][0]
    zp = _download(url, TOOLCHAIN_DIR_LIST[0] / "ninja-win.zip")
    with zipfile.ZipFile(zp) as z:
        z.extractall(root)
    say("ninja 装好了：%s" % (root / "ninja.exe"))
    return root / "ninja.exe"


# ───────────────────────────── 生成 zig 包装脚本与 CMake 工具链文件 ─────────────────────────────
def write_toolchain(work: Path, zig: Path, target: str) -> Path:
    """CMake 只会调「一个可执行文件」，而 zig 的用法是 `zig cc …`（两个词）⇒ 必须包一层。

    ⚠ 这层包装还有第二个作用：把 `-target <三元组>` 钉死在里面。
      写在 CMAKE_C_FLAGS 里会被某些检测步骤丢掉（CMake 试编译时用的是自己的 flags）——
      放进包装脚本，**任何人用任何方式调它都带着目标平台**。
    """
    row = TARGET_DICT[target]
    work.mkdir(parents=True, exist_ok=True)
    ext = ".cmd" if os.name == "nt" else ".sh"
    made: Dict[str, Path] = {}
    for name, sub in (("cc", "cc"), ("cxx", "c++"), ("ar", "ar"), ("ranlib", "ranlib")):
        p = work / ("zig-%s%s" % (name, ext))
        tgt = (" -target " + row["zig_triple"]) if sub in ("cc", "c++") else ""
        if os.name == "nt":
            p.write_text("@echo off\r\n\"%s\" %s%s %%*\r\n" % (zig, sub, tgt), encoding="utf-8")
        else:
            p.write_text("#!/bin/sh\nexec \"%s\" %s%s \"$@\"\n" % (zig, sub, tgt), encoding="utf-8")
            p.chmod(0o755)
        made[name] = p
    tc = work / "zig-toolchain.cmake"
    tc.write_text(
        "# ★394 自动生成：zig 交叉工具链（目标 %s）\n"
        "set(CMAKE_SYSTEM_NAME %s)\n"
        "set(CMAKE_SYSTEM_PROCESSOR %s)\n"
        "set(CMAKE_C_COMPILER   \"%s\")\n"
        "set(CMAKE_CXX_COMPILER \"%s\")\n"
        "set(CMAKE_AR           \"%s\")\n"
        "set(CMAKE_RANLIB       \"%s\")\n"
        "set(CMAKE_C_COMPILER_TARGET %s)\n"
        "set(CMAKE_CXX_COMPILER_TARGET %s)\n"
        "set(FRY_ZIG_CROSS ON)   # ★409 CMakeLists.txt 据此给 macOS 编进隐藏的 new/delete（zig 不认导出白名单）\n"
        "%s"
        "set(CMAKE_FIND_ROOT_PATH_MODE_PROGRAM NEVER)\n"
        "set(CMAKE_FIND_ROOT_PATH_MODE_LIBRARY ONLY)\n"
        "set(CMAKE_FIND_ROOT_PATH_MODE_INCLUDE ONLY)\n"
        "set(THREADS_PREFER_PTHREAD_FLAG ON)\n"
        % (target, row["cmake_system"], row["cmake_proc"],
           str(made["cc"]).replace("\\", "/"), str(made["cxx"]).replace("\\", "/"),
           str(made["ar"]).replace("\\", "/"), str(made["ranlib"]).replace("\\", "/"),
           row["zig_triple"], row["zig_triple"],
           # ★409 ELF：zig 预编的 libc++ / compiler-rt 带调试信息（实测 .so 9.18 MB 里 8.01 MB 是 .debug_*），
           #   **链接时**剥（不是验收后再 strip）⇒ 目标机验收的那一份 = 发出去的那一份；符号表留着（崩溃栈可读）
           # ★410 Mach-O：链接器默认写「调试映射」（STABS：每个 .o 的**构建机绝对路径 + 修改时间**，实测库里 52 条）
           #   ⇒ 路径泄露 + 每次重编字节都不同（.o 的 mtime 变了）。-Wl,-S 只去掉这些调试条目、真符号表留着；
           #   实测加了之后同一份源码两次编出来逐字节相同
           ('set(CMAKE_SHARED_LINKER_FLAGS_INIT "-Wl,--strip-debug")\n'
            'set(CMAKE_EXE_LINKER_FLAGS_INIT "-Wl,--strip-debug")\n') if row["fmt"] == "elf" else
           ('set(CMAKE_SHARED_LINKER_FLAGS_INIT "-Wl,-S")\n'
            'set(CMAKE_EXE_LINKER_FLAGS_INIT "-Wl,-S")\n')),
        encoding="utf-8", newline="\n")
    return tc


# ───────────────────────────── 产物校验：纯 Python 读 ELF / Mach-O ─────────────────────────────
def inspect_elf(path: Path) -> Dict[str, Any]:
    """不装任何工具、不跑目标系统，直接按格式规范读 ELF —— 「这真的是一个 Linux 共享库」要拿证据说话。"""
    b = path.read_bytes()
    if b[:4] != b"\x7fELF":
        return {"ok_bool": False, "why_str": "开头不是 ELF 魔数"}
    is64, little = b[4] == 2, b[5] == 1
    end = "<" if little else ">"
    e_type, e_machine = struct.unpack_from(end + "HH", b, 16)
    e_shoff, = struct.unpack_from(end + "Q", b, 0x28)
    e_shentsize, e_shnum, e_shstrndx = struct.unpack_from(end + "HHH", b, 0x3A)
    sections = []
    for i in range(e_shnum):
        off = e_shoff + i * e_shentsize
        sh_name, sh_type, sh_flags, sh_addr, sh_offset, sh_size, sh_link, sh_info = struct.unpack_from(end + "IIQQQQII", b, off)
        sh_entsize, = struct.unpack_from(end + "Q", b, off + 56)
        sections.append({"name_off": sh_name, "type": sh_type, "offset": sh_offset, "size": sh_size,
                         "link": sh_link, "entsize": sh_entsize})
    strtab = sections[e_shstrndx]
    names = b[strtab["offset"]: strtab["offset"] + strtab["size"]]

    def sec_name(s):
        e = names.index(b"\0", s["name_off"])
        return names[s["name_off"]:e].decode("utf-8", "replace")

    by_name = {sec_name(s): s for s in sections}
    dynsym, dynstr = by_name.get(".dynsym"), by_name.get(".dynstr")
    exports: List[str] = []
    if dynsym and dynstr:
        sb = b[dynstr["offset"]: dynstr["offset"] + dynstr["size"]]
        n = dynsym["size"] // (dynsym["entsize"] or 24)
        for i in range(n):
            off = dynsym["offset"] + i * dynsym["entsize"]
            st_name, st_info, st_other, st_shndx, st_value, st_size = struct.unpack_from(end + "IBBHQQ", b, off)
            if st_shndx == 0 or not st_name:            # 未定义符号 = 它需要别人提供的，不是它导出的
                continue
            e = sb.index(b"\0", st_name)
            exports.append(sb[st_name:e].decode("utf-8", "replace"))
    needed: List[str] = []
    runpath: List[str] = []
    soname = ""
    dyn = by_name.get(".dynamic")
    if dyn and dynstr:
        sb = b[dynstr["offset"]: dynstr["offset"] + dynstr["size"]]
        for i in range(dyn["size"] // 16):
            tag, val = struct.unpack_from(end + "qQ", b, dyn["offset"] + i * 16)
            if tag == 0:
                break
            if tag in (1, 14, 15, 29):                  # DT_NEEDED / DT_SONAME / DT_RPATH / DT_RUNPATH
                e = sb.index(b"\0", val)
                s = sb[val:e].decode("utf-8", "replace")
                if tag == 1:
                    needed.append(s)
                elif tag == 14:
                    soname = s
                else:
                    runpath.extend(x for x in s.split(":") if x)
    glibc = sorted({tuple(int(x) for x in m.groups() if x) for m in re.finditer(rb"GLIBC_(\d+)\.(\d+)(?:\.(\d+))?", b)})
    return {"ok_bool": True, "format_str": "ELF", "class_str": "64 位" if is64 else "32 位",
            "endian_str": "小端" if little else "大端",
            "type_str": {1: "REL(目标文件)", 2: "EXEC(可执行)", 3: "DYN(共享库/PIE)"}.get(e_type, str(e_type)),
            "machine_str": {0x3E: "x86-64", 0xB7: "AArch64"}.get(e_machine, hex(e_machine)),
            "soname_str": soname, "needed_list": sorted(needed), "rpaths_list": runpath,
            # ★409 最低系统 = 引用到的最高 GLIBC_x.y 符号版本（实测，不是抄配置）
            "min_os_str": ("glibc %s" % ".".join(map(str, glibc[-1]))) if glibc else "",
            "export_count_int": len(exports), "exports_list": sorted(exports),
            "host_path_hits_int": host_path_hits(b),                 # ★410 构建机路径（ELF 靠 --strip-debug 已是 0）
            "size_int": path.stat().st_size, "sha256_str": hashlib.sha256(b).hexdigest()}


def _uleb(b: bytes, i: int) -> Tuple[int, int]:
    r = s = 0
    while True:
        x = b[i]
        i += 1
        r |= (x & 0x7F) << s
        s += 7
        if x < 0x80:
            return r, i


def macho_export_trie(b: bytes, base: int) -> List[str]:
    """★409 dyld 真正查的导出表（export trie）；symtab 里的「外部符号」只是近似（私有外部 N_PEXT 也会混进来）。"""
    out: List[str] = []
    stack = [(0, "")]
    while stack:
        off, prefix = stack.pop()
        i = base + off
        term, i = _uleb(b, i)
        if term:
            out.append(prefix)
            i += term
        nchild = b[i]
        i += 1
        for _ in range(nchild):
            e = b.index(b"\0", i)
            edge = b[i:e].decode("utf-8", "replace")
            child, i = _uleb(b, e + 1)
            stack.append((child, prefix + edge))
    return out


def host_path_hits(b: bytes) -> int:
    """★410 二进制里出现了几处构建机的仓库路径（两种斜杠、不分大小写）：> 0 = 路径泄露，且每台机器编出来都不一样。"""
    low = b.lower()
    return sum(low.count(s.encode("utf-8").lower()) for s in {str(REPO), REPO.as_posix()})


def inspect_macho(path: Path) -> Dict[str, Any]:
    """Mach-O：文件头 + LC_ID_DYLIB + 依赖 + rpath + 最低系统 + 签名 + 导出表（export trie；无 trie 才退回 symtab）。"""
    b = path.read_bytes()
    magic, = struct.unpack_from("<I", b, 0)
    if magic not in (0xFEEDFACF, 0xFEEDFACE):
        return {"ok_bool": False, "why_str": "开头不是 Mach-O 魔数（%s）" % hex(magic)}
    cputype, cpusub, filetype, ncmds, sizeofcmds, flags = struct.unpack_from("<iiIIII", b, 4)
    off = 32 if magic == 0xFEEDFACF else 28
    install_name, sym_exports, dylibs, rpaths = "", [], [], []
    trie: Optional[Tuple[int, int]] = None
    minos = sdk = ""
    codesig = False
    stabs = 0                                            # ★410 调试映射条目（N_STAB：N_SO / N_OSO / N_FUN …）

    def cstr(at: int) -> str:
        return b[at: b.index(b"\0", at)].decode("utf-8", "replace")

    for _ in range(ncmds):
        cmd, cmdsize = struct.unpack_from("<II", b, off)
        if cmd == 0x0D:                                  # LC_ID_DYLIB
            install_name = cstr(off + struct.unpack_from("<I", b, off + 8)[0])
        elif cmd in (0x0C, 0x8000001F, 0x80000018):      # LC_LOAD_DYLIB / LC_LOAD_WEAK_DYLIB / LC_REEXPORT_DYLIB
            dylibs.append(cstr(off + struct.unpack_from("<I", b, off + 8)[0]))
        elif cmd == 0x8000001C:                          # LC_RPATH
            rpaths.append(cstr(off + struct.unpack_from("<I", b, off + 8)[0]))
        elif cmd == 0x1D:                                # LC_CODE_SIGNATURE（arm64 没有它 = 一启动就被内核杀掉）
            codesig = True
        elif cmd == 0x32:                                # LC_BUILD_VERSION
            _plat, v_min, v_sdk = struct.unpack_from("<III", b, off + 8)
            minos = "%d.%d" % (v_min >> 16, (v_min >> 8) & 0xFF)
            sdk = "%d.%d" % (v_sdk >> 16, (v_sdk >> 8) & 0xFF)
        elif cmd == 0x80000022:                          # LC_DYLD_INFO_ONLY（export_off / export_size 在最后两格）
            v = struct.unpack_from("<10I", b, off + 8)
            trie = (v[8], v[9])
        elif cmd == 0x80000033:                          # LC_DYLD_EXPORTS_TRIE
            trie = struct.unpack_from("<II", b, off + 8)
        elif cmd == 0x02:                                # LC_SYMTAB
            symoff, nsyms, stroff, strsize = struct.unpack_from("<IIII", b, off + 8)
            sb = b[stroff: stroff + strsize]
            for i in range(nsyms):
                n_strx, n_type, n_sect, n_desc, n_value = struct.unpack_from("<IBBHQ", b, symoff + i * 16)
                if n_type & 0xE0:                        # N_STAB：调试条目，不是符号
                    stabs += 1
                    continue
                if (n_type & 0x0E) == 0x0E and (n_type & 0x01) and not (n_type & 0x10):   # N_SECT 且 N_EXT、非 N_PEXT
                    e = sb.index(b"\0", n_strx)
                    sym_exports.append(sb[n_strx:e].decode("utf-8", "replace"))
        off += cmdsize
    raw = macho_export_trie(b, trie[0]) if trie and trie[1] else sym_exports
    exports = [n[1:] if n.startswith("_") else n for n in raw]
    return {"ok_bool": True, "format_str": "Mach-O",
            "machine_str": {0x0100000C: "arm64", 0x01000007: "x86-64"}.get(cputype, str(cputype)),
            "type_str": {6: "DYLIB(动态库)", 2: "EXECUTE"}.get(filetype, str(filetype)),
            "install_name_str": install_name, "needed_list": sorted(dylibs), "rpaths_list": rpaths,
            "min_os_str": ("macOS %s" % minos) if minos else "", "sdk_str": sdk, "codesig_bool": codesig,
            "export_source_str": "export trie" if trie and trie[1] else "symtab",
            "export_count_int": len(exports), "exports_list": sorted(exports),
            "stab_count_int": stabs, "host_path_hits_int": host_path_hits(b),
            "size_int": path.stat().st_size, "sha256_str": hashlib.sha256(b).hexdigest()}


# ───────────────────────────── ★409 目标机验收前的静态闸（Windows 上能查的全查掉） ─────────────────────────────
EXPECTED_MACHINE_DICT = {"linux-x64": "x86-64", "linux-arm64": "AArch64", "macos-arm64": "arm64", "macos-x64": "x86-64"}


def static_problems(target: str, facts: Dict[str, Dict[str, Any]]) -> List[str]:
    """四个二进制「拿到目标机之前」就能判死的毛病（纯函数：输入是 inspect_* 的结果，按文件名索引）。

    ⚠ 这里全绿只说明「格式 / 架构 / 装载路径 / 签名」没毛病，**不说明算得对** —— 那要目标机跑 golden。
    """
    row = TARGET_DICT[target]
    lib_name = row["lib"]
    want_fmt = "ELF" if row["fmt"] == "elf" else "Mach-O"
    probs: List[str] = []
    for name in (lib_name,) + tuple(EXE_NAMES.values()):
        f = facts.get(name)
        if not f or not f.get("ok_bool"):
            probs.append("%s：缺文件或不是 %s（%s）" % (name, want_fmt, (f or {}).get("why_str", "没找到")))
            continue
        if f.get("format_str") != want_fmt or f.get("machine_str") != EXPECTED_MACHINE_DICT[target]:
            probs.append("%s：是 %s %s，目标要 %s %s" % (name, f.get("format_str"), f.get("machine_str"),
                                                     want_fmt, EXPECTED_MACHINE_DICT[target]))
        # 构建机路径烙进 rpath：泄露路径 + 每台机器产物不同（409 实测交叉编的 macOS 示例 / 命令行都烙进了 C:/…）
        bad_rpath = [p for p in f.get("rpaths_list", []) if not p.startswith(("$ORIGIN", "@loader_path", "@executable_path"))]
        if bad_rpath:
            probs.append("%s：rpath 里有构建机路径 %s（只许 $ORIGIN / @loader_path）" % (name, bad_rpath))
        if target == "macos-arm64" and not f.get("codesig_bool"):
            probs.append("%s：arm64 没有代码签名（Apple Silicon 上一启动就被内核杀掉）" % name)
        # ★410 调试映射 / 构建机路径：路径泄露给对方 + 每次重编字节都不同（不可复现）；409 的 macOS 产物实测库里 52 条、73 处路径
        if f.get("stab_count_int"):
            probs.append("%s：带 %d 条调试映射（STABS：构建机路径 + .o 修改时间）—— 链接加 -Wl,-S" % (name, f["stab_count_int"]))
        if f.get("host_path_hits_int"):
            probs.append("%s：二进制里有 %d 处构建机路径（泄露 + 不可复现）" % (name, f["host_path_hits_int"]))
    lib = facts.get(lib_name) or {}
    if want_fmt == "Mach-O" and lib.get("install_name_str") != "@loader_path/" + lib_name:
        probs.append("%s：install_name 是 %r，应为 @loader_path/%s" % (lib_name, lib.get("install_name_str"), lib_name))
    for key in ("demo", "cli"):                                          # 这两个动态链库：必须按「同目录」找到它
        f = facts.get(EXE_NAMES[key]) or {}
        if not f.get("ok_bool"):
            continue
        if want_fmt == "Mach-O":
            if "@loader_path/" + lib_name not in f.get("needed_list", []):
                probs.append("%s：没有按 @loader_path/%s 依赖库（%s）" % (EXE_NAMES[key], lib_name, f.get("needed_list")))
        elif lib_name not in f.get("needed_list", []) or "$ORIGIN" not in f.get("rpaths_list", []):
            probs.append("%s：要 DT_NEEDED %s + RUNPATH $ORIGIN（实际 %s ｜ %s）"
                         % (EXE_NAMES[key], lib_name, f.get("needed_list"), f.get("rpaths_list")))
    return probs


def header_api_names() -> List[str]:
    """头文件里声明的 C 接口名（与出包冒烟的导出面闸同一个真源）。"""
    import re
    text = (REPO / "include" / "fry_halftone.h").read_text(encoding="utf-8")
    return sorted(set(re.findall(r"FRY_API\s+[\w\s\*]+FRY_CALL\s+(\w+)", text)))


# ───────────────────────────── 主流程 ─────────────────────────────
def build_one(target: str, zig: Path, ninja: Path, version: str, jobs: int) -> Dict[str, Any]:
    row = TARGET_DICT[target]
    work = OUT / target
    build = work / "cmake"
    if build.exists():
        shutil.rmtree(build)
    tc = write_toolchain(work, zig, target)
    lock = json.loads((REPO / "cpp.lock.json").read_text(encoding="utf-8"))
    t0 = time.time()
    cfg = [str(shutil.which("cmake") or "cmake"), "-S", str(REPO), "-B", str(build), "-G", "Ninja",
           "-DCMAKE_MAKE_PROGRAM=" + str(ninja), "-DCMAKE_TOOLCHAIN_FILE=" + str(tc),
           "-DCMAKE_BUILD_TYPE=Release", "-DFRY_SDK_VERSION=" + version]
    say("配置：cmake -G Ninja（工具链 %s）" % tc.name)
    r = subprocess.run(cfg, capture_output=True, text=True, encoding="utf-8", errors="replace")
    if r.returncode != 0:
        return {"target_str": target, "ok_bool": False, "stage_str": "configure",
                "log_str": (r.stdout + r.stderr)[-4000:]}
    say("编译：ninja %s（%d 并发）" % (" ".join(NINJA_TARGETS), jobs))
    r = subprocess.run([str(ninja), "-C", str(build), "-j", str(jobs)] + list(NINJA_TARGETS),
                       capture_output=True, text=True, encoding="utf-8", errors="replace")
    if r.returncode != 0:
        return {"target_str": target, "ok_bool": False, "stage_str": "compile",
                "log_str": (r.stdout + r.stderr)[-4000:]}
    lib = next(build.rglob(row["lib"]), None)
    if lib is None:
        return {"target_str": target, "ok_bool": False, "stage_str": "artifact", "log_str": "编完了却找不到 " + row["lib"]}
    dst = work / row["lib"]
    shutil.copy2(lib, dst)
    # ★409 prebuilt/：四个二进制 + 「它们是谁」—— 目标机上 `fry_build.py --prebuilt-dir` 拿它做装配 + 冒烟 + 打包
    pre = work / "prebuilt"
    if pre.exists():
        shutil.rmtree(pre)
    pre.mkdir(parents=True)
    shutil.copy2(lib, pre / row["lib"])
    for key, name in EXE_NAMES.items():
        hit = next((p for p in build.rglob(name) if p.is_file()), None)
        if hit is None:
            return {"target_str": target, "ok_bool": False, "stage_str": "artifact", "log_str": "编完了却找不到 " + name}
        shutil.copy2(hit, pre / name)
    zig_ver = subprocess.run([str(zig), "version"], capture_output=True, text=True).stdout.strip()
    import fry_build   # 惰性：只有真编完才需要（外壳指纹的输入清单与算法唯一真源在 fry_build.py）
    (pre / "prebuilt_info.json").write_text(json.dumps({
        "origin_str": "zig %s 交叉编译（%s 宿主）-target %s" % (zig_ver, platform.system(), row["zig_triple"]),
        "compiler_str": "zig %s（clang + libc++ 静态）-target %s" % (zig_ver, row["zig_triple"]),
        "zig_triple_str": row["zig_triple"], "algorithm_fingerprint_str": lock.get("tree_sha256_str", ""),
        # ★410 外壳指纹（src/ include/ CMakeLists.txt …）：目标机上 fry_build.py --prebuilt-dir 拿它核对、写进 build_report
        "wrapper_sha256_str": fry_build.wrapper_fingerprint(REPO),
        "version_str": version, "built_at_str": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        "files_dict": {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(pre.iterdir()) if p.is_file()}},
        ensure_ascii=False, indent=1), encoding="utf-8")
    # ★★394 风险 1 的第一道堵：产物旁边放一张**说明书**，让任何人拿到它都知道这不是交付件。
    #   （文件本身完全正常、链接得上、看起来和真包一模一样 —— 这正是它危险的地方。）
    (work / "⚠未验证_请勿当交付件.txt").write_text(
        "这个目录里的 %s 是在 Windows 上**交叉编译**出来的（zig），目标平台是 %s。\n\n"
        "它没有、也不可能在这台机器上跑过验收：本机没有那个系统，加载不了这个格式。\n"
        "而本 SDK 的承诺是「与 Python 生产线逐字节一致」——三个平台的数学库是三份不同实现，\n"
        "★392 实测：只差 1 ulp 就能让 402 / 433 张 BMP 不同。\n\n"
        "所以：\n"
        "  · 可以拿它做**接口联调**（能不能 dlopen、参数怎么传、返回码对不对）；\n"
        "  · **不可以**当正式交付件发给客户 / 同事出货。\n\n"
        "要可交付的包：\n"
        "  Linux ：python tools/fry_build_linux_native.py --mode native|prebuilt（★409 WSL2 里真编 / 真跑 golden）\n"
        "          或 gitlab.com 网页 Build → Pipelines → New pipeline（共享 runner）\n"
        "  macOS ：★409 python tools/fry_target_kit.py 打「目标机验收包」→ 拷到任意一台 Mac →\n"
        "          bash run_on_target.sh（真跑 golden + 出包，一条命令）；或 CI 的 macos runner / Mac 上原生编\n"
        % (row["lib"], target), encoding="utf-8")
    info = inspect_elf(dst) if row["fmt"] == "elf" else inspect_macho(dst)
    want = header_api_names()
    got = list(info.get("exports_list", []))
    missing = [n for n in want if n not in got]
    # ★ 导出面要**两头都查**：少了 = 消费方链接不上；多了 = 内部符号漏出去（出包冒烟的导出面闸是严格相等，
    #   多一个就出不了包）。394 实测：不加白名单时 Linux 多 12 个、macOS 多 14 个。
    extra = [n for n in got if n not in want and not n.startswith(("__dso_handle", "_mh_"))]
    info["api_expected_int"] = len(want)
    info["api_missing_list"] = missing
    info["api_extra_list"] = extra
    # ★409 四个二进制一起过静态闸（格式 / 架构 / rpath / 签名 / 装载路径）—— 目标机上才发现就晚了
    inspect = inspect_elf if row["fmt"] == "elf" else inspect_macho
    facts = {p.name: inspect(p) for p in sorted(pre.iterdir()) if p.is_file() and p.suffix != ".json"}
    static = static_problems(target, facts)
    ok = bool(info.get("ok_bool")) and not missing and not extra and not static
    out = {"target_str": target, "ok_bool": ok, "stage_str": "done", "seconds_float": round(time.time() - t0, 1),
           "api_expected_int": len(want), "api_missing_list": missing, "api_extra_list": extra,
           "static_problems_list": static, "min_os_str": info.get("min_os_str", ""),
           "binaries_dict": {n: {k: f.get(k) for k in ("machine_str", "type_str", "needed_list", "rpaths_list",
                                                       "min_os_str", "codesig_bool", "size_int", "sha256_str")}
                             for n, f in facts.items()},
           "artifact_str": str(dst), "zig_triple_str": row["zig_triple"], "why_str": row["why"],
           "algorithm_fingerprint_str": lock.get("tree_sha256_str", ""), "version_str": version,
           # ★★ 这一行是整份产物的「身价」：没在目标平台跑过 golden ⇒ 不是交付件
           "verified_on_target_bool": False,
           "verify_note_str": "交叉编译只证明「编得出来、导出面齐全」；逐字节 golden 必须在目标平台跑（见 docs/跨平台出包.md）",
           "inspect_dict": info}
    return out


def main(argv=None) -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    ap = argparse.ArgumentParser(description="在 Windows 上交叉编译 Linux / macOS 原生库（zig）")
    ap.add_argument("--target", default="linux-x64", help="linux-x64 / linux-arm64 / macos-arm64 / macos-x64 / all")
    ap.add_argument("--version", default="0.0.0-dev")
    ap.add_argument("--jobs", type=int, default=max(2, (os.cpu_count() or 8) // 2))
    ap.add_argument("--install-toolchain", action="store_true", help="没有 zig / ninja 就自动下载（带 sha256 校验）")
    ap.add_argument("--glibc", default=GLIBC_DEFAULT_STR, help="★409 Linux 目标的 glibc 基线（默认 2.28 = manylinux_2_28）")
    ns = ap.parse_args(argv)
    resolve_triples(ns.glibc)

    print("=" * 96)
    print("★394 跨平台交叉编译（宿主 %s %s）" % (platform.system(), platform.machine()))
    print("=" * 96)
    zig = find_zig(ns.install_toolchain)
    ninja = find_ninja(ns.install_toolchain)
    say("zig   ：%s" % zig)
    say("ninja ：%s" % ninja)

    targets = list(TARGET_DICT) if ns.target == "all" else [t.strip() for t in ns.target.split(",")]
    bad = [t for t in targets if t not in TARGET_DICT]
    if bad:
        raise SystemExit("✗ 不认识的目标 %s（可选：%s）" % (bad, " / ".join(TARGET_DICT)))
    rows = []
    for t in targets:
        print("\n── %s（%s）──" % (t, TARGET_DICT[t]["why"]))
        row = build_one(t, zig, ninja, ns.version, ns.jobs)
        rows.append(row)
        if row["stage_str"] == "done":
            ins = row["inspect_dict"]
            say("%s %s ｜ %s %s ｜ %.2f MB ｜ 导出 %d 个（头文件要求 %d 个）｜ %.0f s"
                % ("✓" if row["ok_bool"] else "⚠", Path(row["artifact_str"]).name, ins.get("format_str"), ins.get("machine_str"),
                   ins["size_int"] / 1048576.0, ins["export_count_int"], row["api_expected_int"], row["seconds_float"]))
            say("  依赖：%s ｜ 最低系统（实测）：%s" % ("、".join(ins.get("needed_list") or []) or "（无）",
                                                   row.get("min_os_str") or "?"))
            if row["static_problems_list"]:
                say("  ✗ 静态闸（四个二进制）%d 条：" % len(row["static_problems_list"]))
                for p in row["static_problems_list"]:
                    say("      " + p)
            else:
                say("  ✓ 静态闸：库 / 探针 / 纯 C 示例 / 命令行 四个二进制的格式、架构、rpath、签名、装载路径都对")
            if row["api_extra_list"]:
                say("  ⚠ 导出面多出 %d 个内部符号（出包冒烟的导出面闸会红）：%s"
                    % (len(row["api_extra_list"]), "、".join(row["api_extra_list"][:4]) + (" …" if len(row["api_extra_list"]) > 4 else "")))
            say("  ⚠ verified_on_target = false —— 没在目标平台跑过 golden，**不是交付件**")
        else:
            say("✗ %s 失败在「%s」：" % (t, row["stage_str"]))
            for line in (row.get("log_str") or "").splitlines()[-12:]:
                print("      " + line)
    OUT.mkdir(parents=True, exist_ok=True)
    # ★409 按目标合并：这次编的覆盖同名目标，其余目标的记录保留（它们的 prebuilt/ 还在；是否过期由打包时的指纹闸判）
    old_rows: List[Dict[str, Any]] = []
    if (OUT / "cross_info.json").is_file():
        try:
            old_rows = json.loads((OUT / "cross_info.json").read_text(encoding="utf-8")).get("targets_list", [])
        except (ValueError, OSError):
            old_rows = []
    fresh = {r["target_str"] for r in rows}
    merged = [r for r in old_rows if r.get("target_str") not in fresh and (OUT / str(r.get("target_str"))).is_dir()] + rows
    report = {"host_str": "%s %s" % (platform.system(), platform.machine()),
              "zig_str": str(zig), "ninja_str": str(ninja), "built_at_str": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
              "targets_list": sorted(merged, key=lambda r: r["target_str"]),
              "note_str": "交叉编译产物一律 verified_on_target=false；正式交付走 CI 或目标平台真机（docs/跨平台出包.md）"}
    (OUT / "cross_info.json").write_text(json.dumps(report, ensure_ascii=False, indent=1), encoding="utf-8")
    print("\n报告：%s" % (OUT / "cross_info.json"))
    return 0 if all(r["ok_bool"] for r in rows) else 1


if __name__ == "__main__":
    raise SystemExit(main())
