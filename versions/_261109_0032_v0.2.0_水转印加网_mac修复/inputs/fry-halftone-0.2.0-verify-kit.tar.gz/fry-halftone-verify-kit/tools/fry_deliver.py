# -*- coding: utf-8 -*-
r"""fry_deliver.py —— 把**刚出包并冒烟通过**的动态库交付回算法仓（界面功能 HS200_halftone_dll 用的就是这一份）。

【为什么需要它】算法仓的界面要调 dll，dll 却只能在本仓（打包仓）编出来 ⇒ 必然有一份**拷贝**住在算法仓里。
  副本不会自己更新、也不报错 ⇒ 交付时写一份 sdk_info.json（版本 / 算法指纹 / 平台 / 交付时间 / dll 的 sha256），
  算法仓那边：① 运行时比对「dll 自报的指纹」与「算法仓 C++ 源码现在的指纹」，不一致就在结果里提示；
            ② 测试里比对 sdk_info.json 与 dll 本身（sha256）—— 手工换了 dll 却没更新说明，当场红。

【前置条件（不满足就拒绝交付）】
  · out/sdk/fry-halftone-sdk/ 存在（先跑 python tools/fry_build.py）；
  · out/build_report.json 说冒烟通过（smoke_bool = true）——**没冒烟的包不许进算法仓**；
  · 包里的算法指纹 == 算法仓 fry_project_components_cpp 现在的指纹（否则交付的是旧算法，拒绝；--allow-stale 可强行）；
  · ★387 包里 sdk_info.json 记的 dll sha256 == bin/ 里 dll 现算（出包后 dll 被换过 ⇒ 拒绝）。
【★387 交付什么】dll + 头文件 + sdk_info.json + params_schema.json（库自报的参数说明）+ SDK_参数说明.md ——
  算法仓 HS200 的参数覆盖闸直接读 params_schema.json / 库自报对账，不再正则去扒 C++ 源码。
【★393 再加三样】VERSION（一眼看版本）+ verify_delivery.py（装机目录也能自检）+ delivery_manifest.json
  （机读清单，runtime 等级、平铺布局）—— 交付完当场按清单查一遍，缺件就判失败。

【★449 变体交付（不动原先 dll）】--variant <关键词> ⇒ 交付到 _bin/<平台>_<YYMMDD_HHMM>_<关键词>/（如
  _bin/win32-x64_261027_0300_wt_unified/），**原先的 _bin/<平台>/ 一个字节不碰**（交付前后各算一次它的 sha256 当场核对）。
  为什么：新 dll 多了统一引擎，但老 dll 可能还要用（复现旧结果 / 给老调用方）⇒ 新旧并存，用「时间 + 关键词」区分；
  算法仓 HS200 按算法自动挑：legacy → 原先那份，统一引擎 → 最新的变体（也可在界面直接选文件夹）。
  同名变体目录已存在 ⇒ 拒绝（每个变体只写一次，免得悄悄覆盖掉别人正在用的那份）；--stamp 可指定时间戳
  （fry_release 用它让变体目录与全交付目录同一个时间戳）。

【用法】python tools/fry_deliver.py --algo-repo <算法仓根目录> [--allow-stale] [--variant <关键词> [--stamp YYMMDD_HHMM]]
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import shutil
import sys
import time
from typing import List
from pathlib import Path

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO / "tools"))
import fry_build    # noqa: E402
import fry_delivery_contract as DC  # noqa: E402  ★393 装机目录也按清单交付 + 自检
import fry_payload  # noqa: E402

TARGET_REL = Path("fry_project_components") / "HS200_halftone_dll" / "_bin"
VARIANT_KEYWORD_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,47}$")     # ★449 只许 ASCII：目录名要过 .bat / cmd / 各平台
STAMP_RE = re.compile(r"^\d{6}_\d{4}$")                                  # YYMMDD_HHMM（与全交付目录 _YYMMDD_HHMM_ 同格式）


def variant_dir_name(tag: str, keyword: str, stamp: str) -> str:
    """★449 变体目录名 = <平台>_<YYMMDD_HHMM>_<关键词>（纯函数；关键词 / 时间戳不合法就报错，不悄悄改写）。"""
    if not VARIANT_KEYWORD_RE.match(keyword or ""):
        raise ValueError("变体关键词只许字母 / 数字 / _ . -（以字母或数字开头，≤ 48 个字符），收到 %r" % keyword)
    if not STAMP_RE.match(stamp or ""):
        raise ValueError("时间戳必须形如 261027_0300（YYMMDD_HHMM），收到 %r" % stamp)
    return "%s_%s_%s" % (tag, stamp, keyword)


def _sha_or_none(p: Path):
    return hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else None


def main(argv=None) -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    ap = argparse.ArgumentParser(description="把出好包的动态库交付回算法仓")
    ap.add_argument("--algo-repo", required=True)
    ap.add_argument("--allow-stale", action="store_true", help="算法仓 C++ 源码与包里的指纹不一致也交付（⚠ 只给排障用）")
    ap.add_argument("--variant", default="", help="★449 交付成新的一份：_bin/<平台>_<YYMMDD_HHMM>_<关键词>/，原先的 _bin/<平台>/ 不动")
    ap.add_argument("--stamp", default="", help="★449 变体目录的时间戳 YYMMDD_HHMM（默认现在）")
    ns = ap.parse_args(argv)
    if ns.stamp and not ns.variant:
        print("✗ --stamp 只和 --variant 一起用")
        return 1
    algo = Path(ns.algo_repo).resolve()
    row = fry_build.plat()
    sdk = REPO / "out" / "sdk" / fry_build.SDK_NAME
    report_path = REPO / "out" / "build_report.json"
    if not (sdk / "bin" / row["lib"]).is_file() or not report_path.is_file():
        print("✗ 还没出包：先跑 python tools/fry_build.py")
        return 1
    report = json.loads(report_path.read_text(encoding="utf-8"))
    if not report.get("smoke_bool"):
        print("✗ 上一次出包跳过了冒烟 —— 没被验证过的库不许交付进算法仓")
        return 1
    info = json.loads((sdk / "sdk_info.json").read_text(encoding="utf-8"))
    src_now = fry_payload.tree_sha256(fry_payload.scan(algo / fry_payload.SOURCE_SUBDIR_STR))
    if src_now != info["algorithm_fingerprint_str"]:
        msg = "包里的算法指纹 %s ≠ 算法仓 C++ 源码现在的指纹 %s（C++ 改过，请先同步载荷再出包）" % (
            info["algorithm_fingerprint_str"][:16], src_now[:16])
        if not ns.allow_stale:
            print("✗ " + msg)
            return 1
        print("⚠ " + msg + " —— --allow-stale 强行交付")
    pkg_sha = hashlib.sha256((sdk / "bin" / row["lib"]).read_bytes()).hexdigest()
    if info.get("library_sha256_str") and info["library_sha256_str"] != pkg_sha:
        print("✗ 包里 sdk_info.json 记的 dll sha256 %s ≠ bin/%s 现算 %s（出包后 dll 被换过？重新出包）"
              % (info["library_sha256_str"][:16], row["lib"], pkg_sha[:16]))
        return 1
    original = algo / TARGET_REL / row["tag"] / row["lib"]
    original_sha_before = _sha_or_none(original)
    if ns.variant:
        try:
            dst = algo / TARGET_REL / variant_dir_name(row["tag"], ns.variant, ns.stamp or time.strftime("%y%m%d_%H%M"))
        except ValueError as e:
            print("✗ %s" % e)
            return 1
        if dst.exists() and any(dst.iterdir()):
            print("✗ 变体目录 %s 已存在 —— 每个变体只写一次（别人可能正在用）；换个关键词，或过一分钟再交付" % dst)
            return 1
    else:
        dst = algo / TARGET_REL / row["tag"]
    # ★393 装机目录的清场：先探「旧 dll 是不是被占用」，再动手 —— 顺序反了会**先把目录删掉一半**才失败
    #   （实测：界面开着时 Windows 锁住 dll，rmtree 崩在半路，报的还是一串 PermissionError 堆栈，没人看得懂）。
    #   被占用时不放弃：Windows **允许给打开着的文件改名** ⇒ 把旧的改名让路，新的照常写进去；
    #   正在运行的那个软件继续用它手里那一份（本来也换不了热的），重启后自然用上新的。
    stale_note = ""
    if dst.exists():
        locked: List[Path] = []
        for p in sorted(dst.rglob("*"), reverse=True):
            if p.is_dir():
                continue
            if p.name.endswith(".old"):                        # 上一次让路留下的：能删就删掉
                try:
                    p.unlink()
                except PermissionError:
                    pass
                continue
            try:
                p.unlink()
            except PermissionError:
                target = p.with_name("%s_被占用_%s.old" % (p.name, time.strftime("%y%m%d_%H%M%S")))
                try:
                    p.rename(target)
                    locked.append(p)
                except OSError as e:
                    print("✗ %s 既删不掉也改不了名：%s —— 请先关掉加网软件再重新交付" % (p, e))
                    return 3
        if locked:
            stale_note = "⚠ %s 当时正被占用（加网软件开着）⇒ 旧文件已改名让路，新的已写入；**正在运行的那个软件要重启才会用上新 dll**" % (
                "、".join(p.name for p in locked))
            print(stale_note)
    dst.mkdir(parents=True, exist_ok=True)
    shutil.copy2(sdk / "bin" / row["lib"], dst / row["lib"])
    shutil.copy2(sdk / "include" / "fry_halftone.h", dst / "fry_halftone.h")
    for name in (fry_build.PS.SCHEMA_FILE_NAME_STR, fry_build.PS.DOC_FILE_NAME_STR):
        if (sdk / name).is_file():
            shutil.copy2(sdk / name, dst / name)
        else:
            print("⚠ 包里没有 %s（★387 之前出的包）—— 算法仓的参数对账会退回「没查」" % name)
    # ★393 装机目录也要够「自证完整」：版本文件 + 自检脚本（清单最后写，因为它要记别人的 sha256）
    for name in ("VERSION", "verify_delivery.py"):
        if (sdk / name).is_file():
            shutil.copy2(sdk / name, dst / name)
        else:
            print("⚠ 包里没有 %s（★393 之前出的包）" % name)
    lib_sha = hashlib.sha256((dst / row["lib"]).read_bytes()).hexdigest()
    if lib_sha != pkg_sha:
        print("✗ 复制后的 dll sha256 %s ≠ 包里 %s（磁盘 / 杀毒软件改了文件？）" % (lib_sha[:16], pkg_sha[:16]))
        return 1
    delivered = dict(info, delivered_at_str=time.strftime("%Y-%m-%dT%H:%M:%S%z"), library_sha256_str=lib_sha,
                     build_report_dict={k: report.get(k) for k in ("version_str", "total_s_float", "smoke_dict")},
                     source_now_fingerprint_str=src_now, stale_bool=src_now != info["algorithm_fingerprint_str"],
                     variant_str=ns.variant, delivered_dir_str=dst.name)                    # ★449 哪一份（空 = 原先那份）
    (dst / "sdk_info.json").write_text(json.dumps(delivered, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
    # ★393 装机目录的清单（runtime 等级、平铺布局）—— 算法仓 HS200 每次跑之前照着它查一遍
    DC.write_manifest(dst, "runtime", "%s-%s-%s(装机)" % (fry_build.PACKAGE_NAME, info.get("version_str", "?"), row["tag"]), flat=True)
    res = DC.check(dst, "runtime", check_version=False)
    if not res["ok_bool"]:
        DC.report(res, "交付后自检")
        print("✗ 交付到算法仓之后按 runtime 等级一查就缺件 —— 交付脚本漏拷了东西")
        return 1
    print("✓ 装机目录按 runtime 等级 %d 项齐全（清单 %s 已随行）" % (res["checked_int"], DC.MANIFEST_NAME_STR))
    print("✓ 已交付 %s → %s（%.2f MB，指纹 %s，sha256 %s）" % (row["lib"], dst, (dst / row["lib"]).stat().st_size / 1048576.0,
                                                         info["algorithm_fingerprint_str"][:16], lib_sha[:16]))
    if ns.variant:                                     # ★449「不动原先 dll」要有证据，不是口头保证
        after = _sha_or_none(original)
        if after != original_sha_before:
            print("✗ 原先的 %s 在交付变体时被改了（%s → %s）—— 这不该发生，请检查" % (original, str(original_sha_before)[:16], str(after)[:16]))
            return 1
        print("✓ 原先的 %s 一个字节没动（sha256 %s，交付前后相同）" % (
            original.parent.name + "/" + original.name, (after or "（原先就没有）")[:16]))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
