@echo off
rem === fry-halftone: one-click release (3 platforms bundle) + deliver a NEW dll variant into the algorithm repo (449) ===
rem Pure-ASCII only: cmd parses .bat in the OEM codepage; Chinese defaults live in fry_oneclick_release.py (UTF-8).
rem The original dll in HS200_halftone_dll\_bin\win32-x64\ is never touched; the new one goes to
rem   HS200_halftone_dll\_bin\win32-x64_<YYMMDD_HHMM>_<keyword>\
rem Extra arguments are passed through, e.g.:  fry_oneclick_release.bat --variant wt_unified --parity none
chcp 65001 >nul
set "HERE=%~dp0"
set "MC=%HERE%..\..\fry_py_260604_c180_depth_dither_more\fry_bats\machine_config.bat"
if exist "%MC%" call "%MC%"
if not defined PY set "PY=python"

echo ============================================================
echo   fry-halftone one-click release + deliver (new dll variant)
echo   python : %PY%
echo   log    : out\oneclick\_YYMMDD_HHMM_oneclick.log
echo ============================================================
echo.
"%PY%" -X utf8 "%HERE%fry_oneclick_release.py" %*
set "RC=%ERRORLEVEL%"
echo.
echo ============================================================
echo   Done (exit code %RC%)
echo ============================================================
pause
exit /b %RC%
