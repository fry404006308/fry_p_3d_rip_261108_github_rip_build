# -*- coding: utf-8 -*-
r"""fry_surface.py —— ★412 「对外接口面」与「这一版该升哪一位」（纯函数为主，出包前 / 出包后 / 交付时共用这一份）。

【为什么】411 起交付版本号由交付记录递增，但默认只加修订号：改了算法和只改了错别字都是 +0.0.1，
  同事从号码上看不出「要不要重新验证」。⇒ 按 SemVer（semver.org）从「这一版对外变了什么」自动定升哪一位：
    · 对外接口面 = 三张清单：C 接口（头文件里的函数声明）｜ 参数（参数表的名字 + 类型）｜ 命令行（子命令 + 开关）；
    · 删了 / 改了任何一项 = 不兼容 → 主版本；加了 = 新功能 → 次版本；算法指纹变了（输出会变，同事要重新验证）→ 次版本；
      只有外壳实现 / 文档 / 打包变了 → 修订号；
    · ★ 0.x 期间（SemVer §4：初始开发期，接口还不稳定）不兼容的改动升**次版本**，不自动跳 1.0.0 —— 1.0.0 要人决定。
【两把尺子】接口面有两种量法，必须一致（B.1-43：闸自己也要有尺子）：
    A 出包前从**源码**解析（头文件 / cpp/src/api/job.cpp 的 kSpecs / src/cli 的字面量）—— 用来在编译前定版本号；
    B 出包后从**产物**读（params_schema.json / 真跑 `--help`）—— A ≠ B 说明源码解析器瞎了，直接报错，不许带着错的判断交付。
【上一版没记接口面】（0.1.0 / 0.1.1 的记录里没有）：接口面是源码的函数，而头文件 / 命令行源码在外壳指纹里、参数表在算法指纹里
    ⇒ 两个指纹都与上一版相同 ⇒ 接口面必然相同（可以推断）；指纹变了又没记录 ⇒ 判「不知道」、要求人工 --bump（大声，不猜）。
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

REPO = Path(__file__).resolve().parents[1]
SURFACE_SCHEMA = "fry-halftone-surface/1"
LEVELS = ("none", "patch", "minor", "major")
CATS = (("api_list", "C 接口"), ("params_list", "参数"), ("cli_list", "命令行"))

HEADER_REL = "include/fry_halftone.h"
PARAMS_REL = "cpp/src/api/job.cpp"
CLI_REL = "src/cli/fry_halftone_cli.cpp"


# ───────────────────────── 解析：源码（尺子 A）─────────────────────────
def api_from_header(text: str) -> List[str]:
    """头文件里行首的 `FRY_API <ret> FRY_CALL <name>(<args>);` → 规范化的 `ret name(args)`（按名字排序）。
    ⚠ 只认行首：前面 `#  define FRY_API …` 那几行也含 FRY_API，不锚行首会把宏定义吞进第一个函数的返回类型。"""
    decls = re.findall(r"^FRY_API\s+([^;(#]+?)\s+FRY_CALL\s+(\w+)\s*\(([^;]*?)\)\s*;", text, flags=re.M)
    return sorted(("%s %s(%s)" % (" ".join(r.split()), n, " ".join(a.split()))) for r, n, a in decls)


def params_from_source(text: str) -> List[str]:
    """cpp/src/api/job.cpp 的 `const Spec kSpecs[] = { {"name", "kind", …}, … };` → `name:kind`（按名字排序）。"""
    m = re.search(r"kSpecs\[\]\s*=\s*\{(.*?)\n\};", text, flags=re.S)
    if not m:
        return []
    return sorted("%s:%s" % (n, k) for n, k in re.findall(r'\{\s*"(\w+)"\s*,\s*"(\w+)"', m.group(1)))


def cli_from_source(text: str) -> List[str]:
    """src/cli 里的子命令（`a[1] == "slice"`）与长开关（`"--out"` 字面量）。别名 help / -h / -v 不算（--help / --version 已算）。"""
    subs = set(re.findall(r'a\[1\]\s*==\s*"([a-z]+)"', text)) - {"help"}
    opts = set(re.findall(r'"(--[a-z][a-z0-9-]*)"', text))
    return sorted(subs) + sorted(opts)


def source_surface(repo: Optional[Path] = None) -> Dict[str, Any]:
    repo = repo or REPO
    read = lambda rel: (repo / rel).read_text(encoding="utf-8") if (repo / rel).is_file() else ""   # noqa: E731
    return {"schema_str": SURFACE_SCHEMA, "api_list": api_from_header(read(HEADER_REL)),
            "params_list": params_from_source(read(PARAMS_REL)), "cli_list": cli_from_source(read(CLI_REL))}


# ───────────────────────── 解析：产物（尺子 B）─────────────────────────
def params_from_schema(schema: Dict[str, Any]) -> List[str]:
    """库自己导出的 params_schema.json → `name:kind`（schema 每项的 `kind` 就是 kSpecs 里的 kind）。
    ⚠ 412 第一版写成读 `type`（不存在 ⇒ 全是 None）—— 被「源码 ≠ 产物」这道闸当场抓到。"""
    return sorted("%s:%s" % (p.get("name"), p.get("kind")) for p in schema.get("params", []))


def cli_from_help(text: str) -> List[str]:
    """真跑 `fry-halftone-cli --help` 的原文 → 子命令（Usage 行里 `fry-halftone-cli <子命令>`）+ 长开关。"""
    subs = set(re.findall(r"^\s*fry-halftone-cli ([a-z]+)\b", text, flags=re.M))
    opts = set(re.findall(r"(?<![\w-])(--[a-z][a-z0-9-]*)", text))
    return sorted(subs) + sorted(opts)


def api_names(api_list: List[str]) -> List[str]:
    """`ret name(args)` → 函数名（排序）。"""
    return sorted(re.search(r"(\w+)\(", s).group(1) for s in api_list)


def surface_mismatch(src: Dict[str, Any], built: Dict[str, Any]) -> List[str]:
    """尺子 A（源码）vs 尺子 B（产物）：每张清单必须逐项相同（只比两边都量了的清单）。
    built 还可以带 `api_names_list`（库导出表里的名字，冒烟的导出面闸已证明 = 头文件）：C 接口只能按**名字**比，签名没有产物侧的尺子。"""
    probs = []
    for key, name in CATS:
        if key in built and built[key] != src.get(key):
            a, b = set(src.get(key) or []), set(built[key])
            probs.append("%s：源码解析 ≠ 产物（源码多 %s，产物多 %s）—— 源码解析器漏看了，按它定的版本号不可信"
                         % (name, sorted(a - b)[:4], sorted(b - a)[:4]))
    if "api_names_list" in built:
        a, b = set(api_names(src.get("api_list") or [])), set(built["api_names_list"])
        if a != b:
            probs.append("C 接口名：源码解析 ≠ 库的导出表（源码多 %s，导出表多 %s）—— 头文件解析器漏看了，按它定的版本号不可信"
                         % (sorted(a - b)[:4], sorted(b - a)[:4]))
    return probs


# ───────────────────────── 比较与判定 ─────────────────────────
def _names(items: List[str], key: str) -> Dict[str, str]:
    """清单项 → {身份: 全文}：C 接口按函数名、参数按参数名、命令行按项本身（改签名 / 改类型 = 同名不同文）。"""
    if key == "api_list":
        return {re.search(r"(\w+)\(", s).group(1): s for s in items}
    if key == "params_list":
        return {s.split(":", 1)[0]: s for s in items}
    return {s: s for s in items}


def diff_surface(prev: Dict[str, Any], cur: Dict[str, Any]) -> Dict[str, Dict[str, List[str]]]:
    out = {}
    for key, _ in CATS:
        a, b = _names(prev.get(key) or [], key), _names(cur.get(key) or [], key)
        out[key] = {"removed_list": sorted(set(a) - set(b)), "added_list": sorted(set(b) - set(a)),
                    "changed_list": sorted(k for k in set(a) & set(b) if a[k] != b[k])}
    return out


def _max(a: str, b: str) -> str:
    return a if LEVELS.index(a) >= LEVELS.index(b) else b


def required_bump(prev: Optional[Dict[str, Any]], cur: Dict[str, Any]) -> Dict[str, Any]:
    """这一版至少该升哪一位（纯函数）。
    prev / cur：{"version_str", "algorithm_fingerprint_str", "wrapper_sha256_str", "surface_dict"}（prev 可以没有 surface_dict）。
    返回 {"level_str": patch|minor|major|unknown, "reasons_list": [...], "diff_dict": {...}, "inferred_bool": 上一版接口面是推断的}。"""
    if not prev:
        return {"level_str": "patch", "reasons_list": ["第一次交付（没有上一版可比）"], "diff_dict": {}, "inferred_bool": False}
    reasons: List[str] = []
    level = "patch"
    same_algo = prev.get("algorithm_fingerprint_str") == cur.get("algorithm_fingerprint_str")
    same_wrap = prev.get("wrapper_sha256_str") == cur.get("wrapper_sha256_str")
    prev_surface = prev.get("surface_dict")
    inferred = False
    if not prev_surface:
        if same_algo and same_wrap:
            prev_surface, inferred = cur.get("surface_dict") or {}, True
        else:
            return {"level_str": "unknown", "diff_dict": {}, "inferred_bool": False, "reasons_list": [
                "上一版 %s 的记录里没有接口面，而%s变了 —— 没法自动判断接口有没有变，请用 --bump 指定" % (
                    prev.get("version_str"), "、".join(x for x, s in (("算法指纹", same_algo), ("外壳指纹", same_wrap)) if not s))]}
    diff = diff_surface(prev_surface, cur.get("surface_dict") or {})
    for key, name in CATS:
        d = diff[key]
        if d["removed_list"] or d["changed_list"]:
            level = _max(level, "major")
            reasons.append("%s有不兼容的改动：删了 %s，改了 %s" % (name, d["removed_list"] or "无", d["changed_list"] or "无"))
        if d["added_list"]:
            level = _max(level, "minor")
            reasons.append("%s加了 %s（新功能，兼容）" % (name, d["added_list"]))
    if not same_algo:
        level = _max(level, "minor")
        reasons.append("算法指纹变了（%s… → %s…）：输出会变，同事要重新验证" % (
            str(prev.get("algorithm_fingerprint_str"))[:12], str(cur.get("algorithm_fingerprint_str"))[:12]))
    if not same_wrap and level == "patch":
        reasons.append("外壳 / 命令行的实现变了，对外接口面没变")
    if level == "patch" and same_algo and same_wrap:
        reasons.append("算法、外壳、接口面都没变：只有文档 / 打包变化")
    return {"level_str": level, "reasons_list": reasons, "diff_dict": diff, "inferred_bool": inferred}


def effective_level(level: str, prev_version: Optional[str]) -> Tuple[str, str]:
    """★ 0.x 规则：主版本号还是 0 时，不兼容的改动升次版本（SemVer §4），不自动跳 1.0.0。返回 (实际升的位, 说明)。"""
    if level == "major" and prev_version and prev_version.split(".")[0] == "0":
        return "minor", "0.x 期间不兼容的改动升次版本（SemVer §4）；1.0.0 要人决定（Mac 验收通过、接口承诺稳定之后）"
    return level, ""


def bump_level(old: Optional[str], new: str) -> str:
    """两个版本号之间升的是哪一位：major / minor / patch / none（同号）/ first（没有旧号）。"""
    if not old:
        return "first"
    a, b = [tuple(int(x) for x in v.split(".")) for v in (old, new)]
    if b == a:
        return "none"
    if b[0] != a[0]:
        return "major"
    return "minor" if b[1] != a[1] else "patch"


def bump_problems(old: Optional[str], new: str, required: Dict[str, Any]) -> List[str]:
    """交付时的闸：实际升的位够不够（手填 --version 也要过它）。unknown = 上一版没记接口面又变了指纹：放行但说明里写明没核对。"""
    if not old or required.get("level_str") in (None, "unknown"):
        return []
    need, note = effective_level(required["level_str"], old)
    got = bump_level(old, new)
    if got == "none":
        return []                                      # 同号重出目录：由「同号同字节」那道闸管
    order = {"patch": 1, "minor": 2, "major": 3}
    if order[got] < order[need]:
        return ["版本号 %s → %s 只升了%s，但这一版至少要升%s：%s%s" % (
            old, new, {"patch": "修订号", "minor": "次版本", "major": "主版本"}[got],
            {"patch": "修订号", "minor": "次版本", "major": "主版本"}[need], "；".join(required["reasons_list"]),
            "（%s）" % note if note else "")]
    return []
