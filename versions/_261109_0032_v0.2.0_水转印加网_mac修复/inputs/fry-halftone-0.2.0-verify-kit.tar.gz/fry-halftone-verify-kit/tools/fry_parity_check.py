# -*- coding: utf-8 -*-
r"""fry_parity_check.py —— ★412 跨平台一致性复核：交付的 Windows 包与 Linux 包，对同一批真实模型出片，逐张逐字节比。

【来源】410 / 411 在算法仓 docs 里手动跑的三个实验脚本（c410_parity_run / c410_parity_compare / c410_wsl_parity.sh），
  411 的建议 ②：并进一键出包（fry_release --bundle），一条命令就得到最全的证据。输出格式与 410 完全相同
  ⇒ 全交付目录的闸（全一致 / 跑的就是交付的那份库 / 版本对得上）原样适用。
【模型清单】tools/fry_parity_models.json：目录 + 期望个数（**个数不对就大声失败**，防止模型集悄悄变小 —— B.1-14）；
  清单是本机路径，换机器请改它，或 fry_release --parity none 明确跳过（交付说明会写「这一版没做」）。
【判据】每个模型三样都相同：返回码（该拒收的件各平台同样拒收）、切片张数、digest = sha256(「文件名 md5」逐行) ⇔ 每张 BMP 逐字节相同。
  另记：每个平台跑的是哪份库（库 / 命令行的 sha256）、库自报的算法指纹 —— 证明「证据 = 交付的那份字节」。

用法：
  python tools/fry_parity_check.py --win-zip out/fry-halftone-X-win32-x64.zip --linux prebuilt=out/linux/prebuilt/…tar.zst
                                   [--linux native=out/linux/native/…tar.zst] [--config tools/fry_parity_models.json] --out-dir out/parity
  子命令（在某一个平台上跑一批模型；WSL 里就是这样被调用的）：
  python fry_parity_check.py run --cli <bin/fry-halftone-cli> --models-list <清单> --out <结果.json> --tag win --edge-mm 10
"""
from __future__ import annotations

import argparse
import hashlib
import json
import platform
import shutil
import subprocess
import sys
import tempfile
import time
import zipfile
from itertools import combinations
from pathlib import Path
from typing import Any, Dict, List, Optional

REPO = Path(__file__).resolve().parents[1]
CONFIG = REPO / "tools" / "fry_parity_models.json"
LIB_NAMES = ("fry_halftone.dll", "libfry_halftone.so", "libfry_halftone.dylib")
PARAMS = {"ink_c_um": 400, "ink_m_um": 500, "ink_y_um": 300, "use_black_k": False}     # 与 409 / 410 / 411 同一套参数
TAG_NAMES = {"win": "Windows · MSVC", "linux_native": "Linux · gcc 原生", "linux_prebuilt": "Linux · zig 交叉（交付件）"}


def sha256_file(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


# ───────────────────────── 在一个平台上跑一批（Windows 与 WSL 同一份代码）─────────────────────────
def run_one(cli: str, model: str, work: Path, params_file: Path, edge_mm: float, timeout_s: int) -> Dict[str, Any]:
    out_dir = work / "slices"
    if out_dir.exists():
        shutil.rmtree(out_dir)
    cmd = [cli, "slice", model, "--target-longest-edge", str(edge_mm), "--params", str(params_file), "--out", str(out_dir)]
    t0 = time.perf_counter()
    try:
        r = subprocess.run(cmd, capture_output=True, timeout=timeout_s)
        rc, err = r.returncode, r.stderr.decode("utf-8", "replace")
    except subprocess.TimeoutExpired:
        rc, err = -9, "timeout %d s" % timeout_s
    sec = time.perf_counter() - t0
    bmps = sorted(out_dir.glob("*.bmp")) if out_dir.is_dir() else []
    md5_list = [[p.name, hashlib.md5(p.read_bytes()).hexdigest()] for p in bmps]
    digest = hashlib.sha256("".join("%s %s\n" % (n, m) for n, m in md5_list).encode("utf-8")).hexdigest()
    total = sum(p.stat().st_size for p in bmps)
    shutil.rmtree(out_dir, ignore_errors=True)
    return {"rc": rc, "seconds": round(sec, 3), "slices": len(bmps), "bytes": total, "digest": digest,
            "md5_list": md5_list, "err_tail": "\n".join(err.strip().splitlines()[-3:])}


def run_models(cli: Path, models: List[str], out_json: Path, tag: str, edge_mm: float, timeout_s: int = 900) -> Dict[str, Any]:
    cli = cli.resolve()
    lib = next((cli.parent / n for n in LIB_NAMES if (cli.parent / n).is_file()), None)
    if lib is None:
        raise SystemExit("命令行旁边没有库（%s）—— 必须用解包后的完整 bin/ 跑" % "、".join(LIB_NAMES))
    info_raw = subprocess.run([str(cli), "info", "--json"], capture_output=True).stdout.decode("utf-8", "replace").strip()
    try:
        info = json.loads(info_raw.splitlines()[-1]) if info_raw else {}
    except ValueError:
        info = {"raw_str": info_raw}
    res: Dict[str, Any] = {
        "tag": tag, "host": "%s %s（%s）" % (platform.system(), platform.machine(), platform.platform()), "params": PARAMS,
        "edge_mm": edge_mm, "cli_version": subprocess.run([str(cli), "--version"], capture_output=True).stdout.decode("utf-8", "replace").strip(),
        "lib_name": lib.name, "lib_sha256": sha256_file(lib), "cli_sha256": sha256_file(cli), "info": info, "models": {}}
    work = Path(tempfile.mkdtemp(prefix="fry_parity_"))
    params_file = work / "params.json"
    params_file.write_text(json.dumps(PARAMS), encoding="utf-8")
    t_all = time.perf_counter()
    try:
        for i, m in enumerate(models, 1):
            name = Path(m.replace("\\", "/")).name
            res["models"][name] = row = run_one(str(cli), m, work, params_file, edge_mm, timeout_s)
            el = time.perf_counter() - t_all
            print("[%s] %2d/%d rc=%d %6.2f s %5d 张 %s ｜ 已用 %.0f s ｜ 预计还要 %.0f s"
                  % (tag, i, len(models), row["rc"], row["seconds"], row["slices"], name, el, el / i * (len(models) - i)), flush=True)
    finally:
        shutil.rmtree(work, ignore_errors=True)
    res["total_seconds"] = round(sum(r["seconds"] for r in res["models"].values()), 2)
    out_json.parent.mkdir(parents=True, exist_ok=True)
    out_json.write_text(json.dumps(res, ensure_ascii=False, indent=0), encoding="utf-8")
    return res


# ───────────────────────── 比较（纯函数）─────────────────────────
def fingerprint_of(info: Dict[str, Any]) -> str:
    for k, v in (info or {}).items():
        if "fingerprint" in k.lower() and isinstance(v, str) and len(v) == 64:
            return v
    return ""


def compare(runs: Dict[str, Dict[str, Any]], suffix: str = "") -> Dict[str, Any]:
    """两两比（返回码 + 张数 + digest）；输出 {"summary", "rows"}，summary 与 410 的 compare 同形（交付闸直接认）。"""
    tags = [t for t in ("win", "linux_native", "linux_prebuilt") if t in runs] + sorted(t for t in runs if t not in TAG_NAMES)
    if "win" not in runs or len(tags) < 2:
        raise ValueError("至少要 Windows 加一个 Linux 才能比（现在只有 %s）" % tags)
    names = sorted(set.intersection(*(set(runs[t]["models"]) for t in tags)))
    missing = {t: sorted(set(runs[t]["models"]) - set(names)) for t in tags if set(runs[t]["models"]) - set(names)}
    rows, pair_same = [], {"%s=%s" % (a, b): 0 for a, b in combinations(tags, 2)}
    for n in names:
        ms = {t: runs[t]["models"][n] for t in tags}
        row = {"model": n, "rc": {t: ms[t]["rc"] for t in tags}, "slices": {t: ms[t]["slices"] for t in tags},
               "seconds": {t: ms[t]["seconds"] for t in tags}, "bytes": ms["win"]["bytes"]}
        for a, b in combinations(tags, 2):
            same = ms[a]["rc"] == ms[b]["rc"] and ms[a]["slices"] == ms[b]["slices"] and ms[a]["digest"] == ms[b]["digest"]
            diff = 0
            if not same:
                da, db = dict(tuple(x) for x in ms[a]["md5_list"]), dict(tuple(x) for x in ms[b]["md5_list"])
                diff = sum(1 for k in set(da) | set(db) if da.get(k) != db.get(k))
            row["%s=%s" % (a, b)] = {"same": same, "diff_slices": diff}
            pair_same["%s=%s" % (a, b)] += int(same)
        rows.append(row)
    summary = {"suffix": suffix, "edge_mm": runs["win"].get("edge_mm"), "params": runs["win"].get("params"),
               "model_count": len(names), "total_slices_win": sum(r["slices"]["win"] for r in rows),
               "total_bytes_win": sum(r["bytes"] for r in rows), "pair_identical_models": pair_same,
               "all_identical": bool(names) and not missing and all(v == len(names) for v in pair_same.values()),
               "missing_models_dict": missing,
               "rc_nonzero": {r["model"]: r["rc"] for r in rows if any(v != 0 for v in r["rc"].values())},
               "total_seconds": {t: round(sum(r["seconds"][t] for r in rows), 1) for t in tags},
               "hosts": {t: runs[t].get("host") for t in tags},
               "cli_versions": {t: runs[t].get("cli_version") for t in tags},
               "lib_sha256_dict": {t: runs[t].get("lib_sha256", "") for t in tags},
               "cli_sha256_dict": {t: runs[t].get("cli_sha256", "") for t in tags},
               "algorithm_fingerprint_dict": {t: fingerprint_of(runs[t].get("info")) for t in tags}}
    return {"summary": summary, "rows": rows}


# ───────────────────────── 模型清单 ─────────────────────────
def load_models(config: Path) -> Dict[str, Any]:
    """{"models_list", "edge_mm_list", "problems_list"}：目录里的 *.glb（排序）+ 期望个数核对。"""
    if not config.is_file():
        return {"models_list": [], "edge_mm_list": [], "problems_list": ["没有一致性模型清单 %s" % config]}
    cfg = json.loads(config.read_text(encoding="utf-8"))
    models: List[str] = []
    probs: List[str] = []
    for d in cfg.get("dirs_list", []):
        p = Path(d)
        if not p.is_dir():
            probs.append("模型目录不存在：%s" % d)
            continue
        models += sorted(str(x) for x in p.glob("*.glb"))
    if len(models) != int(cfg.get("expect_count_int", -1)):
        probs.append("模型个数 %d ≠ 清单期望的 %s（目录变了？）—— 个数不对的复核不能当证据" % (len(models), cfg.get("expect_count_int")))
    return {"models_list": models, "edge_mm_list": [float(x) for x in cfg.get("edge_mm_list", [10.0])], "problems_list": probs}


# ───────────────────────── 总调度：Windows 本机 + WSL ─────────────────────────
def run_all(win_zip: Path, linux: Dict[str, Path], config: Path, out_dir: Path) -> List[Path]:
    import fry_wsl as W
    cfg = load_models(config)
    if cfg["problems_list"]:
        raise SystemExit("✗ 一致性复核的模型清单有问题：%s" % "；".join(cfg["problems_list"]))
    out_dir.mkdir(parents=True, exist_ok=True)
    models = cfg["models_list"]
    (out_dir / "models_win.txt").write_text("\n".join(models) + "\n", encoding="utf-8")
    (out_dir / "models_wsl.txt").write_bytes(("\n".join(W.path(Path(m)) for m in models) + "\n").encode("utf-8"))
    work = Path(tempfile.mkdtemp(prefix="fry_parity_win_"))
    written: List[Path] = []
    try:
        with zipfile.ZipFile(win_zip) as zf:
            zf.extractall(work)
        cli = work / "fry-halftone" / "bin" / "fry-halftone-cli.exe"
        for edge in cfg["edge_mm_list"]:
            suf = "_e%g" % edge
            runs = {"win": run_models(cli, models, out_dir / ("parity_win%s.json" % suf), "win", edge)}
            lines = ["#!/usr/bin/env bash", "set -u", 'W="$HOME/fry_parity412"', 'rm -rf "$W" && mkdir -p "$W"',
                     'cp -f "%s" "$W/"' % W.path(Path(__file__))]
            for tag, arc in linux.items():
                lines += ['mkdir -p "$W/%s" && tar --zstd -xf "%s" -C "$W/%s"' % (tag, W.path(arc), tag),
                          'python3 "$W/fry_parity_check.py" run --cli "$W/%s/fry-halftone/bin/fry-halftone-cli" --models-list "%s" '
                          '--out "%s" --tag linux_%s --edge-mm %g; echo "@@RC %s $?"' % (
                              tag, W.path(out_dir / "models_wsl.txt"), W.path(out_dir / ("parity_linux_%s%s.json" % (tag, suf))),
                              tag, edge, tag)]
            lines += ['rm -rf "$W"']
            r = W.run_lines(lines, out_dir / "parity_wsl.sh")
            print(W.text(r.stdout)[-3000:], flush=True)
            for tag in linux:
                p = out_dir / ("parity_linux_%s%s.json" % (tag, suf))
                if not p.is_file():
                    raise SystemExit("✗ WSL 里 %s 那一轮没有产出结果（%s）：%s" % (tag, p.name, W.text(r.stderr)[-500:]))
                runs["linux_" + tag] = json.loads(p.read_text(encoding="utf-8"))
            res = compare(runs, suf)
            out = out_dir / ("compare%s.json" % suf)
            out.write_text(json.dumps(res, ensure_ascii=False, indent=1), encoding="utf-8")
            s = res["summary"]
            print("%s 一致性（最长边 %g mm）：%d 个模型、Windows %s 张；%s ｜ 拒收 %s → %s" % (
                "✓" if s["all_identical"] else "✗", edge, s["model_count"], format(s["total_slices_win"], ","),
                "、".join("%s %d/%d" % (k, v, s["model_count"]) for k, v in s["pair_identical_models"].items()),
                list(s["rc_nonzero"]) or "无", out), flush=True)
            written.append(out)
    finally:
        shutil.rmtree(work, ignore_errors=True)
    return written


def main(argv: Optional[List[str]] = None) -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    argv = list(sys.argv[1:] if argv is None else argv)
    if argv[:1] == ["run"]:
        ap = argparse.ArgumentParser(prog="fry_parity_check.py run")
        ap.add_argument("--cli", required=True)
        ap.add_argument("--models-list", required=True)
        ap.add_argument("--out", required=True)
        ap.add_argument("--tag", required=True)
        ap.add_argument("--edge-mm", type=float, default=10.0)
        ns = ap.parse_args(argv[1:])
        models = [ln.strip() for ln in Path(ns.models_list).read_text(encoding="utf-8").splitlines() if ln.strip()]
        run_models(Path(ns.cli), models, Path(ns.out), ns.tag, ns.edge_mm)
        return 0
    ap = argparse.ArgumentParser(description="★412 跨平台一致性复核（交付的包 × 真实模型，逐张逐字节）")
    ap.add_argument("--win-zip", required=True)
    ap.add_argument("--linux", action="append", default=[], help="标签=包，如 prebuilt=out/linux/prebuilt/…tar.zst（可给多次）")
    ap.add_argument("--config", default=str(CONFIG))
    ap.add_argument("--out-dir", required=True)
    ns = ap.parse_args(argv)
    linux = {x.split("=", 1)[0]: Path(x.split("=", 1)[1]) for x in ns.linux}
    outs = run_all(Path(ns.win_zip), linux, Path(ns.config), Path(ns.out_dir))
    ok = all(json.loads(p.read_text(encoding="utf-8"))["summary"]["all_identical"] for p in outs)
    print("%s 一致性复核：%s" % ("✓" if ok else "✗", " ".join(str(p) for p in outs)))
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
