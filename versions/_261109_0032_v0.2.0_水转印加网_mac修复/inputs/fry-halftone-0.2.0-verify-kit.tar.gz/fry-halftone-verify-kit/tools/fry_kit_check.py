# -*- coding: utf-8 -*-
r"""fry_kit_check.py —— ★412 验收包在 WSL 的真 Linux 里完整跑一遍（Mac 上跑的就是同一个 run_on_target.sh）。

【为什么】macOS 只能交验收包、在 Mac 上验；我们能做的最大努力 = 拿**同一个验收包、同一个脚本**在真 Linux（linux-x64 目标）上
  把整条流程跑通：装配 → 冒烟（golden 逐字节 / 命令行契约 / 交付清单）→ 出包。411 是手动跑的（算法仓 docs 411 的
  c411_wsl_kit_test.sh），412 并进一键出包。
【查五件事】① run_on_target.sh 返回 0 且 linux-x64「可交付」② results/ 里 `sha256sum -c` 通过 ③ 解开它出的包，包里 `sha256sum -c`
  全 OK（411 修的那一行）④ 包里 `python3 verify_delivery.py` 通过 ⑤ ★反向：改包里 1 个字节，verify_delivery.py 必须返回非 0
  且两把尺子（清单 + SHA256SUMS）都点名 —— 只验「好的能过」等于没验。
【输出】<out-dir>/kit_check.json（五项结果）+ kit_linux_build_report.json（给全交付目录的 --kit-linux-report）+ 日志。
用法：python tools/fry_kit_check.py --kit out/kit/fry-halftone-X-verify-kit.tar.gz --out-dir out/kit_check
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO / "tools"))


def script_lines(kit_wsl: str, out_wsl: str) -> List[str]:
    return [
        "#!/usr/bin/env bash", "set -u", 'W="$HOME/fry_kit_check412"', 'rm -rf "$W" && mkdir -p "$W" && cd "$W"',
        'tar -xzf "%s"' % kit_wsl,
        'bash fry-halftone-verify-kit/run_on_target.sh > "%s/run_on_target.log" 2>&1; echo "@@RUNNER_RC=$?"' % out_wsl,
        'R="$W/fry-halftone-verify-kit/results/linux-x64"',
        # ⚠ 结尾那句提示「里面有可交付的包…」成败都会打印 ⇒ 必须认「✓ linux-x64：可交付」整句
        'grep -q "✓ linux-x64：可交付" "%s/run_on_target.log" && echo "@@DELIVERABLE=1" || echo "@@DELIVERABLE=0"' % out_wsl,
        '(cd "$R" && sha256sum -c SHA256SUMS.txt) > "%s/results_sums.log" 2>&1; echo "@@RESULTS_SUMS_RC=$?"' % out_wsl,
        'mkdir -p "$W/unpacked" && tar --zstd -xf "$R"/*.tar.zst -C "$W/unpacked"',
        '(cd "$W/unpacked/fry-halftone" && sha256sum -c SHA256SUMS.txt) > "%s/package_sums.log" 2>&1; echo "@@PKG_SUMS_RC=$?"' % out_wsl,
        'echo "@@PKG_SUMS_LINES=$(grep -c ": OK" "%s/package_sums.log")"' % out_wsl,
        '(cd "$W/unpacked/fry-halftone" && python3 verify_delivery.py) > "%s/verify.log" 2>&1; echo "@@VERIFY_RC=$?"' % out_wsl,
        '(cd "$W/unpacked/fry-halftone" && printf "x" >> SDK_README_EN.md && python3 verify_delivery.py) > "%s/tamper.log" 2>&1;'
        ' echo "@@TAMPER_RC=$?"' % out_wsl,
        'cp -f "$R/build_report.json" "%s/kit_linux_build_report.json"' % out_wsl,
        'cd / && rm -rf "$W"',
    ]


def verdict(markers: Dict[str, int], tamper_log: str) -> Dict[str, Any]:
    """五项判定（纯函数）。tamper_log = 反向那一次 verify_delivery.py 的输出：两把尺子都要点名被改的文件。"""
    both_rulers = ("内容与清单不符" in tamper_log) and ("SHA256SUMS.txt 里的 SDK_README_EN.md" in tamper_log)
    checks = {"runner_ok_bool": markers.get("RUNNER_RC") == 0 and markers.get("DELIVERABLE") == 1,
              "results_sums_ok_bool": markers.get("RESULTS_SUMS_RC") == 0,
              "package_sums_ok_bool": markers.get("PKG_SUMS_RC") == 0 and markers.get("PKG_SUMS_LINES", 0) > 0,
              "verify_ok_bool": markers.get("VERIFY_RC") == 0,
              "tamper_caught_bool": markers.get("TAMPER_RC", 0) != 0 and both_rulers}
    return {**checks, "ok_bool": all(checks.values()), "markers_dict": markers}


def parse_markers(stdout: str) -> Dict[str, int]:
    return {k: int(v) for k, v in re.findall(r"^@@(\w+)=(-?\d+)", stdout, flags=re.M)}


def run(kit: Path, out_dir: Path) -> Dict[str, Any]:
    import fry_wsl as W
    out_dir.mkdir(parents=True, exist_ok=True)
    for old in ("kit_linux_build_report.json", "kit_check.json", "run_on_target.log", "results_sums.log", "package_sums.log",
                "verify.log", "tamper.log"):
        (out_dir / old).unlink(missing_ok=True)       # 上一次的结果不许冒充这一次（尤其 tamper.log 是判据的输入）
    r = W.run_lines(script_lines(W.path(kit), W.path(out_dir)), out_dir / "kit_check.sh")
    markers = parse_markers(W.text(r.stdout))
    tamper = (out_dir / "tamper.log").read_text(encoding="utf-8", errors="replace") if (out_dir / "tamper.log").is_file() else ""
    res = verdict(markers, tamper)
    res.update({"kit_str": kit.name, "report_path_str": str(out_dir / "kit_linux_build_report.json"),
                "report_exists_bool": (out_dir / "kit_linux_build_report.json").is_file()})
    res["ok_bool"] = res["ok_bool"] and res["report_exists_bool"]
    (out_dir / "kit_check.json").write_text(json.dumps(res, ensure_ascii=False, indent=1), encoding="utf-8")
    print("%s 验收包在 WSL 真 Linux：%s" % ("✓" if res["ok_bool"] else "✗", "、".join(
        "%s %s" % (k.replace("_bool", ""), "✓" if v else "✗") for k, v in res.items() if k.endswith("_bool") and k != "ok_bool")), flush=True)
    return res


def main(argv: Optional[List[str]] = None) -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    ap = argparse.ArgumentParser(description="★412 验收包在 WSL 真 Linux 里完整跑一遍（含反向篡改）")
    ap.add_argument("--kit", required=True)
    ap.add_argument("--out-dir", required=True)
    ns = ap.parse_args(argv)
    return 0 if run(Path(ns.kit), Path(ns.out_dir))["ok_bool"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
