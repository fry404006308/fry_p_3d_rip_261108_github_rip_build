# -*- coding: utf-8 -*-
r"""fry_param_schema.py —— ★387 随 SDK 包发出去的**参数说明**：谁写、怎么读、怎么证明它说的是真话。

【为什么要它】386 之前 SDK 包里只有手写的 `SDK_使用说明.md` 参数表：
  · 默认值 / 取值范围是人抄的 —— C++ 改了默认值，表不会自己变，也不报错（两处真相）；
  · 桌面端要做设置界面，只能再抄一遍；算法仓界面 HS200 对账只能正则去扒 C++ 源码（386 实测正则有盲区）。
  ⇒ 让**库自己说**：`FryHalftone_GetParamSchemaJson()`（★387 升到 v3：带 default 与取值范围），出包时原样导出成
    `params_schema.json`，再由它逐行生成人读版 `SDK_参数说明.md`。表里每一格都来自库自报，打包脚本不另写一份。

【怎么证明它说的是真话（三道，都在出包冒烟里跑）】
  ① 形状闸 schema_problems：版本号对 / 参数不为 0 个 / 字段齐 / 名字不重复 / 默认值满足它自己写的类型与范围 / 跨参数规则提到的键都存在；
  ② 包内说明闸 package_problems：sdk_info.json 的 sha256 = 包里 dll 现算；params_schema.json = 库现场自报；人读版每个参数都有一行；
  ③ 行为闸（tests/test_c_abi.py ⑩⑪，真调 dll）：只给尺寸 vs 把说明里的默认值全写出来 ⇒ 回显参数与 BMP md5 都相同；
     按说明生成边界值（下限、刚过下限、上限、null、错类型、不在可选值里）逐个喂给 dll ⇒ 收 / 拒必须与说明推出来的一致。
  ⚠ ① ② 只能证明「文件与库一致」，证明不了「库说的就是库做的」—— 那是 ③ 的事（B.1-16「设了参数 ≠ 生效了」的同族）。

【纯函数一览】value_problems / schema_problems / valid_value / boundary_probes / probe_params / render_markdown / package_problems
  只有 read_schema_text 要加载动态库（ctypes）。
"""
from __future__ import annotations

import ctypes
import hashlib
import json
import platform
from pathlib import Path
from typing import Any, Dict, List, Tuple

SCHEMA_ID_STR = "fry-halftone-params/3"
SCHEMA_FILE_NAME_STR = "params_schema.json"
DOC_FILE_NAME_STR = "SDK_参数说明.md"
FIELD_TUPLE: Tuple[str, ...] = ("name", "kind", "description", "default", "nullable")     # 每个参数必须有的字段
KIND_LABEL_DICT: Dict[str, str] = {"number": "数字", "number_or_null": "数字", "unit_interval": "数字", "int_or_null": "整数",
                                   "bool": "布尔", "choice_fill": "字符串（枚举）", "vec3_positive": "数组（3 个数）",
                                   "number_any": "数字", "choice_orient_mode": "字符串（枚举）", "choice_axis": "字符串（枚举）",
                                   "choice": "字符串（枚举）", "attenuation": "数字"}      # ★449 后两种 = 统一引擎的新 kind


def sha256_file(path: Path) -> str:
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read_schema_text(lib: Path) -> str:
    """向**要发出去的那个库**要参数说明（FryHalftone_GetParamSchemaJson）。"""
    return read_lib_text(lib, "FryHalftone_GetParamSchemaJson")


def read_lib_text(lib: Path, fn_name: str) -> str:
    """向库要一个自报字符串（无参、返回 const char* 的接口：参数说明 / ★409 版本 / 算法指纹）。"""
    is_win = platform.system() == "Windows"
    lib_obj = ctypes.WinDLL(str(lib)) if is_win else ctypes.CDLL(str(lib))
    fn = getattr(lib_obj, fn_name)
    fn.restype, fn.argtypes = ctypes.c_char_p, []
    text = fn().decode("utf-8")
    if is_win:        # 放掉文件句柄：同一进程稍后还要复制 / 压缩这个 dll（Windows 上被加载着的文件删不掉）
        free = ctypes.windll.kernel32.FreeLibrary
        free.argtypes = [ctypes.c_void_p]
        free(ctypes.c_void_p(lib_obj._handle))
    return text


# ───────────────────────────── 读懂说明 ─────────────────────────────
def _is_num(v: Any) -> bool:
    return isinstance(v, (int, float)) and not isinstance(v, bool)


def _above(v: float, lo: float, exclusive: bool) -> bool:
    return v > lo if exclusive else v >= lo


def value_problems(spec: Dict[str, Any], value: Any) -> List[str]:
    """一个值满不满足说明里写的类型与范围 —— 只读字段（nullable / choices / length / integer / min / max），
    不认 kind 的名字：C++ 以后加一种新 kind，只要字段写全，这里不用改。"""
    if value is None:
        return [] if spec.get("nullable") else ["不许是 null"]
    if spec.get("kind") == "bool":
        return [] if isinstance(value, bool) else ["应是 true / false（JSON 布尔）"]
    if "choices" in spec:
        return [] if isinstance(value, str) and value in spec["choices"] else ["不在可选值 %s 里" % spec["choices"]]
    if "length" in spec:
        if not isinstance(value, list) or len(value) != spec["length"]:
            return ["应是 %d 个数的数组" % spec["length"]]
        lo, exc = spec.get("item_min", float("-inf")), bool(spec.get("item_min_exclusive"))
        if not all(_is_num(v) and _above(v, lo, exc) for v in value):
            return ["数组里有不满足 %s %s 的数" % (">" if exc else "≥", lo)]
        return []
    if not _is_num(value):
        return ["应是数字"]
    out: List[str] = []
    if spec.get("integer") and not isinstance(value, int):
        out.append("应是整数（不能带小数点）")
    if "min" in spec and not _above(value, spec["min"], bool(spec.get("min_exclusive"))):
        out.append("应 %s %s" % (">" if spec.get("min_exclusive") else "≥", spec["min"]))
    if "max" in spec and value > spec["max"]:
        out.append("应 ≤ %s" % spec["max"])
    return out


def schema_problems(schema: Any) -> List[str]:
    """① 形状闸。空列表 = 合格；⚠ 一个参数都没有算不合格（查了 0 个不许报通过，B.1-17）。"""
    if not isinstance(schema, dict):
        return ["参数说明不是 JSON 对象"]
    bad: List[str] = []
    if schema.get("schema") != SCHEMA_ID_STR:
        bad.append("schema 版本 %r ≠ %s（库与打包脚本不是同一代）" % (schema.get("schema"), SCHEMA_ID_STR))
    params = schema.get("params")
    if not isinstance(params, list) or not params:
        return bad + ["params 是空的：一个参数都没有"]
    names: List[str] = []
    for p in params:
        if not isinstance(p, dict):
            bad.append("params 里有一条不是对象：%r" % (p,))
            continue
        miss = [f for f in FIELD_TUPLE if f not in p]
        if miss:
            bad.append("%s 缺字段 %s" % (p.get("name"), ", ".join(miss)))
            continue
        names.append(p["name"])
        bad += ["%s 的默认值 %s %s" % (p["name"], json.dumps(p["default"], ensure_ascii=False), why)
                for why in value_problems(p, p["default"])]
    dup = sorted({n for n in names if names.count(n) > 1})
    if dup:
        bad.append("参数名重复：%s" % ", ".join(dup))
    known = set(names)
    for group in schema.get("one_of_required", []):
        bad += ["one_of_required 提到了不存在的参数 %s" % n for n in group if n not in known]
    for rule in schema.get("requires", []):
        bad += ["requires 提到了不存在的参数 %s" % rule.get(k) for k in ("when", "then_required") if rule.get(k) not in known]
    spec_of = {p["name"]: p for p in params if isinstance(p, dict) and "name" in p}
    for key in ("only_when", "echo_omit_when"):                  # ★449 条件规则：提到的键都要存在，条件值要是 when 键的合法值
        for rule in schema.get(key, []):
            if not isinstance(rule, dict) or not isinstance(rule.get("params"), list) or not isinstance(rule.get("equals"), list):
                bad.append("%s 里有一条规则缺 params / when / equals：%r" % (key, rule))
                continue
            bad += ["%s 提到了不存在的参数 %s" % (key, n) for n in rule["params"] + [rule.get("when")] if n not in known]
            if rule.get("when") in spec_of:
                bad += ["%s 的条件值 %s 不是 %s 的合法值" % (key, json.dumps(v, ensure_ascii=False), rule["when"])
                        for v in rule["equals"] if value_problems(spec_of[rule["when"]], v)]
    return bad


# ───────────────────────────── ★449 条件规则（only_when / echo_omit_when）─────────────────────────────
def defaults_of(schema: Dict[str, Any]) -> Dict[str, Any]:
    return {p["name"]: p["default"] for p in schema["params"]}


def inactive_names(schema: Dict[str, Any], effective: Dict[str, Any]) -> List[str]:
    """在这组生效值下，哪些键**不许出现**（它所在的某条 only_when 规则不满足）。effective = 默认值 ∪ 调用方给的值。"""
    out = set()
    for rule in schema.get("only_when", []):
        if effective.get(rule["when"]) not in rule["equals"]:
            out.update(rule["params"])
    return sorted(out)


def echo_omitted_names(schema: Dict[str, Any], effective: Dict[str, Any]) -> List[str]:
    """在这组生效值下，库的参数回显里**不出现**哪些键（echo_omit_when 规则满足）。"""
    out = set()
    for rule in schema.get("echo_omit_when", []):
        if effective.get(rule["when"]) in rule["equals"]:
            out.update(rule["params"])
    return sorted(out)


def explicit_defaults(schema: Dict[str, Any], given: Dict[str, Any]) -> Dict[str, Any]:
    """「把默认值全写出来」的请求：默认值 ∪ given，再去掉在这组值下不许出现的键（否则库按规则返回 2）。"""
    eff = dict(defaults_of(schema), **given)
    drop = set(inactive_names(schema, eff)) - set(given)
    return {k: v for k, v in eff.items() if k not in drop}


def expected_echo(schema: Dict[str, Any], given: Dict[str, Any]) -> Dict[str, Any]:
    """只给 given、其余省略时，库的参数回显应当是什么（由说明推出，不写死）。"""
    eff = dict(defaults_of(schema), **given)
    drop = set(echo_omitted_names(schema, eff))
    return {k: v for k, v in eff.items() if k not in drop}


def valid_value(spec: Dict[str, Any]) -> Any:
    """一个肯定合法的非 null 值（探针的「对照组」：别的键都用它，只让被测的键变）。默认值合法就用默认值。"""
    if spec.get("default") is not None and not value_problems(spec, spec["default"]):
        return spec["default"]
    if spec.get("kind") == "bool":
        return False
    if "choices" in spec:
        return spec["choices"][0]
    if "length" in spec:
        return [float(spec.get("item_min", 0.0)) + 0.5] * int(spec["length"])
    lo = float(spec.get("min", 0.0)) + 1.0
    return int(lo) if spec.get("integer") else lo


def boundary_probes(spec: Dict[str, Any]) -> List[Any]:
    """② 按说明生成「压线」的值：null、错类型、每个可选值与一个不存在的值、下限本身、刚过下限、越过下限、上限、越过上限、非整数。
    期望收还是拒不在这里写死 —— 由 value_problems 从同一份说明推出来（说明写错一个字段，探针就会和 dll 对不上）。"""
    probes: List[Any] = [None]
    if spec.get("kind") == "bool":
        return probes + [True, False, "false", 1]
    if "choices" in spec:
        return probes + list(spec["choices"]) + ["__not_a_choice__", 0]
    if "length" in spec:
        lo, n = float(spec.get("item_min", 0.0)), int(spec["length"])
        return probes + [[lo + 0.5] * n, [lo] + [lo + 0.5] * (n - 1), [lo - 0.5] + [lo + 0.5] * (n - 1), [lo + 0.5] * (n - 1), "x"]
    step = 1 if spec.get("integer") else 0.5
    probes.append("1")
    if "min" in spec:
        lo = spec["min"]
        probes += [lo, lo + step, lo - step]
    if "max" in spec:
        probes += [spec["max"], spec["max"] + step]
    if spec.get("integer"):
        probes.append(float(spec.get("min", 0)) + 1.5)
    return probes


def probe_params(schema: Dict[str, Any], name: str, value: Any) -> Dict[str, Any]:
    """把一个探针值放进一份**只有这个键不同**的 params：尺寸（one_of_required）必须给一个；被 requires 牵连的键补一个合法值。"""
    spec_of = {p["name"]: p for p in schema["params"]}
    params: Dict[str, Any] = {name: value}
    for group in schema.get("one_of_required", []):
        if name in group:
            if value is None:                                     # 被测的尺寸键给 null ⇒ 由同组另一个键提供尺寸
                other = next(n for n in group if n != name)
                params[other] = valid_value(spec_of[other])
        elif not any(n in params for n in group):
            params[group[0]] = valid_value(spec_of[group[0]])
    for rule in schema.get("requires", []):
        if params.get(rule["when"]) == rule.get("equals") and rule["then_required"] not in params:
            params[rule["then_required"]] = valid_value(spec_of[rule["then_required"]])
    # ★449 only_when：被测的键只在某条件下许出现 ⇒ 把条件键设成规则允许的第一个值（规则可以串联，迭代到不动）
    changed = True
    while changed:
        changed = False
        for rule in schema.get("only_when", []):
            if any(n in params for n in rule["params"]) and rule["when"] not in params:
                params[rule["when"]] = rule["equals"][0]
                changed = True
    return params


# ───────────────────────────── 人读版 ─────────────────────────────
def range_text(spec: Dict[str, Any]) -> str:
    if spec.get("kind") == "bool":
        text = "`true` / `false`"
    elif "choices" in spec:
        text = " / ".join("`%s`" % c for c in spec["choices"])
    elif "length" in spec:
        text = "%d 个数，每个 %s %s" % (spec["length"], ">" if spec.get("item_min_exclusive") else "≥", spec.get("item_min"))
    else:
        parts = []
        if "min" in spec:
            parts.append("%s %s" % (">" if spec.get("min_exclusive") else "≥", spec["min"]))
        if "max" in spec:
            parts.append("≤ %s" % spec["max"])
        text = ("整数 " if spec.get("integer") else "") + ("，".join(parts) if parts else "任意")
    return text + (" 或 `null`" if spec.get("nullable") else "")


def _cell(text: Any) -> str:
    return str(text).replace("|", "\\|").replace("\n", " ")


def render_markdown(schema: Dict[str, Any], version: str, platform_tag: str, library_sha256: str) -> str:
    """params_schema.json → 人读版（纯函数；每一格都来自说明本身，不手写任何参数信息）。"""
    params = schema["params"]
    lines = [
        "# 水转印加网 SDK · 参数说明 / Parameter reference",
        "",
        "> ⚠ **本文件由出包脚本自动生成，不要手改。** 来源：这个动态库自己导出的参数说明 "
        "`FryHalftone_GetParamSchemaJson()`（= 同目录 `%s`）。" % SCHEMA_FILE_NAME_STR,
        "> 出包冒烟已真调动态库核对过：**省略一个参数 = 用这里写的默认值**（结果逐字节相同）；**取值范围的收 / 拒与这里一致**。",
        "> Generated at packaging time from the library's own schema; defaults and ranges were verified against the library.",
        "",
        "| 项 / item | 值 / value |",
        "| --- | --- |",
        "| SDK 版本 / version | `%s` |" % version,
        "| 平台 / platform | `%s` |" % platform_tag,
        "| 说明版本 / schema | `%s` |" % schema.get("schema"),
        "| 参数个数 / parameters | %d |" % len(params),
        "| 描述的动态库 sha256 / library sha256 | `%s` |" % library_sha256,
        "",
        "## 一、参数表 / Parameters",
        "",
        "| # | 参数 / name | 类型 / type | 默认值（省略时真正用的值）/ default | 取值范围 / range | 说明 / description |",
        "| ---: | --- | --- | --- | --- | --- |",
    ]
    for i, p in enumerate(params, 1):
        lines.append("| %d | `%s` | %s | `%s` | %s | %s |" % (
            i, p["name"], _cell(KIND_LABEL_DICT.get(p["kind"], p["kind"])), _cell(json.dumps(p["default"], ensure_ascii=False)),
            _cell(range_text(p)), _cell(p["description"])))
    lines += ["", "## 二、跨参数规则 / Cross-parameter rules", ""]
    for group in schema.get("one_of_required", []):
        lines.append("- **必须且只能给一个**（one of, required）：%s" % " / ".join("`%s`" % n for n in group))
    for rule in schema.get("requires", []):
        lines.append("- `%s` = `%s` 时**必须同时给** `%s`" % (rule["when"], json.dumps(rule.get("equals")), rule["then_required"]))
    for rule in schema.get("only_when", []):                      # ★449
        lines.append("- %s **只在** `%s` ∈ %s 时许出现（否则返回 2）" % (
            "、".join("`%s`" % n for n in rule["params"]), rule["when"], " / ".join("`%s`" % v for v in rule["equals"])))
    for rule in schema.get("echo_omit_when", []):
        lines.append("- `%s` ∈ %s 时，结果里的参数回显**不出现** %s（与旧版回显逐字节相同）" % (
            rule["when"], " / ".join("`%s`" % v for v in rule["equals"]), "、".join("`%s`" % n for n in rule["params"])))
    size_key = (schema.get("one_of_required") or [[params[0]["name"]]])[0][0]
    lines += [
        "",
        "## 三、怎么用 / How to use",
        "",
        "- 参数走 `FryHalftone_SliceModelJsonUtf8` 的 `params` 对象；**键不在上表里、类型或范围不对 ⇒ 返回 2（BAD_ARGUMENT），不会静默忽略**。",
        "- 只想用默认值：`params` 里只放尺寸即可，例如 `{\"%s\": 30.0}`。" % size_key,
        "- 做设置界面：读 `%s`（字段 `name / kind / description / default / nullable / min / min_exclusive / max / integer / choices / length`），"
        "不要照抄本表 —— 换 dll 后以新 dll 自报为准。" % SCHEMA_FILE_NAME_STR,
        "",
    ]
    return "\n".join(lines)


# ───────────────────────────── ② 包内说明闸 ─────────────────────────────
def package_problems(sdk: Path, library_rel: str, import_library_rel: str, schema_text: str) -> List[str]:
    """装配好的 SDK 目录里：说明文件与库是不是同一次出包的。schema_text = 库现场自报（调用方从 bin/ 里那个库现读）。"""
    sdk = Path(sdk)
    bad: List[str] = []
    info_path = sdk / "sdk_info.json"
    if not info_path.is_file():
        return ["缺 sdk_info.json"]
    info = json.loads(info_path.read_text(encoding="utf-8"))
    lib = sdk / library_rel
    if not lib.is_file():
        return bad + ["缺动态库 %s" % library_rel]
    lib_sha = sha256_file(lib)
    if info.get("library_sha256_str") != lib_sha:
        bad.append("sdk_info.json 的 library_sha256_str %s ≠ %s 现算 %s" % (str(info.get("library_sha256_str"))[:16], library_rel, lib_sha[:16]))
    if import_library_rel:
        implib = sdk / import_library_rel
        if not implib.is_file() or info.get("import_library_sha256_str") != sha256_file(implib):
            bad.append("sdk_info.json 的 import_library_sha256_str 与 %s 不符" % import_library_rel)
    schema_path = sdk / SCHEMA_FILE_NAME_STR
    if not schema_path.is_file():
        return bad + ["缺 %s" % SCHEMA_FILE_NAME_STR]
    on_disk = json.loads(schema_path.read_text(encoding="utf-8"))
    live = json.loads(schema_text)
    if on_disk != live:
        bad.append("%s 与库现场自报的参数说明不一致（包里的 dll 换过？）" % SCHEMA_FILE_NAME_STR)
    if info.get("params_schema_sha256_str") != sha256_file(schema_path):
        bad.append("sdk_info.json 的 params_schema_sha256_str 与 %s 不符" % SCHEMA_FILE_NAME_STR)
    n_live = len(live.get("params") or [])
    if info.get("param_count_int") != n_live:
        bad.append("sdk_info.json 写 %s 个参数，库自报 %d 个" % (info.get("param_count_int"), n_live))
    doc_path = sdk / DOC_FILE_NAME_STR
    if not doc_path.is_file():
        return bad + ["缺 %s" % DOC_FILE_NAME_STR]
    doc = doc_path.read_text(encoding="utf-8")
    bad += ["%s 里没有参数 %s 那一行" % (DOC_FILE_NAME_STR, p["name"]) for p in live.get("params") or []
            if "| `%s` |" % p["name"] not in doc]
    if lib_sha not in doc:
        bad.append("%s 写的库 sha256 不是包里这个 dll 的" % DOC_FILE_NAME_STR)
    return bad
