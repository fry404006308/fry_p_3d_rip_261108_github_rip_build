# -*- coding: utf-8 -*-
r"""fry_delivery_bundle.py —— ★410/411 「全交付目录」：同事要的三个平台一次放齐，**信息尽量多**，每次新建一个子目录。

【为什么要有它】同事的需求：Windows 的 dll + macOS、Linux 的对应产物 + 对应的命令行（CLI）包。
  这些东西散在 out/ 的四个地方，版本号、算法指纹各记各的 ⇒ 手工拷很容易拷错一份（而且不报错）
  ⇒ 先过闸（同一版本、同一算法指纹 / 外壳指纹、冒烟都过、验收包 sha256 对得上、随包文本三平台逐字节相同、
     ★411 版本号只增不减），再装配交付目录。
【★411 用户的两条要求】
  ① 版本号不要都是 0.0.0，每次交付依次递增 ⇒ tools/fry_delivery_version.py（0.1.0 起；记录进 git 的 delivery_versions.json）；
  ② 「只给 Windows 时有 examples / include / 各种说明，三平台反而省略了」—— 410 只放了压缩包 ⇒ 现在每个平台都**展开**，
     并且多给：各平台集成说明（命令逐条实测过）、接口 / 参数 / 命令行速查、一次真跑的示例输入输出、版本记录与本版变更。
  ★ 说明里的每个数与每条命令都**从上游现算 / 真跑过**：golden 件数、交付清单项数、导出接口数、参数表（库自报）、
    接口签名（头文件）、命令行帮助（真跑 --help）、示例输出（真跑一次，与标准答案逐字节比对）、集成命令（tools/fry_integration_guide.py）。

【输出目录长什么样】
  out/全交付目录/_YYMMDD_HHMM_水转印加网SDK_v<版本>_三平台交付/
    00_先读我_交付说明.md       这一版是什么 / 目录导航 / 三平台 5 分钟上手 / 接口·参数·命令行速查 / 输出格式 / 验过什么 / 限制 / FAQ
    01_Windows_x64/            .zip + ★展开的 fry-halftone\（bin include lib examples 说明…）+ Windows_集成说明.md + 给业务_使用说明.md
    02_Linux_x64/              .tar.zst + ★展开的 fry-halftone/ + Linux_集成说明.md
    03_macOS_需在Mac上验收/     验收包 + macOS验收步骤.md（怎么验、怎样算成功）+ macOS_集成说明.md + 验收包说明
    04_对接文档/               说明（中 / 英）、参数说明、CHANGELOG、LICENSE、include/、examples/、接口速查、命令行速查
    05_示例输出/               一次真跑：输入模型 + 命令 + 161 张 BMP + slice_metadata.json + 进度与 JSON 事件 + 与标准答案的比对
    06_验收证据/               各平台 build_report、Linux 环境、交叉编译静态闸、验收包信息、一致性实验、集成命令实测
    07_版本记录/               版本记录.md（历次交付）+ 本版变更.md（CHANGELOG 这一版那一节）
    bundle_manifest.json / SHA256SUMS.txt
  同级 .zip（中文名 UTF-8）；out/全交付目录/_交付记录.md 追加一行；打包仓 delivery_versions.json 追加一行（进 git）。

【用法】
  python tools/fry_delivery_bundle.py --next-version                     # 下一个交付版本号是多少
  python tools/fry_delivery_bundle.py [--parity-json a.json] [--integration-json b.json]
  python tools/fry_delivery_bundle.py --dry-run                         # 只过闸，不写任何东西
  一键：python tools/fry_release.py --algo-repo <算法仓> --bundle        # 自动取下一个版本号 → 出齐三平台 → 本工具
⚠ 本工具**不编译、不验收**：只收已经验收过的产物；macOS 在 Windows 上验不了，放的是验收包 + 步骤，状态写「待 Mac 验收」。
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import platform
import re
import shutil
import struct
import subprocess
import sys
import tarfile
import tempfile
import time
import zipfile
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO / "tools"))
import fry_build  # noqa: E402            外壳指纹（cpp/ 之外会编进二进制的源码）的算法与输入清单；随包文件清单
import fry_business_zip  # noqa: E402     给业务的替换说明（与「交付给业务」同一份）
import fry_delivery_contract  # noqa: E402
import fry_delivery_version as DV  # noqa: E402   ★411 交付版本号
import fry_integration_guide as G  # noqa: E402   ★411 各平台集成命令（唯一真源）
import fry_surface as SF  # noqa: E402            ★412 对外接口面 + 该升哪一位

OUT = REPO / "out"
BUNDLE_ROOT_NAME = "全交付目录"
VOID_DIR_NAME = "_作废"                       # 作废的交付目录挪进这里（不删：记录要能回溯）
PACKAGE = "fry-halftone"
MAC_TARGETS = ("macos-arm64", "macos-x64")
KIT_LINUX_TARGETS = ("linux-x64",)          # ★411 Linux 集成说明承诺「服务器 glibc 不同就用验收包在服务器上验」⇒ 验收包必须带它
DIRS = {"win": "01_Windows_x64", "linux": "02_Linux_x64", "mac": "03_macOS_需在Mac上验收", "docs": "04_对接文档",
        "sample": "05_示例输出", "evidence": "06_验收证据", "versions": "07_版本记录"}
DOC_FILES = ("SDK_使用说明.md", "SDK_README_EN.md", "SDK_参数说明.md", "params_schema.json", "CHANGELOG.md", "LICENSE.txt")
SAMPLE_CASE = "gltf_modes_mix_l12"          # 示例 1 用的 golden 件（模型 = fry_integration_guide.SAMPLE_MODEL）
# ★412 三个示例（都是 golden 件 ⇒ 都能与标准答案逐字节比）：默认参数 + 黑墨 + 白底 —— 411 只有示例 1 时，像素值 7（黑）与 9（白）
#   一个都没有，对照表这两行的开环核对是「0 = 0」，没有判别力。实测：7 只在示例 2；9 在示例 2（球心默认是白）和示例 3（色带空位填白）。
#   ⚠ 412 第一版把「9 只在白底示例里出现」写死在说明里 —— 数据（示例 2 有 467,577 个 9）不同意；说明里的这类话一律从计数现算。
SAMPLES = (
    {"key_str": "1_默认参数", "case_str": "gltf_modes_mix_l12", "via_str": "slice",
     "title_str": "默认参数：只给最长边 12 mm", "why_str": "最常见的用法；模型混合了 glTF 的几种上色方式"},
    {"key_str": "2_黑墨K", "case_str": "sphere_l5_k400_amt05_band08", "via_str": "run",
     "title_str": "黑墨：use_black_k、K 满喷 400 µm、灰分量替换 0.5、色带 0.8 mm",
     "why_str": "像素值 7（黑）只在用黑墨时出现；这个球够厚，色带以内的球心是白（9）"},
    {"key_str": "3_白底填充", "case_str": "sphere_l5_white_nosup_w64", "via_str": "run",
     "title_str": "白底填充：band_uninked_fill=white、不打支撑、输出宽 64 像素",
     "why_str": "色带里不落彩墨的格子填白（9）而不是透明（11 = 0）；不打支撑（13 = 0）；输出宽 64 > 原生 45（BMP 补 0 列）"},
)
KIT_LINUX_REPORT_NAME = "验收包在真Linux跑通_build_report.json"   # ★411 --kit-linux-report 放进 06_验收证据/ 的名字
EVIDENCE_NOTES = {
    "build_report_windows.json": "Windows 出包报告：冒烟各项（导出面 / golden / C 接口 / 命令行契约 / 交付清单）、版本号五处、耗时",
    "build_report_linux_prebuilt.json": "Linux（prebuilt = 交付的那一种）出包报告：在 WSL2 真 Linux 里跑的冒烟结果",
    "build_report_linux_native.json": "Linux（native，gcc 原生编，只当对照）出包报告",
    "linux_env_prebuilt.json": "Linux 验收机的环境：发行版 / glibc / 内核", "linux_env_native.json": "Linux（native）验收机的环境",
    "macos_verify_kit_info.json": "macOS 验收包信息：带哪些目标、各目标最低系统、验收包 sha256、「未在目标机验证」标记",
    "cross_static_gate.json": "交叉编译静态闸：四个目标的格式 / 架构 / 签名 / 装载路径 / 导出面检查结果",
    "集成命令实测.json": "集成命令实测：各平台集成说明里每一条命令的返回码、耗时、输出末尾（本机路径已脱敏）",
    KIT_LINUX_REPORT_NAME: "验收包在真 Linux（WSL2）上跑 run_on_target.sh 出的报告 —— Mac 上跑的是同一个脚本",
}
SDK_FILE_NOTES = {
    "bin/fry_halftone.dll": "★ 运行只需要这一个文件", "bin/libfry_halftone.so": "★ 运行只需要这一个文件",
    "bin/fry-halftone-cli.exe": "命令行（与库同目录；只调公开 C 接口）", "bin/fry-halftone-cli": "命令行（与库同目录；只调公开 C 接口）",
    "lib/fry_halftone.lib": "Windows 导入库（C/C++ 隐式链接用；LoadLibrary 动态加载不需要）",
    "include/fry_halftone.h": "C 接口（纯 C / C++ / C# P-Invoke / Delphi 都照它写）",
    "examples/c/fry_halftone_demo.c": "C 示例（编译 / 运行命令写在文件开头，逐条实测过）",
    "examples/csharp/FryHalftoneDemo.cs": "C# P/Invoke 示例（调用约定 / 字符集 / 回调保活都标了）",
    "examples/python/fry_halftone_demo.py": "Python ctypes 示例（不装第三方包）",
    "VERSION": "一行版本号", "sdk_info.json": "版本 / 平台 / 引擎 / 算法指纹 / 库 sha256 / 集成信息（ABI、运行库、线程、内存、返回码…）",
    "params_schema.json": "参数说明（机读，库自己导出）", "SDK_参数说明.md": "参数说明（人读：类型 / 默认值 / 取值范围）",
    "delivery_manifest.json": "交付清单（应该有哪些文件 + sha256 + 为什么必需）",
    "verify_delivery.py": "自检脚本：python verify_delivery.py（按清单 + 按 SHA256SUMS 两把尺子核对，再真加载库、核对版本号）",
    "SHA256SUMS.txt": "包内全部文件的校验和（`sha256sum -c SHA256SUMS.txt` 直接能验）","CHANGELOG.md": "变更历史（按版本号分节）", "LICENSE.txt": "许可与第三方声明",
    "SDK_使用说明.md": "完整集成说明（中文）", "SDK_README_EN.md": "Integration guide (English)",
}


DEFAULT_TOPIC = "水转印加网SDK_三平台交付"      # 主题词给成空白时的兜底


def default_topic(version: str) -> str:
    """★411 默认主题带版本号：同事手上多个交付目录一眼分得清哪个新。"""
    return "水转印加网SDK_v%s_三平台交付" % version


def sha256_file(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def jload(p: Path) -> Dict[str, Any]:
    return json.loads(p.read_text(encoding="utf-8"))


def expected_counts(repo: Optional[Path] = None) -> Dict[str, int]:
    """同事在验收日志里应该看到的数，**从上游现算**（不手写）。"""
    repo = repo or REPO
    return {"golden_int": len(jload(repo / "tests" / "data" / "golden.json")["case_list"]),
            "delivery_win_int": len(fry_delivery_contract.items_for("full", "Windows")),
            "delivery_linux_int": len(fry_delivery_contract.items_for("full", "Linux")),
            "delivery_mac_int": len(fry_delivery_contract.items_for("full", "Darwin"))}


# ───────────────────────────── ① 收集 + 过闸（纯检查，不写东西） ─────────────────────────────
def collect(out: Path, linux_modes: List[str], parity: List[Path], repo: Optional[Path] = None,
            integration: Optional[Path] = None, kit_linux_report: Optional[Path] = None) -> Tuple[Dict[str, Any], List[str]]:
    """把三个平台的产物找齐并逐条核对；返回（输入清单, 问题列表）。问题列表非空 = 不许打包。"""
    repo = repo or REPO
    probs: List[str] = []
    inp: Dict[str, Any] = {"linux": {}, "parity": [], "repo": repo}
    lock_path = repo / "cpp.lock.json"
    fp = jload(lock_path)["tree_sha256_str"] if lock_path.is_file() else ""
    inp["fingerprint"] = fp
    if not fp:
        probs.append("没有 cpp.lock.json —— 不知道这一版的算法指纹，没法核对各平台是不是同一份算法")
    cur_wrapper = fry_build.wrapper_fingerprint(repo)
    rep_path = out / "build_report.json"
    if not rep_path.is_file():
        return inp, probs + ["没有 out/build_report.json —— 先出 Windows 包（python tools/fry_build.py）"]
    rep = jload(rep_path)
    version = rep.get("version_str", "")
    inp["version"] = version
    win_wrapper = rep.get("wrapper_sha256_str", "")
    inp["wrapper"] = win_wrapper
    zip_path = out / ("%s-%s-win32-x64.zip" % (PACKAGE, version))
    sdk = out / "sdk" / "fry-halftone-sdk"
    if rep.get("platform_str") != "win32-x64":
        probs.append("out/build_report.json 不是 Windows 的（%s）" % rep.get("platform_str"))
    probs += _smoke_problems("Windows", rep, fp)
    probs += _wrapper_problems("Windows 包", win_wrapper, cur_wrapper, "当前源码（改过之后没重出包）")
    for p, what in ((zip_path, "Windows 包"), (sdk, "Windows SDK 目录（拷对接文档用）")):
        if not p.exists():
            probs.append("缺%s：%s" % (what, p))
    inp["win"] = {"archive": zip_path, "report": rep_path, "report_dict": rep, "sdk": sdk}
    for mode in linux_modes:
        d = out / "linux" / mode
        rp = d / "build_report.json"
        arc = d / ("%s-%s-linux-x64.tar.zst" % (PACKAGE, version))
        if not rp.is_file() or not arc.is_file():
            probs.append("缺 Linux %s 包或报告（%s）—— 先跑 python tools/fry_build_linux_native.py --mode %s" % (mode, d, mode))
            continue
        lrep = jload(rp)
        if lrep.get("version_str") != version:
            probs.append("Linux %s 的版本 %r ≠ Windows 的 %r（不是同一轮出的包）" % (mode, lrep.get("version_str"), version))
        probs += _smoke_problems("Linux " + mode, lrep, fp)
        probs += _wrapper_problems("Linux %s 包" % mode, lrep.get("wrapper_sha256_str", ""), win_wrapper, "Windows 包")
        schema_w, schema_l = sdk / "params_schema.json", d / "sdk" / "params_schema.json"
        if not (schema_w.is_file() and schema_l.is_file()):
            probs.append("Linux %s 或 Windows 缺 params_schema.json —— 没法核对两边的参数说明" % mode)
        elif schema_w.read_bytes() != schema_l.read_bytes():
            probs.append("Linux %s 的参数说明与 Windows 的不一样 —— 同一份算法源码的库自报说明必须逐字节相同" % mode)
        inp["linux"][mode] = {"archive": arc, "report": rp, "report_dict": lrep, "env": d / "linux_env.json"}
    ki_path = out / "kit" / "kit_info.json"
    kit = out / "kit" / ("%s-%s-verify-kit.tar.gz" % (PACKAGE, version))
    if not ki_path.is_file() or not kit.is_file():
        probs.append("缺 macOS 验收包 —— 先跑 python tools/fry_cross_build.py --target macos-arm64,macos-x64 "
                     "和 python tools/fry_target_kit.py")
    else:
        ki = jload(ki_path)
        if ki.get("version_str") != version:
            probs.append("验收包的版本 %r ≠ Windows 的 %r" % (ki.get("version_str"), version))
        if ki.get("algorithm_fingerprint_str") != fp:
            probs.append("验收包的算法指纹 ≠ 锁文件 —— 源码变过，重新交叉编译并打验收包")
        probs += _wrapper_problems("macOS 验收包", ki.get("wrapper_sha256_str", ""), win_wrapper, "Windows 包")
        missing = [t for t in MAC_TARGETS + KIT_LINUX_TARGETS if t not in (ki.get("targets_dict") or {})]
        if missing:
            probs.append("验收包里缺目标：%s（macOS 两个是交付物；Linux x64 是说明里承诺的「拿验收包在你们服务器上验」）"
                         "—— 用 python tools/fry_cross_build.py --target all 重编再打验收包" % "、".join(missing))
        if not ki.get("kit_sha256_str"):
            probs.append("kit_info.json 没记验收包的 sha256 —— 没法确认拷的是打出来的那一份")
        elif sha256_file(kit) != ki["kit_sha256_str"]:
            probs.append("验收包的 sha256 与 kit_info.json 不符 —— 打包之后被动过")
        if ki.get("verified_on_target_bool") is not False:
            probs.append("kit_info.json 的 verified_on_target_bool 不是 false —— 验收包本身永远是「未验证」")
        inp["mac"] = {"archive": kit, "kit_info": ki_path, "kit_info_dict": ki}
    # ★411 版本号：X.Y.Z、只增不减、同号同字节（三个包的 sha256）
    packages = {}
    if zip_path.is_file():
        packages["win32-x64"] = sha256_file(zip_path)
    first_linux = next(iter(inp["linux"].values()), None)
    if first_linux:
        packages["linux-x64"] = sha256_file(first_linux["archive"])
    if kit.is_file():
        packages["verify-kit"] = sha256_file(kit)
    inp["packages_sha_dict"] = packages
    inp["versions_state"] = DV.load(repo)
    probs += DV.version_problems(version, packages, inp["versions_state"])
    # ★412 对外接口面（从源码现量）+ 升级位：实际升的位要够（手填 --version 也要过这道闸）；
    #   参数表两把尺子：源码解析 = 库自报的 params_schema.json（命令行那一把在 build 里真跑 --help 之后比）
    surface = SF.source_surface(repo)
    inp["surface_dict"] = surface
    if (sdk / "params_schema.json").is_file():
        probs += SF.surface_mismatch(surface, {"params_list": SF.params_from_schema(jload(sdk / "params_schema.json"))})
    req = SF.required_bump(DV.last_record(inp["versions_state"]), {
        "version_str": version, "algorithm_fingerprint_str": fp, "wrapper_sha256_str": win_wrapper, "surface_dict": surface})
    inp["bump_required_dict"] = req
    if DV.parse(version):
        probs += SF.bump_problems(DV.last_version(inp["versions_state"]), version, req)
    sdk_of = {"win": sdk, "linux_prebuilt": out / "linux" / "prebuilt" / "sdk", "linux_native": out / "linux" / "native" / "sdk"}
    for p in parity:
        if not p.is_file():
            probs.append("一致性实验文件不存在：%s" % p)
            continue
        s = jload(p).get("summary") or {}
        if s.get("all_identical") is not True:
            probs.append("一致性实验 %s 说各平台切片**不全一致**（all_identical=%r）—— 先查清楚再交付" % (p.name, s.get("all_identical")))
        bad = {k: v for k, v in (s.get("cli_versions") or {}).items() if v != "%s-cli %s" % (PACKAGE, version)}
        if not s.get("cli_versions") or bad:
            probs.append("一致性实验 %s 不是用这个版本跑的（%s）" % (p.name, bad or "没记版本"))
        probs += _parity_binary_problems(p.name, s, sdk_of, fp)
        inp["parity"].append({"path": p, "summary": s})
    # ★411 集成命令实测：必须是这两个包实测的、而且全过
    inp["integration"] = None
    if integration is not None:
        if not integration.is_file():
            probs.append("集成命令实测文件不存在：%s" % integration)
        else:
            ij = jload(integration)
            want = {k: packages.get(k) for k in ("win32-x64", "linux-x64")}
            if ij.get("package_sha256_dict") != want:
                probs.append("集成命令实测 %s 测的不是这次交付的包（包的 sha256 对不上）—— 对这次的包重跑实测" % integration.name)
            if ij.get("all_ok_bool") is not True:
                probs.append("集成命令实测 %s 没有全过 —— 说明里的命令不能写成「实测过」" % integration.name)
            if ij.get("version_str") != version:
                probs.append("集成命令实测 %s 的版本 %r ≠ %r" % (integration.name, ij.get("version_str"), version))
            inp["integration"] = {"path": integration, "data": ij}
    inp["kit_linux_report"] = None
    if kit_linux_report is not None:                     # ★411 验收包在真 Linux 上跑通的报告（Mac 上跑的是同一个脚本）
        if not kit_linux_report.is_file():
            probs.append("验收包的 Linux 实测报告不存在：%s" % kit_linux_report)
        else:
            krep = jload(kit_linux_report)
            probs += kit_linux_report_problems(krep, version, fp, win_wrapper)
            inp["kit_linux_report"] = {"path": kit_linux_report, "host_str": krep.get("host_str", "?"),
                                       "platform_str": krep.get("platform_str", "?")}
    if sdk.is_dir():                                     # ★410 随包文本三平台逐字节相同（Linux SDK + 验收包 vs Windows SDK）
        probs += shipped_text_problems(shipped_files(sdk), {m: out / "linux" / m / "sdk" for m in inp["linux"]},
                                       kit if "mac" in inp else None)
    inp["cross_info"] = out / "cross" / "cross_info.json"
    return inp, probs


def _smoke_problems(name: str, rep: Dict[str, Any], fp: str) -> List[str]:
    s = rep.get("smoke_dict") or {}
    probs = []
    if not rep.get("smoke_bool"):
        probs.append("%s 没跑冒烟（smoke_bool=false）—— 没验过的包不许交付" % name)
    if s.get("cli_contract_str") != "ok":
        probs.append("%s 的命令行契约没过（cli_contract_str=%r）" % (name, s.get("cli_contract_str")))
    if rep.get("fingerprint_str") != fp:
        probs.append("%s 的算法指纹 %s… ≠ 锁文件 %s…" % (name, str(rep.get("fingerprint_str"))[:12], fp[:12]))
    return probs


def shipped_files(sdk: Path) -> Dict[str, Optional[bytes]]:
    """Windows SDK 里「原样随包」的文件（包内路径 → 字节；缺 = None），按 fry_build 的唯一真源展开。"""
    out: Dict[str, Optional[bytes]] = {}
    for dst in fry_build.SHIPPED_VERBATIM_DICT:
        p = sdk / dst
        out[dst] = p.read_bytes() if p.is_file() else None
    for dst in fry_build.SHIPPED_VERBATIM_DIR_DICT:
        for p in sorted((sdk / dst).rglob("*")):
            if p.is_file():
                out[p.relative_to(sdk).as_posix()] = p.read_bytes()
    return out


def repo_rel_of(sdk_rel: str) -> str:
    """包内路径 → 仓库路径（验收包里存的是仓库路径）。"""
    if sdk_rel in fry_build.SHIPPED_VERBATIM_DICT:
        return fry_build.SHIPPED_VERBATIM_DICT[sdk_rel]
    top, _, rest = sdk_rel.partition("/")
    return fry_build.SHIPPED_VERBATIM_DIR_DICT[top] + "/" + rest


def shipped_text_problems(win: Dict[str, Optional[bytes]], linux_sdks: Dict[str, Path], kit: Optional[Path]) -> List[str]:
    """★410 三个平台的随包文本（说明 / 变更历史 / 许可 / 自检脚本 / 头文件 / 示例）必须逐字节相同。"""
    probs = [("随包文件 %s：Windows SDK 里没有" % rel) for rel, data in win.items() if data is None]
    for mode, sdk in linux_sdks.items():
        diff = [rel for rel, data in win.items() if data is not None
                and (not (sdk / rel).is_file() or (sdk / rel).read_bytes() != data)]
        if diff:
            probs.append("随包文件与 Windows 包不同（Linux %s）：%s —— 三个平台的说明 / 头文件 / 示例必须是同一份，重出落后的那个"
                         % (mode, "、".join(diff[:6])))
    if kit is not None:
        try:
            with tarfile.open(kit) as tf:
                members = {m.name.split("/", 1)[1]: m for m in tf.getmembers() if m.isfile() and "/" in m.name}
                diff = []
                for rel, data in win.items():
                    m = members.get(repo_rel_of(rel))
                    if data is not None and (m is None or tf.extractfile(m).read() != data):
                        diff.append(rel)
        except (tarfile.TarError, OSError) as e:
            return probs + ["验收包打不开（%s）—— 没法核对随包文件" % e]
        if diff:
            probs.append("随包文件与 Windows 包不同（验收包 → Mac 上出的包）：%s —— 改完之后只重打了验收包？三个平台一起重出"
                         % "、".join(diff[:6]))
    return probs


def _parity_binary_problems(name: str, s: Dict[str, Any], sdk_of: Dict[str, Path], fp: str) -> List[str]:
    """★410 一致性证据必须是**这次交付的那份库**跑出来的：实验记下的库 sha256 = 交付包 sdk_info 里的库 sha256。"""
    libs = s.get("lib_sha256_dict") or {}
    if not libs or not all(libs.values()):
        return ["一致性实验 %s 没记是哪份库跑的（lib_sha256_dict）—— 证明不了「证据 = 交付的字节」，用 410 的实验脚本重跑" % name]
    probs = []
    for tag, sha in sorted(libs.items()):
        info_path = sdk_of.get(tag, Path("-")) / "sdk_info.json"
        want = jload(info_path).get("library_sha256_str", "") if info_path.is_file() else ""
        if not want:
            probs.append("一致性实验 %s 的 %s 找不到对应的交付 SDK（%s）—— 没法核对" % (name, tag, info_path))
        elif sha != want:
            probs.append("一致性实验 %s 里 %s 跑的库 %s… ≠ 这次交付的库 %s…（证据不是这份字节跑的）" % (name, tag, sha[:12], want[:12]))
    for tag, got in sorted((s.get("algorithm_fingerprint_dict") or {}).items()):
        if got != fp:
            probs.append("一致性实验 %s 里 %s 的库自报算法指纹 %s… ≠ 锁文件" % (name, tag, str(got)[:12]))
    return probs


def _wrapper_problems(name: str, got: str, ref: str, ref_name: str) -> List[str]:
    """★410 外壳指纹核对（纯函数）：没记 = 旧产物；与参照（当前源码 / Windows 包）不同 = 不是同一份外壳源码编的。"""
    if not got:
        return ["%s 没记外壳指纹（★410 之前出的旧产物）—— 重出一次" % name]
    if ref and got != ref:
        return ["%s 的外壳指纹 %s… ≠ %s %s…（命令行 / dll 外壳 / 导出表不是同一份源码编的）" % (name, got[:12], ref_name, ref[:12])]
    return []


def evidence_note(name: str, parity_names: List[str], extra_notes: Dict[str, str]) -> str:
    if name in extra_notes:
        return extra_notes[name]
    if name in parity_names:
        return "跨平台一致性实验：逐模型、逐张 BMP 比对（含每个平台跑的是哪份库的 sha256）"
    return EVIDENCE_NOTES.get(name, "附加证据")


def kit_linux_report_problems(rep: Dict[str, Any], version: str, fp: str, wrapper: str) -> List[str]:
    """★411 验收包在真 Linux 上跑通的报告（纯函数）：必须是这一版、这份算法、这份外壳、冒烟全过。"""
    probs = []
    if rep.get("version_str") != version:
        probs.append("验收包的 Linux 实测报告版本 %r ≠ %r" % (rep.get("version_str"), version))
    if not rep.get("smoke_bool") or (rep.get("smoke_dict") or {}).get("cli_contract_str") != "ok":
        probs.append("验收包的 Linux 实测报告里冒烟 / 命令行契约没过")
    if rep.get("fingerprint_str") != fp or rep.get("wrapper_sha256_str") != wrapper:
        probs.append("验收包的 Linux 实测报告的算法指纹 / 外壳指纹与这一版不符（不是这个验收包跑的）")
    if not str(rep.get("platform_str", "")).startswith("linux-"):
        probs.append("验收包的 Linux 实测报告不是 Linux 目标（%r）" % rep.get("platform_str"))
    return probs


def parity_sentence(parity: List[Dict[str, Any]]) -> str:
    """一致性实验 → 一句话（数全从实验文件里取）；没给实验就返回空串（说明里就不提）。"""
    if not parity:
        return ""
    ss = [p["summary"] for p in parity]
    models = max(int(s.get("model_count", 0)) for s in ss)
    edges = " / ".join("%g" % s.get("edge_mm", 0) for s in ss)
    slices = sum(int(s.get("total_slices_win", 0)) for s in ss)
    sides: List[str] = []
    for k in sorted({k for s in ss for k in (s.get("pair_identical_models") or {})}):
        for side in k.split("="):
            if side not in sides:
                sides.append(side)
    refused = sorted({m for s in ss for m in (s.get("rc_nonzero") or {})})
    names = {"win": "Windows", "linux_native": "Linux native", "linux_prebuilt": "Linux prebuilt"}
    txt = ("跨平台一致性实验（证据 %s）：%d 个真实模型 × 最长边 %s mm，每个平台共 %s 张 BMP，%s 的切片**逐张逐字节相同**"
           % ("、".join("`%s/%s`" % (DIRS["evidence"], p["path"].name) for p in parity), models, edges,
              format(slices, ","), " = ".join(names.get(s, s) for s in sides)))
    if refused:
        txt += "（其中 %d 个模型在所有平台上都按设计拒收，返回码相同）" % len(refused)
    return txt + "。实验用的就是这一包里的库（sha256 已逐个核对）。\n"


# ───────────────────────────── ② 目录名（纯函数） ─────────────────────────────
def bundle_dir_name(topic: str, now: Optional[time.struct_time] = None) -> str:
    """`_YYMMDD_HHMM_<主题>`：主题里的路径分隔符 / 空白换成下划线（目录名只能是一段）。"""
    stamp = time.strftime("%y%m%d_%H%M", now or time.localtime())
    clean = "".join("_" if c in '\\/:*?"<>| \t' else c for c in topic.strip()) or DEFAULT_TOPIC
    return "_%s_%s" % (stamp, clean)


def unique_dir(root: Path, name: str) -> Path:
    """同一分钟跑两次不覆盖：目录或同名 zip 已存在就加 _2、_3 …（「每次的内容都新建一个子目录」）。"""
    p = root / name
    k = 2
    while p.exists() or (root / (p.name + ".zip")).exists():
        p = root / ("%s_%d" % (name, k))
        k += 1
    return p


# ───────────────────────────── ③ ★411 展开包 + 真跑示例 ─────────────────────────────
def extract_zip(zip_path: Path, into: Path) -> Path:
    into.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(zip_path) as zf:
        zf.extractall(into)
    return into / "fry-halftone"


def _zstd_reader(f):
    """zstd 解压流：第三方 zstandard ｜ Python 3.14 起标准库 compression.zstd；都没有 = None。"""
    try:
        import zstandard  # type: ignore
        return zstandard.ZstdDecompressor().stream_reader(f)
    except ImportError:
        pass
    try:
        from compression import zstd  # type: ignore   # Python ≥ 3.14
        return zstd.ZstdFile(f)
    except ImportError:
        return None


def extract_tar_zst(tar_path: Path, into: Path) -> Path:
    """解 .tar.zst（文件名按 UTF-8，与 Linux 上解出来的一致）。解完由 check_extracted() 按包里的 SHA256SUMS.txt 逐个核对。
    ⚠ 不用 Windows 自带的 tar.exe：它按本机代码页解释 GNU tar 里的文件名，**中文名的文件直接跳过**
      （实测 SDK_使用说明.md / SDK_参数说明.md 两个被跳过，加 --options hdrcharset=UTF-8 也一样），只打一行警告。"""
    into.mkdir(parents=True, exist_ok=True)
    with tar_path.open("rb") as f:
        r = _zstd_reader(f)
        if r is not None:
            with r, tarfile.open(fileobj=r, mode="r|") as tf:
                try:
                    tf.extractall(into, filter="data")
                except TypeError:                              # Python < 3.12 没有 filter 参数
                    tf.extractall(into)
            return into / "fry-halftone"
    if os.name == "nt":
        raise RuntimeError("解 %s 要 zstd 解压：pip install zstandard（或用 Python ≥ 3.14）；"
                           "Windows 自带的 tar.exe 会跳过中文文件名的文件，不能用" % tar_path.name)
    r2 = subprocess.run(["tar", "--zstd", "-xf", str(tar_path), "-C", str(into)], capture_output=True)
    if r2.returncode != 0:
        raise RuntimeError("解不开 %s：%s" % (tar_path.name, r2.stderr.decode("utf-8", "replace")[-300:]))
    return into / "fry-halftone"


def unix_mode_of(p: Path) -> int:
    """整包 zip 里记的 Unix 权限：按**内容**判（ELF / Mach-O / 脚本 = 可执行 0755，其余 0644）。
    ⚠ 不按「tar 里记的权限」：Linux 包是从 Windows 盘（DrvFs）上打的，里面很多文件记成 0777（全员可写）。"""
    with p.open("rb") as f:
        head = f.read(4)
    exe = head[:4] == b"\x7fELF" or head[:4] in (b"\xcf\xfa\xed\xfe", b"\xce\xfa\xed\xfe", b"\xca\xfe\xba\xbe") or head[:2] == b"#!"
    return 0o100755 if exe else 0o100644


def check_extracted(sdk_dir: Path) -> List[str]:
    """展开的 SDK 与包里自带的 SHA256SUMS.txt 逐个对（证明展开出来的 = 包里的；也就是对方 `sha256sum -c` 会看到的）。
    与出包冒烟同一把尺子（fry_delivery_contract.sums_problems）。"""
    return ["展开的 %s：%s" % (sdk_dir.parent.name + "/" + sdk_dir.name, x) for x in fry_delivery_contract.sums_problems(sdk_dir)]


def golden_case(repo: Path, name: str) -> Optional[Dict[str, Any]]:
    return next((c for c in jload(repo / "tests" / "data" / "golden.json")["case_list"] if c["name_str"] == name), None)


def _cli(win_sdk: Path) -> Path:
    return win_sdk / "bin" / "fry-halftone-cli.exe"


def _txt(b: bytes) -> str:
    return b.decode("utf-8", "replace").replace("\r\n", "\n")


def capture_cli_texts(win_sdk: Path, dest: Path) -> Dict[str, Any]:
    """交付的 Windows 命令行真跑 `--help` / `info --json` / `--version`（原文写进 dest，给速查与示例说明用）。"""
    cli = _cli(win_sdk)
    if os.name != "nt" or not cli.is_file():
        return {"ok": False, "why_str": "本机不是 Windows 或没有 %s" % cli.name, "help_str": "", "info_str": "", "version_str": ""}
    dest.mkdir(parents=True, exist_ok=True)
    run = lambda args: _txt(subprocess.run([str(cli)] + args, cwd=str(dest), capture_output=True).stdout)   # noqa: E731
    out = {"ok": True, "help_str": run(["--help"]), "info_str": run(["info", "--json"]).strip(), "version_str": run(["--version"]).strip()}
    (dest / "命令行_help.txt").write_text(out["help_str"], encoding="utf-8", newline="\n")
    (dest / "命令行_info.json").write_text(out["info_str"] + "\n", encoding="utf-8", newline="\n")
    return out


def sample_command(spec: Dict[str, Any], case: Dict[str, Any]) -> Tuple[List[str], Optional[Dict[str, Any]]]:
    """示例的命令行参数（相对路径，在示例目录里执行）；run 方式另返回 request.json 的内容（纯函数）。
    slice 方式只放得下尺寸开关 ⇒ golden 件带别的参数时必须用 run（请求 JSON 与 C 接口 FryHalftone_SliceModelJsonUtf8 同一份）。"""
    model = case["model_str"]
    if spec["via_str"] == "slice":
        p = dict(case["params_dict"])
        flags: List[str] = []
        for key, flag in (("target_height_mm", "--target-height"), ("target_longest_edge_mm", "--target-longest-edge")):
            if p.get(key) is not None:
                flags += [flag, "%g" % p.pop(key)]
        if p:
            raise ValueError("示例 %s 走 slice 只放得下尺寸开关，还有 %s —— 改用 run" % (spec["key_str"], sorted(p)))
        return ["slice", model] + flags + ["--out", "slices", "--json"], None
    return ["run", "request.json", "--json"], {"model": model, "out": "slices", "params": case["params_dict"]}


def run_sample(win_sdk: Path, spec: Dict[str, Any], case: Dict[str, Any], model: Path, dest: Path) -> Dict[str, Any]:
    """★411/412 用交付的 Windows 命令行真跑一个示例（相对路径；输出里的本机绝对路径替换成 <示例目录>）。"""
    cli = _cli(win_sdk)
    base = {"spec_dict": spec, "case_str": case["name_str"], "model_str": model.name}
    if os.name != "nt" or not cli.is_file():
        return dict(base, ok=False, why_str="本机不是 Windows 或没有 %s —— 示例输出要在 Windows 上出" % cli.name)
    dest.mkdir(parents=True, exist_ok=True)
    shutil.copy2(model, dest / model.name)
    args, req = sample_command(spec, case)
    if req is not None:
        (dest / "request.json").write_text(json.dumps(req, ensure_ascii=False, indent=1) + "\n", encoding="utf-8", newline="\n")
    t0 = time.perf_counter()
    r = subprocess.run([str(cli)] + args, cwd=str(dest), capture_output=True)
    sec = round(time.perf_counter() - t0, 2)
    out_txt, err_txt = _txt(r.stdout), _txt(r.stderr)
    for form in sorted({str(dest), str(dest).replace("\\", "\\\\"), dest.as_posix(), str(dest).replace("\\", "/")}, key=len, reverse=True):
        out_txt = out_txt.replace(form, "<示例目录>")
        err_txt = err_txt.replace(form, "<示例目录>")
    leaks = sorted(set(re.findall(r"[A-Za-z]:(?:\\\\|\\|/)[^\"\s]{0,40}", out_txt + err_txt)))   # 脱敏后还剩盘符路径 = 漏了
    (dest / "命令行_stdout_JSON事件.jsonl").write_text(out_txt, encoding="utf-8", newline="\n")
    (dest / "命令行_stderr_进度.txt").write_text(err_txt, encoding="utf-8", newline="\n")
    events = []
    for ln in out_txt.splitlines():
        if ln.strip().startswith("{"):
            try:
                events.append(json.loads(ln))
            except ValueError:
                pass
    result = events[-1].get("result", {}) if events and events[-1].get("type") == "result" else {}
    return dict(base, ok=r.returncode == 0 and result.get("success") is True, rc_int=r.returncode, seconds_float=sec,
                args_list=args, request_dict=req, events_list=events, stderr_str=err_txt, result_dict=result,
                slice_dir=dest / "slices", path_leaks_list=leaks,
                edge_mm_float=case["params_dict"].get("target_longest_edge_mm"))


def bmp_facts(p: Path) -> Dict[str, Any]:
    b = p.read_bytes()
    if b[:2] != b"BM":
        return {}
    _size, _r1, _r2, off = struct.unpack_from("<IHHI", b, 2)
    hsz, w, h, _pl, bpp, comp, _isz, _xp, _yp, clr, _imp = struct.unpack_from("<IiiHHIIiiII", b, 14)
    return {"bytes_int": len(b), "width_int": w, "height_int": abs(h), "bpp_int": bpp, "compression_int": comp,
            "palette_int": clr or (1 << bpp if bpp <= 8 else 0), "pixel_offset_int": off}


PALETTE_TITLE = "BMP 像素值（调色板索引）→ 材料"          # SDK_使用说明.md 第七节那张表（tests/test_output_palette_doc.py 核对它 = C++ 源码）


def palette_rows(usage_text: str) -> List[List[str]]:
    """从随包的 SDK_使用说明.md 里取「像素值 → 材料」表（[像素值, 材料, 喷不喷, 什么时候出现]）；没有这一节 = 空（旧包）。"""
    if PALETTE_TITLE not in usage_text:
        return []
    sec = usage_text.replace("\r\n", "\n").split(PALETTE_TITLE, 1)[1].split("\n#", 1)[0]
    return [[c.strip() for c in ln.strip().strip("|").split("|")] for ln in sec.splitlines()
            if ln.strip().startswith("|") and ln.strip("| ").split("|")[0].strip().isdigit()]


def palette_usage(slice_dir: Path) -> Dict[int, int]:
    """示例输出里每种像素值一共出现多少个像素（逐张读 4 位 BMP；每行末尾的补齐半字节 / 字节不算）。"""
    total: Dict[int, int] = {}
    for bmp in sorted(slice_dir.glob("*.bmp")):
        b = bmp.read_bytes()
        off = struct.unpack_from("<I", b, 10)[0]
        w, h = struct.unpack_from("<ii", b, 18)
        stride, used = ((w * 4 + 31) // 32) * 4, (w + 1) // 2
        for r in range(abs(h)):
            row = b[off + r * stride: off + r * stride + used]
            for val in set(row):
                n = row.count(val)
                total[val >> 4] = total.get(val >> 4, 0) + n
                total[val & 15] = total.get(val & 15, 0) + n
            if w % 2:                                              # 奇数宽：最后一个字节的低半字节是补齐
                total[row[-1] & 15] -= 1
    return {k: v for k, v in sorted(total.items()) if v}


def palette_check(rows: List[List[str]], usage: Dict[int, int], material_counts: Optional[Dict[str, int]],
                  meta: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """★411 开环核对「像素值 → 材料」表（纯函数）：按表从 BMP 数出的每种材料像素数，必须 = 库在 slice_metadata.json
    里自报的各材料体素数（两个互相独立的来源）。表写错一行（例如黄 ↔ 白对调）这里就对不上。
    ★412 补边：输出宽度 > 原生宽度（参数 output_width_px）时，BMP 里多出来的列是像素值 0（null），库不把它算进体素数
      ⇒ null 的期望 = 自报 null + 补边像素数（输出宽 − 原生宽）× 高 × 层数（高 = grid[1]、层数 = slice_count，都取 meta）。
      另核两个总数（同样两个来源）：BMP 像素总数 = 输出宽 × 高 × 层数；自报体素总数 = 原生宽 × 高 × 层数。
      输出宽度 < 原生宽度（裁掉了体素）⇒ 没法逐项核对，直接报出来（不假装核对过）。
      （411 只有一个默认宽度的示例，永远走不到这条路；412 的白底示例 output_width_px=64 > 原生 45，第一次真跑就撞上。）"""
    if not rows or material_counts is None:
        return {"checked_int": 0, "padding_int": 0, "problem_str": ""}
    expected, pad, probs = dict(material_counts), 0, []
    out_w, nat_w = (meta or {}).get("output_width_px_int"), (meta or {}).get("native_width_px_int")
    grid, n = (meta or {}).get("grid_list") or [], (meta or {}).get("slice_count_int")
    if None not in (out_w, nat_w, n) and len(grid) == 3:
        if out_w < nat_w:
            return {"checked_int": 0, "padding_int": 0, "problem_str": (
                "输出宽度 %d < 原生宽度 %d（裁掉了一部分体素）—— 像素数没法与库自报的体素数逐项核对；示例别用比原生窄的 output_width_px"
                % (out_w, nat_w))}
        pad = (out_w - nat_w) * grid[1] * n
        expected["null"] = expected.get("null", 0) + pad
        if sum(usage.values()) != out_w * grid[1] * n:
            probs.append("BMP 像素总数 %d ≠ 输出宽 %d × 高 %d × 层数 %d" % (sum(usage.values()), out_w, grid[1], n))
        if sum(material_counts.values()) != nat_w * grid[1] * n:
            probs.append("库自报的体素总数 %d ≠ 原生宽 %d × 高 %d × 层数 %d" % (sum(material_counts.values()), nat_w, grid[1], n))
    by_mat = {}
    for r in rows:
        m = re.search(r"（(\w+)）", r[1])
        if m:
            by_mat[m.group(1).lower()] = usage.get(int(r[0]), 0)
    bad = {k: (by_mat.get(k), v) for k, v in expected.items() if by_mat.get(k) != v}
    if bad:
        probs.insert(0, "「像素值 → 材料」表与库自报的材料计数对不上（材料：按表数出的像素数, 库自报%s）：%s" % (
            "；null 已加补边 %d" % pad if pad else "", bad))
    out = {"checked_int": len(material_counts), "padding_int": pad, "problem_str": "；".join(probs)}
    if pad:
        out["padding_note_str"] = "(%d − %d) × %d × %d" % (out_w, nat_w, grid[1], n)
    return out


def sample_problems(sample: Dict[str, Any], case: Optional[Dict[str, Any]]) -> List[str]:
    """示例输出要与标准答案（golden）逐字节相同，否则不许打包（交付的命令行跑出来的和标准答案不一样 = 大事）。"""
    key = (sample.get("spec_dict") or {}).get("key_str", "?")
    if not sample.get("ok"):
        return ["示例 %s 没跑成（%s）" % (key, sample.get("why_str") or "返回码 %s" % sample.get("rc_int"))]
    if sample.get("path_leaks_list"):
        return ["示例 %s 的输出里还有本机绝对路径（脱敏漏了）：%s" % (key, sample["path_leaks_list"][:3])]
    if case is None:
        return ["tests/data/golden.json 里没有示例 %s 用的件 %s" % (key, sample.get("case_str"))]
    res = sample.get("result_dict") or {}
    sdk_res = res.get("sdkResult") or res
    if sdk_res.get("bmpMd5") != case["bmp_md5_str"] or res.get("sliceCount") != case["slice_count_int"]:
        return ["示例 %s 与标准答案不一致：%s 张 / md5 %s，标准答案 %d 张 / md5 %s" % (
            key, res.get("sliceCount"), sdk_res.get("bmpMd5"), case["slice_count_int"], case["bmp_md5_str"])]
    return []


def cli_texts_problems(texts: Dict[str, Any], version: str) -> List[str]:
    if not texts.get("ok"):
        return ["命令行帮助 / 版本没跑成（%s）" % texts.get("why_str")]
    if version and texts.get("version_str") != "%s-cli %s" % (PACKAGE, version):
        return ["交付的命令行自报 %r ≠ %s-cli %s（跑的不是这一版）" % (texts.get("version_str"), PACKAGE, version)]
    return []


def where_values_appear(samples: List[Dict[str, Any]], values: List[int]) -> str:
    """★412 「哪个值只在哪个示例里有」从计数现算（纯函数）—— 第一版写死「白 9 只在白底示例里有」，而示例 2 的球心就有 467,577 个 9。"""
    parts = []
    for v in values:
        keys = [s["spec_dict"]["key_str"] for s in samples if (s.get("usage_dict") or {}).get(v, 0) > 0]
        if len(keys) == 1:
            parts.append("%d 只在示例 %s 里有" % (v, keys[0]))
        elif len(keys) < len(samples):
            parts.append("%d 在示例 %s 里有" % (v, "、".join(keys)))
    return "；".join(parts) or "每个值在每个示例里都有"


def palette_coverage(rows: List[List[str]], usages: List[Dict[int, int]]) -> Dict[str, Any]:
    """★412 对照表的每一行有没有被至少一个示例用到（计数 > 0）—— 没用到的行，开环核对只是「0 = 0」，没有判别力。"""
    seen = {k for u in usages for k, v in u.items() if v > 0}
    vals = [int(r[0]) for r in rows]
    return {"covered_list": [v for v in vals if v in seen], "uncovered_list": [v for v in vals if v not in seen]}


# ───────────────────────────── ④ 从上游生成的速查 ─────────────────────────────
def doc_ref(text: str) -> str:
    """从 SDK_使用说明.md 原样取来的文字里「见第六节」指的是**那份文档**的章节 ⇒ 放进别的文档要改写，否则读者会翻错地方。"""
    return re.sub(r"见第([一二三四五六七八九十]+)节", r"见 `SDK_使用说明.md` 第\1节", text)


def api_rows(header_text: str, usage_text: str) -> List[Tuple[str, str, str]]:
    """接口速查：签名来自头文件，作用来自 SDK_使用说明.md 的「接口一览」表（两份都是随包的原文）。"""
    # 只认行首的声明（头文件前面 `#  define FRY_API …` 那几行也含 FRY_API，不锚行首会把宏定义吞进返回类型）
    decls = re.findall(r"^FRY_API\s+([^;(#]+?)\s+FRY_CALL\s+(\w+)\s*\(([^;]*?)\)\s*;", header_text, flags=re.M)
    table = []
    sec = usage_text.split("## 四、接口一览", 1)[-1].split("\n## ", 1)[0]
    for ln in sec.splitlines():
        cells = [c.strip() for c in ln.strip().strip("|").split("|")]
        if len(cells) >= 2 and "FryHalftone_" in cells[0]:
            table.append((cells[0], cells[1]))

    def purpose(name: str) -> str:
        short = name.replace("FryHalftone_", "")
        for first, desc in table:
            if "`%s`" % name in first or "`%s()`" % name in first or "`%s`" % short in first:
                return desc
            if name.endswith("Utf8") and "`%s`" % name[:-4] in first and "Utf8" in first:
                return desc
        return ""
    rows = []
    for ret, name, args in decls:
        sig = "%s %s(%s)" % (" ".join(ret.split()), name, " ".join(args.split()))
        rows.append((name, sig, doc_ref(purpose(name))))
    return rows


def return_code_rows(header_text: str, usage_text: str = "") -> List[Tuple[str, str, str, str]]:
    """返回码：值与名字取头文件（真源），中文含义优先取 SDK_使用说明.md「返回码」表（写得更全），英文取头文件注释。"""
    zh_doc: Dict[str, str] = {}
    sec = usage_text.split("### 返回码", 1)[-1].split("\n#", 1)[0] if "### 返回码" in usage_text else ""
    for ln in sec.splitlines():
        cells = [c.strip() for c in ln.strip().strip("|").split("|")]
        if len(cells) >= 3 and cells[1].strip("`").startswith("FRY_HALFTONE_"):
            zh_doc[cells[1].strip("`")] = cells[2]
    rows = []
    for m in re.finditer(r"^#define\s+(FRY_HALFTONE_\w+)\s+(\d+)\s*/\*\s*(.*?)\s*\*/", header_text, flags=re.M):
        parts = re.split(r"\s{2,}", m.group(3).strip())
        rows.append((m.group(2), m.group(1), doc_ref(zh_doc.get(m.group(1), parts[0])), parts[-1] if len(parts) > 1 else ""))
    return rows


def param_table_lines(param_doc_text: str) -> List[str]:
    """参数表（库自报 schema 生成的 SDK_参数说明.md 里「参数表」那一节，原样取）。"""
    sec = param_doc_text.split("## 一、", 1)[-1].split("\n## ", 1)[0]
    return [ln for ln in sec.splitlines() if ln.startswith("|")]


def sdk_tree_rows(sdk_dir: Path) -> List[Tuple[str, str]]:
    return [(p.relative_to(sdk_dir).as_posix(), SDK_FILE_NOTES.get(p.relative_to(sdk_dir).as_posix(), ""))
            for p in sorted(sdk_dir.rglob("*"), key=lambda q: q.relative_to(sdk_dir).as_posix()) if p.is_file()]


# ───────────────────────────── ⑤ 给同事的说明 ─────────────────────────────
def mb(p: Path) -> str:
    return "%.2f MB" % (p.stat().st_size / 1048576.0)


def export_count(rep: Dict[str, Any]) -> str:
    s = str((rep.get("smoke_dict") or {}).get("export_surface_str", ""))
    return s[3:] if s.startswith("ok_") else "?"


def tested_of(inp: Dict[str, Any], side: str) -> Dict[str, Any]:
    if not inp.get("integration"):
        return {}
    d = inp["integration"]["data"].get(side) or {}
    t = {k: {"ok": v.get("ok"), "note": v.get("why_str") or "rc=%s" % v.get("rc_int")}      # ok=None = 跳过（本机缺工具）
         for k, v in (d.get("steps_dict") or {}).items()}
    t["_where"] = d.get("where_str", "")
    return t


LEVEL_ZH = {"major": "主版本", "minor": "次版本", "patch": "修订号", "none": "没升（同号重出）", "first": "首个编号版"}


def version_record_text(state: Dict[str, Any], root: Optional[Path] = None) -> str:
    """历次交付一行一条。root = 全交付目录的根：某一行的目录已经挪进 `_作废/` 就在那一行标出来（记录不删，只标）。"""
    rows = state.get("deliveries_list", [])
    lines = ["# 版本记录（每次交付一行，新的在最后）", "",
             "> 版本号规则：交付版一律 `X.Y.Z`，**0.1.0 起每次交付递增**；同一个版本号只对应一批字节（下表三个包的 sha256）。",
             "> 真源：打包仓 `delivery_versions.json`（进 git）。", "",
             "| 版本 | 交付时间 | 目录 | 算法指纹 | 外壳指纹 | Windows 包 | Linux 包 | macOS 验收包 | 与上一版相比 | 升了哪一位（为什么） |",
             "|---|---|---|---|---|---|---|---|---|---|"]
    prev = None
    for r in rows:
        pk = r.get("packages_dict") or {}
        if prev is None:
            diff = "首个编号交付版"
        elif prev.get("version_str") == r.get("version_str"):
            diff = "同一版本、同一批包重出目录"
        else:
            parts = []
            if r.get("algorithm_fingerprint_str") != prev.get("algorithm_fingerprint_str"):
                parts.append("**算法变了**")
            if r.get("wrapper_sha256_str") != prev.get("wrapper_sha256_str"):
                parts.append("外壳 / 命令行变了")
            diff = "、".join(parts) or "算法与外壳都没变，只有文档 / 打包变化"
        if root is not None and r.get("dir_str") and (root / VOID_DIR_NAME / r["dir_str"]).exists():
            diff += "（⚠ 这个目录已作废、挪进 `%s/`，原因见 `_交付记录.md`；包本身与同版本其它行逐字节相同）" % VOID_DIR_NAME
        lvl = LEVEL_ZH.get(r.get("bump_level_str") or SF.bump_level(prev.get("version_str") if prev else None, r["version_str"]), "?")
        why = "；".join(r.get("bump_reasons_list") or []) or "—（这一行的记录里没写原因，412 之前的交付）"
        lines.append("| **%s** | %s | `%s` | `%s…` | `%s…` | `%s…` | `%s…` | `%s…` | %s | %s：%s |" % (
            r.get("version_str"), r.get("created_at_str", "")[:16].replace("T", " "), r.get("dir_str", ""),
            str(r.get("algorithm_fingerprint_str", ""))[:12], str(r.get("wrapper_sha256_str", ""))[:12],
            str(pk.get("win32-x64", ""))[:12], str(pk.get("linux-x64", ""))[:12], str(pk.get("verify-kit", ""))[:12], diff, lvl, why))
        prev = r
    return "\n".join(lines) + "\n"


def readme_text(inp: Dict[str, Any], rows: List[Dict[str, Any]], dir_name: str, exp: Dict[str, int],
                ctx: Dict[str, Any]) -> str:
    v, fp, wr = inp["version"], inp["fingerprint"], inp["wrapper"]
    g = exp["golden_int"]
    win_rep = inp["win"]["report_dict"]
    sample = ctx.get("sample") or {}
    prev = DV.last_version(inp["versions_state"])
    prev_rec = next((r for r in reversed(inp["versions_state"].get("deliveries_list", [])) if r.get("version_str") == prev), None)
    if prev_rec is None:
        change = "首个编号交付版：之前交出去的都是 `0.0.0-dev` 本地调试构建"
    elif prev_rec.get("version_str") == v:
        change = ("%s 这一版再出一次目录：三个包与上一次出的**逐字节相同**、sha256 逐个核对过；本目录修正 / 补充了说明与证据"
                  % v)
    else:
        change = "上一版 %s · %s；本版：%s" % (prev, prev_rec.get("created_at_str", "")[:10],
                                          "、".join(x for x in (
                                              "**算法变了**" if prev_rec.get("algorithm_fingerprint_str") != fp else "",
                                              "外壳 / 命令行变了" if prev_rec.get("wrapper_sha256_str") != wr else "") if x)
                                          or "算法与外壳都没变，只有文档 / 打包变化")
    heads = [ln[4:].strip() for ln in ctx.get("changelog_section", "").splitlines() if ln.startswith("### ")]
    klr = inp.get("kit_linux_report")
    kit_line = ("| 验收包的整条流程（Mac 上跑的就是它） | %s（%s 目标） | **同一个验收包、同一个 `run_on_target.sh`** 已在真 Linux 上跑通：golden %d / %d、命令行契约、交付清单全过"
                "（`%s/%s`）—— Mac 上换成 macOS 的二进制跑同一套步骤 |\n"
                % (klr["host_str"], klr["platform_str"], g, g, DIRS["evidence"], KIT_LINUX_REPORT_NAME)) if klr else ""
    table = "\n".join("| `%s` | %s | %s | %s | %s |" % (r["path"], r["platform"], r["status_zh"], r["min_os"], r["size"])
                      for r in rows)
    lin = next(iter(inp["linux"].values()), None)
    env = jload(lin["env"]) if lin and lin["env"].is_file() else {}
    lin_rep = lin["report_dict"] if lin else {}

    def quick(plat: str, keys: List[str]) -> str:
        spec = G.STEPS[plat]
        t = tested_of(inp, {"win32-x64": "windows", "linux-x64": "linux"}.get(plat, "")) if plat != "darwin" else {}
        out = ["| # | 做什么 | 命令 | 实测 |", "|---|---|---|---|"]
        for i, s in enumerate([s for s in spec["steps"] if s["key"] in keys], 1):
            got = (t.get(s["key"]) or {}).get("ok", "absent")
            mark = ("—（等 Mac 验收）" if plat == "darwin" else "✅" if got is True else "❌" if got is False else
                    "—（未实测：%s）" % t[s["key"]]["note"] if got is None else "—")
            out.append("| %d | %s | `%s` | %s |" % (i, s["title"], G.fill(s["cmd"], model="<模型.glb>", version=v).replace("|", "\\|"), mark))
        return "\n".join(out)
    api = "\n".join("| `%s` | `%s` | %s |" % (n, sig.replace("|", "\\|"), p) for n, sig, p in ctx.get("api_rows", []))
    rcs = "\n".join("| %s | `%s` | %s | %s |" % r for r in ctx.get("rc_rows", []))
    params = "\n".join(ctx.get("param_lines", []))
    help_block = sample.get("help_str", "").strip() or "（本次没能在 Windows 上真跑命令行，见 SDK_使用说明.md 第十节）"
    ev = sample.get("events_list") or []
    ev_sample = "\n".join(json.dumps(e, ensure_ascii=False) for e in (ev[:2] + ev[-1:] if len(ev) > 3 else ev))
    if len(ev_sample) > 2500:
        ev_sample = ev_sample[:2500] + " …（完整见 05_示例输出/%s/命令行_stdout_JSON事件.jsonl）" % SAMPLES[0]["key_str"]
    res = sample.get("result_dict") or {}
    sdk_res = res.get("sdkResult") or {}
    bf = ctx.get("bmp_facts") or {}
    samples = ctx.get("samples") or []
    prow = ctx.get("palette_rows") or []
    samples_md = "\n".join("| `%s/%s/` | %s | `%s` | %s 张（%s × %s）｜ md5 = golden `%s` ✓ |" % (
        DIRS["sample"], s["spec_dict"]["key_str"], s["spec_dict"]["title_str"], _cmd_str(s), (s.get("result_dict") or {}).get("sliceCount", "?"),
        (s.get("bmp_facts_dict") or {}).get("width_int", "?"), (s.get("bmp_facts_dict") or {}).get("height_int", "?"), s.get("case_str"))
        for s in samples)
    if prow and samples:
        def cell(s: Dict[str, Any], val: int) -> str:
            u = s.get("usage_dict") or {}
            n = sum(u.values()) or 1
            return ("%s（%.1f%%）" % (format(u[val], ","), 100.0 * u[val] / n)) if u.get(val) else "0"
        head = "| 像素值 | 材料 | 打印机喷不喷 | 什么时候出现 | %s |\n|---:|---|---|---|%s\n" % (
            " | ".join("示例 %s 的像素数" % s["spec_dict"]["key_str"] for s in samples), "---:|" * len(samples))
        palette_md = ("**BMP 像素值 → 材料**（调色板本身是灰度 ⇒ 按像素值认材料；表取自随包 `SDK_使用说明.md` 第七节，出包测试核对它 = C++ 源码）：\n\n"
                      + head + "\n".join("| %s | %s | %s | %s | %s |" % (r[0], r[1], r[2], r[3], " | ".join(cell(s, int(r[0])) for s in samples))
                                          for r in prow))
        cov = ctx.get("palette_coverage") or {}
        checked = [s for s in samples if (s.get("palette_check_dict") or {}).get("checked_int") and not s["palette_check_dict"].get("problem_str")]
        if checked:
            palette_md += ("\n\n★ 这张表用 %d 个示例逐像素核对过：每个示例按表从 BMP 数出的各材料像素数 = 库在 `slice_metadata.json` 的 "
                           "`material_count_dict` 里自报的体素数（逐项相等）。" % len(checked))
            padded = [s for s in checked if s["palette_check_dict"].get("padding_int")]
            if padded:
                palette_md += "".join(
                    "⚠ 示例 %s 给了 `output_width_px`，比模型原生宽度宽 ⇒ BMP 多出来的列是像素值 0（空、不喷），库不把它算进体素数："
                    "核对时 0 那一项要加上补边 %s 个像素 = %s（输出宽 − 原生宽）× 高 × 层数。" % (
                        s["spec_dict"]["key_str"], format(s["palette_check_dict"]["padding_int"], ","),
                        s["palette_check_dict"].get("padding_note_str", "")) for s in padded)
        if cov.get("uncovered_list"):
            palette_md += "\n\n⚠ 像素值 %s 在这几个示例里都没出现 —— 这几行只由「出包测试核对 = C++ 源码」那一道闸管着。" % cov["uncovered_list"]
        elif cov.get("covered_list"):
            palette_md += "\n\n★ 表里 %d 个像素值**每一个都在示例里真实出现过**（%s）⇒ 每一行都被开环核对到了。" % (
                len(cov["covered_list"]), where_values_appear(samples, cov["covered_list"]))
    else:
        palette_md = "（这一版的 SDK_使用说明.md 还没有「像素值 → 材料」对照表）"
    meta_keys = ctx.get("meta_keys", [])
    integ = inp.get("integration")
    integ_line = ""
    if integ:
        d = integ["data"]

        def side_txt(side: str, name: str) -> str:
            st = d[side]["steps_dict"]
            skipped = [k for k, x in st.items() if x.get("ok") is None]
            return "%s %d / %d ✅%s（%s）" % (name, sum(1 for x in st.values() if x.get("ok") is True), len(st),
                                            "，跳过 %s" % "、".join(skipped) if skipped else "", d[side].get("where_str", ""))
        integ_line = ("| 集成命令实测（本说明第三节与各平台集成说明里的每一条命令，原样执行） | 实测机 | %s ｜ %s |"
                      % (side_txt("windows", "Windows"), side_txt("linux", "Linux")))
    kit_linux = [t for t in ("linux-x64", "linux-arm64") if t in (inp["mac"]["kit_info_dict"].get("targets_dict") or {})]
    lin_server = ("要在你们的服务器上确认，就把 `%s/` 里的同一个验收包拷到服务器上执行同一条命令（这个验收包也带 %s 的目标）。"
                  % (DIRS["mac"], " / ".join(kit_linux)) if kit_linux else
                  "要在你们的服务器上确认，请找我们要一个带 Linux 目标的验收包（这一次的验收包只带 macOS 目标）。")
    heads_md = "\n".join("- " + h for h in heads) or "- （见 `07_版本记录/本版变更.md`）"
    req = inp.get("bump_required_dict") or {}
    lvl = SF.bump_level(DV.last_version(inp["versions_state"]), v)
    bump_md = "%s%s —— 按对外接口面与两个指纹自动判定：%s%s" % (
        LEVEL_ZH.get(lvl, lvl), "（%s → %s）" % (DV.last_version(inp["versions_state"]), v) if lvl not in ("first", "none") else "",
        "；".join(req.get("reasons_list") or ["—"]),
        "（上一版的记录里没有接口面：两个指纹都没变 ⇒ 接口面必然没变，按推断比）" if req.get("inferred_bool") else "")
    sf = inp.get("surface_dict") or {}
    n_sub = len([x for x in sf.get("cli_list", []) if not x.startswith("--")])
    surface_md = "C 接口 %d 个 ｜ 参数 %d 个 ｜ 命令行 %d 个子命令 + %d 个开关（清单记进交付记录，下一版据此判定升哪一位）" % (
        len(sf.get("api_list", [])), len(sf.get("params_list", [])), n_sub, len(sf.get("cli_list", [])) - n_sub)
    older = [r for r in inp["versions_state"].get("deliveries_list", [])
             if DV.parse(r.get("version_str", "")) and DV.parse(r["version_str"]) < DV.parse(v)]
    first_note = "（这是第一个编号版：这一节包含首版以来的全部变更，新的在上）" if not older else ""
    missing = []
    if not inp["parity"]:
        missing.append("| 跨平台一致性复核 | —— | ⚠ **这一版没做**（没有一致性证据）：只有各平台冒烟里的 golden 标准件逐字节 |")
    if not integ:
        missing.append("| 集成命令实测 | —— | ⚠ **这一版没做**：各平台集成说明里的命令标「还没有逐条实测」 |")
    if not inp.get("kit_linux_report"):
        missing.append("| 验收包的整条流程 | —— | ⚠ **这一版没在真 Linux 上跑过验收包**（Mac 上的步骤没有预演） |")
    if inp.get("colleague_check_bool"):
        colleague_line = ("| 站在你的角度复验整包（打完 zip 之后） | WSL 真 Linux | 解开整包 zip → 顶层 `sha256sum -c` → Linux 命令行不 chmod 直接跑、"
                          "自报版本 %s → 包里 `verify_delivery.py` 与 `sha256sum -c` → 第七节 %d 个示例各自只拷模型（+ request.json）到空目录、"
                          "照示例说明的命令用 **Linux** 命令行重出，BMP 与本目录里（Windows 出的）逐字节相同、自报 md5 相同 ｜ "
                          "**没过的目录会被挪进 `%s/`、不记版本号** ⇒ 你拿到的这个目录就是过了的 |" % (v, len(SAMPLES), VOID_DIR_NAME))
    else:
        colleague_line = "| 站在你的角度复验整包 | —— | ⚠ **这一版没做**（没在 Linux 上解开整包、照说明重出示例） |"
    evidence_rows_md = "\n".join(x for x in [kit_line.rstrip("\n"), integ_line, colleague_line] + missing if x)   # 表格行之间不能有空行
    # ★412 跟数据走的话从数据现算（412_08：写死的「只在白底示例」被数据否定过）：glibc 下限取 Linux 出包报告；CentOS 7 那句只在下限正好 2.17 时成立
    gm = re.search(r"glibc ≥ ([\d.]+)", lin_rep.get("min_os_str", "") or "")
    glibc_floor_md = ("glibc ≥ %s%s" % (gm.group(1), "（CentOS 7 起都能加载）" if gm.group(1) == "2.17" else "")) if gm else "上表「最低系统」那一列"
    sample_names_md = " / ".join(s["spec_dict"]["title_str"].split("：", 1)[0] for s in samples) or "—"
    evidence_what = "、".join(["各平台 build_report", "Linux 环境", "交叉编译静态闸", "验收包信息"]
                             + (["跨平台一致性实验"] if inp["parity"] else []) + (["集成命令实测"] if integ else []))
    return f"""# 水转印加网 SDK · 交付说明 v{v}

> 交付目录：`{dir_name}` ｜ 交付日期：{time.strftime("%Y-%m-%d")} ｜ 算法：`water_transfer_depth`（水转印 + 深度抖动）
> 版本号：**{v}**（{change}）
> 算法指纹：`{fp}`
> 外壳指纹：`{wr}`（命令行 / dll 外壳 / 导出表的源码；三个平台必须相同，已过闸）
> 整包：与本目录同级的 `{dir_name}.zip` 就是这个目录（中文文件名按 UTF-8 存，Mac / Linux 解压不乱码；可执行文件记了 Unix 权限，解开就能跑）
>
> **English**: Version {v}. Windows and Linux packages are verified (golden suite byte-identical, CLI contract, delivery checklist);
> every package is also **unpacked** here, so `include/`, `lib/`, `examples/` and all docs are visible without extracting anything.
> macOS ships as a verify kit: run one command on your Mac (`{DIRS["mac"]}/macOS验收步骤.md`); when it passes, `results/` holds the macOS packages.

---

## 一、这一版（v{v}）

| 项 | 值 |
|---|---|
| 版本号 | **{v}** —— 交付版一律 `X.Y.Z`，0.1.0 起每次交付递增（历次见 `{DIRS["versions"]}/版本记录.md`） |
| 与上一版 | {change} |
| 升了哪一位 | {bump_md} |
| 对外接口面 | {surface_md} |
| 本版变更（CHANGELOG「## {v}」这一节的条目） | 共 {len(heads)} 条，完整原文见 `{DIRS["versions"]}/本版变更.md`{first_note} |

{heads_md}

## 二、这一包里有什么

| 文件 | 平台 | 状态 | 最低系统（从二进制实测） | 大小 |
|---|---|---|---|---|
{table}

| 目录 | 里面是什么 |
|---|---|
| `{DIRS["win"]}/fry-halftone/` | ★ **Windows 包展开**：`bin\\`（dll + 命令行）`include\\` `lib\\` `examples\\`（C / C# / Python）+ 全部说明 + 自检脚本 —— 不用解压就能看 |
| `{DIRS["win"]}/Windows_集成说明.md` | 照着敲就能跑的命令（C / Python / C# / 命令行），每条都实测过 |
| `{DIRS["win"]}/给业务_使用说明.md` | 只想替换算法仓软件里的 dll 时看这一份 |
| `{DIRS["linux"]}/fry-halftone/` | ★ **Linux 包展开**（`bin/` 里是 `.so` + 命令行） |
| `{DIRS["linux"]}/Linux_集成说明.md` | Linux 上的命令（cc / python3 / 命令行），每条都实测过 |
| `{DIRS["mac"]}/` | 验收包 + 《macOS验收步骤.md》（怎么验、**六条怎样算成功**）+ 《macOS_集成说明.md》（验收通过后怎么用）+ 验收包说明 |
| `{DIRS["docs"]}/` | 所有说明的副本 + `include/` + `examples/` + 《接口速查》《命令行速查》（不用进平台目录也能先读） |
| `{DIRS["sample"]}/` | ★ **{len(samples)} 个示例真跑**（{sample_names_md}）：每个都有输入模型、命令（或 request.json）、全部 BMP、`slice_metadata.json`、进度与 JSON 事件，并且都与标准答案**逐字节相同** |
| `{DIRS["evidence"]}/` | 我们这边的验收记录：{evidence_what} |
| `{DIRS["versions"]}/` | 历次交付的版本记录 + 本版变更全文 |
| `bundle_manifest.json` / `SHA256SUMS.txt` | 机读清单与校验和：Mac `shasum -a 256 -c SHA256SUMS.txt`，Linux `sha256sum -c SHA256SUMS.txt` |

Windows 包里每个文件是干什么的（`{DIRS["win"]}/fry-halftone/`）：

| 文件 | 作用 |
|---|---|
{chr(10).join("| `%s` | %s |" % (rel, note) for rel, note in ctx.get("win_tree", []))}

## 三、三个平台 5 分钟上手（在解包后的 `fry-halftone/` 目录里执行）

### Windows（cmd）

{quick("win32-x64", ["verify", "cli_version", "cli_slice", "c_build", "c_run", "py_run"])}

C# 的 5 步见 `{DIRS["win"]}/Windows_集成说明.md`（也实测过）。

### Linux（bash）

{quick("linux-x64", ["verify", "cli_version", "cli_slice", "c_build", "c_run", "py_run"])}

### macOS（先在 Mac 上验收，通过后在 `results/` 的包里执行）

{quick("darwin", ["quarantine", "verify", "cli_version", "cli_slice", "c_build", "c_run", "py_run"])}

⚠ **可执行文件要和库在同一个目录**（上面的编译命令都输出到 `bin/`）：Windows 就近加载 dll；Linux 的 RUNPATH=`$ORIGIN`、macOS 库的 install_name=`@loader_path/` 都只认同目录。

## 四、接口速查（{len(ctx.get("api_rows", []))} 个 C 函数，签名取自 `include/fry_halftone.h`）

| 函数 | 签名 | 作用 |
|---|---|---|
{api}

返回码：

| 值 | 名字 | 含义 | English |
|---:|---|---|---|
{rcs}

★ 一句话上手：`FryHalftone_GetVersion()` 看版本 → `FryHalftone_SliceModelJsonUtf8(请求JSON, 结果缓冲, …)` 出片 → 返回 0 成功，非 0 读 errorBuffer（中文原因）。
同一时刻只跑一个作业（并发返回 6 BUSY）；进度回调在调用线程上同步触发；要中止从**另一个线程**调 `FryHalftone_Cancel()`。

## 五、参数速查（JSON 接口 `params` / 命令行 `--params` 用；表格由库自己导出的说明生成）

{params}

⚠ 尺寸二选一必须给一个（`target_height_mm` 或 `target_longest_edge_mm`）；`use_black_k=true` 时必须给 `ink_k_um`；写错键名或类型直接返回 2（不静默忽略）。

## 六、命令行速查（`bin/fry-halftone-cli`，Windows 是 `.exe`）

`--help` 原文（交付的命令行真跑出来的）：

```
{help_block}
```

| 约定 | 取值 |
|---|---|
| 输出目录 | 不存在就建；**必须是空的**，否则退出码 4 |
| 进度（stderr） | 逐行 `[fry-halftone-cli] progress=N stage=...`；成功最后一行 `[fry-halftone-cli] done. slices=N`（与 lmst-cli 同一种格式） |
| `--json`（stdout） | 一行一个事件：若干 `progress` + 一个 `result` 信封（库的原始结果在 `result.sdkResult` 里） |
| 退出码 | 0 成功 ｜ 2 用法 / 参数错 ｜ 3 模型不存在 ｜ 4 输出目录问题 ｜ 11 出片失败 ｜ 12 输出不完整 |

`--json` 事件的真实样子（示例 1 的头两条 + 结果；完整在 `{DIRS["sample"]}/{SAMPLES[0]["key_str"]}/命令行_stdout_JSON事件.jsonl`）：

```
{ev_sample}
```

## 七、输出长什么样（`{DIRS["sample"]}/` 是 {len(samples)} 个示例真跑）

| 示例 | 参数 | 命令（在示例目录里执行） | 结果 |
|---|---|---|---|
{samples_md}

以示例 1 为例：

| 项 | 值 |
|---|---|
| 结果 | {res.get("sliceCount", "?")} 张 BMP，用时 {sample.get("seconds_float", "?")} s；BMP md5 `{sdk_res.get("bmpMd5", "?")}` = 标准答案（golden `{SAMPLE_CASE}`）**逐字节相同** |
| 文件名 | `000000.bmp` … 连续编号，一张 = 一个打印层（z 方向，层高 `voxel_mm[2]` = 0.01 mm） |
| BMP 格式 | 宽 {bf.get("width_int", "?")} × 高 {bf.get("height_int", "?")} 像素，{bf.get("bpp_int", "?")} 位调色板（{bf.get("palette_int", "?")} 色），每张 {bf.get("bytes_int", "?")} 字节；宽 = 喷头方向像素数（`output_width_px`），高 = 运行方向 |
| `slice_metadata.json` | 层数、首末文件名、落墨体素数、墨滴尺寸、输出宽度、SDK 版本、引擎、算法指纹、本次生效的全部参数与尺寸口径… 共 {len(meta_keys)} 个字段：{"、".join("`%s`" % k for k in meta_keys)} |
| `_orient.json` | 摆放朝向（模型轴 → 体素轴的矩阵）与输出宽度 |

{palette_md}

## 八、我们这边已经验过什么

| 平台 | 在哪验的 | 结果 |
|---|---|---|
| Windows x64 | {win_rep.get("host_str", "?")} | 导出面 {export_count(win_rep)} 个接口 ｜ golden {g} / {g} 件与 Python 生产线逐字节一致 ｜ C 接口用例全过 ｜ 命令行契约全过 ｜ 交付清单 {(win_rep.get("smoke_dict") or {}).get("delivery_items_int", "?")} 项 |
| Linux x86-64 | {env.get("os_str", "?")} ｜ {env.get("glibc_str", "?")} ｜ 内核 {env.get("kernel_str", "?")}（WSL2 = 真 Linux 内核） | 导出面 {export_count(lin_rep)} 个接口 ｜ golden {g} / {g} 件逐字节 ｜ C 接口用例全过 ｜ 命令行契约全过 ｜ 交付清单 {(lin_rep.get("smoke_dict") or {}).get("delivery_items_int", "?")} 项 ｜ 来源：{lin_rep.get("build_origin_str", "?")} |
| macOS arm64 / x64 | 还没有（Windows 上没有合法的 macOS 运行环境） | 二进制已编好，并过了静态闸（格式 / 架构 / 签名 / 装载路径 / 导出面 / 不含构建机路径与调试映射）；**逐字节验收请在你的 Mac 上做** |
{evidence_rows_md}

{parity_sentence(inp["parity"])}
`{DIRS["evidence"]}/` 里每个文件是什么：

| 文件 | 是什么 |
|---|---|
{chr(10).join("| `%s` | %s |" % r for r in ctx.get("evidence_rows", []))}

## 九、已知限制（请先知道）

1. **macOS 还没在真机上验过**：交付的是验收包。验收通过（见《macOS验收步骤.md》里的「成功标准」）之前，请不要把 macOS 版当正式件用。
2. **Linux**：库实测只要求 {glibc_floor_md}，但**逐字节一致只在上表那台机器的 glibc 上实测过**。{lin_server}
3. 同一个进程里同一时刻只能跑一个作业（并发返回 6 = BUSY）；命令行的输出目录必须是空的。
4. 暂不支持的模型写法返回 7（Draco / meshopt 压缩、GPU 实例化、渐进式 JPEG、没有回退的 WebP 等，完整清单见 `SDK_使用说明.md` 第六节）。
5. 所有平台包里都有全套说明，**以包里的为准**（`{DIRS["docs"]}/` 是副本）。

## 十、常见问题

| 问 | 答 |
|---|---|
| 版本号在哪看？ | 包名、`VERSION`、`sdk_info.json`、`FryHalftone_GetVersion()`、`fry-halftone-cli --version`、Windows dll 右键属性 → 详细信息，六处一致 |
| 要装 VC++ 运行库吗？ | 不用（C++ 运行库已静态链入，UCRT 用系统自带的） |
| 中文路径？ | 支持：Windows 用宽字符版 `FryHalftone_SliceModel` 或 UTF-8 版 `…Utf8`；命令行直接给中文路径（出包测试里测过） |
| 进度 / 取消？ | 进度回调在调用线程同步触发；从另一个线程调 `FryHalftone_Cancel()`，在下一个检查点返回 5 |
| 返回 7？ | 模型用了暂不支持的写法，errorBuffer 写明是哪一种 |
| 返回 1？ | errorBuffer 开头就是原因（坏文件 / 内存不足 / 输出宽度小于模型…）；不会把进程带崩 |
| 找不到库（Linux / macOS）？ | 程序要和库在同一个目录，或设 rpath / `LD_LIBRARY_PATH`（见各平台集成说明） |
| Mac 上「无法验证开发者」？ | `xattr -dr com.apple.quarantine <解包目录>` |
| Linux 上展开的 `bin/fry-halftone-cli` 报 Permission denied？ | 整包 zip 里记了可执行权限（`unzip` 会保留）；被别的解压工具丢了就 `chmod +x bin/fry-halftone-cli`，或者直接解同目录的 `.tar.zst` |
| 在 Linux / Mac 上能直接用 `{DIRS["win"]}/fry-halftone/` 里的东西吗？ | 说明、头文件、示例、参数表是三平台同一份（出包时逐字节核对过）；二进制（`bin/`）只能在各自平台用 |
| 两次交付怎么比？ | 看 `{DIRS["versions"]}/版本记录.md`：算法指纹变了 = 算法变了；只有外壳指纹变 = 命令行 / 外壳变了 |

## 十一、发回什么

- macOS 验收完：把 `fry-halftone-verify-kit/results/` 整个目录压缩发回（里面有可交付的 macOS 包和验收记录）。
- 任何平台有问题：发回命令的完整输出（或 `verify.log` / `verify_delivery.py` 的输出），并注明版本号 **{v}**。
"""


def mac_guide_text(inp: Dict[str, Any], exp: Dict[str, int]) -> str:
    v, fp = inp["version"], inp["fingerprint"]
    kit = inp["mac"]["archive"].name
    ki = inp["mac"]["kit_info_dict"]
    tg = ki.get("targets_dict") or {}
    minos = (tg.get("macos-arm64") or {}).get("min_os_str") or "macOS 13.0"
    n_api = export_count(inp["win"]["report_dict"])
    g, dm = exp["golden_int"], exp["delivery_mac_int"]
    kit_note = ("\n> ★ 这套流程我们已经在真 Linux 上完整跑通过：**同一个验收包、同一个 `run_on_target.sh`**（linux-x64 目标，%s）"
                "golden %d / %d 逐字节、命令行契约、交付清单全过。你在 Mac 上跑的就是这套步骤，只是换成 macOS 的二进制。\n"
                % (inp["kit_linux_report"]["host_str"], g, g)) if inp.get("kit_linux_report") else ""
    return f"""# macOS 验收步骤（给有 Mac 的同事）· v{v}

> 验收包：`{kit}`（版本 `{v}`）｜ 算法指纹：`{fp}`
>
> **English**: Unpack the kit on your Mac and run `bash fry-halftone-verify-kit/run_on_target.sh --also-x64`.
> Exit code 0 plus a `✓ … 可交付` line per target means it passed. `results/` then holds the deliverable macOS packages. Send `results/` back.

---

## 〇、为什么要你来验

我们的 Windows 电脑能把 macOS 版**编出来**，但**运行**不了它（Apple 只许在 Apple 硬件上运行 macOS）。
而这个 SDK 的承诺是「切片与 Python 生产线**逐字节**一致」，数学函数（sin / pow / atan2）又是每台机器的系统库自己算的
⇒ **只有在真 Mac 上跑一遍才算数**。验收包里有编好的 macOS 二进制和全部判据，一条命令跑完：装配 → 冒烟（{g} 件标准答案逐字节比对、命令行契约、交付清单）→ 出包。
{kit_note}
## 一、准备（一次性，约 5 分钟）

| # | 要什么 | 怎么装 / 怎么查 |
|---|---|---|
| 1 | macOS 13（Ventura）或更新；Apple Silicon（M1~M4）或 Intel 都行 | 左上角苹果菜单 →「关于本机」（本包二进制实测最低：{minos}） |
| 2 | Xcode 命令行工具（提供 `python3`、`nm`） | 终端：`xcode-select --install`（已装会提示已安装） |
| 3 | zstd（出 `.tar.zst` 包要用） | `brew install zstd`（没有 Homebrew：先按 https://brew.sh 装） |
| 4 | （可选）Rosetta 2：只在 Apple Silicon 上想顺带验 Intel 版时需要 | `softwareupdate --install-rosetta` |

> 这几样安装可能要输一次管理员密码（装 Homebrew 一定要）；**验收脚本本身不需要管理员权限**。

## 二、验收（一条命令）

```bash
cd ~/Downloads                                   # 验收包放在哪就 cd 到哪
tar -xzf {kit}
bash fry-halftone-verify-kit/run_on_target.sh --also-x64   # Intel Mac 去掉 --also-x64
echo "退出码 = $?"
```

脚本会自动认出你的 Mac 是 Apple Silicon 还是 Intel，验对应的那一版；`--also-x64` 让 Apple Silicon 顺带用 Rosetta 2 验 Intel 版。
（在 Finder 里双击 `.tar.gz` 解压也可以，解出来同样是 `fry-halftone-verify-kit` 文件夹；
用 Safari 下载时它可能已经自动解压了 —— 看到 `fry-halftone-verify-kit` 文件夹就跳过 `tar` 那一行。）

## 三、怎样才算验收成功（下面**全部**满足）

| # | 看哪里 | 成功是什么样 |
|---|---|---|
| 1 | 退出码 | `退出码 = 0` |
| 2 | 屏幕最后的「验收结果」 | Apple Silicon：`✓ macos-arm64：可交付 → results/macos-arm64/{PACKAGE}-{v}-darwin-arm64.tar.zst`（加了 `--also-x64` 还有一行 `✓ macos-x64：可交付 …`）；Intel Mac：`✓ macos-x64：可交付 …`。**不能有 `✗` 行** |
| 3 | `results/<目标>/` 里的文件 | 5 个：`{PACKAGE}-{v}-darwin-<arm64 或 x64>.tar.zst`（**可交付的 macOS 包**）、`SHA256SUMS.txt`、`build_report.json`、`verify.log`、`target_env.txt` |
| 4 | `verify.log` 里这几行都在（✓ 开头） | `✓ 指纹一致` ｜ `✓ 外壳指纹` ｜ `✓ 导出面闸：库导出 {n_api} 个名字` ｜ `✓ 指纹闸：库自报的算法指纹 = 锁文件` ｜ `✓ C 接口用例 N / N 通过`（两个数相等）｜ **`✓ golden {g} / {g} 件逐字节一致`** ｜ `✓ 纯 C 示例真跑通过` ｜ `✓ 命令行契约：N 项，0 项没过` ｜ `✓ 交付清单闸：full 等级 {dm} 项齐全` ｜ `✓ 全部完成` |
| 5 | `build_report.json` | `"smoke_bool": true`、`"version_str": "{v}"`、`"fingerprint_str": "{fp}"`、`"wrapper_sha256_str": "{inp["wrapper"]}"`、`"platform_str": "darwin-arm64"`（Intel 版是 `darwin-x64`） |
| 6 | `SHA256SUMS.txt` | 在 `results/<目标>/` 里执行 `shasum -a 256 -c SHA256SUMS.txt`，显示 `…tar.zst: OK` |

> ★ 最关键的是 **golden {g} / {g} 件逐字节一致**：它证明在你这台 Mac 的系统数学库上，算出来的切片和 Windows / Linux / Python 生产线一个字节都不差。
> 反过来，只要有一条 ✗、或者退出码不是 0，**这个 macOS 包就不能用**，哪怕别的都是 ✓。

## 四、验收成功之后

1. `results/macos-arm64/{PACKAGE}-{v}-darwin-arm64.tar.zst` 就是 **Apple Silicon 版 macOS SDK**（`results/macos-x64/` 里是 Intel 版）。
2. 解开来用：
   ```bash
   mkdir -p t && tar --zstd -xf fry-halftone-verify-kit/results/macos-arm64/*.tar.zst -C t
   t/fry-halftone/bin/fry-halftone-cli --version        # 打印 fry-halftone-cli {v}
   ```
   （`tar` 报不认 zstd：改用 `zstd -dc fry-halftone-verify-kit/results/macos-arm64/*.tar.zst | tar -xf - -C t`）
   解开的 `t/fry-halftone/` 里怎么编译、怎么调，见同目录的《macOS_集成说明.md》。
3. 把整个 `results/` 发回：`cd fry-halftone-verify-kit && zip -r ../results_mac.zip results`

## 五、没成功怎么办

| 现象 | 原因 | 怎么办 |
|---|---|---|
| 退出码 3，提示「缺工具」 | 没装 Xcode 命令行工具 / zstd | 按提示装好再跑一次 |
| `tar: Error opening archive` / 找不到 `.tar.gz` | Safari 下载时已经自动解压 | 直接用解出来的 `fry-halftone-verify-kit` 文件夹执行第二条命令 |
| 提示「python3 要 ≥ 3.8」 | 系统 python3 太老 | 装 Xcode 命令行工具自带的 python3，或 `brew install python` |
| 弹窗「无法验证开发者」/ 库加载被拦 | 下载隔离属性（脚本已自动清除本目录的） | 再跑一次；仍被拦就执行 `xattr -dr com.apple.quarantine fry-halftone-verify-kit` |
| 一启动就 `Killed: 9` | arm64 签名问题（不应出现） | 把 `results/` 发回 |
| 提示「跳过 macos-x64」 | 没装 Rosetta 2，或 python3 不是 universal2 | 可以只验 arm64；要验 Intel 版就装 Rosetta 2 |
| 退出码 1，`golden` 或别的闸打了 ✗ | **这正是验收要找的问题**（例如 macOS 的数学库让某件结果不同） | **把整个 `results/` 发回**（`verify.log` 里写着哪一件、哪一张不同）；这个包先别用 |

## 六、它会不会动我的电脑

- 不需要管理员权限，不联网，不装任何东西；
- 只读写 `fry-halftone-verify-kit/` 目录里的文件（`out/`、`results/`），并清除这个目录里文件的「下载隔离属性」；
- 用完把整个目录删掉即可。
"""


def cli_quickref_text(sample: Dict[str, Any], version: str) -> str:
    return "\n".join([
        "# 命令行速查 · fry-halftone-cli v%s" % version, "",
        "> 三个平台的包里都带 `bin/fry-halftone-cli`（Windows 是 `.exe`），与库同目录、只调公开 C 接口 ⇒ 命令行出的切片 = 库出的切片。",
        "> 下面的 `--help` 原文、`info --json`、JSON 事件都是**交付的命令行真跑出来的**（见 `05_示例输出/`）。", "",
        "## `--help` 原文", "", "```", (sample.get("help_str") or "（本次没能真跑，见 SDK_使用说明.md 第十节）").strip(), "```", "",
        "## `info --json`", "", "```", (sample.get("info_str") or "—").strip(), "```", "",
        "## 退出码", "", "| 码 | 含义 |", "|---:|---|", "| 0 | 成功 |", "| 2 | 用法 / 参数错（含：同一个键在开关和 `--params` 里都给了） |",
        "| 3 | 模型不存在 |", "| 4 | 输出目录非空（含隐藏文件）或建不了 |", "| 11 | 出片失败（库的返回码写在 JSON 结果里） |",
        "| 12 | 输出不完整（张数对不上） |", "",
        "## 进度与结果的格式", "",
        "- stderr：逐行 `[fry-halftone-cli] progress=N stage=...`；成功最后一行 `[fry-halftone-cli] done. slices=N`",
        "- `--json`：stdout 一行一个事件：`{\"type\":\"progress\",\"percent\":N,\"stage\":\"…\"}` × 若干 + `{\"type\":\"result\",\"result\":{…}}` × 1；"
        "库的原始结果在 `result.sdkResult`（含 `sliceCount`、`bmpMd5`、`algorithmFingerprint`、`params`、`size`、`elapsedSeconds`）", "",
        "## 常用写法", "", "```",
        "fry-halftone-cli slice 模型.glb --target-longest-edge 12 --out 输出目录",
        "fry-halftone-cli slice 模型.glb --target-height 5 --params p.json --out 输出目录 --json",
        "fry-halftone-cli run request.json            # 与 FryHalftone_SliceModelJsonUtf8 同一个请求 JSON",
        "fry-halftone-cli schema                      # 库自报的参数白名单（= params_schema.json）",
        "fry-halftone-cli info --json                 # 名字 / 版本 / 算法 / 引擎 / 算法指纹",
        "```", ""])


def api_quickref_text(rows: List[Tuple[str, str, str]], rcs: List[Tuple[str, str, str, str]], version: str) -> str:
    lines = ["# 接口速查 · v%s" % version, "", "> 签名取自随包的 `include/fry_halftone.h`，作用取自随包的 `SDK_使用说明.md`「接口一览」。", "",
             "| 函数 | 签名 | 作用 |", "|---|---|---|"]
    lines += ["| `%s` | `%s` | %s |" % (n, s.replace("|", "\\|"), p) for n, s, p in rows]
    lines += ["", "## 返回码", "", "| 值 | 名字 | 含义 | English |", "|---:|---|---|---|"] + ["| %s | `%s` | %s | %s |" % r for r in rcs] + [""]
    return "\n".join(lines)


def _cmd_str(s: Dict[str, Any]) -> str:
    return "fry-halftone-cli " + " ".join(s.get("args_list") or [])


def sample_readme_text(samples: List[Dict[str, Any]], texts: Dict[str, Any], version: str) -> str:
    """05_示例输出/示例说明.md：三个示例一览（每个都与标准答案逐字节相同才放行）。"""
    rows = []
    for s in samples:
        res = s.get("result_dict") or {}
        rows.append("| `%s/` | %s | `%s` | %s 张；md5 `%s` = golden `%s` | %s |" % (
            s["spec_dict"]["key_str"], s["spec_dict"]["title_str"], _cmd_str(s), res.get("sliceCount"),
            ((res.get("sdkResult") or {}).get("bmpMd5") or "?")[:12] + "…", s.get("case_str"), s["spec_dict"]["why_str"]))
    return "\n".join([
        "# 示例输出（交付的 Windows 命令行真跑，%d 个示例）· v%s" % (len(samples), version), "",
        "> 每个示例都是 golden 标准件：跑出来的 BMP 与 Python 生产线出的标准答案**逐字节相同**才允许放进交付目录。",
        "> 命令都在各自目录里执行（相对路径）；输出里的本机绝对路径已替换成 `<示例目录>`。", "",
        "| 目录 | 参数 | 命令 | 结果 | 为什么要这个示例 |", "|---|---|---|---|---|"] + rows + [
        "", "| 文件（本目录） | 是什么 |", "|---|---|",
        "| `命令行_help.txt` / `命令行_info.json` | `--help` 与 `info --json` 的原文（%s） |" % (texts.get("version_str") or "?"),
        "| `<示例>/slices/000000.bmp` … | 切片（一张 = 一层） |",
        "| `<示例>/slices/slice_metadata.json` | 这次出片的全部元数据（参数、尺寸、指纹、各材料体素数…） |",
        "| `<示例>/request.json` | `run` 方式的请求（与 C 接口 `FryHalftone_SliceModelJsonUtf8` 同一份 JSON） |",
        "| `<示例>/命令行_stdout_JSON事件.jsonl` / `命令行_stderr_进度.txt` | `--json` 事件流 / 进度行 |", ""])


def sample_detail_text(s: Dict[str, Any], version: str) -> str:
    res = s.get("result_dict") or {}
    sdk_res = res.get("sdkResult") or {}
    bf = s.get("bmp_facts_dict") or {}
    lines = ["# 示例 %s · v%s" % (s["spec_dict"]["key_str"], version), "",
             "| 项 | 值 |", "|---|---|",
             "| 参数 | %s |" % s["spec_dict"]["title_str"],
             "| 输入 | `%s`（本目录；tests/data 里的标准件） |" % s.get("model_str", "?"),
             "| 命令（在本目录执行） | `%s` |" % _cmd_str(s)]
    if s.get("request_dict") is not None:
        lines.append("| 请求（request.json） | `%s` |" % json.dumps(s["request_dict"], ensure_ascii=False))
    lines += ["| 返回码 / 用时 | %s / %s s |" % (s.get("rc_int"), s.get("seconds_float")),
              "| 结果 | %s 张 BMP（%s × %s 像素，%s 位调色板）；BMP md5 `%s` |" % (
                  res.get("sliceCount"), bf.get("width_int", "?"), bf.get("height_int", "?"), bf.get("bpp_int", "?"), sdk_res.get("bmpMd5")),
              "| 与标准答案 | = golden `%s`（Python 生产线出的）**逐字节相同** |" % s.get("case_str"),
              "| 出现的像素值 | %s |" % "、".join("%d（%s 个）" % (k, format(v, ",")) for k, v in sorted((s.get("usage_dict") or {}).items()))]
    pc = s.get("palette_check_dict") or {}
    if pc.get("checked_int") and not pc.get("problem_str"):
        lines.append("| 像素数核对 | 按对照表从 BMP 数出的各材料像素数 = 库自报的 `material_count_dict`（%d 项逐项相等%s） |" % (
            pc["checked_int"], "；0（空）那一项含补边 %s 个像素 = %s（输出宽 − 原生宽）× 高 × 层数" % (
                format(pc["padding_int"], ","), pc.get("padding_note_str", "")) if pc.get("padding_int") else ""))
    return "\n".join(lines + [""])


# ───────────────────────────── ⑥ 装配交付目录 ─────────────────────────────
def build(inp: Dict[str, Any], dest: Path, extra: List[Path], exp: Dict[str, int],
          extra_notes: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
    extra_notes = extra_notes or {}
    dest.mkdir(parents=True)
    for d in DIRS.values():
        (dest / d).mkdir()
    rows: List[Dict[str, Any]] = []
    probs: List[str] = []
    v = inp["version"]

    def put(src: Path, sub: str, platform_: str, status: str, status_zh: str, min_os: str) -> Path:
        dst = dest / sub / src.name
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)
        rows.append({"path": dst.relative_to(dest).as_posix(), "platform": platform_, "status": status,
                     "status_zh": status_zh, "min_os": min_os, "size": mb(dst), "bytes": dst.stat().st_size,
                     "sha256": sha256_file(dst)})
        return dst

    win = inp["win"]
    put(win["archive"], DIRS["win"], "Windows x64", "verified", "✅ 已验收，可交付", win["report_dict"].get("min_os_str", ""))
    win_sdk = extract_zip(win["archive"], dest / DIRS["win"])
    probs += check_extracted(win_sdk)
    lin_sdks: List[Path] = []
    for mode, lin in inp["linux"].items():
        one = len(inp["linux"]) == 1
        sub = DIRS["linux"] if one else "%s/%s_%s" % (DIRS["linux"], mode, "推荐" if mode == "prebuilt" else "对照")
        put(lin["archive"], sub, "Linux x86-64" + ("" if one else "（%s）" % mode), "verified", "✅ 已验收，可交付",
            lin["report_dict"].get("min_os_str", "").split("（")[0])
        lin_sdks.append(extract_tar_zst(lin["archive"], dest / sub))
        probs += check_extracted(lin_sdks[-1])
    tg = inp["mac"]["kit_info_dict"].get("targets_dict") or {}
    put(inp["mac"]["archive"], DIRS["mac"], "macOS arm64 + x64（验收包）", "pending_mac_verification",
        "⏳ 请在 Mac 上验收（见 macOS验收步骤.md）", (tg.get("macos-arm64") or {}).get("min_os_str", ""))
    (dest / DIRS["mac"] / "macOS验收步骤.md").write_text(mac_guide_text(inp, exp), encoding="utf-8", newline="\n")
    with tarfile.open(inp["mac"]["archive"]) as tf:
        m = next((x for x in tf.getmembers() if x.name.endswith("/README_验收.md")), None)
        if m is not None:
            (dest / DIRS["mac"] / "验收包说明_README_验收.md").write_bytes(tf.extractfile(m).read())
    # 各平台集成说明（命令唯一真源 + 实测标记）
    model_in_bundle = dest / DIRS["sample"] / SAMPLES[0]["key_str"] / G.SAMPLE_MODEL   # 示例模型：在展开的包里用相对路径就能找到
    hints = {"win32-x64": "`%s`" % os.path.relpath(model_in_bundle, win_sdk).replace("/", "\\"),
             "linux-x64": ("`%s`" % Path(os.path.relpath(model_in_bundle, lin_sdks[0])).as_posix()) if lin_sdks else "",
             "darwin": "本交付目录的 `%s/%s/%s`（拷到 Mac 上解开的包旁边）" % (DIRS["sample"], SAMPLES[0]["key_str"], G.SAMPLE_MODEL)}
    for plat, sub, fname, side in (("win32-x64", DIRS["win"], "Windows_集成说明.md", "windows"),
                                   ("linux-x64", DIRS["linux"], "Linux_集成说明.md", "linux"),
                                   ("darwin", DIRS["mac"], "macOS_集成说明.md", "")):
        tested = tested_of(inp, side) if side else {}
        (dest / sub / fname).write_text(G.render_guide(plat, v, hints[plat], tested), encoding="utf-8", newline="\n")
    info = jload(win_sdk / "sdk_info.json")
    lib = win_sdk / "bin" / "fry_halftone.dll"
    (dest / DIRS["win"] / "给业务_使用说明.md").write_text(
        fry_business_zip.readme(info, lib.name, sha256_file(lib) if lib.is_file() else "?", "win32-x64",
                                len(fry_delivery_contract.items_for("full", "Windows"))), encoding="utf-8", newline="\n")
    # 对接文档（副本）+ include/ + examples/ + 速查
    docs = dest / DIRS["docs"]
    for name in DOC_FILES:
        if (win_sdk / name).is_file():
            shutil.copy2(win_sdk / name, docs / name)
    for d in ("include", "examples"):
        if (win_sdk / d).is_dir():
            shutil.copytree(win_sdk / d, docs / d)
    header_text = (win_sdk / "include" / "fry_halftone.h").read_text(encoding="utf-8") if (win_sdk / "include" / "fry_halftone.h").is_file() else ""
    usage_text = (win_sdk / "SDK_使用说明.md").read_text(encoding="utf-8") if (win_sdk / "SDK_使用说明.md").is_file() else ""
    ctx: Dict[str, Any] = {"api_rows": api_rows(header_text, usage_text), "rc_rows": return_code_rows(header_text, usage_text),
                           "param_lines": param_table_lines((win_sdk / "SDK_参数说明.md").read_text(encoding="utf-8"))
                           if (win_sdk / "SDK_参数说明.md").is_file() else [],
                           "win_tree": sdk_tree_rows(win_sdk)}
    (docs / "接口速查.md").write_text(api_quickref_text(ctx["api_rows"], ctx["rc_rows"], v), encoding="utf-8", newline="\n")
    # ★412 示例输出：三个 golden 件真跑（默认 / 黑墨 / 白底），逐个与标准答案逐字节比；每个示例都做像素值对照的开环核对
    sample_root = dest / DIRS["sample"]
    texts = capture_cli_texts(win_sdk, sample_root)
    probs += cli_texts_problems(texts, v)
    ctx["cli_texts"] = texts
    ctx["palette_rows"] = palette_rows(usage_text)
    samples: List[Dict[str, Any]] = []
    for spec in SAMPLES:
        case = golden_case(inp["repo"], spec["case_str"])
        model = inp["repo"] / "tests" / "data" / (case["model_str"] if case else "?")
        s = run_sample(win_sdk, spec, case, model, sample_root / spec["key_str"]) if case else dict(
            spec_dict=spec, ok=False, why_str="golden.json 里没有 %s" % spec["case_str"], case_str=spec["case_str"])
        probs += sample_problems(s, case)
        sl = sample_root / spec["key_str"] / "slices"
        bmps = sorted(sl.glob("*.bmp")) if sl.is_dir() else []
        meta = jload(sl / "slice_metadata.json") if (sl / "slice_metadata.json").is_file() else None
        s.update(bmp_facts_dict=bmp_facts(bmps[0]) if bmps else {}, slice_files_int=len(bmps),
                 usage_dict=palette_usage(sl) if bmps else {}, meta_keys_list=list(meta or {}), case_dict=case or {})
        s["palette_check_dict"] = palette_check(ctx["palette_rows"], s["usage_dict"],
                                                (meta or {}).get("material_count_dict") if meta else None, meta)
        if s["palette_check_dict"].get("problem_str"):
            probs.append("示例 %s：%s" % (spec["key_str"], s["palette_check_dict"]["problem_str"]))
        stray = sorted(set(s["usage_dict"]) - {int(r[0]) for r in ctx["palette_rows"]}) if ctx["palette_rows"] else []
        if stray:
            probs.append("示例 %s 里出现了「像素值 → 材料」表外的像素值 %s —— 说明与算法不一致" % (spec["key_str"], stray))
        (sample_root / spec["key_str"] / "示例说明.md").write_text(sample_detail_text(s, v), encoding="utf-8", newline="\n")
        samples.append(s)
    ctx["samples"] = samples
    ctx["sample"] = dict(samples[0], help_str=texts.get("help_str", ""), info_str=texts.get("info_str", ""),
                         version_str=texts.get("version_str", ""))
    ctx["bmp_facts"] = samples[0].get("bmp_facts_dict", {})
    ctx["meta_keys"] = samples[0].get("meta_keys_list", [])
    ctx["palette_coverage"] = palette_coverage(ctx["palette_rows"], [s.get("usage_dict", {}) for s in samples])
    (sample_root / "示例说明.md").write_text(sample_readme_text(samples, texts, v), encoding="utf-8", newline="\n")
    (docs / "命令行速查.md").write_text(cli_quickref_text(ctx["sample"], v), encoding="utf-8", newline="\n")
    # ★412 命令行的对外接口面：源码解析（出包前定版本号用的）= 交付的命令行真跑 --help（两把尺子）
    if texts.get("ok") and inp.get("surface_dict") is not None:
        probs += SF.surface_mismatch(inp["surface_dict"], {"cli_list": SF.cli_from_help(texts["help_str"])})
    # 验收证据
    ev = dest / DIRS["evidence"]
    shutil.copy2(win["report"], ev / "build_report_windows.json")
    for mode, lin in inp["linux"].items():
        shutil.copy2(lin["report"], ev / ("build_report_linux_%s.json" % mode))
        if lin["env"].is_file():
            shutil.copy2(lin["env"], ev / ("linux_env_%s.json" % mode))
    shutil.copy2(inp["mac"]["kit_info"], ev / "macos_verify_kit_info.json")
    if inp["cross_info"].is_file():
        keep = ("target_str", "ok_bool", "min_os_str", "static_problems_list", "api_missing_list", "api_extra_list",
                "verified_on_target_bool", "zig_triple_str")
        slim = [{k: r.get(k) for k in keep} for r in jload(inp["cross_info"]).get("targets_list", [])]
        (ev / "cross_static_gate.json").write_text(json.dumps(slim, ensure_ascii=False, indent=1), encoding="utf-8")
    for p in [x["path"] for x in inp["parity"]] + extra:
        if p.is_file():
            shutil.copy2(p, ev / p.name)
    if inp.get("integration"):
        shutil.copy2(inp["integration"]["path"], ev / "集成命令实测.json")
    if inp.get("kit_linux_report"):
        shutil.copy2(inp["kit_linux_report"]["path"], ev / KIT_LINUX_REPORT_NAME)
    ctx["evidence_rows"] = [(f.name, evidence_note(f.name, [x["path"].name for x in inp["parity"]], extra_notes))
                            for f in sorted(ev.iterdir(), key=lambda q: q.name) if f.is_file()]
    # 版本记录（含这一次）+ 本版变更
    req = inp.get("bump_required_dict") or {}
    entry = {"version_str": v, "created_at_str": time.strftime("%Y-%m-%dT%H:%M:%S%z"), "dir_str": dest.name,
             "algorithm_fingerprint_str": inp["fingerprint"], "wrapper_sha256_str": inp["wrapper"],
             "packages_dict": inp["packages_sha_dict"],
             # ★412 下一版按这三张清单判定「该升哪一位」；这一版升了哪一位、为什么
             "surface_dict": inp.get("surface_dict") or {},
             "bump_level_str": SF.bump_level(DV.last_version(inp["versions_state"]), v),
             "bump_reasons_list": req.get("reasons_list", []), "surface_inferred_bool": bool(req.get("inferred_bool"))}
    state = dict(inp["versions_state"])
    state["deliveries_list"] = list(state.get("deliveries_list", [])) + [entry]
    (dest / DIRS["versions"] / "版本记录.md").write_text(version_record_text(state, dest.parent), encoding="utf-8", newline="\n")
    cl_text = (win_sdk / "CHANGELOG.md").read_text(encoding="utf-8") if (win_sdk / "CHANGELOG.md").is_file() else ""
    section = DV.changelog_section(cl_text, v)
    ctx["changelog_section"] = section
    (dest / DIRS["versions"] / "本版变更.md").write_text(
        "# v%s 的变更（CHANGELOG「## %s」这一节原文）\n\n%s\n" % (v, v, section or "（CHANGELOG 里没有这一版的节 —— 出包时应当先分节）"),
        encoding="utf-8", newline="\n")
    if not section:
        probs.append("CHANGELOG 里没有「## %s」这一节 —— 交付版出包前要先把「未发布」挪到版本号下（fry_release.py --bundle 会做）" % v)
    # 说明 + 清单 + 校验和
    (dest / "00_先读我_交付说明.md").write_text(readme_text(inp, rows, dest.name, exp, ctx), encoding="utf-8", newline="\n")
    manifest = {"bundle_schema_str": "fry-halftone-delivery-bundle/2", "dir_str": dest.name, "version_str": v,
                "previous_version_str": DV.last_version(inp["versions_state"]) or "",
                "algorithm_fingerprint_str": inp["fingerprint"], "wrapper_sha256_str": inp["wrapper"],
                "created_at_str": entry["created_at_str"], "created_on_str": "%s %s" % (platform.system(), platform.machine()),
                "expected_counts_dict": exp, "packages_list": rows, "packages_sha_dict": inp["packages_sha_dict"],
                "samples_list": [{"key_str": s["spec_dict"]["key_str"], "golden_case_str": s.get("case_str"),
                                  "model_str": s.get("model_str"), "command_list": s.get("args_list"),   # ★412 同事角度复验照这条命令跑
                                  "slices_int": (s.get("result_dict") or {}).get("sliceCount"),
                                  "bmp_md5_str": ((s.get("result_dict") or {}).get("sdkResult") or {}).get("bmpMd5"),
                                  "pixel_values_list": sorted(s.get("usage_dict", {}))} for s in samples],
                "palette_coverage_dict": ctx["palette_coverage"],
                "integration_checked_bool": bool(inp.get("integration")),
                "macos_note_str": "macOS 为验收包：在 Mac 上 bash run_on_target.sh 全过后 results/ 里的 .tar.zst 才是可交付件"}
    (dest / "bundle_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=1), encoding="utf-8")
    fry_delivery_contract.write_sums(dest)             # 最后一步（展开包里各自的 SHA256SUMS 照样列进来）
    manifest["build_problems_list"] = probs
    manifest["entry_dict"] = entry
    return manifest


def recheck(dest: Path) -> List[str]:
    """装完再按 SHA256SUMS.txt 逐个复查一遍（拷贝过程中出错也要抓到），并核对目录里没有清单外的文件。"""
    return fry_delivery_contract.sums_problems(dest)


def make_zip(dest: Path) -> Tuple[Path, List[str]]:
    """整个交付目录再打一个 zip（与目录同级，解开就是这个目录）；中文文件名写 UTF-8 标记，打完重开复查。"""
    zp = dest.parent / (dest.name + ".zip")
    if zp.exists():
        return zp, ["%s 已经存在 —— 不覆盖" % zp.name]
    files = sorted((p for p in dest.rglob("*") if p.is_file()), key=lambda p: p.relative_to(dest).as_posix())
    with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as zf:
        for p in files:
            # ★411 记 Unix 权限（create_system=3）：Linux / Mac 上解开整包后，展开的 bin/fry-halftone-cli 直接能跑
            stamp = max(tuple(time.localtime(p.stat().st_mtime)[:6]), (1980, 1, 1, 0, 0, 0))   # zip 不收 1980 年以前的时间
            zi = zipfile.ZipInfo(dest.name + "/" + p.relative_to(dest).as_posix(), stamp)
            zi.create_system, zi.external_attr, zi.compress_type = 3, unix_mode_of(p) << 16, zipfile.ZIP_DEFLATED
            zf.writestr(zi, p.read_bytes())
    probs = []
    with zipfile.ZipFile(zp) as zf:
        bad = zf.testzip()
        if bad:
            probs.append("zip 里 %s 的 CRC 不对" % bad)
        got = {i.filename: i.file_size for i in zf.infolist()}
        want = {dest.name + "/" + p.relative_to(dest).as_posix(): p.stat().st_size for p in files}
        if got != want:
            probs.append("zip 与目录对不上：多 %s 少 %s" % (sorted(set(got) - set(want))[:5], sorted(set(want) - set(got))[:5]))
        no_flag = [i.filename for i in zf.infolist() if not i.filename.isascii() and not i.flag_bits & 0x800]
        if no_flag:
            probs.append("这些中文文件名没有 UTF-8 标记（Mac 上会乱码）：%s" % no_flag[:5])
    return zp, probs


def _log_file(root: Path) -> Path:
    log = root / "_交付记录.md"
    if not log.is_file():
        log.write_text("# 全交付目录 · 交付记录（每次一行，新的在最后）\n\n| 时间 | 目录 | 版本 | 算法指纹 | 平台 |\n|---|---|---|---|---|\n",
                       encoding="utf-8", newline="\n")
    return log


def append_log(root: Path, dest: Path, manifest: Dict[str, Any]) -> None:
    plats = "、".join("%s %s" % (r["platform"], "✅" if r["status"] == "verified" else "⏳") for r in manifest["packages_list"])
    with _log_file(root).open("a", encoding="utf-8", newline="\n") as f:
        f.write("| %s | `%s` | **%s** | `%s…` | %s |\n" % (manifest["created_at_str"], dest.name, manifest["version_str"],
                                                           manifest["algorithm_fingerprint_str"][:16], plats))


def void_bundle(root: Path, dest: Path, zp: Optional[Path], manifest: Dict[str, Any], why: str) -> Path:
    """★412 作废：目录与整包 zip 挪进 `_作废/`（不删，要能回溯），交付记录追加一行作废说明；版本号不记（下次还用这个号）。"""
    void = root / VOID_DIR_NAME
    void.mkdir(parents=True, exist_ok=True)
    vd = unique_dir(void, dest.name)                   # 目录与 zip 都不覆盖以前作废的同名件
    if dest.exists():
        shutil.move(str(dest), str(vd))
    if zp is not None and zp.exists():
        shutil.move(str(zp), str(void / (vd.name + ".zip")))
    with _log_file(root).open("a", encoding="utf-8", newline="\n") as f:
        f.write("| %s | `%s` | ~~%s~~ 作废（未记版本号） | `%s…` | ✗ %s → 已挪进 `%s/` |\n" % (
            manifest["created_at_str"], dest.name, manifest["version_str"], manifest["algorithm_fingerprint_str"][:16],
            why.replace("|", "／").replace("\n", " "), VOID_DIR_NAME))
    return void


def main(argv=None) -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    ap = argparse.ArgumentParser(description="★410/411 全交付目录：三个平台 + 命令行 + 展开的包 + 说明 + 示例 + Mac 验收步骤，每次一个新子目录")
    ap.add_argument("--topic", default=None, help="子目录名里的主题词（默认 水转印加网SDK_v<版本>_三平台交付；前面自动加 _YYMMDD_HHMM_）")
    ap.add_argument("--linux", choices=("prebuilt", "native", "both"), default="prebuilt",
                    help="放哪种 Linux 包：prebuilt（推荐，glibc 2.17 起）/ native / both")
    ap.add_argument("--parity-json", nargs="*", default=[], help="跨平台一致性实验结果（summary.all_identical 必须为真、库 sha256 对得上）")
    ap.add_argument("--integration-json", default=None, help="★411 集成命令实测结果（包的 sha256 对得上、全过）")
    ap.add_argument("--extra-evidence", nargs="*", default=[], help="额外放进 06_验收证据/ 的文件；写成 文件=说明 时说明会进交付说明")
    ap.add_argument("--kit-linux-report", default=None,
                    help="★411 验收包在真 Linux（WSL）里跑 run_on_target.sh 出的 build_report.json（过闸后写进说明：Mac 上跑的是同一个脚本）")
    ap.add_argument("--colleague-check", action="store_true",
                    help="★412 打完在 WSL 真 Linux 里站在同事角度复验整包（fry_bundle_check.py）；不过就挪进 _作废/、不记版本号")
    ap.add_argument("--dry-run", action="store_true", help="只过闸，不写任何东西")
    ap.add_argument("--next-version", action="store_true", help="★411 只打印下一个交付版本号")
    ap.add_argument("--result-json", default=None, help="结论写到这里（fry_release.py --bundle 用）")
    ns = ap.parse_args(argv)
    if ns.next_version:
        print(DV.next_version(DV.load(REPO)))
        return 0
    modes = ["prebuilt", "native"] if ns.linux == "both" else [ns.linux]
    result: Dict[str, Any] = {"ok_bool": False, "message_str": "", "dir_str": "", "file_count_int": 0}

    def finish(rc: int) -> int:
        if ns.result_json:
            Path(ns.result_json).write_text(json.dumps(result, ensure_ascii=False, indent=1), encoding="utf-8")
        return rc

    print("★410/411 全交付目录")
    inp, probs = collect(OUT, modes, [Path(p) for p in ns.parity_json], REPO,
                         Path(ns.integration_json) if ns.integration_json else None,
                         Path(ns.kit_linux_report) if ns.kit_linux_report else None)
    extra_paths = [Path(x.split("=", 1)[0]) for x in ns.extra_evidence]
    extra_notes = {Path(x.split("=", 1)[0]).name: x.split("=", 1)[1] for x in ns.extra_evidence if "=" in x}
    if probs:
        print("✗ 过闸没过（不打交付目录）：")
        for p in probs:
            print("   - " + p)
        result["message_str"] = "过闸没过：" + "；".join(probs)
        return finish(1)
    exp = expected_counts(REPO)
    print("✓ 过闸：版本 %s（上次交付 %s）｜ 算法指纹 %s… ｜ 外壳指纹 %s…（三平台 = 当前源码）｜ Windows + Linux(%s) 冒烟都过 ｜ "
          "macOS 验收包 sha256 对得上 ｜ 参数说明与随包文件三平台逐字节相同%s%s"
          % (inp["version"], DV.last_version(inp["versions_state"]) or "无", inp["fingerprint"][:16], inp["wrapper"][:16],
             "/".join(modes), " ｜ 一致性实验 %d 份全一致" % len(inp["parity"]) if inp["parity"] else "",
             " ｜ 集成命令实测全过" if inp.get("integration") else ""))
    root = OUT / BUNDLE_ROOT_NAME
    name = bundle_dir_name(ns.topic or default_topic(inp["version"]))
    if ns.dry_run:
        print("（--dry-run）会写到：%s" % (root / name))
        result.update(ok_bool=True, message_str="dry-run：过闸", dir_str=str(root / name))
        return finish(0)
    root.mkdir(parents=True, exist_ok=True)
    dest = unique_dir(root, name)
    inp["colleague_check_bool"] = bool(ns.colleague_check)   # 交付说明第八节据此写「打完复验过 / 这一版没做」
    manifest = build(inp, dest, extra_paths, exp, extra_notes)
    bad = manifest.pop("build_problems_list") + recheck(dest)
    zp, zbad = make_zip(dest) if not bad else (None, [])
    if bad or zbad:
        # ★412 与复验没过同一个处理：挪进 _作废/（留着供查看，但根上不留一个像是能交付的目录）、交付记录写明、不记版本号
        void = void_bundle(root, dest, zp, manifest, "装配 / 复查没过：" + "；".join(bad + zbad)[:300])
        print("✗ 装配 / 复查没过（目录已挪进 %s 供查看，**不许交付**、不记版本号）：\n   %s" % (void, "\n   ".join(bad + zbad)))
        result["message_str"] = "装配 / 复查没过：" + "；".join(bad + zbad)
        return finish(1)
    if ns.colleague_check:
        # ★412 站在同事角度（WSL 真 Linux）：解开整包 → 校验 → 直接跑 → 每个示例照说明出片、比对。不过 ⇒ 作废、不记版本号
        import fry_bundle_check
        print("… 同事角度复验：在 WSL 真 Linux 里解开整包 zip、校验、直接跑、每个示例照说明出片比对", flush=True)
        try:
            chk = fry_bundle_check.run(zp, inp["version"], OUT / "bundle_check")
        except Exception as e:                         # WSL 起不来也算没过：没验过的不许交付
            chk = {"ok_bool": False, "error_str": "%s: %s" % (type(e).__name__, e)}
        result["colleague_check_dict"] = {k: v for k, v in chk.items() if k != "markers_dict"}
        if not chk["ok_bool"]:
            why = chk.get("error_str") or "同事角度复验没过（%s）" % "、".join(
                k.replace("_bool", "") for k, v in chk.items() if k.endswith("_bool") and k != "ok_bool" and not v)
            void = void_bundle(root, dest, zp, manifest, why)
            print("✗ %s —— 目录与整包已挪进 %s（不许交付、不记版本号；详见 out/bundle_check/）" % (why, void))
            result["message_str"] = why
            return finish(1)
    DV.record(manifest.pop("entry_dict"), REPO)
    append_log(root, dest, manifest)
    n = sum(1 for p in dest.rglob("*") if p.is_file())
    size = sum(p.stat().st_size for p in dest.rglob("*") if p.is_file()) / 1048576.0
    print("✓ 交付目录：%s（%d 个文件，%.2f MB；按 SHA256SUMS 复查通过）" % (dest, n, size))
    for r in manifest["packages_list"]:
        print("   %-58s %-28s %s" % (r["path"], r["platform"], r["status_zh"]))
    print("✓ 整包 zip：%s（%.2f MB，中文文件名 UTF-8；复查 CRC / 清单 / 标记通过）" % (zp, zp.stat().st_size / 1048576.0))
    print("✓ 版本 %s 已记入 %s（进 git）" % (inp["version"], DV.STATE_NAME))
    print("   → 先读 00_先读我_交付说明.md；macOS 让同事按 %s/macOS验收步骤.md 在 Mac 上跑一条命令" % DIRS["mac"])
    result.update(ok_bool=True, message_str="交付目录 %s（v%s，%d 个文件）+ 整包 %s" % (dest.name, inp["version"], n, zp.name),
                  dir_str=str(dest), file_count_int=n, zip_str=str(zp), zip_sha256_str=sha256_file(zp), version_str=inp["version"])
    return finish(0)


if __name__ == "__main__":
    raise SystemExit(main())
