# -*- coding: utf-8 -*-
r"""fry_intranet_preflight.py —— ★388 搬到公司内网 GitLab 前后的「体检」（**只读**：不改文件、不提交、不推送、不连网）。

【为什么要它】搬家是一次性的、步骤多，而且好几步做错了**不报错或报得很晚**：
  · 仓根 CI 文件手改过、和 ci/ 里的两份都对不上 —— 推上去才发现流水线形状不对；
  · 带着 150 MB 构建产物的历史整个推进内网 —— 内网 GitLab 的存储是那块没备份的群晖（ci-templates docs/artifacts.md）；
  · 想拿这台电脑当 Windows runner，却没装 PowerShell 7 / node —— 第一条流水线才红在 setup 上。
  ⇒ 把「开始之前要确认的事」做成一条命令，✗ 必须先处理，⚠ 看一眼再决定。

【查什么】
  ① CI 文件：仓根 .gitlab-ci.yml 是哪种模式（standalone = gitlab.com 独立 / internal = 内网模板 / drift = 与两份都不同）；
     内网那份的关键形状（include 模板 ref v1、没写 workflow:、三个 build job 与 test:unit 都 extends 底座且不自己写 needs）
  ② 载荷闸：cpp/ 与 cpp.lock.json 逐文件一致
  ③ git：当前分支、未提交改动、远端（URL 里的账号口令一律打码）、已有的版本 tag
  ④ 历史体积：全部历史里的文件 vs 当前 HEAD 用到的文件 —— 多出很多 ⇒ 建议推内网时用「干净快照」
  ⑤ 交付物：.gitignore 管住 out/、.gitattributes 在、对接方文档在
  ⑥ --runner windows|macos|linux：本机当这个平台的 runner 缺什么（git / node≥18 / pwsh 7 / cmake≥3.20 / Python / VS C++ …）

【用法】
  python tools/fry_intranet_preflight.py
  python tools/fry_intranet_preflight.py --runner windows --json D:/x/preflight.json
【退出码】0 = 没有 ✗；1 = 有 ✗（⚠ 只提醒，不算失败）
"""
from __future__ import annotations

import argparse
import json
import os
import platform
import re
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

REPO = Path(__file__).resolve().parents[1]
INTERNAL_HOST_STR = "192.168.110.250"          # 公司内网 GitLab（OPS-0027 文档里的地址）
HISTORY_WARN_MB_FLOAT = 20.0                    # 历史里比 HEAD 多出这么多，就建议干净快照
MIN_NODE_INT, MIN_PWSH_INT = 18, 7
MIN_CMAKE_TUPLE = (3, 20)
BUILD_JOB_TUPLE = ("build:linux", "build:windows", "build:macos")
CONSUMER_DOC_TUPLE = ("docs/SDK_使用说明.md", "docs/SDK_README_EN.md", "include/fry_halftone.h")


# ───────────────────────────── 纯函数（有测试） ─────────────────────────────
def mask_url(url: str) -> str:
    """URL 里 // 与 @ 之间的账号 / 口令 / 令牌一律打码（体检报告会被贴进文档和聊天）。"""
    return re.sub(r"//[^/@\s]+@", "//***@", url or "")


def normalized(data: bytes) -> bytes:
    return (data or b"").replace(b"\r\n", b"\n")


def ci_mode(active: Optional[bytes], standalone: Optional[bytes], internal: Optional[bytes]) -> str:
    """仓根 .gitlab-ci.yml 是哪一份的副本：standalone / internal / drift（都不是）/ missing（没有仓根文件）。"""
    if active is None:
        return "missing"
    hits = [name for name, data in (("standalone", standalone), ("internal", internal))
            if data is not None and normalized(data) == normalized(active)]
    return hits[0] if len(hits) == 1 else "drift"


def _job_block(text: str, job: str) -> str:
    m = re.search(r"^%s:\s*$(.*?)(?=^\S)" % re.escape(job), text + "\n__end__:\n", flags=re.M | re.S)
    return m.group(1) if m else ""


def internal_shape_problems(text: str, package_name: str) -> List[str]:
    """内网 CI 文件的关键形状（与 tests/test_ci_yaml.py 同口径的轻量版：不依赖 PyYAML，搬家现场直接能跑）。"""
    bad: List[str] = []
    if not re.search(r"^\s*-\s*project:\s*shared/ci-templates\s*$", text, flags=re.M):
        bad.append("没有 include shared/ci-templates")
    if not re.search(r"^\s*ref:\s*v1\s*$", text, flags=re.M):
        bad.append("include 的 ref 不是 v1（与模板 SHARED_CI_REF 默认值不一致会在 setup 直接失败）")
    if re.search(r"^workflow:", text, flags=re.M):
        bad.append("写了 workflow: —— 会静默覆盖模板 standard.yml")
    m = re.search(r"^\s*PACKAGE_NAME:\s*(\S+)\s*$", text, flags=re.M)
    if not m or m.group(1).strip("'\"") != package_name:
        bad.append("PACKAGE_NAME 不是 %s" % package_name)
    for job in BUILD_JOB_TUPLE:
        block = _job_block(text, job)
        if not block:
            bad.append("缺 %s" % job)
            continue
        if not re.search(r"^\s+extends:\s*\.shared:build-job\s*$", block, flags=re.M):
            bad.append("%s 没有 extends .shared:build-job（扳机 package:trigger 从它的 needs 注入）" % job)
        if re.search(r"^\s{2}needs:", block, flags=re.M):
            bad.append("%s 自己写了 needs —— extends 是整体替换，扳机会失效且不报错" % job)
        if "publish-artifact" not in block:
            bad.append("%s 没有调模板的 publish-artifact（产物不会进 Package Registry）" % job)
    unit = _job_block(text, "test:unit")
    if not unit:
        bad.append("缺 test:unit —— 独立模式 check 任务的内网版；没有它，搬家后本仓纯函数闸只剩本机 pytest")
    else:
        if not re.search(r"^\s+extends:\s*\.shared:build-job\s*$", unit, flags=re.M):
            bad.append("test:unit 没有 extends .shared:build-job（不等扳机 ⇒ 自动提交程序每推一次都白跑测试）")
        if re.search(r"^\s{2}needs:", unit, flags=re.M):
            bad.append("test:unit 自己写了 needs —— extends 是整体替换，扳机会失效且不报错")
        if "pytest" not in unit:
            bad.append("test:unit 里没有 pytest")
    return bad


def version_tuple(text: str) -> Tuple[int, ...]:
    m = re.search(r"(\d+)(?:\.(\d+))?(?:\.(\d+))?", text or "")
    return tuple(int(g) for g in m.groups() if g is not None) if m else ()


def history_advice(total_bytes: int, head_bytes: int, warn_mb: float = HISTORY_WARN_MB_FLOAT) -> Tuple[str, str]:
    extra_mb = max(total_bytes - head_bytes, 0) / 1048576.0
    text = "本地分支与 tag 的全部历史 %.1f MB，HEAD 用到 %.1f MB，历史多出 %.1f MB" % (total_bytes / 1048576.0, head_bytes / 1048576.0, extra_mb)
    if extra_mb > warn_mb:
        return "warn", text + " ⇒ 推内网建议用「干净快照」（单提交、只带当前文件）"
    return "ok", text


def runner_requirements(plat: str) -> List[Dict[str, Any]]:
    """每个平台 runner 机器要装的东西（来源：ci-templates base.yml 的 setup 检查 + 本仓 packaging 脚本的检查）。"""
    common = [{"name_str": "git", "cmd_list": ["git", "--version"], "min_tuple": (), "why_str": "模板 setup 要 clone 模板仓"},
              {"name_str": "node", "cmd_list": ["node", "--version"], "min_tuple": (MIN_NODE_INT,),
               "why_str": "模板的版本号 / 记账 / 上传脚本都是 Node 写的（≥ 18）"},
              {"name_str": "cmake", "cmd_list": ["cmake", "--version"], "min_tuple": MIN_CMAKE_TUPLE, "why_str": "编 C++ 动态库"}]
    if plat == "windows":
        return common + [
            {"name_str": "pwsh", "cmd_list": ["pwsh", "-NoProfile", "-Command", "$PSVersionTable.PSVersion.ToString()"],
             "min_tuple": (MIN_PWSH_INT,), "why_str": "runner 用 pwsh 跑 job；5.1 会把无 BOM 的中文 ps1 读坏",
             "hint_str": "winget install --id Microsoft.PowerShell --source winget"},
            {"name_str": "python", "cmd_list": ["<FRY_SDK_PYTHON>", "--version"], "min_tuple": (3,),
             "why_str": "出包脚本 tools/fry_build.py（只用标准库）", "hint_str": "runner 的 config.toml 里 environment = [\"FRY_SDK_PYTHON=...\"]"},
            {"name_str": "vs_cpp", "cmd_list": ["<vswhere>"], "min_tuple": (), "why_str": "MSVC 编 dll（CMake 自动找）",
             "hint_str": "Visual Studio（或 Build Tools）勾「使用 C++ 的桌面开发」"},
        ]
    tail = [{"name_str": "python3", "cmd_list": ["python3", "--version"], "min_tuple": (3,), "why_str": "出包脚本 tools/fry_build.py"},
            {"name_str": "zstd", "cmd_list": ["zstd", "--version"], "min_tuple": (), "why_str": "产物格式 .tar.zst（跨仓契约，不许换 .tar.gz）"},
            {"name_str": "nm", "cmd_list": ["nm", "--version"] if plat == "linux" else ["which", "nm"], "min_tuple": (),
             "why_str": "导出面闸读动态库导出表"}]
    if plat == "macos":
        tail.append({"name_str": "xcode_clt", "cmd_list": ["xcode-select", "-p"], "min_tuple": (), "why_str": "Apple 链接器",
                     "hint_str": "xcode-select --install"})
    return common + tail


# ───────────────────────────── 读现场（只读） ─────────────────────────────
def run(cmd: Sequence[str], cwd: Path = REPO, timeout: float = 60.0) -> Tuple[int, str]:
    try:
        r = subprocess.run(list(cmd), cwd=str(cwd), capture_output=True, text=True, encoding="utf-8", errors="replace",
                           timeout=timeout)
        return r.returncode, (r.stdout or "") + (r.stderr or "")
    except (OSError, subprocess.TimeoutExpired) as e:
        return 127, str(e)


def row(name: str, level: str, detail: str, hint: str = "") -> Dict[str, str]:
    return {"name_str": name, "level_str": level, "detail_str": detail, "hint_str": hint}


def read_bytes(path: Path) -> Optional[bytes]:
    return path.read_bytes() if path.is_file() else None


def check_ci(repo: Path) -> List[Dict[str, str]]:
    sys.path.insert(0, str(repo / "tools"))
    import fry_build
    rows = []
    active, std, internal = read_bytes(repo / ".gitlab-ci.yml"), read_bytes(repo / "ci" / "standalone.gitlab-ci.yml"), \
        read_bytes(repo / "ci" / "internal.gitlab-ci.yml")
    mode = ci_mode(active, std, internal)
    level = {"standalone": "ok", "internal": "ok", "drift": "fail", "missing": "fail"}[mode]
    detail = {"standalone": "仓根 .gitlab-ci.yml = ci/standalone.gitlab-ci.yml（gitlab.com 独立模式，搬家前的状态）",
              "internal": "仓根 .gitlab-ci.yml = ci/internal.gitlab-ci.yml（内网模板模式，搬家后的状态）",
              "drift": "仓根 .gitlab-ci.yml 与 ci/ 里两份都不相同（有人手改了其中一份）",
              "missing": "没有仓根 .gitlab-ci.yml"}[mode]
    rows.append(row("CI 模式", level, detail, "" if level == "ok" else "只许整份复制：copy /Y ci\\internal.gitlab-ci.yml .gitlab-ci.yml"))
    if internal is None:
        rows.append(row("内网 CI 形状", "fail", "缺 ci/internal.gitlab-ci.yml"))
    else:
        bad = internal_shape_problems(internal.decode("utf-8"), fry_build.PACKAGE_NAME)
        rows.append(row("内网 CI 形状", "fail" if bad else "ok", "；".join(bad) if bad else "include 模板 v1、无 workflow:、三个 build job 与 test:unit 形状正确"))
    return rows


def check_payload(repo: Path) -> Dict[str, str]:
    code, out = run([sys.executable, str(repo / "tools" / "fry_payload.py"), "check"], cwd=repo, timeout=300)
    last = [ln for ln in out.splitlines() if ln.strip()][-1:] or [""]
    return row("载荷闸", "ok" if code == 0 else "fail", last[0].strip()[:160],
               "" if code == 0 else "先在算法仓改 C++，再 python tools/fry_payload.py sync --source <算法仓>")


def blob_sizes(repo: Path) -> Tuple[int, int, List[Tuple[int, str]]]:
    """(本地分支 + tag 的全部历史里文件对象的字节数, HEAD 用到的文件字节数, 历史里有但 HEAD 没有的最大 5 个(字节, 路径))。
    只数 --branches --tags（= git push 会推出去的东西）：搬家后旧 gitlab.com 的远端跟踪分支还留在本地，那段历史不会再推，不该再报。"""
    code, out = run(["git", "rev-list", "--objects", "--branches", "--tags"], cwd=repo, timeout=300)
    if code != 0:
        return 0, 0, []
    paths: Dict[str, str] = {}
    for ln in out.splitlines():
        sha, _sp, path = ln.partition(" ")
        if sha:
            paths[sha] = path
    try:
        r = subprocess.run(["git", "cat-file", "--batch-check=%(objecttype) %(objectname) %(objectsize)"], cwd=str(repo),
                           input="\n".join(paths) + "\n", capture_output=True, text=True, encoding="utf-8", timeout=300)
    except (OSError, subprocess.TimeoutExpired):
        return 0, 0, []
    blobs: Dict[str, int] = {}
    for ln in r.stdout.splitlines():
        parts = ln.split()
        if len(parts) == 3 and parts[0] == "blob":
            blobs[parts[1]] = int(parts[2])
    code, tree = run(["git", "ls-tree", "-r", "HEAD"], cwd=repo, timeout=120)
    head = {ln.split()[2] for ln in tree.splitlines() if len(ln.split()) >= 3} if code == 0 else set()
    total = sum(blobs.values())
    head_bytes = sum(size for sha, size in blobs.items() if sha in head)
    extra = sorted(((size, paths.get(sha, "?")) for sha, size in blobs.items() if sha not in head), reverse=True)[:5]
    return total, head_bytes, extra


def check_git(repo: Path) -> List[Dict[str, str]]:
    code, _ = run(["git", "rev-parse", "--is-inside-work-tree"], cwd=repo)
    if code != 0:
        return [row("git", "fail", "不是 git 仓库")]
    rows = []
    _c, branch = run(["git", "rev-parse", "--abbrev-ref", "HEAD"], cwd=repo)
    branch = branch.strip()
    rows.append(row("当前分支", "ok" if branch == "main" else "warn", branch,
                    "" if branch == "main" else "模板的发版按钮只挂在默认分支（main）上"))
    _c, status = run(["git", "status", "--porcelain"], cwd=repo)
    n_dirty = len([ln for ln in status.splitlines() if ln.strip()])
    rows.append(row("未提交改动", "ok" if n_dirty == 0 else "warn", "%d 个文件" % n_dirty,
                    "" if n_dirty == 0 else "推内网 / 做快照前先提交（或等自动提交程序提交完再暂停它）"))
    _c, remotes = run(["git", "remote", "-v"], cwd=repo)
    lines = sorted({mask_url(ln.replace("(fetch)", "").replace("(push)", "").strip()) for ln in remotes.splitlines() if ln.strip()})
    origin = next((ln.split()[1] for ln in lines if ln.split()[0] == "origin" and len(ln.split()) > 1), "")
    where = "内网" if INTERNAL_HOST_STR in origin else ("gitlab.com" if "gitlab.com" in origin else "其它")
    rows.append(row("远端", "info", " ｜ ".join(ln.replace("\t", " ") for ln in lines) or "（没有远端）", "origin 在 %s" % where))
    _c, tags = run(["git", "tag", "--list", "v*"], cwd=repo)
    tag_list = [t for t in tags.split() if t]
    rows.append(row("版本 tag", "info", ", ".join(tag_list) if tag_list else "一个都没有 ⇒ 内网第一次发版会是 v0.1.0（模板 FIRST_VERSION 默认）"))
    total, head_bytes, extra = blob_sizes(repo)
    level, text = history_advice(total, head_bytes)
    top = "；最大的：" + "、".join("%s %.1f MB" % (p, s / 1048576.0) for s, p in extra[:3]) if extra and level == "warn" else ""
    rows.append(row("历史体积", level, text + top))
    return rows


def check_deliverables(repo: Path) -> List[Dict[str, str]]:
    rows = []
    gi = (repo / ".gitignore").read_text(encoding="utf-8", errors="replace") if (repo / ".gitignore").is_file() else ""
    rows.append(row(".gitignore 管住 out/", "ok" if re.search(r"^out/\s*$", gi, flags=re.M) else "fail",
                    "有" if "out/" in gi else "没有 —— 自动提交程序会把构建产物提交并推送（382 踩过）"))
    rows.append(row(".gitattributes", "ok" if (repo / ".gitattributes").is_file() else "warn",
                    "在" if (repo / ".gitattributes").is_file() else "不在 —— Windows 检出 CRLF、Linux runner 检出 LF，载荷闸会红（384 踩过）"))
    missing = [p for p in CONSUMER_DOC_TUPLE if not (repo / p).is_file()]
    rows.append(row("对接方文档", "fail" if missing else "ok", ("缺 " + "、".join(missing)) if missing else "、".join(CONSUMER_DOC_TUPLE)))
    return rows


def find_vswhere() -> Optional[str]:
    base = os.environ.get("ProgramFiles(x86)") or r"C:\Program Files (x86)"
    p = Path(base) / "Microsoft Visual Studio" / "Installer" / "vswhere.exe"
    return str(p) if p.is_file() else None


def check_tool(req: Dict[str, Any]) -> Dict[str, str]:
    cmd = list(req["cmd_list"])
    hint = req.get("hint_str", "")
    if cmd[0] == "<FRY_SDK_PYTHON>":
        py = os.environ.get("FRY_SDK_PYTHON") or shutil.which("py") or shutil.which("python")
        if not py:
            return row("runner · python", "fail", "找不到 Python", hint)
        cmd[0] = py
        if "WindowsApps" in py:
            return row("runner · python", "warn", "%s 是 Windows 商店占位版" % py, hint)
    if cmd[0] == "<vswhere>":
        vw = find_vswhere()
        if not vw:
            return row("runner · vs_cpp", "fail", "找不到 vswhere.exe（没装 Visual Studio / Build Tools）", hint)
        code, out = run([vw, "-latest", "-products", "*", "-requires", "Microsoft.VisualStudio.Component.VC.Tools.x86.x64",
                         "-property", "installationPath"])
        path = out.strip().splitlines()[0] if code == 0 and out.strip() else ""
        return row("runner · vs_cpp", "ok" if path else "fail", path or "装了 VS 但没有 C++ 工具链", "" if path else hint)
    exe = shutil.which(cmd[0])
    if not exe:
        return row("runner · %s" % req["name_str"], "fail", "不在 PATH 上（%s）" % req["why_str"], hint)
    code, out = run([exe] + cmd[1:])
    first = (out.strip().splitlines() or [""])[0][:80]
    ver = version_tuple(first)
    need = tuple(req.get("min_tuple") or ())
    if code != 0:
        return row("runner · %s" % req["name_str"], "fail", "运行失败：%s" % first, hint)
    if need and ver[:len(need)] < need:
        return row("runner · %s" % req["name_str"], "fail", "%s（需要 ≥ %s）" % (first, ".".join(map(str, need))), hint)
    return row("runner · %s" % req["name_str"], "ok", first)


def check_runner(plat: str) -> List[Dict[str, str]]:
    rows = [check_tool(req) for req in runner_requirements(plat)]
    exe = shutil.which("gitlab-runner") or (r"C:\GitLab-Runner\gitlab-runner.exe" if Path(r"C:\GitLab-Runner\gitlab-runner.exe").is_file() else "")
    rows.append(row("runner · gitlab-runner", "info", exe or "还没装（注册 runner 时再装，内网 GitLab 页面会给命令）"))
    return rows


def run_checks(repo: Path, runner: Optional[str] = None) -> Dict[str, Any]:
    rows = check_ci(repo) + [check_payload(repo)] + check_git(repo) + check_deliverables(repo)
    if runner:
        rows += check_runner(runner)
    n_fail = sum(r["level_str"] == "fail" for r in rows)
    n_warn = sum(r["level_str"] == "warn" for r in rows)
    return {"repo_str": str(repo), "runner_str": runner or "", "host_str": "%s %s" % (platform.system(), platform.machine()),
            "rows_list": rows, "fail_int": n_fail, "warn_int": n_warn, "row_int": len(rows)}


def main(argv: Optional[List[str]] = None) -> int:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    ap = argparse.ArgumentParser(description="搬到内网 GitLab 前后的只读体检")
    ap.add_argument("--repo", default=str(REPO), help="要体检的打包仓（默认本仓）")
    ap.add_argument("--runner", choices=("windows", "macos", "linux"), default=None, help="顺带检查本机能不能当这个平台的 runner")
    ap.add_argument("--json", dest="json_path", default="")
    ns = ap.parse_args(argv)
    rep = run_checks(Path(ns.repo).resolve(), ns.runner)
    mark = {"ok": "✓", "warn": "⚠", "fail": "✗", "info": "·"}
    print("=" * 96)
    print("★ 内网搬家体检（只读）：%s" % rep["repo_str"])
    print("=" * 96)
    for r in rep["rows_list"]:
        print("%s %-22s %s" % (mark[r["level_str"]], r["name_str"], r["detail_str"]))
        if r["hint_str"] and r["level_str"] in ("warn", "fail", "info"):
            print("  %-22s → %s" % ("", r["hint_str"]))
    print("-" * 96)
    print("查了 %d 项：✗ %d ｜ ⚠ %d  ⇒ %s" % (rep["row_int"], rep["fail_int"], rep["warn_int"],
                                       "先处理 ✗ 再往下走" if rep["fail_int"] else "没有 ✗，可以往下走（⚠ 看一眼再决定）"))
    if ns.json_path:
        Path(ns.json_path).parent.mkdir(parents=True, exist_ok=True)
        Path(ns.json_path).write_text(json.dumps(rep, ensure_ascii=False, indent=1), encoding="utf-8")
    return 1 if rep["fail_int"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
