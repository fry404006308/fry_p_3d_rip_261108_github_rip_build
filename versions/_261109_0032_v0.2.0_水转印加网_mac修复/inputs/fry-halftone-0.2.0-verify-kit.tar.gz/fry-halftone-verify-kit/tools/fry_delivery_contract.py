# -*- coding: utf-8 -*-
r"""fry_delivery_contract.py —— ★393 交付清单：一个 dll 包「必须带什么」的**唯一真源**，外加一把能跑的尺子。

【为什么要它】dll 不只是自己的软件用，同事和公司其它软件也要集成。
  只给一个 .dll，对方立刻会回来要：头文件、导入库、版本号、参数说明、示例、许可、校验值……
  ⇒ **「交付完整」必须是一条可执行的判据，不是一份口头习惯**（CLAUDE.md B.1-43：
    「判据只管我做的对不对，管不了我做完了没有」——漏一个文件，编译、冒烟、golden 全都是绿的）。

【三个等级（是包含关系，不是三选一）】
  runtime     只想「把 dll 换上去跑起来」——我们自己的软件装机、业务替换 dll
  integration 别的软件要**链接/调用**它——同事集成（在 runtime 之上加头文件 / 导入库 / 示例 / 集成说明）
  full        完整交付（再加英文说明、变更历史、许可、自检脚本、校验和）
  ⇒ 查一个包合不合格，先说清「按哪个等级查」。算法仓 `_bin/<平台>/` 按 runtime 查，给同事的 zip 按 full 查。

【这把尺子查四件事】
  ① 每一项都在、不是空文件；② JSON 能解析；③ 清单里记的 sha256 == 现场算的；
  ④ ★**版本号五处一致**：VERSION 文件 ｜ sdk_info.json ｜ dll 自报 GetVersion() ｜ Windows 文件属性(VERSIONINFO) ｜ 包名。
     ★409 只有 Windows 的 PE 才有 VERSIONINFO ⇒ Linux / macOS 查其余四处（409 在 WSL 真跑出包时这里误判「读不到」拒绝交付）。
  ⚠ ④ 是最容易断的一条：版本号从 CI 变量一路传到编译期宏、再到资源脚本，**断在哪一环都不会让编译失败**。

【用法】
  python tools/fry_delivery_contract.py                      # 查 out/sdk/fry-halftone-sdk（full）
  python tools/fry_delivery_contract.py --dir <包目录> --level integration
  python tools/fry_delivery_contract.py --write-manifest     # 生成 delivery_manifest.json（装配时调）
  python tools/fry_delivery_contract.py --selftest           # ★ 自测：正常时绿 + 逐项搞坏必须红
"""
from __future__ import annotations

import argparse
import ctypes
import hashlib
import json
import os
import platform
import shutil
import sys
import tempfile
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

REPO = Path(__file__).resolve().parents[1]
MANIFEST_NAME_STR = "delivery_manifest.json"
SUMS_NAME_STR = "SHA256SUMS.txt"
MANIFEST_SCHEMA_STR = "fry-halftone-delivery/1"

LEVEL_TUPLE = ("runtime", "integration", "full")          # 从小到大，后面的包含前面的


def level_ok(item_level: str, want_level: str) -> bool:
    """这一项在「按 want_level 查」时算不算必需。"""
    return LEVEL_TUPLE.index(item_level) <= LEVEL_TUPLE.index(want_level)


# ─────────────────────────────────────────────────────────────────────────────
# ★ 清单本体：一行一项。加一项 = 这里加一行（别处不用改）
#   (路径模板, 等级, 类别, 为什么必需, 类型)
#   路径模板里的 {lib} / {implib} 由平台填（Windows: fry_halftone.dll / fry_halftone.lib）
#   类型: bin=二进制 ｜ text=文本 ｜ json=要能解析的 JSON ｜ dir=目录(至少一个文件)
# ─────────────────────────────────────────────────────────────────────────────
ITEM_LIST: Tuple[Dict[str, str], ...] = (
    {"path": "bin/{lib}", "level": "runtime", "kind": "bin", "cat": "二进制",
     "why": "动态库本体 —— 没有它什么都谈不上"},
    {"path": "VERSION", "level": "runtime", "kind": "text", "cat": "身份",
     "why": "一眼能看到版本号（不用解析 JSON、不用加载库）"},
    {"path": "sdk_info.json", "level": "runtime", "kind": "json", "cat": "身份",
     "why": "版本 / 平台 / 算法指纹 / dll 的 sha256 / 构建环境 —— 对方核对「我拿到的是哪一版」靠它"},
    {"path": "params_schema.json", "level": "runtime", "kind": "json", "cat": "契约",
     "why": "机器可读的参数白名单：对方可以据此自动生成设置界面 / 校验参数"},
    {"path": "SDK_参数说明.md", "level": "runtime", "kind": "text", "cat": "文档",
     "why": "人读版参数说明（由 params_schema.json 逐行生成，不会与库脱节）"},
    {"path": MANIFEST_NAME_STR, "level": "runtime", "kind": "json", "cat": "清单",
     "why": "★ 机器可读的交付清单：对方拿到包能**自证完整**，不用问我们"},
    {"path": "bin/{cli}", "level": "integration", "kind": "bin", "cat": "二进制",
     "why": "★409 命令行版（协议与 lmst-cli 同构）：桌面端 / 云端 slice-worker 按子进程调；它用的就是同目录这个库"},
    {"path": "include/fry_halftone.h", "level": "integration", "kind": "text", "cat": "契约",
     "why": "C 接口声明 —— 不给头文件，对方只能手抄声明（抄错就是内存错乱）"},
    {"path": "lib/{implib}", "level": "integration", "kind": "bin", "cat": "二进制",
     "why": "Windows 导入库：隐式链接（#pragma comment / 链接器输入）必需", "win_only": "1"},
    {"path": "SDK_使用说明.md", "level": "integration", "kind": "text", "cat": "文档",
     "why": "集成说明（中文）：怎么加载、返回码、线程模型、内存、编译器与运行库要求"},
    {"path": "examples/c/fry_halftone_demo.c", "level": "integration", "kind": "text", "cat": "示例",
     "why": "最小可编译示例（C）—— 对方照抄就能跑通"},
    {"path": "examples/csharp/FryHalftoneDemo.cs", "level": "integration", "kind": "text", "cat": "示例",
     "why": "C# P/Invoke 示例：公司别的软件多是 C#/WPF，字符集与调用约定最容易错"},
    {"path": "examples/python/fry_halftone_demo.py", "level": "integration", "kind": "text", "cat": "示例",
     "why": "Python ctypes 示例：脚本化验证 / 自动化测试最省事"},
    {"path": "SDK_README_EN.md", "level": "full", "kind": "text", "cat": "文档",
     "why": "英文说明：对外 / 非中文同事"},
    {"path": "CHANGELOG.md", "level": "full", "kind": "text", "cat": "文档",
     "why": "变更历史 —— 「上一版到这一版改了什么」不该靠问人"},
    {"path": "LICENSE.txt", "level": "full", "kind": "text", "cat": "合规",
     "why": "许可与第三方声明：别的部门集成前要过合规，没有它会被卡"},
    {"path": "verify_delivery.py", "level": "full", "kind": "text", "cat": "自检",
     "why": "★ 对方自检脚本（只用标准库）：双击就能验「包是不是完整、dll 是不是这一份」"},
    {"path": "SHA256SUMS.txt", "level": "full", "kind": "text", "cat": "完整性",
     "why": "全部文件的 sha256：传输 / 拷贝损坏当场看得出来"},
)


def platform_names(system: str = "") -> Dict[str, str]:
    sys_name = system or platform.system()
    row = {"Windows": {"lib": "fry_halftone.dll", "implib": "fry_halftone.lib", "tag": "win32-x64", "cli": "fry-halftone-cli.exe"},
           "Linux": {"lib": "libfry_halftone.so", "implib": "", "tag": "linux-x64", "cli": "fry-halftone-cli"},
           "Darwin": {"lib": "libfry_halftone.dylib", "implib": "", "tag": "darwin-arm64", "cli": "fry-halftone-cli"}}.get(sys_name)
    if row is None:
        raise SystemExit("✗ 不认识的平台 %r" % sys_name)
    row = dict(row)
    # ★409 与 fry_build.plat() 同一口径：Intel Mac 是 darwin-x64（以前这里写死 arm64，两处标签会对不上）
    if sys_name == "Darwin" and not system and platform.machine() != "arm64":
        row["tag"] = "darwin-x64"
    if sys_name == "Linux" and not system and platform.machine() in ("aarch64", "arm64"):
        row["tag"] = "linux-arm64"
    return row


def items_for(level: str, system: str = "") -> List[Dict[str, str]]:
    """按等级 + 平台展开成「这个包必须有哪些文件」。"""
    names = platform_names(system)
    is_win = (system or platform.system()) == "Windows"
    out: List[Dict[str, str]] = []
    for it in ITEM_LIST:
        if it.get("win_only") and not is_win:
            continue
        if not level_ok(it["level"], level):
            continue
        row = dict(it)
        row["path"] = it["path"].format(**names)
        out.append(row)
    return out


def sha256_file(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


# ───────────────────────────── 版本号：五处各怎么读 ─────────────────────────────
def version_from_file(pkg: Path) -> str:
    p = pkg / "VERSION"
    return p.read_text(encoding="utf-8").strip() if p.is_file() else ""


def version_from_info(pkg: Path) -> str:
    p = pkg / "sdk_info.json"
    if not p.is_file():
        return ""
    try:
        info = json.loads(p.read_text(encoding="utf-8"))
    except ValueError:
        return ""
    return str(info.get("version_str") or info.get("sdk_version_str") or "")


def version_from_library(lib: Path) -> str:
    """真加载一次库、真调一次 GetVersion() —— 「编译期宏有没有被注进去」只有这样才看得见。"""
    if not lib.is_file():
        return ""
    dll = None
    try:
        dll = ctypes.CDLL(str(lib)) if platform.system() != "Windows" else ctypes.WinDLL(str(lib))
        fn = dll.FryHalftone_GetVersion
        fn.restype = ctypes.c_char_p
        return (fn() or b"").decode("utf-8", "replace")
    except OSError as e:                                                # noqa: BLE001
        return "<加载失败: %s>" % e
    except AttributeError:
        return "<没有导出 FryHalftone_GetVersion>"
    finally:
        # ⚠ Windows 上加载过的 dll 会被**占用**：不放手的话，后面谁都删不掉 / 覆盖不了这个文件
        #   （自测把包拷到临时目录再删，不 FreeLibrary 就报「拒绝访问」）。
        if dll is not None and platform.system() == "Windows":
            try:
                ctypes.windll.kernel32.FreeLibrary(ctypes.c_void_p(dll._handle))
            except Exception:                                           # noqa: BLE001
                pass


FILEINFO_KEY_TUPLE = ("CompanyName", "ProductName", "FileDescription", "FileVersion", "ProductVersion",
                      "InternalName", "OriginalFilename", "LegalCopyright", "Comments",
                      "Algorithm", "AlgorithmFingerprint")


def read_fileinfo_strings(lib: Path) -> Dict[str, str]:
    """把 Windows 文件属性（VERSIONINFO 资源）里的字符串整块读出来。

    ⚠⚠ 393 实测的坑：有资源 ≠ 资源是对的 —— rc.exe 默认按系统 ANSI 代码页读 .rc，
      我们的 .rc 是 UTF-8 ⇒ 中文全成了乱码，而「版本号四处一致」那道闸照样绿。
      ⇒ 所以要把**每一栏**都读出来，和构建时打算写的逐字比（见 check() 里的「文件属性逐字比对」）。
    """
    if platform.system() != "Windows" or not lib.is_file():
        return {}
    out: Dict[str, str] = {}
    try:
        ver = ctypes.WinDLL("version")
        path = str(lib)
        size = ver.GetFileVersionInfoSizeW(ctypes.c_wchar_p(path), None)
        if not size:
            return {}
        buf = ctypes.create_string_buffer(size)
        if not ver.GetFileVersionInfoW(ctypes.c_wchar_p(path), 0, size, buf):
            return {}
        block = ctypes.c_void_p()
        length = ctypes.c_uint()
        if not (ver.VerQueryValueW(buf, ctypes.c_wchar_p(r"\VarFileInfo\Translation"),
                                   ctypes.byref(block), ctypes.byref(length)) and length.value >= 4):
            return {}
        raw = ctypes.string_at(block.value, 4)
        lang, code = int.from_bytes(raw[:2], "little"), int.from_bytes(raw[2:], "little")
        for key in FILEINFO_KEY_TUPLE:
            q = r"\StringFileInfo\%04x%04x\%s" % (lang, code, key)
            if ver.VerQueryValueW(buf, ctypes.c_wchar_p(q), ctypes.byref(block), ctypes.byref(length)) and length.value:
                out[key] = ctypes.wstring_at(block.value, length.value).strip("\x00").strip()
    except Exception as e:                                              # noqa: BLE001
        return {"<错误>": "读文件属性失败: %s" % e}
    return out


def version_from_fileinfo(lib: Path) -> str:
    """Windows 文件属性里的版本（右键「属性 → 详细信息」看到的那个）。
    ⚠ 这一处最容易缺：没有 .rc 资源时文件属性是空的，而编译、冒烟、golden 全都照常绿。"""
    got = read_fileinfo_strings(lib)
    if "<错误>" in got:
        return "<%s>" % got["<错误>"]
    return got.get("FileVersion", "")


def version_sources(pkg: Path, package_name: str = "") -> Dict[str, str]:
    """五处版本号各是什么（读不到的给空串；调用方决定哪些必须一致）。"""
    names = platform_names()
    lib = pkg / "bin" / names["lib"]
    if not lib.is_file():                                               # 算法仓 _bin 布局：dll 与说明平铺
        lib = pkg / names["lib"]
    out = {"VERSION 文件": version_from_file(pkg),
           "sdk_info.json": version_from_info(pkg),
           "dll 自报 GetVersion()": version_from_library(lib)}
    if platform.system() == "Windows":                  # ★409 只有 PE 有 VERSIONINFO；Linux / macOS 没有这一处（不是「读不到」）
        out["Windows 文件属性"] = version_from_fileinfo(lib)
    out["包名"] = package_name
    return out


# ───────────────────────────── 校验 ─────────────────────────────
def check(pkg: Path, level: str = "full", package_name: str = "", check_version: bool = True) -> Dict[str, Any]:
    """按等级查一个包。-> {ok_bool, level_str, checked_int, problems_list, rows_list, versions_dict}"""
    problems: List[str] = []
    rows: List[Dict[str, Any]] = []
    manifest = {}
    mpath = pkg / MANIFEST_NAME_STR
    if mpath.is_file():
        try:
            manifest = json.loads(mpath.read_text(encoding="utf-8"))
        except ValueError as e:
            problems.append("%s 不是合法 JSON：%s" % (MANIFEST_NAME_STR, e))
    recorded = {str(r.get("path_str")): str(r.get("sha256_str", "")) for r in (manifest.get("files_list") or [])}
    # ⚠ 装机目录是**平铺**的（dll 与说明都在同一层，没有 bin/ include/）⇒ 清单里记的键也要按文件名再查一次，
    #   否则查不到就等于「跳过 sha256 核对」——而跳过是静默的（B.1-17②：闸要报「查了多少个」）。
    recorded.update({Path(k).name: v for k, v in recorded.items() if Path(k).name not in recorded})

    for it in items_for(level, ""):
        p = pkg / it["path"]
        row: Dict[str, Any] = {"path_str": it["path"], "level_str": it["level"], "cat_str": it["cat"], "ok_bool": True}
        if not p.exists():
            # ★ 兼容算法仓 _bin 的平铺布局：bin/xxx 与 include/xxx 允许直接躺在根目录
            flat = pkg / Path(it["path"]).name
            if flat.is_file():
                p = flat
                row["flat_bool"] = True
            else:
                row["ok_bool"] = False
                row["note_str"] = "缺文件"
                problems.append("缺 %s（%s：%s）" % (it["path"], it["cat"], it["why"]))
                rows.append(row)
                continue
        if p.is_file() and p.stat().st_size == 0:
            row["ok_bool"] = False
            row["note_str"] = "空文件"
            problems.append("%s 是空文件" % it["path"])
        if it["kind"] == "json" and p.is_file():
            try:
                json.loads(p.read_text(encoding="utf-8"))
            except (ValueError, OSError) as e:
                row["ok_bool"] = False
                row["note_str"] = "JSON 解析失败"
                problems.append("%s 不是合法 JSON：%s" % (it["path"], e))
        if p.is_file():
            row["size_int"] = p.stat().st_size
            got = sha256_file(p)
            row["sha256_str"] = got
            want = recorded.get(it["path"], "") or recorded.get(Path(it["path"]).name, "")
            if want and want != got and it["path"] != MANIFEST_NAME_STR:
                row["ok_bool"] = False
                row["note_str"] = "与清单记录的 sha256 不符"
                problems.append("%s 的 sha256 与 %s 记录的不符（文件被换过？）" % (it["path"], MANIFEST_NAME_STR))
        rows.append(row)

    # ★393 文件属性逐字比对：期望值来自**构建输入**（CMake 的 FRY_* 变量，由 fry_build 写进 sdk_info.json），
    #   不是从 dll 自己读一遍再和自己比（B.1-31：期望必须从被测环节的上游算）。
    if platform.system() == "Windows":
        names = platform_names()
        lib = pkg / "bin" / names["lib"]
        if not lib.is_file():
            lib = pkg / names["lib"]
        info_path = pkg / "sdk_info.json"
        want_props: Dict[str, str] = {}
        if info_path.is_file():
            try:
                want_props = dict((json.loads(info_path.read_text(encoding="utf-8")) or {}).get("file_properties_dict") or {})
            except ValueError:
                want_props = {}
        if want_props and lib.is_file():
            got_props = read_fileinfo_strings(lib)
            for k, want in want_props.items():
                got = got_props.get(k, "")
                if got != want:
                    problems.append("文件属性 %s = %r ≠ 构建时写的 %r（.rc 代码页不对会变成乱码，而版本号那一栏照样是对的）"
                                    % (k, got, want))
        elif lib.is_file() and not want_props:
            problems.append("sdk_info.json 里没有 file_properties_dict —— 文件属性这一段没人核对（★393 起必须有）")

    # ★411 第二把尺子：SHA256SUMS.txt 逐行核对（= 对方 `sha256sum -c` 看到的）。393~410 它里面清单那一行一直过期，
    #   而上面只按清单核对 ⇒ 一直绿（B.1-43 ⑩）。full 等级才有 SUMS；缺它上面已经按缺件报了。
    if level == "full" and (pkg / SUMS_NAME_STR).is_file():
        problems += sums_problems(pkg)

    # ⚠ 读版本要真加载一次 dll，比较慢 ⇒ 不查版本时就别读（自测里要跑十几轮）
    versions = version_sources(pkg, package_name) if check_version else {}
    if check_version:
        must = {k: v for k, v in versions.items() if v and not v.startswith("<")}
        # 包名里带的版本只做「包含」判断（包名形如 fry_halftone_dll_1.2.3_win32-x64_260920_0130）
        pkg_ver = must.pop("包名", "")
        vals = set(must.values())
        if len(vals) > 1:
            problems.append("版本号不一致：" + " ｜ ".join("%s=%s" % (k, v) for k, v in must.items()))
        if pkg_ver and vals and not any(v in pkg_ver for v in vals):
            problems.append("包名 %r 里没有版本号 %s" % (pkg_ver, "/".join(sorted(vals))))
        missing = [k for k, v in versions.items() if not v and k != "包名"]
        if missing:
            problems.append("这几处读不到版本号：" + "、".join(missing))
        bad = [("%s=%s" % (k, v)) for k, v in versions.items() if v.startswith("<")]
        if bad:
            problems.append("版本号读取出错：" + "；".join(bad))

    return {"ok_bool": not problems, "level_str": level, "checked_int": len(rows),
            "problems_list": problems, "rows_list": rows, "versions_dict": versions}


def write_manifest(pkg: Path, level: str, package_name: str, extra: Optional[Dict[str, Any]] = None,
                   flat: bool = False) -> Path:
    """把清单落成包里的 delivery_manifest.json（★ 它自己也是清单的一项，所以先写占位再回填别人的 sha256）。

    flat=True 用于**装机目录**（算法仓 `_bin/<平台>/`）：那里所有文件平铺在一层，
    清单里就按文件名记，免得写着 bin/xxx 而实际在根目录（路径对不上 = 静默跳过核对）。
    """
    files: List[Dict[str, Any]] = []
    for it in items_for(level, ""):
        rel = Path(it["path"]).name if flat else it["path"]
        p = pkg / rel
        if it["path"] in (MANIFEST_NAME_STR, SUMS_NAME_STR):
            # 清单自己 / ★411 SHA256SUMS.txt 不记 sha256：SUMS 要覆盖终版清单，清单再记 SUMS 就成环（只查在不在）
            files.append({"path_str": rel, "level_str": it["level"], "cat_str": it["cat"],
                          "why_str": it["why"], "sha256_str": "", "size_int": 0})
            continue
        row = {"path_str": rel, "level_str": it["level"], "cat_str": it["cat"], "why_str": it["why"]}
        if p.is_file():
            row["sha256_str"] = sha256_file(p)
            row["size_int"] = p.stat().st_size
        else:
            row["sha256_str"] = ""
            row["size_int"] = -1                                        # -1 = 装配时就不在（校验会当缺件报红）
        files.append(row)
    data: Dict[str, Any] = {
        "schema_str": MANIFEST_SCHEMA_STR,
        "package_str": package_name,
        "level_str": level,
        "platform_str": platform_names()["tag"],
        "version_str": version_from_info(pkg) or version_from_file(pkg),
        "how_to_verify_str": "python verify_delivery.py        # 只用 Python 标准库，双击也行",
        "levels_dict": {"runtime": "把 dll 换上去跑起来", "integration": "别的软件链接 / 调用它", "full": "完整交付"},
        "files_list": files,
    }
    if extra:
        data.update(extra)
    out = pkg / MANIFEST_NAME_STR
    out.write_text(json.dumps(data, ensure_ascii=False, indent=1) + "\n", encoding="utf-8", newline="\n")
    return out


def write_sums(pkg: Path) -> Path:
    """SHA256SUMS.txt：包里除它自己以外的每个文件（`sha256sum -c` / `shasum -a 256 -c` 的格式）。"""
    files = sorted((q for q in pkg.rglob("*") if q.is_file() and q != pkg / SUMS_NAME_STR),
                   key=lambda q: q.relative_to(pkg).as_posix())
    out = pkg / SUMS_NAME_STR
    out.write_text("".join("%s  %s\n" % (sha256_file(q), q.relative_to(pkg).as_posix()) for q in files),
                   encoding="utf-8", newline="\n")
    return out


def seal(pkg: Path, level: str, package_name: str, extra: Optional[Dict[str, Any]] = None) -> Path:
    """★411 封包（唯一顺序）：先写清单，**最后**写 SHA256SUMS.txt（覆盖终版清单）。
    393~410 是「清单 → SUMS → 再写一次清单」⇒ SUMS 里清单那一行必然过期：`sha256sum -c` 报 FAILED，
    而 verify_delivery.py 只看清单 ⇒ 一直绿（B.1-43 ⑩「测错了东西」）。之后谁都不许再动包里的文件。"""
    write_manifest(pkg, level, package_name, extra)
    return write_sums(pkg)


def sums_problems(pkg: Path) -> List[str]:
    """按 SHA256SUMS.txt 逐行核对（与 `sha256sum -c` 同一口径），外加「目录里没有清单外的文件」。"""
    sums = pkg / SUMS_NAME_STR
    if not sums.is_file():
        return ["%s 里没有 %s" % (pkg, SUMS_NAME_STR)]
    probs, listed = [], set()
    for line in sums.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        want, _, rel = line.partition("  ")
        listed.add(rel)
        p = pkg / rel
        if not p.is_file() or sha256_file(p) != want:
            probs.append("%s 与 %s 不符" % (rel, SUMS_NAME_STR))
    actual = {q.relative_to(pkg).as_posix() for q in pkg.rglob("*") if q.is_file() and q != sums}
    if actual != listed:
        probs.append("%s 与目录对不上：多 %s 少 %s" % (SUMS_NAME_STR, sorted(actual - listed)[:5], sorted(listed - actual)[:5]))
    return probs


def report(res: Dict[str, Any], title: str = "") -> None:
    print("=" * 78)
    print("交付清单闸（★393）%s ｜ 等级 %s ｜ 查了 %d 项" % (("｜ " + title) if title else "", res["level_str"], res["checked_int"]))
    print("=" * 78)
    for r in res["rows_list"]:
        mark = "✓" if r.get("ok_bool") else "✗"
        note = ("　← " + r["note_str"]) if r.get("note_str") else ""
        size = ("%8d B" % r["size_int"]) if r.get("size_int") is not None and r.get("size_int", -1) >= 0 else "        -"
        print("  %s [%-11s %-6s] %-34s %s%s" % (mark, r["level_str"], r["cat_str"], r["path_str"], size, note))
    print("  ── 版本号 %d 处 ──" % len(res["versions_dict"]))
    for k, v in res["versions_dict"].items():
        print("     %-22s %s" % (k, v or "（读不到）"))
    if res["problems_list"]:
        print("  ✗ 问题 %d 条：" % len(res["problems_list"]))
        for p in res["problems_list"]:
            print("     ·", p)
    print("总判定：%s" % ("✓ 交付完整" if res["ok_bool"] else "✗ 不完整，拒绝交付"))


# ───────────────────────────── 自测（正常时绿 + 搞坏必须红）─────────────────────────────
def selftest(pkg: Path) -> int:
    """★ D.1-9：只验一个方向 = 只证明了一半。这里逐项搞坏，每一项都必须让闸变红。"""
    print("自测用的包：%s" % pkg)
    base = check(pkg, "full", check_version=False)
    if not base["ok_bool"]:
        print("✗ 基准就没过，自测无从谈起：")
        for p in base["problems_list"]:
            print("   ·", p)
        return 1
    print("✓ 基准：full 等级 %d 项全在" % base["checked_int"])
    ok = True
    with tempfile.TemporaryDirectory(prefix="fry393_") as td:
        for it in items_for("full", ""):
            work = Path(td) / "pkg"
            if work.exists():
                shutil.rmtree(work)
            shutil.copytree(pkg, work)
            victim = work / it["path"]
            if not victim.is_file():
                continue
            victim.unlink()
            res = check(work, "full", check_version=False)
            hit = any(it["path"] in p for p in res["problems_list"])
            print("   %s 删掉 %-34s ⇒ %s" % ("✓" if (not res["ok_bool"] and hit) else "✗", it["path"],
                                            "闸报红并点名" if hit else "闸没抓到！"))
            ok = ok and (not res["ok_bool"]) and hit
        # 再搞一次「内容被换掉」：sha256 必须对不上
        work = Path(td) / "pkg2"
        shutil.copytree(pkg, work)
        target = work / "SDK_参数说明.md"
        if target.is_file():
            target.write_text(target.read_text(encoding="utf-8") + "\n偷偷加一行\n", encoding="utf-8")
            res = check(work, "full", check_version=False)
            hit = any("sha256" in p for p in res["problems_list"])
            print("   %s 改掉 SDK_参数说明.md 的内容           ⇒ %s" % ("✓" if hit else "✗", "sha256 对不上，报红" if hit else "没抓到！"))
            ok = ok and hit
    print("自测：%s" % ("✓ 通过（正常时绿、每一项搞坏都红）" if ok else "✗ 没过"))
    return 0 if ok else 1


def main(argv=None) -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    ap = argparse.ArgumentParser()
    ap.add_argument("--dir", default="", help="要查的包目录（默认 out/sdk/fry-halftone-sdk）")
    ap.add_argument("--level", default="full", choices=list(LEVEL_TUPLE))
    ap.add_argument("--package-name", default="", help="包名（用于「包名里带版本号」这一条）")
    ap.add_argument("--no-version-check", action="store_true", help="不查版本五处一致（只在库加载不了的环境用）")
    ap.add_argument("--write-manifest", action="store_true", help="生成 delivery_manifest.json")
    ap.add_argument("--selftest", action="store_true")
    ns = ap.parse_args(argv)
    pkg = Path(ns.dir) if ns.dir else (REPO / "out" / "sdk" / "fry-halftone-sdk")
    if not pkg.is_dir():
        print("✗ 目录不存在：%s（先跑 python tools/fry_build.py）" % pkg)
        return 1
    if ns.selftest:
        return selftest(pkg)
    if ns.write_manifest:
        out = write_manifest(pkg, ns.level, ns.package_name or pkg.name)
        print("✓ 清单已写入 %s（%s 等级，%d 项）" % (out, ns.level, len(items_for(ns.level, ""))))
    res = check(pkg, ns.level, ns.package_name, check_version=not ns.no_version_check)
    report(res, pkg.name)
    return 0 if res["ok_bool"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
