# -*- coding: utf-8 -*-
r"""fry_wsl.py —— ★412 在 WSL 的真 Linux 里跑一段 bash（一致性复核 / 验收包实测 / 同事角度复验共用）。

⚠ 逻辑一律写成 .sh 文件再让 WSL 执行：直接把命令拼进 `wsl … bash -c "…"` 时，`$` 会被提前展开、`/mnt/…` 路径会被 MSYS 改写，
  都不报错（记忆 wsl-command-line-expands-dollar）。输出按 UTF-8 读（WSL_UTF8=1）。
"""
from __future__ import annotations

import subprocess
import sys
from pathlib import Path
from typing import List

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO / "tools"))
import fry_build_linux_native as LN  # noqa: E402


def distro() -> str:
    return LN.wsl_distro()


def path(p: Path) -> str:
    """Windows 路径 → WSL 里的 /mnt/<盘>/… 路径。"""
    return LN.to_wsl_path(Path(p))


def run_lines(lines: List[str], sh: Path, timeout: int = 7200) -> subprocess.CompletedProcess:
    """把 lines 写成 sh（LF、UTF-8）交给 WSL 执行；没有 WSL 发行版就大声失败。"""
    d = distro()
    if not d:
        raise RuntimeError("本机没有可用的 WSL 发行版 —— 这一步要在真 Linux 里跑（wsl --install -d Debian）")
    sh.parent.mkdir(parents=True, exist_ok=True)
    sh.write_bytes(("\n".join(lines) + "\n").encode("utf-8"))
    return subprocess.run(["wsl", "-d", d, "-u", "root", "--", "bash", path(sh)], capture_output=True,
                          env=LN.wsl_env(), timeout=timeout)


def text(b: bytes) -> str:
    return b.decode("utf-8", "replace").replace("\r\n", "\n")
