# -*- coding: utf-8 -*-
r"""fry_target_kit.py —— ★409 「目标机验收包」：Windows 上交叉编好的二进制 + 全部判据 + 一条命令的验收脚本。

【为什么要有它（本篇最重要的一句）】
  交叉编译（fry_cross_build.py）只能证明「编出来了、格式 / 架构 / 装载路径 / 签名都对」；
  本 SDK 的承诺是「与 Python 生产线**逐字节**一致」，而数学库（libm：pow / atan2 / cos / sin）是**目标机自己的**
  ⇒ golden 只能在目标机上跑。Linux 有 WSL（本机就是真 Linux 用户态）；macOS 在 Windows 上既没有合法的虚拟机，
  也没有能加载 Mach-O 的环境 ⇒ 把「验收」这一步**打包带走**：任意一台 Mac 上一条命令 =
  指纹闸 → 装配 → 冒烟（导出面 / 指纹 / 说明 / 探针 / C 接口 / golden 逐字节 / 纯 C 示例 / 命令行契约 / 交付清单）→ 出包，
  与 CI、与 WSL 验收走的是**同一份** fry_build.py（--prebuilt-dir）。

【包里有什么】
  prebuilt/<目标>/   四个二进制 + prebuilt_info.json（来自 out/cross/<目标>/prebuilt；★ 静态闸必须已过、sha256 必须对得上）
  判据与装配所需     tools/ tests/（含 golden 数据）include/ docs/ examples/ packaging/ cpp.lock.json CHANGELOG LICENSE
  ⚠ **不带算法源码**（cpp/ src/）：验收包会被拷来拷去；源码只该在仓库里。fry_build.py 发现没有 cpp/ 时
    把「载荷闸」换成「指纹闸」（预编件指纹 = 锁文件），库自报的指纹在冒烟里再对一次。
  run_on_target.sh   入口：认出本机是哪个目标 → 验收 → 结果拷到 results/<目标>/（包 + 包的 SHA256SUMS + 报告 + 机器环境）
  kit_info.json      版本 / 算法指纹 / 每个二进制的 sha256 / ★ verified_on_target=false（包本身永远是「未验证」）

【用法】
  python tools/fry_target_kit.py                                   # cross_info.json 里所有静态闸已过的目标
  python tools/fry_target_kit.py --target macos-arm64,macos-x64
  目标机：tar -xzf fry-halftone-<版本>-verify-kit.tar.gz && bash fry-halftone-verify-kit/run_on_target.sh
"""
from __future__ import annotations

import argparse
import hashlib
import io
import json
import platform
import sys
import tarfile
import time
from pathlib import Path
from typing import Any, Dict, List

REPO = Path(__file__).resolve().parents[1]
CROSS = REPO / "out" / "cross"
OUT = REPO / "out" / "kit"
KIT_DIR_NAME = "fry-halftone-verify-kit"
# 验收要用到的仓库内容（相对仓库根）；⚠ cpp/ src/ 故意不在里面（见文件头）
INCLUDE_LIST = ["tools", "tests", "include", "docs", "examples", "packaging",
                "cpp.lock.json", "CHANGELOG.md", "LICENSE.txt", "README.md"]
SKIP_PART_SET = {"__pycache__", ".pytest_cache", ".git", "out"}
SKIP_SUFFIX_SET = {".pyc", ".pyo"}
TAG_DICT = {"macos-arm64": "darwin-arm64", "macos-x64": "darwin-x64", "linux-x64": "linux-x64", "linux-arm64": "linux-arm64"}


def sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def pick_targets(wanted: str) -> List[Dict[str, Any]]:
    """从 cross_info.json 挑目标：只收**静态闸已过**的；二进制 sha256 必须与 prebuilt_info.json 一致（打的就是验过的那一份）。"""
    info_path = CROSS / "cross_info.json"
    if not info_path.is_file():
        raise SystemExit("✗ 没有 out/cross/cross_info.json —— 先跑 python tools/fry_cross_build.py --target …")
    rows = json.loads(info_path.read_text(encoding="utf-8"))["targets_list"]
    by = {r["target_str"]: r for r in rows}
    names = list(by) if wanted == "auto" else [t.strip() for t in wanted.split(",") if t.strip()]
    lock_fp = json.loads((REPO / "cpp.lock.json").read_text(encoding="utf-8"))["tree_sha256_str"]
    picked: List[Dict[str, Any]] = []
    for t in names:
        r = by.get(t)
        if r is None:
            raise SystemExit("✗ cross_info.json 里没有 %s —— 先交叉编它" % t)
        if not r.get("ok_bool"):
            if wanted == "auto":
                print("  跳过 %s：交叉编译 / 静态闸没过（%s）" % (t, r.get("static_problems_list") or r.get("stage_str")))
                continue
            raise SystemExit("✗ %s 的交叉编译 / 静态闸没过，不能打进验收包" % t)
        pre = CROSS / t / "prebuilt"
        pinfo = json.loads((pre / "prebuilt_info.json").read_text(encoding="utf-8"))
        for name, sha in pinfo["files_dict"].items():
            if sha256_bytes((pre / name).read_bytes()) != sha:
                raise SystemExit("✗ %s/%s 的 sha256 与 prebuilt_info.json 不符 —— 编完之后被动过" % (t, name))
        if pinfo.get("algorithm_fingerprint_str") != lock_fp:
            raise SystemExit("✗ %s 的预编件指纹 ≠ 当前 cpp.lock.json —— 源码变过，重新交叉编" % t)
        picked.append({"target_str": t, "dir": pre, "prebuilt_info_dict": pinfo, "cross_row_dict": r})
    if not picked:
        raise SystemExit("✗ 一个可打包的目标都没有")
    versions = {p["prebuilt_info_dict"]["version_str"] for p in picked}
    if len(versions) != 1:
        raise SystemExit("✗ 这几个目标的版本号不一致：%s —— 用同一个 --version 重新交叉编" % sorted(versions))
    # ★410 外壳指纹（src/ include/ CMakeLists.txt …）：各目标必须是同一份外壳源码编的，且记了这个值（旧产物没有 ⇒ 重编）
    wrappers = {p["prebuilt_info_dict"].get("wrapper_sha256_str", "") for p in picked}
    if "" in wrappers:
        raise SystemExit("✗ 有目标的 prebuilt_info.json 没记外壳指纹（旧版交叉编译产物）—— 重新交叉编")
    if len(wrappers) != 1:
        raise SystemExit("✗ 这几个目标的外壳指纹不一致（不是同一份 src/ include/ CMakeLists.txt 编的）—— 一起重新交叉编")
    return picked


def repo_files() -> List[Path]:
    out: List[Path] = []
    for rel in INCLUDE_LIST:
        p = REPO / rel
        if p.is_file():
            out.append(p)
        elif p.is_dir():
            out += [q for q in sorted(p.rglob("*")) if q.is_file()
                    and not (set(q.relative_to(REPO).parts) & SKIP_PART_SET) and q.suffix not in SKIP_SUFFIX_SET]
        else:
            raise SystemExit("✗ 仓库里缺 %s（验收要用）" % rel)
    return out


RUNNER_SH = r'''#!/usr/bin/env bash
# run_on_target.sh —— ★409 目标机验收：认出本机 → 用包里预编的二进制跑 fry_build.py --prebuilt-dir
#   （指纹闸 → 装配 → 冒烟：导出面 / 指纹 / 说明 / 探针 / C 接口 / golden 逐字节 / 纯 C 示例 / 命令行契约 / 交付清单 → 出包）
# 用法：bash run_on_target.sh             验本机这个架构
#       bash run_on_target.sh --also-x64  Apple Silicon 上顺带用 Rosetta 2 验 Intel 版（darwin-x64）
# 退出码：0 全过（results/ 里是可交付的包）｜ 1 验收没过（不是交付件）｜ 2 参数错 ｜ 3 缺工具（会打印安装命令）
set -euo pipefail
KIT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$KIT"
PY="${FRY_SDK_PYTHON:-python3}"
ALSO_X64=0
for a in "$@"; do
  case "$a" in
    --also-x64) ALSO_X64=1 ;;
    -h|--help) sed -n '2,7p' "$0"; exit 0 ;;
    *) echo "不认识的参数：${a}（只认 --also-x64）" >&2; exit 2 ;;
  esac
done
OS="$(uname -s)"
if [ "$OS" = "Darwin" ]; then
  export PATH="/opt/homebrew/bin:/usr/local/bin:$PATH"
  xcode-select -p >/dev/null 2>&1 || { echo "缺 Xcode 命令行工具（nm / python3）：xcode-select --install" >&2; exit 3; }
fi
missing=""
for t in "$PY" nm tar zstd; do command -v "$t" >/dev/null 2>&1 || missing="$missing $t"; done
SHA=""          # 出包后给包写 SHA256SUMS.txt：Linux 用 sha256sum，macOS 自带 shasum
if command -v sha256sum >/dev/null 2>&1; then SHA="sha256sum"
elif command -v shasum >/dev/null 2>&1; then SHA="shasum -a 256"
else missing="$missing sha256sum"; fi
if [ -n "$missing" ]; then
  if [ "$OS" = "Darwin" ]; then hint="xcode-select --install ；brew install zstd"
  else hint="sudo apt-get install -y python3 binutils zstd（或发行版对应的包）"; fi
  echo "缺工具：$missing —— 装好再跑：$hint" >&2
  exit 3
fi
"$PY" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 8) else 1)' || { echo "python3 要 ≥ 3.8" >&2; exit 3; }
VERSION="$("$PY" -c 'import json; print(json.load(open("kit_info.json", encoding="utf-8"))["version_str"])')"

HW="$(uname -m)"
if [ "$OS" = "Darwin" ] && [ "$(sysctl -n hw.optional.arm64 2>/dev/null || echo 0)" = "1" ]; then
  HW="arm64"      # Rosetta 里开的终端会谎报 x86_64 ⇒ 以硬件为准
fi
case "$OS-$HW" in
  Darwin-arm64) NATIVE=macos-arm64 ;;
  Darwin-x86_64) NATIVE=macos-x64 ;;
  Linux-x86_64) NATIVE=linux-x64 ;;
  Linux-aarch64|Linux-arm64) NATIVE=linux-arm64 ;;
  *) echo "不支持的平台：$OS $HW" >&2; exit 3 ;;
esac
tag_of() {
  case "$1" in macos-arm64) echo darwin-arm64 ;; macos-x64) echo darwin-x64 ;; *) echo "$1" ;; esac
}

if [ "$OS" = "Darwin" ]; then
  # 浏览器 / 聊天工具下载的文件带隔离属性：未公证的 dylib 会被 Gatekeeper 拦下（dlopen 失败）
  echo "· 清除本目录的下载隔离属性（com.apple.quarantine；只动 $KIT 里的文件）"
  xattr -dr com.apple.quarantine "$KIT" 2>/dev/null || true
fi
mkdir -p "$KIT/results"

env_note() {   # 这台机器是谁：随结果一起带回去（验收证据的一部分）
  {
    echo "date: $(date '+%Y-%m-%d %H:%M:%S %z')"
    echo "uname: $(uname -a)"
    if [ "$OS" = "Darwin" ]; then sw_vers 2>/dev/null || true; echo "hw.optional.arm64: $(sysctl -n hw.optional.arm64 2>/dev/null || echo 0)"
    else cat /etc/os-release 2>/dev/null | grep -E '^(PRETTY_NAME|VERSION_ID)=' || true; ldd --version 2>&1 | head -1 || true; fi
    echo "python: $("$@" -c 'import platform, sys; print(sys.version.split()[0], platform.machine())')"
  }
}

RESULT_ROWS=""
verify_one() {   # $1 = 目标；其余 = 跑 python 的命令（可带 arch 前缀）
  local tgt="$1"; shift
  local pre="$KIT/prebuilt/$tgt" dst="$KIT/results/$tgt" rc=0 tag
  tag="$(tag_of "$tgt")"
  if [ ! -d "$pre" ]; then
    echo "✗ 包里没有 $tgt 的预编二进制" >&2
    RESULT_ROWS="$RESULT_ROWS\n  ✗ ${tgt}：包里没有"
    return 1
  fi
  chmod +x "$pre"/* 2>/dev/null || true
  rm -rf "$dst" && mkdir -p "$dst"
  echo
  echo "================ 验收 ${tgt}（版本 ${VERSION}）================"
  env_note "$@" > "$dst/target_env.txt"
  "$@" tools/fry_build.py --version "$VERSION" --prebuilt-dir "$pre" 2>&1 | tee "$dst/verify.log" || rc=$?
  cp -f out/build_report.json "$dst/" 2>/dev/null || true
  if [ "$rc" = "0" ] && [ -f "out/fry-halftone-$VERSION-$tag.tar.zst" ]; then
    mv -f "out/fry-halftone-$VERSION-$tag.tar.zst" "$dst/"
    # 收包的人在 results/<目标>/ 里跑 `shasum -a 256 -c SHA256SUMS.txt`（或 sha256sum -c）就能核对包在路上没坏
    (cd "$dst" && $SHA "fry-halftone-$VERSION-$tag.tar.zst") > "$dst/SHA256SUMS.txt"
    RESULT_ROWS="$RESULT_ROWS\n  ✓ ${tgt}：可交付 → results/$tgt/fry-halftone-$VERSION-$tag.tar.zst"
    return 0
  fi
  RESULT_ROWS="$RESULT_ROWS\n  ✗ ${tgt}：验收没过（rc=${rc}）→ 看 results/$tgt/verify.log"
  return 1
}

FAIL=0
if [ "$OS" = "Darwin" ] && [ "$NATIVE" = "macos-arm64" ]; then
  verify_one macos-arm64 arch -arm64 "$PY" || FAIL=1
  if [ "$ALSO_X64" = "1" ]; then
    if arch -x86_64 "$PY" -c 'import platform, sys; sys.exit(0 if platform.machine() == "x86_64" else 1)' 2>/dev/null; then
      verify_one macos-x64 arch -x86_64 "$PY" || FAIL=1
    else
      echo "⚠ 跳过 macos-x64：需要 Rosetta 2（softwareupdate --install-rosetta）+ universal2 的 python3（Xcode 命令行工具自带的 /usr/bin/python3 就是）" >&2
      RESULT_ROWS="$RESULT_ROWS\n  ⚠ macos-x64：没验（本机跑不了 x86_64 的 python3）"
    fi
  fi
else
  verify_one "$NATIVE" "$PY" || FAIL=1
fi
echo
echo "================ 验收结果 ================"
printf "%b\n" "$RESULT_ROWS"
echo "（把 results/ 整个目录发回来：里面有可交付的包、SHA256SUMS.txt、build_report.json、verify.log、target_env.txt）"
exit "$FAIL"
'''

README_MD = """# 水转印加网 SDK · 目标机验收包（{version}）

> ⚠ **这个包本身不是交付件**：里面的二进制是在 Windows 上用 zig **交叉编译**的，还没在目标系统上跑过 golden。
> 跑完下面这一条命令、全部通过后，`results/<目标>/` 里的 `.tar.zst` **才是**可交付的 SDK 包。

## 一条命令

```bash
bash run_on_target.sh             # 验本机这个架构
bash run_on_target.sh --also-x64  # Apple Silicon 上顺带用 Rosetta 2 验 Intel 版
```

| 本机 | 验哪个 | 需要 |
|---|---|---|
| Apple Silicon Mac | macos-arm64（+ `--also-x64` 时 macos-x64） | `xcode-select --install`；`brew install zstd` |
| Intel Mac | macos-x64 | 同上 |
| Linux x86_64 | linux-x64 | python3、binutils（nm）、zstd |
| Linux aarch64 | linux-arm64 | 同上 |

## 它做了什么

1. 指纹闸：预编件的算法指纹 = `cpp.lock.json`（二进制与这份验收包是同一次出的）
2. 装配：与正式出包同一份 `tools/fry_build.py`（`--prebuilt-dir`）
3. 冒烟：导出面 → 指纹（库自报）→ 包内说明 → 版本探针 → C 接口用例 → **golden 13 例逐字节** → 纯 C 示例 → 命令行契约 → 交付清单
4. 出包：`results/<目标>/fry-halftone-{version}-<平台>.tar.zst` + `SHA256SUMS.txt` + `build_report.json` + `verify.log` + `target_env.txt`

## 包含的目标

{targets}

---

# Verify kit (English)

This kit is **not** a deliverable. Run `bash run_on_target.sh` on the target machine; only when every check passes is
`results/<target>/*.tar.zst` a deliverable SDK package (verified byte-for-byte against the golden set on that machine).
"""


def build_kit(picked: List[Dict[str, Any]]) -> Path:
    version = picked[0]["prebuilt_info_dict"]["version_str"]
    lock = json.loads((REPO / "cpp.lock.json").read_text(encoding="utf-8"))
    targets_md = "\n".join("- `%s`：%s ｜ 最低系统（实测）%s ｜ %s" % (
        p["target_str"], p["prebuilt_info_dict"]["zig_triple_str"], p["cross_row_dict"].get("min_os_str", "?"),
        p["prebuilt_info_dict"]["origin_str"]) for p in picked)
    kit_info = {
        "kit_schema_str": "fry-halftone-verify-kit/1", "version_str": version,
        "algorithm_fingerprint_str": lock["tree_sha256_str"],
        "wrapper_sha256_str": picked[0]["prebuilt_info_dict"]["wrapper_sha256_str"],   # ★410 pick_targets 已核对各目标相同
        "created_at_str": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        "created_on_str": "%s %s" % (platform.system(), platform.machine()),
        # ★★ 包本身永远「未验证」：验没验过由目标机上的 results/<目标>/build_report.json 说了算
        "verified_on_target_bool": False,
        "targets_dict": {p["target_str"]: {"tag_str": TAG_DICT[p["target_str"]],
                                           "min_os_str": p["cross_row_dict"].get("min_os_str", ""),
                                           "zig_triple_str": p["prebuilt_info_dict"]["zig_triple_str"],
                                           "files_dict": p["prebuilt_info_dict"]["files_dict"]} for p in picked},
        "source_included_bool": False,
    }
    OUT.mkdir(parents=True, exist_ok=True)
    path = OUT / ("fry-halftone-%s-verify-kit.tar.gz" % version)
    n_files = 0

    def add_bytes(tf: tarfile.TarFile, arc: str, data: bytes, mode: int) -> None:
        ti = tarfile.TarInfo(KIT_DIR_NAME + "/" + arc)
        ti.size, ti.mode, ti.mtime = len(data), mode, int(time.time())
        ti.uid = ti.gid = 0
        ti.uname = ti.gname = ""
        tf.addfile(ti, io.BytesIO(data))

    with tarfile.open(path, "w:gz", format=tarfile.PAX_FORMAT) as tf:
        for f in repo_files():
            rel = f.relative_to(REPO).as_posix()
            add_bytes(tf, rel, f.read_bytes(), 0o755 if f.suffix == ".sh" else 0o644)
            n_files += 1
        for p in picked:
            for f in sorted(p["dir"].iterdir()):
                if f.is_file():
                    add_bytes(tf, "prebuilt/%s/%s" % (p["target_str"], f.name), f.read_bytes(),
                              0o644 if f.suffix == ".json" else 0o755)
                    n_files += 1
        add_bytes(tf, "run_on_target.sh", RUNNER_SH.encode("utf-8"), 0o755)
        add_bytes(tf, "README_验收.md", README_MD.format(version=version, targets=targets_md).encode("utf-8"), 0o644)
        add_bytes(tf, "kit_info.json", json.dumps(kit_info, ensure_ascii=False, indent=1).encode("utf-8"), 0o644)
        n_files += 3
    (OUT / "kit_info.json").write_text(json.dumps(dict(kit_info, kit_path_str=str(path), kit_sha256_str=sha256_bytes(path.read_bytes()),
                                                       kit_file_count_int=n_files), ensure_ascii=False, indent=1), encoding="utf-8")
    print("  ✓ 验收包：%s（%.2f MB，%d 个文件，%d 个目标：%s）"
          % (path, path.stat().st_size / 1048576.0, n_files, len(picked), "、".join(p["target_str"] for p in picked)))
    print("  ⚠ 它本身不是交付件：到目标机上 `bash %s/run_on_target.sh` 全过之后，results/<目标>/ 里的包才是" % KIT_DIR_NAME)
    return path


def main(argv=None) -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    ap = argparse.ArgumentParser(description="★409 打「目标机验收包」（交叉编好的二进制 + 判据 + 一条命令的验收脚本）")
    ap.add_argument("--target", default="auto", help="auto（所有静态闸已过的）或 macos-arm64,macos-x64,linux-x64,linux-arm64")
    ns = ap.parse_args(argv)
    print("★409 目标机验收包")
    build_kit(pick_targets(ns.target))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
