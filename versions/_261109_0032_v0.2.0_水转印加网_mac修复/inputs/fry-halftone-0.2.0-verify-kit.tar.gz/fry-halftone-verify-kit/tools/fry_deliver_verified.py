# -*- coding: utf-8 -*-
r"""fry_deliver_verified.py —— ★461 把 **GitHub 真机验收通过** 的 Linux / macOS 加网库交付进算法仓 HS200（变体目录）。

【为什么】fry_deliver.py 只交付「本机编、本机冒烟」的那一份（= Windows）。Linux / macOS 的库是 zig 交叉编的，
  本机只能出验收包；461 起由公开验收仓 fry_p_3d_rip_261108_github_rip_build 在 GitHub 的真机上跑完冒烟 + golden，
  fry_gh_publish deliver 把通过的包放到本仓 out/github_verified/<版本目录>/<平台>/。本脚本把它们送进算法仓。

【交付到哪】算法仓 fry_project_components/HS200_halftone_dll/_bin/<平台>_<YYMMDD_HHMM>_<关键词>/（★449 变体目录）；
  时间戳与关键词默认 = 算法仓里 **win32-x64 最新统一引擎变体** 的那一份（同一次构建的五个平台同名，一眼对得上）。

【前置条件（不满足就拒绝，一个都不写）】
  · verdict.json 说 ok_bool = true，且是在**本平台的机器上**验的（host_target_str == 平台）；
  · 包里 sdk_info.json 的库 sha256 == 现算；版本 == win32-x64 变体的版本；
  · 算法指纹 == 算法仓 fry_project_components_cpp 现在的指纹（--allow-stale 可强行，只给排障用）；
  · 目标变体目录不存在（每个变体只写一次）。
【交付什么】库 + 头文件 + sdk_info.json + params_schema.json + SDK_参数说明.md + VERSION + verify_delivery.py
  + github_verdict.json（哪台 GitHub 机器、什么系统、哪次 CI 运行验的）。

用法：python tools/fry_deliver_verified.py --algo-repo <算法仓> [--verified-dir out/github_verified/<版本目录>] [--dry-run]
"""
from __future__ import annotations

import argparse
import hashlib
import io
import json
import re
import shutil
import subprocess
import sys
import tarfile
import tempfile
from pathlib import Path
from typing import Any, Dict, List, Optional

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO / "tools"))
import fry_payload  # noqa: E402

TARGET_REL = Path("fry_project_components") / "HS200_halftone_dll" / "_bin"
VARIANT_DIR_RE = re.compile(r"^(?P<tag>[a-z0-9-]+)_(?P<stamp>\d{6}_\d{4})_(?P<kw>[A-Za-z0-9][A-Za-z0-9_.-]*)$")   # = export_cpp_sdk.py
LIB_NAME_DICT = {"linux-x64": "libfry_halftone.so", "linux-arm64": "libfry_halftone.so",
                 "darwin-arm64": "libfry_halftone.dylib", "darwin-x64": "libfry_halftone.dylib"}
FLAT_FILE_LIST = ["include/fry_halftone.h", "sdk_info.json", "params_schema.json", "SDK_参数说明.md", "VERSION", "verify_delivery.py"]


def sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def read_tar_zst(path: Path) -> Dict[str, bytes]:
    """解 .tar.zst（三条路依次试：python zstandard 模块 → zstd 命令 → tar --zstd）。返回 {成员名: 内容}。"""
    raw: Optional[bytes] = None
    try:
        import zstandard                                                   # noqa: F401
        raw = zstandard.ZstdDecompressor().stream_reader(open(path, "rb")).read()
    except ImportError:
        try:
            r = subprocess.run(["zstd", "-dc", str(path)], capture_output=True)
            if r.returncode == 0 and r.stdout:
                raw = r.stdout
        except OSError:
            pass
        if raw is None:
            tmp = Path(tempfile.mkdtemp())
            r = subprocess.run(["tar", "--zstd", "-xf", str(path), "-C", str(tmp)], capture_output=True)
            if r.returncode != 0:
                raise SystemExit("✗ 解不开 %s：装 zstd（或 pip install zstandard）" % path.name)
            out = {p.relative_to(tmp).as_posix(): p.read_bytes() for p in tmp.rglob("*") if p.is_file()}
            shutil.rmtree(tmp, ignore_errors=True)
            return out
    with tarfile.open(fileobj=io.BytesIO(raw), mode="r:") as t:
        return {m.name: t.extractfile(m).read() for m in t.getmembers() if m.isfile()}


def newest_win_variant(algo: Path) -> Optional[Path]:
    found = []
    for d in (algo / TARGET_REL).iterdir():
        m = VARIANT_DIR_RE.match(d.name)
        if d.is_dir() and m and m.group("tag") == "win32-x64" and (d / "fry_halftone.dll").is_file():
            try:
                schema = json.loads((d / "params_schema.json").read_text(encoding="utf-8"))
            except (OSError, ValueError):
                continue
            if any(p.get("name") == "wt_engine" for p in schema.get("params", [])):
                found.append((m.group("stamp"), m.group("kw"), d))
    return sorted(found, reverse=True)[0][2] if found else None


def plan_one(tdir: Path, tag: str, fp_now: str, want_version: str) -> Dict[str, Any]:
    """一个平台：读 verdict + 包，查闸，返回要写的文件（不落盘）。problems_list 非空 = 不交付。"""
    probs: List[str] = []
    v = json.loads((tdir / "verdict.json").read_text(encoding="utf-8"))
    if not v.get("ok_bool"):
        probs.append("verdict 没过")
    if v.get("host_target_str") != tag:
        probs.append("verdict 是在 %s 上验的，不是 %s" % (v.get("host_target_str"), tag))
    pkgs = sorted(tdir.glob("fry-halftone-*-%s.tar.zst" % tag))
    if len(pkgs) != 1:
        return {"tag_str": tag, "problems_list": probs + ["应当正好 1 个 .tar.zst，实际 %d 个" % len(pkgs)], "files_dict": {}}
    if v.get("deliverable_dict", {}).get(pkgs[0].name) != sha256_bytes(pkgs[0].read_bytes()):
        probs.append("包的 sha256 与 verdict 记的不一致")
    members = read_tar_zst(pkgs[0])
    root = "fry-halftone/"
    lib = LIB_NAME_DICT[tag]
    files: Dict[str, bytes] = {}
    if root + "bin/" + lib not in members:
        probs.append("包里没有 bin/%s" % lib)
    else:
        files[lib] = members[root + "bin/" + lib]
    for rel in FLAT_FILE_LIST:
        if root + rel in members:
            files[Path(rel).name] = members[root + rel]
        else:
            probs.append("包里没有 %s" % rel)
    info = json.loads(files.get("sdk_info.json", b"{}").decode("utf-8"))
    if lib in files and info.get("library_sha256_str") != sha256_bytes(files[lib]):
        probs.append("sdk_info.json 记的库 sha256 ≠ 现算（包被改过）")
    if info.get("platform_str") != tag:
        probs.append("sdk_info.json 说平台是 %s" % info.get("platform_str"))
    if info.get("version_str") != want_version:
        probs.append("版本 %s ≠ win32-x64 变体的 %s" % (info.get("version_str"), want_version))
    stale = info.get("algorithm_fingerprint_str") != fp_now
    files["github_verdict.json"] = (json.dumps({
        "schema_str": "fry-halftone-github-verdict/1", "target_str": tag, "verified_bool": bool(v.get("ok_bool")),
        "machine_dict": v.get("machine_dict", {}), "version_dir_str": v.get("version_dir_str"),
        "checks_int": len(v.get("checks_list", [])), "package_str": pkgs[0].name,
        "package_sha256_str": sha256_bytes(pkgs[0].read_bytes()), "started_at_str": v.get("started_at_str")},
        ensure_ascii=False, indent=1) + "\n").encode("utf-8")
    return {"tag_str": tag, "problems_list": probs, "stale_bool": stale, "files_dict": files,
            "fingerprint_str": info.get("algorithm_fingerprint_str", ""), "library_sha256_str": info.get("library_sha256_str", "")}


def main(argv=None) -> int:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    ap = argparse.ArgumentParser(description="GitHub 真机验过的 Linux / macOS 加网库 → 算法仓 HS200 变体目录")
    ap.add_argument("--algo-repo", required=True)
    ap.add_argument("--verified-dir", default="", help="out/github_verified/<版本目录>（默认最新）")
    ap.add_argument("--allow-stale", action="store_true")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--result-json", default="")
    ns = ap.parse_args(argv)
    algo = Path(ns.algo_repo).resolve()
    vroot = Path(ns.verified_dir) if ns.verified_dir else sorted((REPO / "out" / "github_verified").glob("_*"))[-1]
    win = newest_win_variant(algo)
    if win is None:
        raise SystemExit("✗ 算法仓 HS200 里还没有 win32-x64 的统一引擎变体 —— 先 fry_deliver.py --variant")
    m = VARIANT_DIR_RE.match(win.name)
    win_info = json.loads((win / "sdk_info.json").read_text(encoding="utf-8"))
    fp_now = fry_payload.tree_sha256(fry_payload.scan(algo / fry_payload.SOURCE_SUBDIR_STR))
    print("· 对齐 win32-x64 变体 %s（版本 %s）｜ 算法仓 C++ 指纹 %s" % (win.name, win_info["version_str"], fp_now[:16]))
    plans = [plan_one(vroot / tag, tag, fp_now, win_info["version_str"]) for tag in LIB_NAME_DICT if (vroot / tag).is_dir()]
    bad = []
    for p in plans:
        dst = algo / TARGET_REL / ("%s_%s_%s" % (p["tag_str"], m.group("stamp"), m.group("kw")))
        p["dst"] = dst
        if dst.exists() and any(dst.iterdir()):
            same = all((dst / n).is_file() and (dst / n).read_bytes() == b for n, b in p["files_dict"].items() if n != "github_verdict.json")
            if same:
                p["skip_bool"] = True
            else:
                p["problems_list"].append("变体目录 %s 已存在且内容不同（每个变体只写一次）" % dst.name)
        if p.get("stale_bool") and not ns.allow_stale:
            p["problems_list"].append("包的算法指纹 %s ≠ 算法仓现在的 %s（C++ 改过，重新出包）" % (p["fingerprint_str"][:16], fp_now[:16]))
        bad += ["%s：%s" % (p["tag_str"], x) for x in p["problems_list"]]
    if not plans:
        bad.append("%s 里没有 Linux / macOS 平台" % vroot)
    if bad:
        print("✗ 不交付（一个都没写）：\n  " + "\n  ".join(bad))
        return 1
    rows = []
    for p in plans:
        if p.get("skip_bool"):
            print("✓ %-13s 已交付过（内容相同）→ %s" % (p["tag_str"], p["dst"].name))
        elif not ns.dry_run:
            p["dst"].mkdir(parents=True, exist_ok=True)
            for n, b in p["files_dict"].items():
                (p["dst"] / n).write_bytes(b)
            print("✓ %-13s → %s（库 %s…）" % (p["tag_str"], p["dst"].relative_to(algo), p["library_sha256_str"][:16]))
        rows.append({"tag_str": p["tag_str"], "dst_str": str(p["dst"]), "library_sha256_str": p["library_sha256_str"],
                     "skipped_bool": bool(p.get("skip_bool")), "dry_run_bool": ns.dry_run})
    if ns.result_json:
        Path(ns.result_json).write_text(json.dumps({"ok_bool": True, "rows_list": rows, "verified_dir_str": str(vroot)},
                                                   ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
    return 0


if __name__ == "__main__":
    sys.exit(main())
