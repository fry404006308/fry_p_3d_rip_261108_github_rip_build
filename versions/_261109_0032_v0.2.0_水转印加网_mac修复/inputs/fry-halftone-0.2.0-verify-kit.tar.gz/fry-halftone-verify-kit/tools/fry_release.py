# -*- coding: utf-8 -*-
r"""fry_release.py —— **算法改完之后，重新出包的一键命令**（界面上的「一键打包」按钮调的也是它）。

【它把四件事串成一条】（★394 可选第 ③b 步：跨平台交叉编译探针 --cross；★409 可选 ③c Linux 真出包 / ③d macOS 验收包）
  ① 查   算法仓现在和上次同步进来的那份差多少（tools/fry_payload.py status）
  ② 同步 有变化才同步（--sync auto，默认）；也可以强制 always / 永不 never
  ③ 出包 五步流水线（tools/fry_build.py）：载荷闸 → CMake 编译 → 装配 → ★冒烟（C 接口 + golden 与 Python 逐字节）→ 压缩
  ④ 发版（可选，默认不做）：提交载荷 → 打 tag vX.Y.Z → 推送 ⇒ GitLab CI 三平台出正式版
  最后写一份 result.json（界面的子进程桥 TR100 靠它判成败，同时核对返回码）。

【为什么「发版」有这么多闸】OPS-0027：正式 tag **不可移动**。在编不出来 / 载荷不对的 commit 上打了 tag，
  只能作废一个版本号收场。所以：
  · 没有在**同一次运行里**出包 + 冒烟通过，就**拒绝**打 tag；
  · tag 已存在（本地或远端）就拒绝，不覆盖；
  · ★★ 打 tag 前核对「将要被打 tag 的那个 commit 里的 cpp.lock.json 指纹 == 刚才冒烟通过的包的指纹」。
    这条专门防一个真实的坑：这台机器上有**自动提交程序**，它什么时候提交是随机的 ——
    如果 tag 打在「新载荷还没被提交」的那个 commit 上，CI 就会用**旧算法**编出一个**新版本号**的包，
    文件名、版本号全对，内容是旧的，而且没有任何报错。

【★388 搬到内网之后】仓根 .gitlab-ci.yml 换成 ci/internal.gitlab-ci.yml（OPS-0027 模板模式）后，**本地 --tag 会被拒绝**：
  正式版改在 GitLab 网页上点 release:tag —— 版本号由模板按提交记录算、打 tag 前查整条流水线全绿，本地手工打 tag 会绕过这两道闸。
  「本地出包 + 冒烟 + 交付算法仓界面」这一半照常用；确要强发（OPS-0027 留的逃生口）加 --force-manual-tag。

【★409 一次出齐三个平台（本机能做到的最大范围）】
  ③c --linux native|prebuilt|both：在本机 WSL2 / Docker 的**真 Linux** 里跑同一套冒烟（golden 逐字节）⇒ **可交付**
       native = Linux 里 gcc 原生编（glibc ≥ 该发行版）｜prebuilt = Windows 上 zig 交叉编 + 真 Linux 验收（glibc 2.17 起可加载）
  ③d --mac-kit：交叉编 macOS arm64 + x64 → 打「目标机验收包」（**不是交付件**：拷到任意一台 Mac 上
       `bash run_on_target.sh` 一条命令真跑 golden + 出包；Windows 上没有合法的 macOS 运行环境）
  ⚠ 这两步是**用户点名要的产物** ⇒ 失败 = 整次失败（与 ③b 探针不同：探针失败不影响 Windows 包）
  ★410/411/412 --bundle：三个平台出齐后，**证据全在一条命令里产出**，再放进 out/全交付目录/_YYMMDD_HHMM_<主题>/：
    ③e 集成命令实测（交付说明里的每条命令在 Windows 与 WSL 里原样真跑）
    ③f ★412 跨平台一致性复核（tools/fry_parity_check.py：真实模型清单 tools/fry_parity_models.json，逐张逐字节；--parity none 明确跳过）
    ③g ★412 验收包在 WSL 真 Linux 里完整跑一遍（tools/fry_kit_check.py：Mac 上跑的就是同一个 run_on_target.sh；含反向篡改）
    ③h 打交付目录（tools/fry_delivery_bundle.py）→ ★412 打完在 WSL 里站在同事角度复验整包（tools/fry_bundle_check.py：
       解开 zip → 校验 → 直接跑 → 3 个示例照说明重出、逐字节比）；不过 ⇒ 目录挪进 _作废/、不记版本号
  ★449 ③i --deliver-variant <关键词>：全部通过后交付进算法仓，但**新增一份**而不是覆盖：
       _bin/<平台>_<YYMMDD_HHMM>_<关键词>/（时间戳 = 全交付目录名开头那段，一眼对得上），原先的 _bin/<平台>/ 不动
       （tools/fry_deliver.py --variant；交付前后核对原 dll 的 sha256）。--bundle-topic 里可写 {version}。

【★412 版本号自动定升哪一位】（tools/fry_surface.py；--bump auto 默认）
  同步之后、编译之前，从源码解析对外接口面（C 接口 / 参数 / 命令行）+ 算法指纹 + 外壳指纹，与上一次交付的记录比：
  删了 / 改了 → 主版本（0.x 期间升次版本，SemVer §4）｜ 加了 / 算法指纹变了 → 次版本 ｜ 只有实现 / 文档 → 修订号。
  出包之后再用产物（库自报参数表 / 真跑 --help / 库导出表）量一遍接口面，与源码解析不一致就报错（尺子自己也要有尺子）。
  判定写进 out/version_decision.json；1.0.0 不会自动出现 —— 要人决定：显式 --bump major（0.x → 1.0.0）或手给 --version 1.0.0。

【用法】
  python tools/fry_release.py --algo-repo <算法仓>                         本地出包（最常用）
  python tools/fry_release.py --algo-repo <算法仓> --linux both --mac-kit   ★409 Windows + Linux 两种 + macOS 验收包
  python tools/fry_release.py --algo-repo <算法仓> --bundle                 ★410 三平台 + 全交付目录（给同事的一整包）
  python tools/fry_release.py --algo-repo <算法仓> --tag v0.2.0 --push     出包 + 发正式版（仅 gitlab.com 独立模式）
  python tools/fry_release.py --algo-repo <算法仓> --bundle --bundle-topic "水转印统一引擎HE500-510-520_v{version}_三平台交付" \
         --deliver-variant wt_unified                                       ★449 三平台交付 + 新增一份 dll 进算法仓（Windows 上可双击 tools/fry_oneclick_release.bat）
"""
from __future__ import annotations

import argparse
import contextlib
import io
import json
import os
import re
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO / "tools"))
import fry_build    # noqa: E402
import fry_payload  # noqa: E402
import fry_delivery_version as DV  # noqa: E402   ★411 交付版本号（0.1.0 起每次交付递增，记录进 git）
import fry_surface as SF  # noqa: E402            ★412 对外接口面 → 该升哪一位

TAG_RE = re.compile(r"^v\d+\.\d+\.\d+(-[0-9A-Za-z.\-]+)?$")
LINUX_MODES = ("none", "native", "prebuilt", "both")
MAC_KIT_TARGETS = ("macos-arm64", "macos-x64")
ALL_CROSS = ("linux-x64", "linux-arm64", "macos-arm64", "macos-x64")


def bundle_plan(linux: str, mac_kit: bool, bundle: bool, cross: str = "none") -> Dict[str, Any]:
    """★410 --bundle = 「给同事的三平台全交付」（纯函数）：返回这次真正要跑的 linux 模式 / 是否出验收包 / 交叉编哪些 /
    验收包带哪些目标 / 交付目录里放哪种 Linux 包（none = 不打交付目录）。
    · 没点 Linux 就补 prebuilt；**交付目录只放一个 Linux 包**：有 prebuilt 就放 prebuilt（实测 glibc ≥ 2.17 就能加载），
      native 只当本机对照（WSL 里 Debian 13 编的，实测要 glibc ≥ 2.38 —— RHEL 9 / Ubuntu 22.04 都加载不了）；
    · 交叉编全部四个目标、验收包带全部（静态闸已过的）目标 ⇒ 同一个验收包也能拿到同事的 Linux 服务器上验。"""
    if not bundle:      # ★411 交叉编了全部目标又要验收包 ⇒ 验收包也带全部（与 --bundle 同一口径，之后单独打交付目录也过得了闸）
        return {"linux_str": linux, "mac_kit_bool": mac_kit, "bundle_linux_str": "none", "cross_str": cross,
                "kit_target_str": "auto" if (mac_kit and cross == "all") else ",".join(MAC_KIT_TARGETS)}
    linux = "prebuilt" if linux == "none" else linux
    return {"linux_str": linux, "mac_kit_bool": True, "bundle_linux_str": "native" if linux == "native" else "prebuilt",
            "cross_str": "all", "kit_target_str": "auto"}


def current_facts(repo: Optional[Path] = None, lock: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """★412 这次要出的包的「对外事实」（出包**前**就能算）：算法指纹（锁文件）、外壳指纹（源码）、对外接口面（源码解析）。"""
    repo = repo or REPO
    lock = lock or json.loads((repo / "cpp.lock.json").read_text(encoding="utf-8"))
    return {"algorithm_fingerprint_str": lock.get("tree_sha256_str", ""), "wrapper_sha256_str": fry_build.wrapper_fingerprint(repo),
            "surface_dict": SF.source_surface(repo)}


def decide_bump(bump: str, state: Dict[str, Any], facts: Dict[str, Any]) -> tuple:
    """★412 这次升哪一位（返回 (patch|minor|major, 判定详情)）：auto = 按接口面 + 两个指纹与上一次交付比（SemVer；0.x 期间
    不兼容改动升次版本）；显式给的就用给的，但仍然算出「至少该升哪一位」—— 不够就拒绝（交付闸也会再查一遍）。"""
    last = DV.last_version(state)
    req = SF.required_bump(DV.last_record(state), dict(facts, version_str="(这一次)"))
    need, note = SF.effective_level(req["level_str"], last) if req["level_str"] != "unknown" else ("unknown", "")
    info = {"requested_str": bump, "required_dict": req, "required_level_str": need, "zero_rule_note_str": note, "last_version_str": last}
    if bump == "auto":
        if need == "unknown":
            raise RuntimeError("；".join(req["reasons_list"]) + "（例：--bump minor）")
        return need, dict(info, level_str=need)
    order = {"patch": 1, "minor": 2, "major": 3}
    if need != "unknown" and order[bump] < order[need]:
        raise RuntimeError("--bump %s 不够：这一版至少要升%s —— %s%s" % (
            bump, {"minor": "次版本", "major": "主版本"}[need], "；".join(req["reasons_list"]), "（%s）" % note if note else ""))
    return bump, dict(info, level_str=bump)


def resolve_version(version: Optional[str], tag: Optional[str], bundle: bool, bump: str = "patch",
                    repo: Optional[Path] = None, stamp: bool = True) -> tuple:
    """★411 这次出包用哪个版本号（返回 (版本号, 是否给 CHANGELOG 分了节)）。
    · 发正式版：取 tag（去掉 v），并且必须大于已交付的最大版本号（否则同事手上的「新版」号码反而更小）；
    · 交付（--bundle 或 --version auto）：没给版本号 = 下一个交付版本号，出包前把 CHANGELOG「未发布」挪到这个版本号下；
      显式给的必须是 X.Y.Z 且大于已交付的最大版本号；
    · 其余：给什么用什么，都不给 = 0.0.0-dev（本地调试构建，交付工具会拒收）。"""
    if bump == "auto":
        raise ValueError("resolve_version 要的是具体的位（patch / minor / major）：auto 先用 decide_bump 定")
    state = DV.load(repo)
    last = DV.last_version(state)
    delivered = {d.get("version_str") for d in state.get("deliveries_list", [])}
    if tag:
        v = version or tag[1:]
        if DV.parse(v) and last and DV.parse(v) <= DV.parse(last):
            raise RuntimeError("正式版号 %s 不大于已交付的 %s —— 同事手上已经有 %s，换一个更大的版本号" % (v, last, last))
        # 正式版同时出全交付目录：一样要给 CHANGELOG 分节（交付目录的「本版变更」取这一节）；只发版不交付就不动 CHANGELOG
        changed = DV.stamp_changelog(v, DV.today(), (repo or REPO) / "CHANGELOG.md", delivered) if (stamp and bundle and DV.parse(v)) else False
        return v, changed
    if bundle or version == "auto":
        v = DV.next_version(state, bump) if version in (None, "auto") else version
        if not DV.parse(v):
            raise RuntimeError("交付版本号必须是 X.Y.Z（纯数字三段），收到 %r；不给就自动取下一个（%s）" % (v, DV.next_version(state, bump)))
        if last and DV.parse(v) <= DV.parse(last):
            raise RuntimeError("交付版本号只能递增：已交付到 %s，这次给的是 %s（不给就自动取 %s）" % (last, v, DV.next_version(state, bump)))
        changed = DV.stamp_changelog(v, DV.today(), (repo or REPO) / "CHANGELOG.md", delivered) if stamp else False
        return v, changed
    return version or "0.0.0-dev", False


def preflight_problems(parity: str, parity_config: Path) -> List[str]:
    """★412 --bundle 一跑十几分钟；一开始就能查的先查，免得编完才发现：一致性复核的模型清单（目录在不在、个数对不对）、WSL。"""
    probs: List[str] = []
    if parity != "none":
        import fry_parity_check as PC
        probs += ["一致性复核：" + p for p in PC.load_models(parity_config)["problems_list"]]
        if probs:
            probs[-1] += "（清单是本机路径：换机器改 %s，或这一版明确不做 --parity none）" % parity_config.name
    import fry_wsl
    if not fry_wsl.distro():
        probs.append("本机没有可用的 WSL 发行版 —— Linux 出包、验收包实测、同事角度复验都要在真 Linux 里跑")
    return probs


def cross_targets_for(cross: str, linux: str, mac_kit: bool) -> List[str]:
    """★409 这次要交叉编哪些目标（纯函数）：探针 + Linux prebuilt 要的 linux-x64 + 验收包要的两个 macOS，并成**一次**编。"""
    want: List[str] = []
    if cross and cross != "none":
        want += list(ALL_CROSS) if cross == "all" else [t.strip() for t in cross.split(",") if t.strip()]
    if linux in ("prebuilt", "both"):
        want.append("linux-x64")
    if mac_kit:
        want += list(MAC_KIT_TARGETS)
    return [t for t in ALL_CROSS if t in want] + sorted(t for t in set(want) if t not in ALL_CROSS)


def say(text: str) -> None:
    print("★ " + text, flush=True)


def git(*args: str, check: bool = True) -> subprocess.CompletedProcess:
    """git 命令；撞上自动提交程序正持有的 index.lock 时稍等重试（最多 10 次）。"""
    for attempt in range(10):
        r = subprocess.run(["git", "-C", str(REPO), *args], capture_output=True, text=True,
                           encoding="utf-8", errors="replace")
        if r.returncode == 0 or "index.lock" not in (r.stderr or ""):
            break
        time.sleep(1.0 + attempt)
    if check and r.returncode != 0:
        raise RuntimeError("git %s 失败：%s" % (" ".join(args), (r.stderr or r.stdout).strip()[:500]))
    return r


def run_step(cmd: List[str]) -> int:
    print("$ " + " ".join(cmd), flush=True)
    return subprocess.run(cmd, cwd=str(REPO), env=dict(os.environ, PYTHONIOENCODING="utf-8")).returncode


def silent(fn, *args) -> int:
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        rc = fn(*args)
    print(buf.getvalue(), end="", flush=True)
    return rc


def active_ci_mode(repo: Path) -> str:
    """仓根 .gitlab-ci.yml 是哪种模式：include 了 shared/ci-templates = internal（内网 OPS-0027）；否则 standalone；没有文件 = missing。"""
    path = repo / ".gitlab-ci.yml"
    if not path.is_file():
        return "missing"
    text = path.read_text(encoding="utf-8", errors="replace")
    return "internal" if re.search(r"^\s*-\s*project:\s*shared/ci-templates\s*$", text, flags=re.M) else "standalone"


def manual_tag_refusal(mode: str, tag: Optional[str], force: bool) -> str:
    """★388 内网模式下本地手工打 tag 要拒绝（返回原因；空串 = 放行）。纯函数，界面按钮与命令行共用这一个判据。"""
    if mode != "internal" or not tag or force:
        return ""
    return ("仓根 CI 已是内网模式（OPS-0027）：正式版请在 GitLab 网页上，找**点过 package:trigger、整条绿了**的那条 main 流水线点 "
            "release:tag —— 版本号由模板按提交记录算、打 tag 前会查整条流水线全绿；本地手工打 %s 会绕过这两道闸。"
            "本地出包 + 冒烟照常可用（去掉 --tag）；确要强发（OPS-0027 留的逃生口）加 --force-manual-tag" % tag)


def do_tag(tag: str, push: bool, built_fingerprint: str, algo_commit: str) -> Dict[str, Any]:
    if not TAG_RE.match(tag):
        raise RuntimeError("tag %r 不是 vX.Y.Z[-预发布] 格式" % tag)
    if git("tag", "--list", tag).stdout.strip():
        raise RuntimeError("本地已经有 tag %s —— 正式 tag 不可移动，换一个版本号" % tag)
    if push:
        remote = git("ls-remote", "--tags", "origin", "refs/tags/%s" % tag, check=False)
        if remote.returncode != 0:
            raise RuntimeError("连不上远端 origin：%s" % (remote.stderr or "").strip()[:300])
        if remote.stdout.strip():
            raise RuntimeError("远端已经有 tag %s —— 正式 tag 不可移动，换一个版本号" % tag)

    git("add", "-A")
    staged = git("diff", "--cached", "--name-only").stdout.split()
    if staged:
        msg = "build: 同步算法载荷 %s（指纹 %s）" % (algo_commit[:12] or "?", built_fingerprint[:16])
        git("commit", "-m", msg)
        say("已提交 %d 个文件：%s" % (len(staged), msg))
    head = git("rev-parse", "HEAD").stdout.strip()
    # ★★ 核对：将要被打 tag 的 commit 里，载荷指纹就是刚才冒烟通过的那一份
    lock_in_head = json.loads(git("show", "%s:cpp.lock.json" % head).stdout)
    if lock_in_head.get("tree_sha256_str") != built_fingerprint:
        raise RuntimeError("HEAD(%s) 里的载荷指纹 %s ≠ 刚出包的指纹 %s —— 拒绝打 tag（否则 CI 会用旧算法出新版本号的包）"
                           % (head[:12], str(lock_in_head.get("tree_sha256_str"))[:16], built_fingerprint[:16]))
    git("tag", "-a", tag, "-m", "fry-halftone %s（算法 %s，指纹 %s）" % (tag, algo_commit[:12], built_fingerprint[:16]))
    say("已打 tag %s → commit %s（载荷指纹核对一致）" % (tag, head[:12]))
    pushed = False
    if push:
        git("push", "origin", "HEAD")
        git("push", "origin", tag)
        remote = git("ls-remote", "--tags", "origin", "refs/tags/%s" % tag).stdout.strip()
        if not remote:
            raise RuntimeError("推送后远端仍看不到 tag %s" % tag)
        pushed = True
        say("已推送 %s ⇒ GitLab 会自动起流水线出三平台正式版（Build → Pipelines 里看）" % tag)
    return {"tag_str": tag, "commit_str": head, "pushed_bool": pushed}


def variant_stamp(bundle_dir_str: str, now: Optional[time.struct_time] = None) -> str:
    """★449 变体 dll 目录的时间戳：有全交付目录就取它名字开头的 _YYMMDD_HHMM_（两者一眼对得上），没有就取现在。"""
    name = re.split(r"[\\/]", bundle_dir_str.rstrip("\\/"))[-1] if bundle_dir_str else ""   # 两种分隔符都认（日志里的路径可能来自另一平台）
    m = re.match(r"^_(\d{6}_\d{4})_", name)
    return m.group(1) if m else time.strftime("%y%m%d_%H%M", now or time.localtime())


def main(argv: Optional[List[str]] = None) -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    ap = argparse.ArgumentParser(description="算法改完后一键重新出包（可选发版）")
    ap.add_argument("--algo-repo", required=True, help="算法仓根目录（里面有 fry_project_components_cpp/）")
    ap.add_argument("--python", default=sys.executable, help="跑出包脚本的 Python（384 起只用标准库）")
    ap.add_argument("--version", default=None,
                    help="出包的版本号；给了 --tag 时默认取 tag 去掉 v；★411 auto = 下一个交付版本号（--bundle 时默认就是 auto）；"
                         "都不给 = 0.0.0-dev（本地调试构建，不许交付）")
    ap.add_argument("--bump", choices=("auto", "patch", "minor", "major"), default="auto",
                    help="★412 交付时升哪一位：auto（默认：按对外接口面 + 两个指纹与上一次交付比，SemVer；0.x 期间不兼容改动升次版本）"
                         "｜ patch ｜ minor ｜ major（显式给的不够「至少该升的位」会被拒）")
    ap.add_argument("--parity", choices=("auto", "none"), default="auto",
                    help="★412 --bundle 时的跨平台一致性复核：auto（默认，按 --parity-config 的真实模型跑）｜ none（明确跳过，交付说明会写「没做」）")
    ap.add_argument("--parity-config", default=str(REPO / "tools" / "fry_parity_models.json"),
                    help="★412 一致性复核的模型清单（目录 + 期望个数）")
    ap.add_argument("--sync", choices=("auto", "always", "never"), default="auto",
                    help="auto=算法有变化才同步（默认）｜always=强制同步｜never=用现有载荷")
    ap.add_argument("--tag", default=None, help="发正式版：打这个 tag（如 v0.2.0）")
    ap.add_argument("--push", action="store_true", help="把提交和 tag 推到远端（触发 CI）")
    ap.add_argument("--force-manual-tag", action="store_true",
                    help="★388 内网模式下仍要本地手工打 tag（OPS-0027 的逃生口；平时应在 GitLab 上点 release:tag）")
    ap.add_argument("--result-json", default=None, help="结论写到这里（界面用）")
    # ★394 顺手出跨平台产物：**交叉编译只当编译探针**，产物标 verified_on_target=false，不进正式交付
    ap.add_argument("--cross", default="none",
                    help="none（默认）/ linux-x64 / macos-arm64 / all —— 在本机交叉编译看看 Linux/macOS 编不编得过")
    ap.add_argument("--linux", choices=LINUX_MODES, default="none",
                    help="★409 同时出 Linux 包（WSL2/Docker 里真跑 golden ⇒ 可交付）：native / prebuilt / both")
    ap.add_argument("--mac-kit", action="store_true",
                    help="★409 交叉编 macOS arm64+x64 并打目标机验收包（不是交付件：拷到 Mac 上一条命令验收出包）")
    ap.add_argument("--bundle", action="store_true",
                    help="★410 出齐三平台后放进 out/全交付目录/_YYMMDD_HHMM_<主题>/（隐含 --mac-kit；没给 --linux 就用 prebuilt）")
    ap.add_argument("--bundle-topic", default=None, help="★410 交付目录名里的主题词（默认 水转印加网SDK_v<版本>_三平台交付）；"
                                                          "★449 可写 {version} 占位（换成这次的版本号）")
    ap.add_argument("--deliver-variant", default="",
                    help="★449 全部通过后顺手交付进算法仓、但**不动原先的 dll**：_bin/<平台>_<YYMMDD_HHMM>_<关键词>/"
                         "（时间戳与全交付目录相同；关键词只许 ASCII）")
    ns = ap.parse_args(argv)
    plan = bundle_plan(ns.linux, ns.mac_kit, ns.bundle, ns.cross)
    ns.linux, ns.mac_kit, ns.cross = plan["linux_str"], plan["mac_kit_bool"], plan["cross_str"]
    t0 = time.perf_counter()
    result: Dict[str, Any] = {"ok_bool": False, "message_str": "", "key_output_dict": {}}
    key = result["key_output_dict"]
    rc = 1
    try:
        algo = Path(ns.algo_repo).resolve()
        if ns.push and not ns.tag:
            raise RuntimeError("--push 只和 --tag 一起用（普通出包是本地的事，不推送任何东西）")
        refusal = manual_tag_refusal(active_ci_mode(REPO), ns.tag, ns.force_manual_tag)
        if refusal:                                     # ★388 放在同步 / 出包之前：不白跑几十秒再拒绝
            raise RuntimeError(refusal)
        if plan["bundle_linux_str"] != "none":          # ★412 同理：一致性清单 / WSL 不在，一开始就说
            pre = preflight_problems(ns.parity, Path(ns.parity_config))
            if pre:
                raise RuntimeError("出包前自检没过（免得编完十几分钟才发现）：" + "；".join(pre))
        say("① 查：算法仓 %s 与上次同步的载荷差多少" % algo)
        st = silent(fry_payload.do_status, algo)
        if st == 2:
            raise RuntimeError("算法仓路径不对：%s" % algo)
        changed = (st == 3)
        key["algo_changed_bool"] = changed

        do_sync = ns.sync == "always" or (ns.sync == "auto" and changed)
        say("② 同步：%s" % ("需要（算法有变化）" if changed and ns.sync == "auto" else
                          "强制同步" if ns.sync == "always" else
                          "跳过（--sync never）" if ns.sync == "never" else "跳过（算法没有变化）"))
        if do_sync and silent(fry_payload.do_sync, algo) != 0:
            raise RuntimeError("同步载荷失败")
        key["synced_bool"] = do_sync
        lock = fry_payload.load_lock()
        key["fingerprint_str"] = lock["tree_sha256_str"]
        key["algo_commit_str"] = lock.get("source_dict", {}).get("commit_str", "")

        # ★412 版本号放在同步之后定：升哪一位取决于这一版的算法指纹（同步可能改它）、外壳指纹、对外接口面
        facts = current_facts(REPO, lock)
        state = DV.load()
        delivering = bool(ns.bundle or ns.version == "auto" or ns.tag)
        if ns.tag:                                        # 正式版的号由 tag 定：不「定」，但要过「升的位够不够」这道闸
            req = SF.required_bump(DV.last_record(state), dict(facts, version_str="(这一次)"))
            level, decision = "patch", {"requested_str": "tag", "required_dict": req, "last_version_str": DV.last_version(state),
                                        "zero_rule_note_str": ""}
        elif delivering:
            level, decision = decide_bump(ns.bump, state, facts)
        else:
            level, decision = "patch", {}
        version, stamped = resolve_version(ns.version, ns.tag, ns.bundle, level)
        if ns.tag:
            bad = SF.bump_problems(DV.last_version(state), version, decision["required_dict"]) if DV.parse(version) else []
            if bad:
                raise RuntimeError("；".join(bad))
            level = SF.bump_level(DV.last_version(state), version) if DV.parse(version) else "patch"
        key["delivery_version_str"] = version
        if delivering:
            decision["version_str"] = version
            key["version_decision_dict"] = decision
            (REPO / "out").mkdir(exist_ok=True)
            (REPO / "out" / "version_decision.json").write_text(json.dumps(dict(decision, facts_dict=facts), ensure_ascii=False, indent=1),
                                                                encoding="utf-8")
            say("★412 版本号 %s（上次交付 %s）：升%s —— %s%s" % (
                version, decision.get("last_version_str") or "无",
                {"patch": "修订号", "minor": "次版本", "major": "主版本", "first": "（首个编号版）", "none": "（同号）"}.get(level, level),
                "；".join(decision["required_dict"]["reasons_list"]),
                "（%s）" % decision["zero_rule_note_str"] if decision.get("zero_rule_note_str") else ""))
        if stamped:
            say("★411 CHANGELOG「未发布」已挪到「## %s」下" % version)

        say("③ 出包：版本 %s（五步流水线：载荷闸 → 编译 → 装配 → 冒烟含 golden 逐字节 → 打包）" % version)
        build_rc = run_step([ns.python, str(REPO / "tools" / "fry_build.py"), "--version", version])
        if build_rc != 0:
            raise RuntimeError("出包失败（fry_build.py 返回码 %d）—— 看上面的日志" % build_rc)
        row = fry_build.plat()
        ext = ".zip" if row["archive"] == "zip" else ".tar.zst"
        archive = REPO / "out" / ("%s-%s-%s%s" % (fry_build.PACKAGE_NAME, version, row["tag"], ext))
        if not archive.is_file():
            raise RuntimeError("出包说成功了，但找不到产物 %s" % archive)
        sdk_dir = REPO / "out" / "sdk" / "fry-halftone-sdk"
        info = json.loads((sdk_dir / "sdk_info.json").read_text(encoding="utf-8"))
        key.update({"version_str": version, "archive_path_str": str(archive),
                    "archive_mb_float": round(archive.stat().st_size / 1048576.0, 1),
                    "sdk_dir_str": str(sdk_dir), "platform_str": row["tag"],
                    # ★387 界面上能直接看到：这次包里 dll 的 sha256、参数说明文件在哪、几个参数
                    "library_sha256_str": info.get("library_sha256_str", ""), "param_count_int": info.get("param_count_int", 0),
                    "params_doc_path_str": str(sdk_dir / info["params_doc_file_str"]) if info.get("params_doc_file_str") else ""})
        if delivering:
            # ★412 两把尺子：出包前从源码解析的对外接口面（版本号就是按它定的）= 刚出的包
            #   （库自报参数表 + 真跑 --help + 库的导出表：冒烟的导出面闸已证明「导出表 = 头文件里的名字」，这里只取它的结论）
            cli_exe = sdk_dir / "bin" / ("fry-halftone-cli" + (".exe" if os.name == "nt" else ""))
            built = {"params_list": SF.params_from_schema(json.loads((sdk_dir / "params_schema.json").read_text(encoding="utf-8")))}
            if cli_exe.is_file():
                built["cli_list"] = SF.cli_from_help(subprocess.run([str(cli_exe), "--help"], capture_output=True).stdout.decode("utf-8", "replace"))
            smoke = json.loads((REPO / "out" / "build_report.json").read_text(encoding="utf-8")).get("smoke_dict") or {}
            if str(smoke.get("export_surface_str", "")).startswith("ok_"):
                built["api_names_list"] = fry_build.header_api_names()
            bad = SF.surface_mismatch(facts["surface_dict"], built)
            if bad:
                raise RuntimeError("出包前定版本号用的接口面与刚出的包对不上（版本号可能定错了）：%s" % "；".join(bad))
            key["surface_checked_list"] = sorted(built)
            say("★412 接口面两把尺子一致：源码解析 = 产物（%s）" % "、".join(
                {"params_list": "库自报参数表", "cli_list": "真跑 --help", "api_names_list": "库导出表"}[k] for k in sorted(built)))

        targets = cross_targets_for(ns.cross, ns.linux, ns.mac_kit)
        if targets:
            say("③b 交叉编译 %s（zig；★ 只证明「编得过 + 静态闸过」，**本身不是交付件**）" % ",".join(targets))
            cross_rc = run_step([ns.python, str(REPO / "tools" / "fry_cross_build.py"),
                                 "--target", ",".join(targets), "--version", version, "--install-toolchain"])
            key["cross_target_str"] = ",".join(targets)
            key["cross_ok_bool"] = (cross_rc == 0)
            key["cross_report_str"] = str(REPO / "out" / "cross" / "cross_info.json")
            key["cross_verified_on_target_bool"] = False          # ★ 永远是 false：本机跑不了目标平台的 golden
            if cross_rc != 0:
                say("   ⚠ 交叉编译没全过（返回码 %d）—— 看上面的日志；这**不影响** Windows 包是否可交付" % cross_rc)

        failed: List[str] = []
        for mode in (("native", "prebuilt") if ns.linux == "both" else (ns.linux,) if ns.linux != "none" else ()):
            say("③c Linux 真出包（%s）：在 WSL2 / Docker 的真 Linux 里跑同一套冒烟（golden 逐字节）" % mode)
            lrc = run_step([ns.python, str(REPO / "tools" / "fry_build_linux_native.py"), "--mode", mode, "--version", version])
            art = REPO / "out" / "linux" / mode / ("%s-%s-linux-x64.tar.zst" % (fry_build.PACKAGE_NAME, version))
            ok = lrc == 0 and art.is_file()
            key["linux_%s_ok_bool" % mode] = ok
            key["linux_%s_archive_str" % mode] = str(art) if ok else ""
            if not ok:
                failed.append("Linux %s（返回码 %d）" % (mode, lrc))
        if ns.mac_kit:
            say("③d macOS 目标机验收包（⚠ 不是交付件：拷到 Mac 上 bash run_on_target.sh 才出可交付包）")
            krc = run_step([ns.python, str(REPO / "tools" / "fry_target_kit.py"), "--target", plan["kit_target_str"]])
            kit = REPO / "out" / "kit" / ("%s-%s-verify-kit.tar.gz" % (fry_build.PACKAGE_NAME, version))
            ok = krc == 0 and kit.is_file()
            key["mac_kit_ok_bool"] = ok
            key["mac_kit_path_str"] = str(kit) if ok else ""
            key["mac_kit_verified_on_target_bool"] = False
            if not ok:
                failed.append("macOS 验收包（返回码 %d）" % krc)
        if failed:                                       # ★409 点名要的产物没出来 = 整次失败（探针除外）
            raise RuntimeError("Windows 包已出（%s），但这些没出来：%s —— 看上面的日志" % (archive.name, "、".join(failed)))
        if plan["bundle_linux_str"] != "none":
            say("③e 集成命令实测：交付说明里的每一条命令（C / Python / C# / 命令行）在 Windows 与 WSL 里原样真跑")
            integ_json = REPO / "out" / "integration_check.json"
            lin_arc = REPO / "out" / "linux" / plan["bundle_linux_str"].replace("both", "prebuilt") / (
                "%s-%s-linux-x64.tar.zst" % (fry_build.PACKAGE_NAME, version))
            irc = run_step([ns.python, str(REPO / "tools" / "fry_integration_check.py"), "--win-zip", str(archive),
                            "--linux-archive", str(lin_arc), "--version", version, "--out", str(integ_json)])
            if irc != 0:
                raise RuntimeError("交付说明里的集成命令没有全部跑通（返回码 %d，逐条结果 %s）—— 说明里的命令不能交出去" % (irc, integ_json))
            key["integration_check_str"] = str(integ_json)
            parity_jsons: List[Path] = []
            if ns.parity != "none":
                say("③f 跨平台一致性复核：交付的 Windows 包与 Linux 包，对真实模型逐张逐字节比（模型清单 %s）" % ns.parity_config)
                pdir = REPO / "out" / "parity"
                for old in pdir.glob("compare_e*.json") if pdir.is_dir() else []:
                    old.unlink()                           # 旧的比对结果不许混进这一版的证据
                linux_args: List[str] = []
                for mode in (("prebuilt", "native") if ns.linux == "both" else (ns.linux,)):
                    linux_args += ["--linux", "%s=%s" % (mode, REPO / "out" / "linux" / mode / (
                        "%s-%s-linux-x64.tar.zst" % (fry_build.PACKAGE_NAME, version)))]
                prc = run_step([ns.python, str(REPO / "tools" / "fry_parity_check.py"), "--win-zip", str(archive)] + linux_args
                               + ["--config", ns.parity_config, "--out-dir", str(pdir)])
                parity_jsons = sorted(pdir.glob("compare_e*.json"))
                if prc != 0 or not parity_jsons:
                    raise RuntimeError("跨平台一致性复核没过（返回码 %d，结果在 %s）—— 各平台切片不一致 / 模型清单不对，先查清楚；"
                                       "确定这一版不做就加 --parity none（交付说明会写明）" % (prc, pdir))
                key["parity_json_list"] = [str(p) for p in parity_jsons]
            else:
                say("③f 跨平台一致性复核：跳过（--parity none；交付说明会写明这一版没做）")
            say("③g 验收包在 WSL 真 Linux 里完整跑一遍（Mac 上跑的就是同一个 run_on_target.sh；含反向篡改）")
            kdir = REPO / "out" / "kit_check"
            kc = run_step([ns.python, str(REPO / "tools" / "fry_kit_check.py"), "--kit", key["mac_kit_path_str"], "--out-dir", str(kdir)])
            if kc != 0:
                raise RuntimeError("验收包在真 Linux 上没跑通（返回码 %d，结果在 %s）—— Mac 上也不会过，先修" % (kc, kdir))
            say("③h 全交付目录：三个平台的包（展开）+ 对接文档 + 3 个示例 + 验收证据 + 版本记录 → out/全交付目录/_YYMMDD_HHMM_<主题>/"
                "（打完在 WSL 里站在同事角度复验；不过就作废、不记版本号）")
            bundle_json = REPO / "out" / "bundle_result.json"
            cmd = [ns.python, str(REPO / "tools" / "fry_delivery_bundle.py"), "--linux", plan["bundle_linux_str"],
                   "--integration-json", str(integ_json), "--kit-linux-report", str(kdir / "kit_linux_build_report.json"),
                   "--colleague-check", "--result-json", str(bundle_json)]
            if parity_jsons:
                cmd += ["--parity-json"] + [str(p) for p in parity_jsons]
            if ns.bundle_topic:
                cmd += ["--topic", ns.bundle_topic.replace("{version}", version)]
            brc = run_step(cmd)
            bres = json.loads(bundle_json.read_text(encoding="utf-8")) if bundle_json.is_file() else {}
            if brc != 0 or not bres.get("ok_bool"):
                raise RuntimeError("三个平台都出了，但全交付目录没打成（返回码 %d）：%s" % (brc, bres.get("message_str", "看上面的日志")))
            key["bundle_dir_str"] = bres["dir_str"]
            key["bundle_file_count_int"] = bres.get("file_count_int", 0)
            key["colleague_check_ok_bool"] = (bres.get("colleague_check_dict") or {}).get("ok_bool") is True

        if ns.deliver_variant:
            stamp = variant_stamp(key.get("bundle_dir_str", ""))
            say("③i ★449 交付进算法仓（新增一份，原先的 dll 不动）：_bin/%s_%s_%s/" % (row["tag"], stamp, ns.deliver_variant))
            drc = run_step([ns.python, str(REPO / "tools" / "fry_deliver.py"), "--algo-repo", str(algo),
                            "--variant", ns.deliver_variant, "--stamp", stamp])
            if drc != 0:
                raise RuntimeError("包出好了，但交付进算法仓失败（返回码 %d）—— 看上面的日志" % drc)
            key["delivered_variant_dir_str"] = str(algo / "fry_project_components" / "HS200_halftone_dll" / "_bin" /
                                                   ("%s_%s_%s" % (row["tag"], stamp, ns.deliver_variant)))

        if ns.tag:
            say("④ 发版：tag %s%s" % (ns.tag, " + 推送" if ns.push else "（只打本地 tag，不推送）"))
            key.update(do_tag(ns.tag, ns.push, lock["tree_sha256_str"], key["algo_commit_str"]))
        else:
            say("④ 发版：跳过（没给 --tag；本地出包不会推送任何东西）")

        rc = 0
        result["ok_bool"] = True
        extra = "".join("；Linux %s 可交付 %s" % (m, Path(key["linux_%s_archive_str" % m]).name)
                        for m in ("native", "prebuilt") if key.get("linux_%s_ok_bool" % m))
        if key.get("mac_kit_ok_bool"):
            extra += "；macOS 验收包 %s（拷到 Mac 上 bash run_on_target.sh）" % Path(key["mac_kit_path_str"]).name
        if key.get("bundle_dir_str"):
            extra += "；全交付目录 %s（%d 个文件，先读 00_先读我_交付说明.md）" % (key["bundle_dir_str"], key["bundle_file_count_int"])
        if key.get("delivered_variant_dir_str"):
            extra += "；★已交付进算法仓 %s（原先的 dll 没动）" % key["delivered_variant_dir_str"]
        result["message_str"] = "出包成功 %s（%.1f MB，算法%s，指纹 %s，dll sha256 %s，参数说明 %d 个参数）%s%s" % (
            archive.name, key["archive_mb_float"], "有变化已同步" if do_sync else "无变化",
            key["fingerprint_str"][:12], (key["library_sha256_str"] or "（包里没写）")[:12], key["param_count_int"] or 0,
            extra, ("；已发版 %s" % ns.tag) if ns.tag else "")
        print("✓ " + result["message_str"], flush=True)
    except Exception as ex:                                             # noqa: BLE001
        result["message_str"] = "✗ %s" % ex
        print(result["message_str"], flush=True)
    result["rc_int"] = rc
    result["elapsed_s_float"] = round(time.perf_counter() - t0, 1)
    result["output_path_str"] = result["run_dir_str"] = str(REPO / "out")
    if ns.result_json:
        Path(ns.result_json).write_text(json.dumps(result, ensure_ascii=False, indent=1), encoding="utf-8")
    return rc


if __name__ == "__main__":
    raise SystemExit(main())
