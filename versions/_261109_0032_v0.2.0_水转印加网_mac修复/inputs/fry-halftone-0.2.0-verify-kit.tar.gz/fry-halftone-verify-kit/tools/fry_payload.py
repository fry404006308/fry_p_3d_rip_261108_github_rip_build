# -*- coding: utf-8 -*-
r"""fry_payload.py —— 算法载荷（C++ 源码 `cpp/`）的同步与校验。

【它解决什么问题】
  算法的**唯一真源**是算法仓 `fry_py_260604_c180_depth_dither_more/fry_project_components_cpp/`（★384 起是 C++ 版）；
  本仓（打包仓）只负责「把它编成 dll / so / dylib」。两个仓 ⇒ 载荷在这里必然是一份**副本**，
  副本不会自己更新，而且不报错 ⇒ 必须配闸：
  · `sync`   从算法仓拷一份进 `cpp/`，把**每个文件的 sha256** 与**算法仓的 commit** 写进 `cpp.lock.json`；
  · `check`  重新扫 `cpp/`，与锁文件逐个比对 —— 少一个 / 多一个 / 改一个字节都报红（CI 编译前先跑它）；
  · `status` 算法仓**现在**和上次同步差多少（要不要重新出包）；
  · `info`   打印锁文件摘要。

【★384 修的 CI 失败：换行符（CRLF / LF）】
  流水线 #2854243250 的 check 任务报「载荷被改 427 个」，其实**一个字节的代码都没改**：
  · 本机 git 设了 `core.autocrlf=true` ⇒ Windows 工作区里文本文件是 CRLF；锁文件的 sha256 就是按 CRLF 算的；
  · GitLab 的 Linux runner 检出是 LF ⇒ 同一个文件字节不同 ⇒ sha256 全不同 ⇒ 闸把「换行符不同」当成「被改」。
  ⇒ 根治两层：① 指纹按**规范化内容**算（文本文件 CRLF→LF 后再哈希，二进制原样）——指纹与检出方式无关；
               ② 仓库加 `.gitattributes`（文本一律 LF）——工作区本身也不再随机器变。
  ⚠ 只做 ② 不够：已经检出的工作区不会自己变，别人机器的 git 配置也管不到；只做 ① 也不够：打进 SDK 的源码仍随机器变。

【tree_sha256 是什么】把 `路径\0sha256\n` 按路径排序拼起来再做一次 sha256 —— 一句话指纹，编进 dll
  （`FryHalftone_GetAlgorithmFingerprint()`），拿到一个库就能回答「里面到底是哪一版算法」。

【用法】
  python tools/fry_payload.py sync   --source <算法仓根目录>
  python tools/fry_payload.py check
  python tools/fry_payload.py status --source <算法仓根目录>
  python tools/fry_payload.py info
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Tuple

REPO = Path(__file__).resolve().parents[1]
PAYLOAD_DIR = REPO / "cpp"
LOCK_PATH = REPO / "cpp.lock.json"
SCHEMA_STR = "fry-payload-lock/2"
SOURCE_SUBDIR_STR = "fry_project_components_cpp"

# ── 载荷口径（数据，不是一串 if）──────────────────────────────────────────────
# 文本文件：哈希前 CRLF→LF（★384 CI 修复）；同步时也按 LF 写出（仓库里只存一种换行）
TEXT_EXT_TUPLE: Tuple[str, ...] = (".h", ".hpp", ".c", ".cc", ".cpp", ".inc", ".txt", ".cmake", ".md")
TEXT_NAME_TUPLE: Tuple[str, ...] = ("CMakeLists.txt",)
BINARY_EXT_TUPLE: Tuple[str, ...] = ()
EXCLUDE_DIR_TUPLE: Tuple[str, ...] = ("build", "out", ".vs", ".vscode", "__pycache__", "cmake-build-debug", "cmake-build-release")
EOL_RULE_STR = "text files (%s): CRLF→LF before sha256; binaries raw" % " ".join(TEXT_EXT_TUPLE + TEXT_NAME_TUPLE)


def is_text(path: Path) -> bool:
    return path.name in TEXT_NAME_TUPLE or path.suffix.lower() in TEXT_EXT_TUPLE


def normalized_bytes(path: Path) -> bytes:
    data = path.read_bytes()
    return data.replace(b"\r\n", b"\n") if is_text(path) else data


def sha256_of(path: Path) -> str:
    return hashlib.sha256(normalized_bytes(path)).hexdigest()


def wanted(root: Path) -> List[Path]:
    """root 下所有该进载荷的文件（相对路径，按 posix 路径排序 —— 与文件系统遍历顺序无关）。"""
    out: List[Path] = []
    if not root.is_dir():
        return out
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = sorted(d for d in dirnames if d not in EXCLUDE_DIR_TUPLE and not d.startswith("."))
        for fn in sorted(filenames):
            p = Path(dirpath) / fn
            if is_text(p) or p.suffix.lower() in BINARY_EXT_TUPLE:
                out.append(p.relative_to(root))
    return sorted(out, key=lambda p: p.as_posix())


def scan(root: Path) -> Dict[str, str]:
    return {p.as_posix(): sha256_of(root / p) for p in wanted(root)}


def tree_sha256(files_dict: Dict[str, str]) -> str:
    h = hashlib.sha256()
    for k in sorted(files_dict):
        h.update(k.encode("utf-8"))
        h.update(b"\0")
        h.update(files_dict[k].encode("ascii"))
        h.update(b"\n")
    return h.hexdigest()


def git_facts(source: Path) -> Dict[str, Any]:
    """算法仓的 commit / 远端 / 是否有未提交改动 —— 拿不到就如实写空，绝不编。"""
    def run(*args: str) -> str:
        try:
            return subprocess.run(["git", "-C", str(source), *args], capture_output=True,
                                  text=True, encoding="utf-8", errors="replace", timeout=60).stdout.strip()
        except Exception:                                      # noqa: BLE001
            return ""
    status = run("status", "--porcelain", "--", SOURCE_SUBDIR_STR)
    return {"repo_url_str": run("remote", "get-url", "origin"),
            "commit_str": run("rev-parse", "HEAD"),
            "commit_time_str": run("log", "-1", "--format=%cI"),
            "branch_str": run("rev-parse", "--abbrev-ref", "HEAD"),
            "dirty_bool": bool(status)}


def source_dir(source: Path) -> Path:
    return source / SOURCE_SUBDIR_STR


def do_sync(source: Path) -> int:
    src_root = source_dir(source)
    if not (src_root / "CMakeLists.txt").is_file():
        print("✗ %s 里没有 %s/CMakeLists.txt —— --source 要指向算法仓的根目录" % (source, SOURCE_SUBDIR_STR))
        return 2
    rel_list = wanted(src_root)
    if PAYLOAD_DIR.exists():
        shutil.rmtree(PAYLOAD_DIR)
    total = 0
    for rel in rel_list:
        dst = PAYLOAD_DIR / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        data = normalized_bytes(src_root / rel)
        dst.write_bytes(data)
        total += len(data)
    files_dict = scan(PAYLOAD_DIR)
    lock = {"schema_str": SCHEMA_STR,
            "payload_kind_str": "cpp",
            "source_dict": dict(git_facts(source), path_str=str(source), subdir_str=SOURCE_SUBDIR_STR),
            "text_ext_list": list(TEXT_EXT_TUPLE), "text_name_list": list(TEXT_NAME_TUPLE),
            "exclude_dir_list": list(EXCLUDE_DIR_TUPLE), "eol_rule_str": EOL_RULE_STR,
            "synced_at_str": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
            "file_count_int": len(files_dict), "total_bytes_int": total,
            "tree_sha256_str": tree_sha256(files_dict), "files_dict": files_dict}
    LOCK_PATH.write_bytes((json.dumps(lock, ensure_ascii=False, indent=1) + "\n").encode("utf-8"))
    src = lock["source_dict"]
    print("✓ 同步完成：%d 个文件 / %.2f MB" % (len(files_dict), total / 1048576.0))
    print("  算法仓 commit : %s%s" % (src["commit_str"][:12] or "(不是 git 仓)",
                                   "  ⚠ 载荷目录有未提交改动" if src["dirty_bool"] else ""))
    print("  载荷指纹      : %s" % lock["tree_sha256_str"])
    if src["dirty_bool"]:
        print("  ⚠⚠ 算法仓的 %s 有未提交改动 ⇒ 这份载荷在算法仓里**找不到对应的 commit**；出正式版前请先提交干净。" % SOURCE_SUBDIR_STR)
    return 0


def load_lock() -> Dict[str, Any]:
    if not LOCK_PATH.is_file():
        raise SystemExit("✗ 缺 cpp.lock.json —— 先跑 `python tools/fry_payload.py sync --source <算法仓>`")
    lock = json.loads(LOCK_PATH.read_text(encoding="utf-8"))
    if lock.get("schema_str") != SCHEMA_STR:
        raise SystemExit("✗ 锁文件格式 %r 不认识（本工具认 %r）" % (lock.get("schema_str"), SCHEMA_STR))
    return lock


def do_check() -> int:
    lock = load_lock()
    want: Dict[str, str] = lock["files_dict"]
    got = scan(PAYLOAD_DIR)
    missing = sorted(set(want) - set(got))
    extra = sorted(set(got) - set(want))
    changed = sorted(k for k in set(want) & set(got) if want[k] != got[k])
    # ★ 报「通过」时必须同时报「查了多少个」——查了 0 个要算报红
    print("载荷闸：锁里 %d 个文件，工作区 %d 个（%s）" % (len(want), len(got), EOL_RULE_STR))
    if not want:
        print("✗ 锁文件里一个文件都没有 —— 查了 0 个不算通过")
        return 1
    for tag, rows in (("缺失", missing), ("多出", extra), ("被改", changed)):
        for r in rows[:20]:
            print("  ✗ %s：%s" % (tag, r))
        if len(rows) > 20:
            print("  ✗ %s：……另有 %d 个" % (tag, len(rows) - 20))
    if missing or extra or changed:
        print("✗ 载荷与 cpp.lock.json 不一致（缺 %d / 多 %d / 改 %d）" % (len(missing), len(extra), len(changed)))
        print("  改了算法就重新同步：python tools/fry_payload.py sync --source <算法仓>")
        return 1
    got_tree = tree_sha256(got)
    if got_tree != lock["tree_sha256_str"]:
        print("✗ 指纹不一致：锁 %s ≠ 实测 %s" % (lock["tree_sha256_str"], got_tree))
        return 1
    print("✓ 载荷闸通过：%d 个文件逐个 sha256 相同（换行符已规范化），指纹 %s" % (len(got), got_tree))
    return 0


def do_status(source: Path) -> int:
    """返回码：0 = 一致（不用重新同步）｜ 3 = 有差异（该重新同步 + 出包）｜ 2 = 路径不对。只读算法仓。"""
    src_root = source_dir(source)
    if not (src_root / "CMakeLists.txt").is_file():
        print("✗ %s 里没有 %s/" % (source, SOURCE_SUBDIR_STR))
        return 2
    lock = load_lock()
    want: Dict[str, str] = lock["files_dict"]
    got = scan(src_root)
    changed = sorted(k for k in set(want) & set(got) if want[k] != got[k])
    added, removed = sorted(set(got) - set(want)), sorted(set(want) - set(got))
    src = git_facts(source)
    print("算法仓 %s（commit %s%s）" % (source, src["commit_str"][:12] or "?", "，载荷目录有未提交改动" if src["dirty_bool"] else ""))
    print("上次同步：commit %s，%s" % (lock["source_dict"].get("commit_str", "")[:12] or "?", lock.get("synced_at_str")))
    for tag, rows in (("改", changed), ("增", added), ("删", removed)):
        for r in rows[:15]:
            print("  %s %s" % (tag, r))
        if len(rows) > 15:
            print("  %s ……另有 %d 个" % (tag, len(rows) - 15))
    if changed or added or removed:
        print("⇒ 算法有变化（改 %d / 增 %d / 删 %d）：需要重新同步并出包" % (len(changed), len(added), len(removed)))
        return 3
    print("⇒ 算法与上次同步完全一致（%d 个文件），不需要重新出包" % len(got))
    return 0


def do_info() -> int:
    lock = load_lock()
    src = lock["source_dict"]
    print("算法载荷（cpp/）")
    print("  来源仓库    : %s" % (src.get("repo_url_str") or "(未记录)"))
    print("  来源 commit : %s (%s)%s" % (src.get("commit_str", "")[:12] or "(未记录)", src.get("branch_str") or "?",
                                       "  ⚠ 同步时有未提交改动" if src.get("dirty_bool") else ""))
    print("  同步时间    : %s" % lock.get("synced_at_str"))
    print("  文件 / 体积 : %d 个 / %.2f MB" % (lock["file_count_int"], lock["total_bytes_int"] / 1048576.0))
    print("  载荷指纹    : %s" % lock["tree_sha256_str"])
    return 0


def main(argv: List[str] | None = None) -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    ap = argparse.ArgumentParser(description="算法载荷（C++）的同步与校验")
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("sync", help="从算法仓同步一份载荷并写锁文件")
    p.add_argument("--source", required=True, help="算法仓根目录（里面要有 fry_project_components_cpp/）")
    sub.add_parser("check", help="校验 cpp/ 与锁文件一致（CI 闸）")
    st = sub.add_parser("status", help="算法仓现在和上次同步的差多少（要不要重新出包）")
    st.add_argument("--source", required=True, help="算法仓根目录")
    sub.add_parser("info", help="打印锁文件摘要")
    ns = ap.parse_args(argv)
    if ns.cmd == "sync":
        return do_sync(Path(ns.source).resolve())
    if ns.cmd == "status":
        return do_status(Path(ns.source).resolve())
    return do_check() if ns.cmd == "check" else do_info()


if __name__ == "__main__":
    raise SystemExit(main())
