# -*- coding: utf-8 -*-
r"""fry_publish.py —— **独立模式**（gitlab.com 阶段）下把产物送进 Package Registry。

【它模仿的是内网 OPS-0027 模板的哪一段】`templates/release/publish.yml`：
  · 每个 build job **自己**把产物直传 registry，只留一份几百字节的「记账片段」；
  · 最后一个 publish job 收齐片段 → 生成 `manifest.json`（跨仓契约：文件名 / sha256 / 体积）→ 也传上去；
  · 打的是正式 tag 时再建一个 Release 页（人读的索引，链到 registry，自己不存文件）。
  ⚠ 为什么产物不经过 GitLab 的 job artifacts 中转：内网实例实测撞过 100 MB / 413；
    一个包 ~100 MB，中转一次就是一次失败机会。

【三个子命令】
  upload   --file <产物> --platform <win32-x64|linux-x64|darwin-arm64>   （build job 末尾调）
  manifest                                                             （publish job 调）
  release                                                              （publish job，tag 流水线才调）

全部只用标准库（urllib），认证一律用 CI 自带的 `CI_JOB_TOKEN` —— **仓库里不存任何密钥**。
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any, Dict, List

FRAG_DIR = Path(".ci-artifacts")


def env(name: str) -> str:
    val = os.environ.get(name, "")
    if not val:
        raise SystemExit("✗ 缺环境变量 %s —— 这个脚本只在 GitLab CI 里跑" % name)
    return val


def registry_url(file_name: str) -> str:
    return "%s/projects/%s/packages/generic/%s/%s/%s" % (
        env("CI_API_V4_URL"), env("CI_PROJECT_ID"), urllib.parse.quote(env("PACKAGE_NAME")),
        urllib.parse.quote(env("VERSION")), urllib.parse.quote(file_name))


def http(method: str, url: str, body: Any = None, headers: Dict[str, str] | None = None) -> bytes:
    hdrs = {"JOB-TOKEN": env("CI_JOB_TOKEN")}
    hdrs.update(headers or {})
    req = urllib.request.Request(url, data=body, method=method, headers=hdrs)
    try:
        with urllib.request.urlopen(req, timeout=1800) as resp:
            return resp.read()
    except urllib.error.HTTPError as ex:
        raise SystemExit("✗ %s %s → HTTP %d：%s" % (method, url, ex.code, ex.read()[:500].decode("utf-8", "replace")))


def sha256_of(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fp:
        for chunk in iter(lambda: fp.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def cmd_upload(file: Path, platform: str) -> int:
    if not file.is_file():
        raise SystemExit("✗ 产物不存在：%s" % file)
    size = file.stat().st_size
    digest = sha256_of(file)
    with open(file, "rb") as fp:
        http("PUT", registry_url(file.name), body=fp, headers={"Content-Length": str(size),
                                                               "Content-Type": "application/octet-stream"})
    FRAG_DIR.mkdir(exist_ok=True)
    frag = {"platform": platform, "file": file.name, "sha256": digest, "size": size}
    (FRAG_DIR / ("%s.json" % platform)).write_text(json.dumps(frag, ensure_ascii=False), encoding="utf-8")
    print("✓ 已上传 %s（%.1f MB，sha256 %s…）→ registry %s/%s" % (file.name, size / 1048576.0, digest[:16],
                                                                   env("PACKAGE_NAME"), env("VERSION")))
    return 0


def cmd_manifest() -> int:
    frags: List[Dict[str, Any]] = [json.loads(p.read_text(encoding="utf-8")) for p in sorted(FRAG_DIR.glob("*.json"))]
    # ★ 报通过时要报收了几个（算法仓 B.1-17）；一个平台都没收到 = 红
    if not frags:
        raise SystemExit("✗ 一个平台的记账片段都没收到 —— build job 都没跑成？")
    manifest = {"package": env("PACKAGE_NAME"), "version": env("VERSION"),
                "commit": os.environ.get("CI_COMMIT_SHA", ""), "pipeline": os.environ.get("CI_PIPELINE_ID", ""),
                "platforms": {f["platform"]: {k: f[k] for k in ("file", "sha256", "size")} for f in frags}}
    data = json.dumps(manifest, ensure_ascii=False, indent=1).encode("utf-8")
    Path("manifest.json").write_bytes(data)
    http("PUT", registry_url("manifest.json"), body=data, headers={"Content-Type": "application/json"})
    print("✓ manifest.json 已上传：%d 个平台 %s" % (len(frags), sorted(manifest["platforms"])))
    return 0


def cmd_release() -> int:
    tag = env("CI_COMMIT_TAG")
    manifest = json.loads(Path("manifest.json").read_text(encoding="utf-8"))
    links = [{"name": row["file"], "url": registry_url(row["file"]), "link_type": "package"}
             for row in manifest["platforms"].values()]
    links.append({"name": "manifest.json", "url": registry_url("manifest.json"), "link_type": "other"})
    lines = ["水转印加网 SDK %s" % env("VERSION"), "", "| 平台 | 文件 | sha256 | 体积 |", "| --- | --- | --- | --- |"]
    for plat, row in sorted(manifest["platforms"].items()):
        lines.append("| %s | %s | `%s` | %.1f MB |" % (plat, row["file"], row["sha256"], row["size"] / 1048576.0))
    body = {"tag_name": tag, "name": "fry-halftone %s" % env("VERSION"), "description": "\n".join(lines),
            "assets": {"links": links}}
    url = "%s/projects/%s/releases" % (env("CI_API_V4_URL"), env("CI_PROJECT_ID"))
    http("POST", url, body=json.dumps(body).encode("utf-8"), headers={"Content-Type": "application/json"})
    print("✓ Release 页已建：%s（%d 个下载链接）" % (tag, len(links)))
    return 0


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    up = sub.add_parser("upload")
    up.add_argument("--file", required=True)
    up.add_argument("--platform", required=True)
    sub.add_parser("manifest")
    sub.add_parser("release")
    ns = ap.parse_args()
    if ns.cmd == "upload":
        return cmd_upload(Path(ns.file), ns.platform)
    return cmd_manifest() if ns.cmd == "manifest" else cmd_release()


if __name__ == "__main__":
    raise SystemExit(main())
