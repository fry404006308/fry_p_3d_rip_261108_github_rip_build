# -*- coding: utf-8 -*-
r"""fry_version.py —— **独立模式**（gitlab.com 阶段）下版本号怎么算。

【为什么要有它】OPS-0027 的第一条铁律：**版本号由机器从 git tag 算出来，不许人在代码里改**。
  公司内网 GitLab 上，这件事由 `shared/ci-templates` 的 `version` job 做（resolve-version.mjs）；
  但现在仓库在 gitlab.com 上，够不着那份模板 ⇒ 这里用同一套口径做一个最小实现：

  | 触发                       | 版本号                               | 含义                     |
  | 推了 tag `v1.2.3`          | `1.2.3`                              | 正式版                   |
  | 推了 tag `v1.2.3-beta.1`   | `1.2.3-beta.1`                       | 内测版                   |
  | 普通提交的流水线            | `<下一版>-p<流水线号>.g<短 sha>`        | 候选包（验证用，不是发版）|
  | 本机（没有 CI 环境变量）     | `0.0.0-dev`                          | 占位值                   |
  「下一版」= 最近一个 `vX.Y.Z` tag 的修订号 +1；一个 tag 都没有时从 0.1.0 起。

  ⚠ 与内网模板的差别（照实说）：内网模板会按提交前缀（feat:/fix:/BREAKING）决定涨哪一位，
    这里一律只涨修订号 —— 要涨次版本/主版本就**直接打对应的 tag**。换到内网后以模板为准。

【用法】python tools/fry_version.py [--dotenv version.env]
"""
from __future__ import annotations

import argparse
import os
import re
import subprocess
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parents[1]
TAG_RE = re.compile(r"^v(\d+)\.(\d+)\.(\d+)(-[0-9A-Za-z.\-]+)?$")


def last_release_tag() -> str:
    try:
        out = subprocess.run(["git", "-C", str(REPO), "tag", "--list", "v*", "--sort=-v:refname"],
                             capture_output=True, text=True, timeout=30).stdout
    except Exception:                                                   # noqa: BLE001
        return ""
    for line in out.splitlines():
        m = TAG_RE.match(line.strip())
        if m and not m.group(4):                                         # 只认正式版 tag 做基准
            return line.strip()
    return ""


def compute(env: dict) -> str:
    tag = env.get("CI_COMMIT_TAG", "")
    if tag:
        m = TAG_RE.match(tag)
        if not m:
            raise SystemExit("✗ tag %r 不是 vX.Y.Z[-预发布] 格式 —— 版本号必须能从 tag 算出来" % tag)
        return tag[1:]
    if not env.get("CI"):
        return "0.0.0-dev"
    base = last_release_tag()
    if base:
        x, y, z = (int(v) for v in TAG_RE.match(base).groups()[:3])
        nxt = "%d.%d.%d" % (x, y, z + 1)
    else:
        nxt = "0.1.0"
    return "%s-p%s.g%s" % (nxt, env.get("CI_PIPELINE_ID", "0"), env.get("CI_COMMIT_SHORT_SHA", "unknown"))


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    ap = argparse.ArgumentParser()
    ap.add_argument("--dotenv", default=None, help="把 VERSION=… 写进这个文件（给 GitLab 的 dotenv 报告用）")
    ns = ap.parse_args()
    version = compute(dict(os.environ))
    print(version)
    if ns.dotenv:
        Path(ns.dotenv).write_text("VERSION=%s\n" % version, encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
