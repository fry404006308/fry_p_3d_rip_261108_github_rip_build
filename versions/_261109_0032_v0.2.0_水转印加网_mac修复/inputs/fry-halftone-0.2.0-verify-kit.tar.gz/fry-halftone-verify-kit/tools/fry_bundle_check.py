# -*- coding: utf-8 -*-
r"""fry_bundle_check.py —— ★412 站在「拿到整包 zip 的 Linux 同事」的角度，在 WSL 真 Linux 里验收最终交付目录（一键出包的最后一步）。

【为什么】交付目录里每一道闸都是在 Windows 上、按我们的方式核对的；同事是在他的系统上、按说明书的方式用的。
  411 在 WSL 里手动做过一次（算法仓 docs 411 的 c411_wsl_bundle_check.sh），412 并进一键出包：
    ① 解开整包 zip（有 unzip 用 unzip；没有就用 Python 按 zip 里记的 Unix 权限解 —— 与 unzip 行为一致）；
    ② 顶层 `sha256sum -c SHA256SUMS.txt` 全部 OK；
    ③ 展开的 Linux 命令行不用 chmod 就能跑，自报版本 = 这一版；
    ④ 包里 `python3 verify_delivery.py` 通过、包里 `sha256sum -c` 全部 OK；
    ⑤ 05_示例输出 的**每一个**示例：只拷模型（+ request.json）到空目录，照 bundle_manifest.json 里记的那条命令
       （= 示例说明里写给同事的那条，同一个函数生成）用 Linux 命令行出片，两把尺子：
         a. 出的 BMP 张数、全部拼起来的 md5 = 交付目录里这个示例的输出（Windows 出的，在 Linux 上用同一种方法算）；
         b. Linux 命令行自报的 bmpMd5 = 清单里记的 Windows 自报值（出包时已核对 = golden）。
【输出】<out-dir>/bundle_check.json（各项 + 逐示例 + ok_bool）+ 日志。不过 ⇒ fry_delivery_bundle 把这个交付目录挪进 _作废/、不记版本号。
用法：python tools/fry_bundle_check.py --zip out/全交付目录/<目录>.zip --version X.Y.Z --out-dir out/bundle_check
"""
from __future__ import annotations

import argparse
import json
import re
import shlex
import sys
import zipfile
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO / "tools"))
LINUX_DIR = "02_Linux_x64/fry-halftone"          # 交付目录里展开的 Linux 包
SAMPLES_DIR = "05_示例输出"


def samples_from_zip(zip_path: Path) -> Tuple[str, List[Dict[str, Any]]]:
    """从整包 zip 里读 bundle_manifest.json：交付目录名 + 示例清单（每个示例的模型、命令、Windows 自报的 bmpMd5）。"""
    with zipfile.ZipFile(zip_path) as zf:
        name = next(n for n in zf.namelist() if n.endswith("/bundle_manifest.json") and n.count("/") == 1)
        man = json.loads(zf.read(name).decode("utf-8"))
    return name.split("/", 1)[0], list(man.get("samples_list") or [])


def sample_lines(i: int, s: Dict[str, Any], out_wsl: str) -> List[str]:
    """一个示例：拷模型（+ request.json）到空目录 → 照清单里的命令出片 → 报张数 / md5 / 自报 md5（纯函数）。"""
    p = "S%d_" % i
    cmd = " ".join(shlex.quote(a) for a in s.get("command_list") or [])
    return [
        'S="$B/%s/%s"; T="$W/s%d"; mkdir -p "$T"' % (SAMPLES_DIR, s["key_str"], i),
        'cp "$S/%s" "$T/"; [ -f "$S/request.json" ] && cp "$S/request.json" "$T/"' % s["model_str"],
        '(cd "$T" && "$L/bin/fry-halftone-cli" %s) > "%s/sample%d.log" 2>"%s/sample%d_stderr.log"; echo "@@%sRC=$?"'
        % (cmd, out_wsl, i, out_wsl, i, p),
        'echo "@@%sN=$(ls "$T"/slices/*.bmp 2>/dev/null | wc -l)"' % p,
        'echo "@@%sWANT_N=$(ls "$S"/slices/*.bmp 2>/dev/null | wc -l)"' % p,
        # cat /dev/null 打头：一张都没出时 cat 不会去等标准输入
        'echo "@@%sMD5 $(cat /dev/null $(ls "$T"/slices/*.bmp 2>/dev/null) | md5sum | cut -c1-32)"' % p,
        'echo "@@%sWANT_MD5 $(cat /dev/null $(ls "$S"/slices/*.bmp 2>/dev/null) | md5sum | cut -c1-32)"' % p,
        'echo "@@%sSDK_MD5 $(grep -oE \'"bmpMd5" *: *"[0-9a-f]{32}"\' "%s/sample%d.log" | tail -1 | grep -oE \'[0-9a-f]{32}\')"'
        % (p, out_wsl, i),
    ]


def script_lines(zip_wsl: str, out_wsl: str, dir_name: str, samples: List[Dict[str, Any]]) -> List[str]:
    lines = [
        "#!/usr/bin/env bash", "set -u", 'W="$HOME/fry_bundle_check412"', 'rm -rf "$W" && mkdir -p "$W" && cd "$W"',
        'if command -v unzip >/dev/null 2>&1; then unzip -q "%s" && echo "@@UNZIP=system"; else' % zip_wsl,
        '  python3 - "%s" <<\'PY\'' % zip_wsl,
        "import os, sys, zipfile",
        "zf = zipfile.ZipFile(sys.argv[1])",
        "for zi in zf.infolist():",
        "    p = zf.extract(zi, '.')",
        "    mode = (zi.external_attr >> 16) & 0o777",
        "    if zi.create_system == 3 and mode:",
        "        os.chmod(p, mode)",
        "print('@@UNZIP=python')",
        "PY",
        "fi",
        'B="$W/%s"' % dir_name,
        '(cd "$B" && sha256sum -c --quiet SHA256SUMS.txt) > "%s/bundle_sums.log" 2>&1; echo "@@BUNDLE_SUMS_RC=$?"' % out_wsl,
        'echo "@@BUNDLE_SUMS_LINES=$(wc -l < "$B/SHA256SUMS.txt")"',
        'L="$B/%s"' % LINUX_DIR,
        '[ -x "$L/bin/fry-halftone-cli" ] && echo "@@CLI_EXEC=1" || echo "@@CLI_EXEC=0"',
        'echo "@@CLI_VERSION_TEXT $("$L/bin/fry-halftone-cli" --version)"',
        '(cd "$L" && python3 verify_delivery.py) > "%s/verify.log" 2>&1; echo "@@VERIFY_RC=$?"' % out_wsl,
        '(cd "$L" && sha256sum -c --quiet SHA256SUMS.txt) > "%s/package_sums.log" 2>&1; echo "@@PKG_SUMS_RC=$?"' % out_wsl,
    ]
    for i, s in enumerate(samples, 1):
        lines += sample_lines(i, s, out_wsl)
    return lines + ['cd / && rm -rf "$W"']


def parse(stdout: str) -> Dict[str, Any]:
    out: Dict[str, Any] = {k: int(v) for k, v in re.findall(r"^@@(\w+)=(-?\d+)$", stdout, flags=re.M)}
    for k, v in re.findall(r"^@@(\w+) (.*)$", stdout, flags=re.M):
        out[k] = v.strip()
    m = re.search(r"^@@UNZIP=(\w+)", stdout, flags=re.M)
    out["UNZIP"] = m.group(1) if m else ""
    return out


def verdict(m: Dict[str, Any], version: str, samples: List[Dict[str, Any]]) -> Dict[str, Any]:
    """判定（纯函数）。示例一个都没有 = 没验过 = 红（B.1-17：闸报通过必须同时报查了多少个，0 个算红）。"""
    rows = []
    for i, s in enumerate(samples, 1):
        p = "S%d_" % i
        n, md5, sdk = m.get(p + "N", 0), m.get(p + "MD5", ""), m.get(p + "SDK_MD5", "")
        row = {"key_str": s.get("key_str"), "rc_int": m.get(p + "RC"), "slices_int": n, "want_slices_int": m.get(p + "WANT_N"),
               "md5_str": md5, "want_md5_str": m.get(p + "WANT_MD5", ""), "sdk_md5_str": sdk, "want_sdk_md5_str": s.get("bmp_md5_str") or ""}
        row["files_match_bool"] = m.get(p + "RC") == 0 and n > 0 and n == m.get(p + "WANT_N") and bool(md5) and md5 == row["want_md5_str"]
        row["sdk_md5_match_bool"] = bool(sdk) and sdk == row["want_sdk_md5_str"]
        row["ok_bool"] = row["files_match_bool"] and row["sdk_md5_match_bool"]
        rows.append(row)
    checks = {"bundle_sums_ok_bool": m.get("BUNDLE_SUMS_RC") == 0 and m.get("BUNDLE_SUMS_LINES", 0) > 0,
              "cli_exec_ok_bool": m.get("CLI_EXEC") == 1 and m.get("CLI_VERSION_TEXT") == "fry-halftone-cli %s" % version,
              "verify_ok_bool": m.get("VERIFY_RC") == 0,
              "package_sums_ok_bool": m.get("PKG_SUMS_RC") == 0,
              "samples_match_bool": bool(rows) and all(r["ok_bool"] for r in rows)}
    return {**checks, "ok_bool": all(checks.values()), "samples_checked_int": len(rows), "samples_list": rows,
            "unzip_str": m.get("UNZIP", ""), "markers_dict": m}


def run(zip_path: Path, version: str, out_dir: Path) -> Dict[str, Any]:
    import fry_wsl as W
    out_dir.mkdir(parents=True, exist_ok=True)
    for old in list(out_dir.glob("sample*.log")) + [out_dir / n for n in ("bundle_check.json", "bundle_sums.log", "verify.log", "package_sums.log")]:
        old.unlink(missing_ok=True)                    # 上一次的结果不许冒充这一次
    dir_name, samples = samples_from_zip(zip_path)
    r = W.run_lines(script_lines(W.path(zip_path), W.path(out_dir), dir_name, samples), out_dir / "bundle_check.sh")
    res = verdict(parse(W.text(r.stdout)), version, samples)
    res.update({"zip_str": zip_path.name, "version_str": version, "wsl_rc_int": r.returncode})
    (out_dir / "bundle_check.json").write_text(json.dumps(res, ensure_ascii=False, indent=1), encoding="utf-8")
    print("%s 同事角度复验（WSL 真 Linux，解压方式 %s）：%s ｜ 示例 %d 个：%s" % (
        "✓" if res["ok_bool"] else "✗", res["unzip_str"] or "?",
        "、".join("%s %s" % (k.replace("_bool", ""), "✓" if v else "✗") for k, v in res.items()
                 if k.endswith("_bool") and k not in ("ok_bool", "samples_match_bool")),
        len(res["samples_list"]), "、".join("%s %s" % (s["key_str"], "✓" if s["ok_bool"] else "✗") for s in res["samples_list"]) or "无"),
        flush=True)
    return res


def main(argv: Optional[List[str]] = None) -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    ap = argparse.ArgumentParser(description="★412 同事角度复验：WSL 真 Linux 里解开整包、校验、直接跑、每个示例出片比对")
    ap.add_argument("--zip", required=True)
    ap.add_argument("--version", required=True)
    ap.add_argument("--out-dir", required=True)
    ns = ap.parse_args(argv)
    return 0 if run(Path(ns.zip), ns.version, Path(ns.out_dir))["ok_bool"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
