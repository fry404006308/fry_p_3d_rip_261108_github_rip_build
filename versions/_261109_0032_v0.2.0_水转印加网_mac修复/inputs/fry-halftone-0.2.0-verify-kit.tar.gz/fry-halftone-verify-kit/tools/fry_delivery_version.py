# -*- coding: utf-8 -*-
r"""fry_delivery_version.py —— ★411 交付版本号：0.1.0 起每次交付递增，记录进 git，CHANGELOG 按版本号分节。

【为什么】410 之前交出去的包都叫 0.0.0-dev：同事手上有两次交付就分不清哪个新、哪个旧（文件名、GetVersion()、
  dll 属性全一样）。⇒ 交付版一律 X.Y.Z，**只增不减**；每次交付记一行（版本 / 日期 / 目录 / 两个指纹 / 三个包的 sha256），
  记录文件 `delivery_versions.json` 放在打包仓根（进 git —— `out/` 不进 git，本机坏了记录不能跟着没）。

【规则】
  · 第一次交付 0.1.0（与 CI 的规则一致：一个正式 tag 都没有时从 0.1.0 起）；之后默认修订号 +1（--bump minor / major 可改）。
  · 0.0.0-dev = 本地调试构建（没指定版本号）：**不许交付**。
  · 同一个版本号只对应一批字节：版本号已经交付过 ⇒ 只有三个包的 sha256 与那次**逐个相同**才允许再出一次目录（同一批包补文档），否则拒绝。
  · 交付时把 CHANGELOG「## 未发布」下的内容挪到「## X.Y.Z（日期）」下（出包之前做 ⇒ 三个平台的包里都是分好节的那份）。
  · ⚠ 以后走 CI 正式版时，正式 tag 必须大于已交付的最大版本号（fry_release.py --tag 会查；内网模板自动算号时要人工确认）。
"""
from __future__ import annotations

import json
import re
import time
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

REPO = Path(__file__).resolve().parents[1]
STATE_NAME = "delivery_versions.json"
FIRST_VERSION = "0.1.0"
VERSION_RE = re.compile(r"^(\d+)\.(\d+)\.(\d+)$")
UNRELEASED = "## 未发布"
PLACEHOLDER = "（下一次交付的变更记在这里：交付时会自动挪到新版本号下面）"


def parse(version: str) -> Optional[Tuple[int, int, int]]:
    m = VERSION_RE.match(str(version or ""))
    return (int(m.group(1)), int(m.group(2)), int(m.group(3))) if m else None


def state_path(repo: Optional[Path] = None) -> Path:
    return (repo or REPO) / STATE_NAME


def load(repo: Optional[Path] = None) -> Dict[str, Any]:
    p = state_path(repo)
    if not p.is_file():
        return {"schema_str": "fry-halftone-deliveries/1", "deliveries_list": []}
    return json.loads(p.read_text(encoding="utf-8"))


def last_version(state: Dict[str, Any]) -> Optional[str]:
    vs = [d["version_str"] for d in state.get("deliveries_list", []) if parse(d.get("version_str", ""))]
    return max(vs, key=parse) if vs else None


def last_record(state: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """最大版本号的最后一条记录（同号重出目录时取最新那一行）；没有交付过 = None。"""
    last = last_version(state)
    recs = [d for d in state.get("deliveries_list", []) if d.get("version_str") == last]
    return recs[-1] if recs else None


def next_version(state: Dict[str, Any], bump: str = "patch") -> str:
    last = last_version(state)
    if last is None:
        return FIRST_VERSION
    a, b, c = parse(last)
    return {"major": "%d.0.0" % (a + 1), "minor": "%d.%d.0" % (a, b + 1)}.get(bump, "%d.%d.%d" % (a, b, c + 1))


def version_problems(version: str, packages_dict: Dict[str, str], state: Dict[str, Any]) -> List[str]:
    """交付版本号闸（纯函数）：格式 / 只增不减 / 同号同字节。空列表 = 放行。"""
    if not parse(version):
        return ["交付版本号必须是 X.Y.Z（纯数字三段），现在是 %r —— 0.0.0-dev 是本地调试构建，不许交付；"
                "用 python tools/fry_release.py --algo-repo <算法仓> --bundle（自动取下一个版本号 %s）重新出包"
                % (version, next_version(state))]
    last = last_version(state)
    if last and parse(version) < parse(last):
        return ["版本号只能递增：上次交付的是 %s，这次是 %s" % (last, version)]
    same = [d for d in state.get("deliveries_list", []) if d.get("version_str") == version]
    if same and same[-1].get("packages_dict") != packages_dict:
        return ["版本号 %s 已经交付过，而这次的包和那次不一样 —— 同一个版本号只能对应一批字节；用下一个版本号 %s 重新出包"
                % (version, next_version(state))]
    return []


def record(entry: Dict[str, Any], repo: Optional[Path] = None) -> Path:
    """交付成功后追加一行（进 git：打包仓的自动提交程序会提交它）。"""
    state = load(repo)
    state.setdefault("deliveries_list", []).append(entry)
    state["note_str"] = ("每次交付一行；版本号只增不减（0.1.0 起）；同一版本号只对应一批字节（packages_dict 是三个包的 sha256）。"
                         "由 tools/fry_delivery_bundle.py 写，不要手改。")
    p = state_path(repo)
    p.write_text(json.dumps(state, ensure_ascii=False, indent=1) + "\n", encoding="utf-8", newline="\n")
    return p


def _split(text: str) -> Tuple[str, str]:
    return ("\r\n", text.replace("\r\n", "\n")) if "\r\n" in text else ("\n", text)


def is_leftover_section(top: str, version: str, delivered: Optional[Iterable[str]]) -> bool:
    """★412 最上面那一节是不是「上次出包分了节、却没交付成」的残留（纯函数）：
    比已交付的最大版本号还大（一次都没交付过时：≥ 0.1.0）、又不是这次的号。delivered = None（调用方没说）⇒ 一律不算（不改号）。
    ⚠ 只认「比已交付的都大」：CHANGELOG 里 0.1.0 之前手写的旧节（如 0.0.9）比首个编号版还小，永远不会被改号。"""
    if delivered is None or top == version or not parse(top):
        return False
    vs = [parse(v) for v in delivered if parse(v)]
    return parse(top) > max(vs) if vs else parse(top) >= parse(FIRST_VERSION)


def stamp_changelog(version: str, date_str: str, path: Optional[Path] = None, delivered: Optional[Iterable[str]] = None) -> bool:
    """把「## 未发布」下的内容挪到「## X.Y.Z（日期）」下。返回是否改了文件。
    · 幂等：这一版已经分过节、未发布里只剩占位行 ⇒ 不动；
    · 这一版已经分过节（例如上次出包到一半失败、还没交付）而未发布里又记了新条目 ⇒ 并进这一节的开头（不许静默留在「未发布」）；
    · ★412 最上面那一节是上次没交付成的残留、又不是这次的号（例如上次按修订号分了 0.1.2 的节，出包中途失败；
      这次按接口面判定要升次版本 0.2.0）⇒ 把那一节**改号**成这次的号（否则 0.1.2 的条目永远挂在一个不存在的版本下）；
      delivered = 已交付过的版本号（判「残留」用，见 is_leftover_section；不给 = 不改号）；
    · 换行保持原样（读字节再解码 —— read_text 会先把 CRLF 规整成 LF，那样「保留 CRLF」就是一句空话）。"""
    p = path or (REPO / "CHANGELOG.md")
    eol, text = _split(p.read_bytes().decode("utf-8"))
    i = text.find(UNRELEASED + "\n")
    if i < 0:
        raise SystemExit("✗ CHANGELOG.md 里没有「%s」这一节，不知道这一版改了什么" % UNRELEASED)
    body_start = i + len(UNRELEASED) + 1
    m = re.search(r"^## ", text[body_start:], flags=re.M)
    body_end = body_start + m.start() if m else len(text)
    body = "\n".join(ln for ln in text[body_start:body_end].split("\n") if ln.strip() != PLACEHOLDER).strip("\n")
    head = text[:i] + UNRELEASED + "\n\n" + PLACEHOLDER + "\n\n"
    rest = text[body_end:].lstrip("\n")
    top = re.match(r"## (\d+\.\d+\.\d+)(（[^\n]*）)?[^\n]*\n", rest)
    renamed = False
    if top and is_leftover_section(top.group(1), version, delivered):
        rest = "## %s（%s）\n" % (version, date_str) + rest[top.end():]          # 没交付成的残留节改号（内容原样保留）
        renamed = True
    sec = re.search(r"^## %s(（|\s|$)" % re.escape(version), rest, flags=re.M)
    if sec:
        if not body.strip() and not renamed:
            return False
        if not body.strip():
            new = head + rest
            p.write_bytes(new.rstrip("\n").replace("\n", eol).encode("utf-8") + eol.encode("utf-8"))
            return True
        line_end = rest.find("\n", sec.start())
        line_end = len(rest) if line_end < 0 else line_end + 1
        new = head + rest[:line_end] + "\n" + body + "\n" + rest[line_end:]
    else:
        new = head + "## %s（%s）\n\n" % (version, date_str) + (body.strip() and body or "（本版没有功能变更：只是重新打包）") + "\n\n" + rest
    p.write_bytes(new.rstrip("\n").replace("\n", eol).encode("utf-8") + eol.encode("utf-8"))
    return True


def changelog_section(text: str, version: str) -> str:
    """取出「## X.Y.Z（…）」这一节（不含标题）；没有就返回空串。"""
    _, text = _split(text)
    m = re.search(r"^## %s(（[^\n]*）)?[^\n]*\n" % re.escape(version), text, flags=re.M)
    if not m:
        return ""
    rest = text[m.end():]
    n = re.search(r"^## ", rest, flags=re.M)
    return rest[: n.start() if n else len(rest)].strip("\n")


def today() -> str:
    return time.strftime("%Y-%m-%d")
