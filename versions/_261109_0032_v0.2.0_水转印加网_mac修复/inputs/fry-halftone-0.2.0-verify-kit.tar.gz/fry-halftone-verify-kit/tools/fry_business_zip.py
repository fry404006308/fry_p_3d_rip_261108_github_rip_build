# -*- coding: utf-8 -*-
r"""fry_business_zip.py —— 一键拷走的交付包：★393 起给的是**完整包**（不再只给一个 dll）。

【391 是怎么做的、393 为什么改】
  391 版本只放 dll + 三个说明：因为当时的读者只有「业务人员换一个 dll」。
  393 的新前提：**同事和公司其它软件也要集成这个库** ⇒ 只给 dll，对方立刻要头文件、导入库、
  版本号、示例、许可、校验值…… ⇒ 干脆一次给全，并且让对方**能自己验证包是完整的**。
  ⇒ 包里现在是 `tools/fry_delivery_contract.py` 里 full 等级的全部 17 项 + 一份「给业务」的替换说明。

【三类读者，一个包】
  · 业务人员：只看 `给业务_使用说明.md`（换哪一个文件、怎么核对）——其余的不用管；
  · 同事 / 其它软件：看 `SDK_使用说明.md` + `include/` + `lib/` + `examples/`（C / C# / Python）；
  · 谁都可以先跑一次 `python verify_delivery.py`：包完整吗、dll 能加载吗、版本号处处一致吗。

【前置条件（不满足就拒绝，绝不打一个没验过的包）】
  out/sdk/fry-halftone-sdk 存在 ｜ out/build_report.json 说冒烟通过 ｜ dll 现算 sha256 == sdk_info.json 记录的
  ｜ ★393 交付清单闸（full 等级）通过 ｜ 打完再解开 zip 复查一次（清单 + dll 逐字节）。

【输出】out/交付给业务/fry_halftone_dll_<版本>_<平台>_<YYMMDD_HHMM>.zip + 固定名 fry_halftone_dll_最新_<平台>.zip
  （`out/` 与 `*.zip` 都在 .gitignore 里：不进 git）
【用法】python tools/fry_build.py && python tools/fry_business_zip.py
  · `--dry-run`：★401 只跑**前置检查**（出过包吗 / 冒烟过吗 / sha256 对得上吗 / 清单齐吗），
    一个字节都不写。给「我只想确认现在能不能出包」用。
  · `--help`：★401 以前敲 `--help` 会**直接出一个包**（参数被整个忽略）——
    看着只是不方便，实际会让人在不想出包的时候出一个包，而且那个包还会盖掉「最新」那个固定名。
"""
from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import sys
import time
import zipfile
from pathlib import Path

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO / "tools"))
import fry_build  # noqa: E402
import fry_delivery_contract as DC  # noqa: E402

OUT_DIR = REPO / "out" / "交付给业务"
TARGET_HINT = r"<软件目录>\fry_project_components\HS200_halftone_dll\_bin\win32-x64"


def sha256(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def latest_changes(version: str = "") -> str:
    """★411 这一版改了什么：CHANGELOG 里「## <版本号>」那一节的第一条（交付版按版本号分节）；
    没有这一节（本地调试构建）就取「未发布」下的第一条（### 开头到下一个 ### 为止）。"""
    text = (REPO / "CHANGELOG.md").read_text(encoding="utf-8").replace("\r\n", "\n")
    anchor = text.find("\n## %s" % version) if version else -1
    start = text.find("### ", anchor if anchor >= 0 else text.find("## 未发布"))
    if start < 0:
        return "（CHANGELOG 里没有找到「未发布」条目）"
    end = text.find("\n### ", start + 4)
    return text[start: end if end > 0 else len(text)].strip()


def readme(info: dict, lib_name: str, lib_sha: str, tag: str, items: int) -> str:
    ver = info.get("sdk_version_str") or info.get("version_str") or "?"
    fp = info.get("algorithm_fingerprint_str") or "?"
    lines = [
        "# 加网 dll 交付包",
        "",
        "| 项 | 值 |",
        "| --- | --- |",
        "| 动态库 | `bin/%s` |" % lib_name,
        "| 平台 | %s |" % tag,
        "| 版本 | %s |" % ver,
        "| 算法指纹 | `%s` |" % fp,
        "| dll 的 sha256 | `%s` |" % lib_sha,
        "| 打包时间 | %s |" % time.strftime("%Y-%m-%d %H:%M"),
        "| 包内文件 | %d 项（按交付清单 full 等级）|" % items,
        "",
        "## 零、先跑一次自检（30 秒，建议每次都跑）",
        "",
        "```",
        "python verify_delivery.py",
        "```",
        "",
        "它会回答三件事：包**完整**吗、dll **能加载**吗、版本号**处处一致**吗。全绿就可以放心用；",
        "有红就把整段输出发回来，不用再描述现象。",
        "",
        "## 一、我只想换掉软件里的 dll（业务人员看这一节就够）",
        "",
        "把 `bin/%s` 复制到加网软件的这个目录，**覆盖同名旧文件**" % lib_name,
        "（同目录的 `sdk_info.json`、`SDK_参数说明.md`、`params_schema.json`、`VERSION` 一起覆盖）：",
        "",
        "```",
        TARGET_HINT,
        "```",
        "",
        "⚠ 替换前先关掉加网软件（dll 被占用时 Windows 不让覆盖）。",
        "",
        "换完怎么确认换对了（二选一都行）：",
        "",
        "1. 右键 dll → 属性 → 详细信息：**文件版本**应当是 `%s`；" % ver,
        "2. 或者算一次 sha256，与上表逐字比对：",
        "",
        "```",
        "Get-FileHash .\\%s -Algorithm SHA256" % lib_name,
        "```",
        "",
        "3. 软件里「C++ 加网出片」跑完后，输出目录的 `slice_metadata.json` 里 `algorithm_fingerprint_str` 应等于上表的算法指纹。",
        "",
        "## 二、我要在自己的程序里调用它（开发看这一节）",
        "",
        "| 想做的事 | 看哪个文件 |",
        "| --- | --- |",
        "| 接口声明（C / C++ / C# P-Invoke / Delphi 都照它写） | `include/fry_halftone.h` |",
        "| Windows 隐式链接用的导入库 | `lib/fry_halftone.lib` |",
        "| 完整集成说明（加载方式、返回码、线程、内存、运行库要求） | `SDK_使用说明.md`（英文 `SDK_README_EN.md`） |",
        "| 参数有哪些、默认值、取值范围 | `SDK_参数说明.md`（机读版 `params_schema.json`） |",
        "| 照抄就能跑的例子 | `examples/c/`、`examples/csharp/`、`examples/python/` |",
        "| 这一版是什么来历（版本 / 指纹 / 编译器 / 运行库 / 最低系统） | `sdk_info.json` |",
        "| 许可与第三方声明 | `LICENSE.txt` |",
        "| 变更历史 | `CHANGELOG.md` |",
        "| 这个包应该有哪些文件（机读） | `delivery_manifest.json` |",
        "",
        "★ 一句话上手：`LoadLibrary` → `FryHalftone_GetVersion()` → `FryHalftone_SliceModelJsonUtf8(...)`，",
        "返回 0 是成功，非 0 读 errorBuffer（里面写的是中文原因）。",
        "",
        "## 三、这一版改了什么",
        "",
        latest_changes(ver),
        "",
        "## 四、遇到问题",
        "",
        "- 返回 7（不支持）：报错信息会写明是哪一种模型写法不支持 —— 请改用软件里「RIP 加网出片」（Python 生产线）出这一件，并把模型发给开发。",
        "- 返回 1（失败）：报错开头就是原因；多半是模型文件本身坏了。",
        "- 返回 2（参数不合法）：对照 `SDK_参数说明.md` 的取值范围；参数名写错不会被忽略，会直接报错。",
        "- 加载不了 dll：先跑 `python verify_delivery.py`；本库**不需要**安装 VC++ 运行库（C++ 运行库已静态链接）。",
        "",
    ]
    return "\n".join(lines)


def parse_args(argv=None) -> argparse.Namespace:
    """★401 真的解析参数。⚠ 以前这里什么都不解析，`--help` 会直接出一个包。"""
    ap = argparse.ArgumentParser(
        prog="fry_business_zip.py",
        description="打一个「一键拷走」的交付包（完整 SDK + 给业务的替换说明）。",
        epilog="先跑 python tools/fry_build.py 出包，再跑本脚本。"
               "产物：out/交付给业务/fry_halftone_dll_最新_<平台>.zip（给业务的就是这一个）。")
    ap.add_argument("--dry-run", action="store_true",
                    help="只跑前置检查（出过包吗 / 冒烟过吗 / sha256 对得上吗 / 交付清单齐吗），不写任何文件")
    return ap.parse_args(argv)


def main(argv=None) -> int:
    args = parse_args(argv)
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    row = fry_build.plat()
    sdk = REPO / "out" / "sdk" / fry_build.SDK_NAME
    lib = sdk / "bin" / row["lib"]
    report_path = REPO / "out" / "build_report.json"
    if not lib.is_file() or not report_path.is_file():
        print("✗ 还没出包：先跑 python tools/fry_build.py")
        return 1
    report = json.loads(report_path.read_text(encoding="utf-8"))
    if not report.get("smoke_bool"):
        print("✗ 上一次出包的冒烟没有通过（build_report.json smoke_bool=false）—— 不打给业务的包")
        return 1
    info = json.loads((sdk / "sdk_info.json").read_text(encoding="utf-8"))
    lib_sha = sha256(lib)
    if info.get("library_sha256_str") and info["library_sha256_str"] != lib_sha:
        print("✗ dll 现算 sha256 %s ≠ sdk_info.json 记录的 %s（出包后 dll 被换过）—— 拒绝"
              % (lib_sha[:16], info["library_sha256_str"][:16]))
        return 1
    if args.dry_run:
        print("✓ 前置检查全过（出过包 ｜ 冒烟通过 ｜ dll sha256 %s 对得上）—— --dry-run，没有写任何文件"
              % lib_sha[:16])
        return 0
    ver = str(info.get("sdk_version_str") or info.get("version_str") or "dev")
    stamp = time.strftime("%y%m%d_%H%M")
    name = "fry_halftone_dll_%s_%s_%s" % (ver, row["tag"], stamp)
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    staging = OUT_DIR / "_staging" / name
    if staging.exists():
        shutil.rmtree(staging)
    staging.parent.mkdir(parents=True, exist_ok=True)
    # ★393 完整包：整份 SDK 原样拷过来（清单 full 等级的 17 项都在里面）
    shutil.copytree(sdk, staging)
    (staging / "给业务_使用说明.md").write_text(
        readme(info, lib.name, lib_sha, row["tag"], len(DC.items_for("full", ""))), encoding="utf-8")
    # 校验和与清单要把刚写的说明也算进去 ⇒ 重新封包（★411 DC.seal：先清单、最后 SHA256SUMS）
    DC.seal(staging, "full", name)
    res = DC.check(staging, "full", package_name=name)
    if not res["ok_bool"]:
        DC.report(res, "给业务的包")
        print("✗ 交付清单闸没过 —— 不打这个包")
        return 1
    print("✓ 交付清单闸：full 等级 %d 项齐全 ｜ 版本号处处一致（%s）"
          % (res["checked_int"], "、".join("%s=%s" % (k, v) for k, v in res["versions_dict"].items() if v)))

    zpath = OUT_DIR / (name + ".zip")
    with zipfile.ZipFile(zpath, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for f in sorted(staging.rglob("*")):
            if f.is_file():
                z.write(f, arcname="%s/%s" % (name, f.relative_to(staging).as_posix()))
    # ★ 打完再解开复查一次：清单 + dll 逐字节（「压缩这一步」本身也可能出事，B.1-31）
    check_dir = OUT_DIR / "_staging" / (name + "_解开复查")
    if check_dir.exists():
        shutil.rmtree(check_dir)
    with zipfile.ZipFile(zpath) as z:
        names = z.namelist()
        z.extractall(check_dir)
    unzipped = check_dir / name
    res2 = DC.check(unzipped, "full", package_name=name)
    same = (unzipped / "bin" / lib.name).read_bytes() == lib.read_bytes()
    if not (res2["ok_bool"] and same):
        DC.report(res2, "解开复查")
        print("✗ 解开复查没过（dll 逐字节相同 = %s）" % same)
        return 1
    shutil.rmtree(OUT_DIR / "_staging", ignore_errors=True)
    latest = OUT_DIR / ("fry_halftone_dll_最新_%s.zip" % row["tag"])      # 固定名字：永远是最近一次打的那一份
    shutil.copy2(zpath, latest)
    print("✓ 交付包：%s（%.2f MB，%d 个文件，dll sha256 %s）"
          % (zpath, zpath.stat().st_size / 1048576.0, len(names), lib_sha[:16]))
    print("✓ 解开复查：清单 %d 项齐全、dll 与冒烟过的逐字节相同" % res2["checked_int"])
    for n in sorted(names):
        print("   ·", n)
    print("✓ 同一份另存为固定名字：%s（直接拷走这一个即可）" % latest)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
