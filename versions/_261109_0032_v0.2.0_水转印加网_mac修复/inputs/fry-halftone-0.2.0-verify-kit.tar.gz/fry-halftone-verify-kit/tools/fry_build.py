# -*- coding: utf-8 -*-
r"""fry_build.py —— **三平台共用的一条出包流水线**（Windows / Linux / macOS 走同一份代码）。

【★384 起的形态：一份 C++ 源码，每个平台编一次】
  382/383：Python 算法用 PyInstaller 冻结成子进程 + 一层 C 壳 ⇒ 每个平台要「冻结一遍 + 编一遍」，
           而且冻结只能在目标平台上做（PyInstaller 不能跨平台）。
  384   ：算法是 C++（`cpp/`，算法仓 fry_project_components_cpp 的副本）⇒ 每个平台 **CMake 编一遍** 就完，
           产物只有一个动态库（Windows 0.5 MB 量级，382 的包 ~220 MB）。
  ⚠ C++ 同样**不能**「在 Windows 上编一次三平台通用」：机器码与系统调用约定按平台不同 ⇒ 仍是三台机器各编一次
    （lmst 同样如此）；省掉的是「冻结 Python 运行时」那一遍，以及它带来的 200 MB 与冷启动。

【五步 · 每一步都有判据】
  ①  载荷闸    cpp/ 与 cpp.lock.json 逐文件 sha256 一致（换行符规范化）   不一致 → 停
  ②  编译      CMake：fry_halftone 动态库 + 版本探针 + 纯 C 示例 + ★409 对外命令行 fry-halftone-cli
               ★409 `--prebuilt-dir <目录>`：跳过这一步，拿别处编好的四个二进制（如 Windows 上 zig 交叉编的 Linux 版）
                    在**本机**做 ③④⑤ —— 「在 A 机编、在 B 机验收」（B = 目标平台真机 / WSL）
  ③  装配      bin/ + include/ + lib/ + examples/(C/C#/Python) + 说明 + VERSION + sdk_info.json
               ★393 + CHANGELOG + LICENSE + delivery_manifest.json（机读清单）+ SHA256SUMS + verify_delivery.py（对方自检）
               ★387 + params_schema.json（库自己导出的参数说明：键 / 类型 / 默认值 / 取值范围）+ SDK_参数说明.md（由它逐行生成）
               ★387 sdk_info.json 写 library_sha256_str（以前只有交付进算法仓时才写 ⇒ 选 SDK 包时 sha256 核对被跳过）
  ④  冒烟      导出面闸 → ★387 包内说明闸 → 版本探针 → C 接口用例（ctypes，★387 含「说明文件的默认值 / 范围 = 库真实行为」）
               → ★golden 逐字节（与 Python 生产线一致）→ 纯 C 示例真跑 → ★393 交付清单闸（该带的都带了 + 版本号处处一致）
  ④+ ★409 命令行契约（tests/test_cli_contract.py：lmst-cli 同构协议 + golden 全部经 CLI 逐字节）
  ⑤  打包      Windows .zip ｜ 其余 .tar.zst
  ★ ④ 才是真判据：前三步全绿只说明「编出来了」，第四步说明「它真的能用、而且和 Python 一样」。

【用法】
  python tools/fry_build.py                       本地出包（版本号 0.0.0-dev）
  python tools/fry_build.py --version 1.2.3       CI 出包
  python tools/fry_build.py --no-archive          只装配不压缩
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import platform
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

REPO = Path(__file__).resolve().parents[1]
OUT = REPO / "out"
BUILDDIR = OUT / "cmake"
SDK_NAME = "fry-halftone-sdk"
PACKAGE_NAME = "fry-halftone"

sys.path.insert(0, str(REPO / "tools"))
import fry_delivery_contract as DC  # noqa: E402  ★393 交付清单（一个包必须带什么）的唯一真源 + 尺子
import fry_param_schema as PS  # noqa: E402   ★387 参数说明两件套（机读版由库自己导出，人读版由机读版逐行生成）
import fry_payload  # noqa: E402

# 平台差异做成数据（加一个平台 = 这里加一行）
PLATFORM_DICT: Dict[str, Dict[str, Any]] = {
    "Windows": {"tag": "win32-x64", "lib": "fry_halftone.dll", "implib": "fry_halftone.lib",
                "probe": "FryVersionProbe.exe", "demo": "FryHalftoneDemoC.exe", "cli": "fry-halftone-cli.exe", "archive": "zip"},
    "Linux": {"tag": "linux-x64", "lib": "libfry_halftone.so", "implib": "",
              "probe": "FryVersionProbe", "demo": "FryHalftoneDemoC", "cli": "fry-halftone-cli", "archive": "tar.zst"},
    "Darwin": {"tag": "darwin-arm64", "lib": "libfry_halftone.dylib", "implib": "",
               "probe": "FryVersionProbe", "demo": "FryHalftoneDemoC", "cli": "fry-halftone-cli", "archive": "tar.zst"},
}


def say(step: str, text: str) -> None:
    # 行首带 ★：界面的子进程桥（TR100）按「★ / ✓ / ✗ / ⚠」决定哪些行上界面，其余只进日志文件
    print("\n★ ═══ %s ═══ %s" % (step, text), flush=True)


def run(cmd: List[str], cwd: Optional[Path] = None, env: Optional[Dict[str, str]] = None) -> None:
    print("$ " + " ".join(str(c) for c in cmd), flush=True)
    rc = subprocess.run([str(c) for c in cmd], cwd=str(cwd or REPO), env=dict(os.environ, **(env or {}))).returncode
    if rc != 0:
        raise SystemExit("✗ 这一步失败（返回码 %d）：%s" % (rc, " ".join(str(c) for c in cmd)))


def plat() -> Dict[str, Any]:
    sysname = platform.system()
    if sysname not in PLATFORM_DICT:
        raise SystemExit("✗ 没见过的平台 %r —— 在 PLATFORM_DICT 里加一行" % sysname)
    row = dict(PLATFORM_DICT[sysname])
    if sysname == "Darwin" and platform.machine() != "arm64":
        row["tag"] = "darwin-x64"
    if sysname == "Linux" and platform.machine() in ("aarch64", "arm64"):
        row["tag"] = "linux-arm64"          # ★409 ARM 服务器上验收 linux-arm64 预编件时，包名不能再叫 x64
    return row


# ───────────────────────────── ② 编译 ─────────────────────────────
def stale_cmake_source(builddir: Path, repo: Path) -> Optional[str]:
    """★449 CMake 缓存记着「当初配置时的源码目录」（CMAKE_HOME_DIRECTORY）：仓库搬家后（实测 C:/_260331_gitlab → E:/_260331_gitlab）
    它对不上，cmake 直接报错退出。对不上 ⇒ 返回缓存里记的旧路径；对得上 / 没有缓存 ⇒ None（纯函数，只读文件）。"""
    cache = builddir / "CMakeCache.txt"
    if not cache.is_file():
        return None
    for line in cache.read_text(encoding="utf-8", errors="replace").splitlines():
        if line.startswith("CMAKE_HOME_DIRECTORY:"):
            old = line.split("=", 1)[1].strip()
            norm = lambda x: os.path.normcase(os.path.normpath(str(x).replace("/", os.sep)))   # noqa: E731
            return None if norm(old) == norm(repo) else old
    return None


def build_native(version: str, generator: Optional[str]) -> None:
    old = stale_cmake_source(BUILDDIR, REPO)
    if old:                                     # 缓存是别处配置的 ⇒ 整个编译目录作废重来（只是中间产物，下一步全部重编）
        print("  ⚠ %s 是在 %s 配置的（仓库搬过家）⇒ 清掉重新配置" % (BUILDDIR, old))
        shutil.rmtree(BUILDDIR)
    BUILDDIR.mkdir(parents=True, exist_ok=True)
    cmd = ["cmake", "-S", str(REPO), "-B", str(BUILDDIR), "-DCMAKE_BUILD_TYPE=Release", "-DFRY_SDK_VERSION=%s" % version]
    if generator:
        cmd += ["-G", generator]
    run(cmd)
    run(["cmake", "--build", str(BUILDDIR), "--config", "Release", "--parallel"])


def find_artifact(name: str) -> Path:
    """MSVC 的多配置生成器会多套一层 Release/，所以现场找，不写死路径。"""
    hits = sorted(p for p in BUILDDIR.rglob(name) if p.is_file())
    if not hits:
        raise SystemExit("✗ 构建目录里找不到 %s" % name)
    return hits[0]


PREBUILT_INFO_NAME = "prebuilt_info.json"      # ★409 --prebuilt-dir 目录里的「这几个二进制是谁、用什么编的」


def prebuilt_fingerprint_problem(pinfo: Dict[str, Any], lock: Dict[str, Any]) -> str:
    """★409 验收包不带源码时的「载荷闸」替身（纯函数）：预编件的算法指纹必须 = 锁文件；空串 = 没问题。"""
    got, want = pinfo.get("algorithm_fingerprint_str"), lock.get("tree_sha256_str")
    if not want:
        return "锁文件里没有 tree_sha256_str"
    if got != want:
        return "预编件的算法指纹 %r ≠ 锁文件 %r —— 二进制与这份验收包不是同一次出的" % (got, want)
    return ""


# ★410 外壳指纹：cpp/ 之外、会编进二进制的输入（与 CMakeLists.txt 引用的一一对应；tests/test_build_helpers.py 有闭包闸）
WRAPPER_INPUT_LIST = ["CMakeLists.txt", "src", "include", "packaging/windows/fry_halftone.rc.in", "packaging/export",
                      "tools/FryVersionProbe.cpp", "examples/c"]
WRAPPER_TEXT_SUFFIX_SET = {".h", ".hpp", ".c", ".cc", ".cpp", ".inc", ".txt", ".cmake", ".in", ".map", ".def", ".rc"}


def wrapper_fingerprint(repo: Optional[Path] = None) -> str:
    """★410 外壳指纹（读文件，不编译）：算法指纹只管 cpp/ ⇒ 改了命令行 / dll 外壳 / 导出表而某个平台没重编，
    算法指纹照样相等、**不报错** ⇒ 把 cpp/ 之外会编进二进制的输入也算一个树 sha256（文本 CRLF→LF，与载荷锁同一口径）。
    缺任何一项 = 空串（验收包不带源码：那里用预编件记下的值）。"""
    repo = repo or REPO
    files: List[Path] = []
    for rel in WRAPPER_INPUT_LIST:
        p = repo / rel
        if p.is_file():
            files.append(p)
        elif p.is_dir():
            files += [q for q in p.rglob("*") if q.is_file() and "__pycache__" not in q.parts]
        else:
            return ""
    h = hashlib.sha256()
    for q in sorted(files, key=lambda q: q.relative_to(repo).as_posix()):
        data = q.read_bytes()
        if q.suffix.lower() in WRAPPER_TEXT_SUFFIX_SET or q.name == "CMakeLists.txt":
            data = data.replace(b"\r\n", b"\n")
        h.update(q.relative_to(repo).as_posix().encode("utf-8") + b"\0" + hashlib.sha256(data).digest())
    return h.hexdigest()


def prebuilt_wrapper_problem(recorded: str, local: str) -> str:
    """★410 预编件的外壳指纹核对（纯函数）：recorded = prebuilt_info.json 里记的，local = 本机源码现算（验收包里没有源码 = 空串）。"""
    if not recorded:
        return "预编件没记外壳指纹（旧版交叉编译产物）—— 重新交叉编译：python tools/fry_cross_build.py --target …"
    if local and recorded != local:
        return ("预编件的外壳指纹 %s… ≠ 当前源码 %s… —— src/ include/ CMakeLists.txt 等改过之后没重新交叉编"
                % (recorded[:16], local[:16]))
    return ""


def find_lib_for_facts() -> Path:
    return find_artifact(plat()["lib"])


def measured_min_os(lib: Path) -> str:
    """★409 这个库**实际**要求的最低系统版本（纯函数，读二进制，不跑它）。

    Linux：库依赖的 glibc 符号版本都以字符串形式躺在 .dynstr 里（GLIBC_2.2.5 / GLIBC_2.34 / GLIBC_2.38 …），
      取最大的那个 = 目标机 glibc 至少要这么新（更老的机器加载时报 `GLIBC_2.38 not found`）。
    macOS：LC_BUILD_VERSION（或老式 LC_VERSION_MIN_MACOSX）里的 minos。
    """
    import re as _re
    import struct as _struct
    b = lib.read_bytes()
    if b[:4] == b"\x7fELF":
        vers = [tuple(int(x) for x in m.groups() if x is not None) for m in _re.finditer(rb"GLIBC_(\d+)\.(\d+)(?:\.(\d+))?", b)]
        arch = {0x3E: "x86-64", 0xB7: "aarch64"}.get(_struct.unpack_from("<H", b, 18)[0], "?")
        if not vers:
            return "Linux %s（库里没有 glibc 版本需求）" % arch
        top = max(vers)
        return "glibc ≥ %s（实测：库引用的最高符号版本 GLIBC_%s）%s" % (".".join(map(str, top)), ".".join(map(str, top)), arch)
    magic = _struct.unpack_from("<I", b, 0)[0] if len(b) >= 4 else 0
    if magic == 0xFEEDFACF:
        cputype, _sub, _ft, ncmds = _struct.unpack_from("<iiII", b, 4)
        arch = {0x0100000C: "arm64", 0x01000007: "x86-64"}.get(cputype, "?")
        off = 32
        for _ in range(ncmds):
            cmd, size = _struct.unpack_from("<II", b, off)
            if cmd in (0x32, 0x24):                          # LC_BUILD_VERSION / LC_VERSION_MIN_MACOSX
                v = _struct.unpack_from("<I", b, off + (12 if cmd == 0x32 else 8))[0]
                return "macOS ≥ %d.%d（实测：Mach-O 的 minos）%s" % (v >> 16, (v >> 8) & 0xFF, arch)
            off += size
        return "macOS %s（没读到 minos）" % arch
    return "（不认识的二进制格式，没量）"


# ───────────────────────────── ③ 装配 ─────────────────────────────
def integration_facts(version: str) -> Dict[str, Any]:
    """★393 写进 sdk_info.json 的「集成信息」—— 对接方最常问的那几条，包里直接给答案。

    ⚠ 这里的每一条都必须是**这次构建的事实**，不许写「一般来说」：编译器版本从 CMake 缓存读，
      运行库口径与 CMakeLists 里写的一致（改了 CMake 必须同步改这里 —— 两处真相，所以下面留了判据注释）。
    """
    row = plat()
    cc = ""
    cache_dict: Dict[str, str] = {}
    cache = BUILDDIR / "CMakeCache.txt"
    if cache.is_file():
        for line in cache.read_text(encoding="utf-8", errors="replace").splitlines():
            if line.startswith("CMAKE_CXX_COMPILER:"):
                cc = cc or line.split("=", 1)[-1].strip()
            if line.startswith("FRY_"):                  # FRY_COMPANY_NAME:STRING=... 之类
                k, _sep, v = line.partition("=")
                cache_dict[k.split(":")[0]] = v.strip()
    # ⚠ Visual Studio 生成器的 CMakeCache 里**没有** CMAKE_CXX_COMPILER —— 编译器信息在这个文件里
    #   （只看 cache 会得到一句「没读到」，而「用哪个编译器编的」正是对接方最常问的一条）
    ident = {}
    for f in sorted(BUILDDIR.glob("CMakeFiles/*/CMakeCXXCompiler.cmake")):
        for line in f.read_text(encoding="utf-8", errors="replace").splitlines():
            for key in ("CMAKE_CXX_COMPILER_ID", "CMAKE_CXX_COMPILER_VERSION"):
                if line.startswith('set(%s "' % key):
                    ident[key] = line.split('"')[1]
    if ident:
        cc = "%s %s%s" % (ident.get("CMAKE_CXX_COMPILER_ID", "?"), ident.get("CMAKE_CXX_COMPILER_VERSION", "?"),
                          ("（%s）" % cc) if cc else "")
    origin = "native"
    pre = BUILDDIR / PREBUILT_INFO_NAME
    if pre.is_file():                                  # ★409 --prebuilt-dir：二进制是别处编的，编译器 / 来源以那边写的为准
        try:
            pinfo = json.loads(pre.read_text(encoding="utf-8"))
        except ValueError:
            pinfo = {}
        cc = str(pinfo.get("compiler_str") or cc)
        origin = "prebuilt：%s" % (pinfo.get("origin_str") or "?")
    is_win = platform.system() == "Windows"
    # ★393 文件属性（VERSIONINFO）里打算写什么 —— 期望值的**唯一上游是 CMake 的构建输入**，
    #   交付清单闸拿它和 dll 里真正的资源逐字比（有资源 ≠ 资源是对的：代码页错了就是一堆乱码）
    props: Dict[str, str] = {}
    if is_win and cache_dict:
        props = {"CompanyName": cache_dict.get("FRY_COMPANY_NAME", ""),
                 "ProductName": cache_dict.get("FRY_PRODUCT_NAME", ""),
                 "FileDescription": cache_dict.get("FRY_FILE_DESCRIPTION", ""),
                 "FileVersion": version, "ProductVersion": version,
                 "InternalName": "fry_halftone", "OriginalFilename": "fry_halftone.dll",
                 "LegalCopyright": cache_dict.get("FRY_COPYRIGHT", ""),
                 "Algorithm": cache_dict.get("FRY_ALGORITHM_NAME", "water_transfer_depth")}
    return {
        "abi_str": "C ABI；Windows 调用约定 __stdcall，其它平台默认",
        "header_language_str": "C89 兼容（纯 C / C++ / C# P-Invoke / Delphi 都能用）",
        "cxx_standard_str": "C++17",
        "compiler_str": cc or "（本机 CMake 缓存里没读到）",
        "runtime_str": ("MSVC C++ 运行库静态链接；UCRT 动态链接系统 ucrtbase.dll ⇒ **不需要装 VC++ Redistributable**"
                        if is_win else "libstdc++ / libgcc 静态链接；依赖系统 glibc"),
        # ★409 最低系统版本**从二进制里现场量**（以前写死「glibc 2.28+」—— 409 在 WSL 实测 trixie 编出来的库要 GLIBC_2.38，写的是假话）
        "min_os_str": "Windows 10 x64 及以上" if is_win else measured_min_os(find_lib_for_facts()),
        "build_origin_str": origin,
        "thread_safety_str": "同一时刻只跑一个作业（并发调用返回 6 BUSY）；Cancel 可从其它线程调；进度回调在调用线程上同步触发",
        "memory_hint_str": "峰值随体素数线性增长；17 mm 半球件约 0.83 GB",
        "network_bool": False,
        "writes_registry_bool": False,
        "entry_points_list": header_api_names(),
        "return_codes_dict": {"0": "OK", "1": "FAILED", "2": "BAD_ARGUMENT", "5": "CANCELLED",
                              "6": "BUSY", "7": "UNSUPPORTED（模型写法暂不支持，原因写在 errorBuffer）"},
        "version_sources_list": ["VERSION", "sdk_info.json", "FryHalftone_GetVersion()",
                                 "Windows 文件属性（VERSIONINFO）"] if is_win else
                                ["VERSION", "sdk_info.json", "FryHalftone_GetVersion()"],
        "delivery_manifest_file_str": DC.MANIFEST_NAME_STR,
        "self_check_cmd_str": "python verify_delivery.py",
        "file_properties_dict": props,
    }


# ★410 原样随包的文件（包内路径 → 仓库路径）：assemble 按它拷；全交付目录按它核「三个平台 + 验收包逐字节相同」—— 唯一真源。
#   （SDK_参数说明.md / sdk_info.json / 清单 / 校验和里带平台与库的 sha256，天然各平台不同，不在这里）
SHIPPED_VERBATIM_DICT = {"include/fry_halftone.h": "include/fry_halftone.h",
                         "SDK_使用说明.md": "docs/SDK_使用说明.md", "SDK_README_EN.md": "docs/SDK_README_EN.md",
                         "CHANGELOG.md": "CHANGELOG.md", "LICENSE.txt": "LICENSE.txt",
                         "verify_delivery.py": "packaging/verify_delivery.py"}
SHIPPED_VERBATIM_DIR_DICT = {"examples": "examples"}          # 整个目录原样拷


def assemble(version: str, lock: Dict[str, Any]) -> Path:
    row = plat()
    sdk = OUT / "sdk" / SDK_NAME
    if sdk.exists():
        shutil.rmtree(sdk)
    (sdk / "bin").mkdir(parents=True)
    (sdk / "include").mkdir(parents=True)
    lib = sdk / "bin" / row["lib"]
    shutil.copy2(find_artifact(row["lib"]), lib)
    # ★409 对外命令行与库放同一个目录（Windows 同目录找 dll ｜ Linux rpath=$ORIGIN ｜ macOS @loader_path）
    shutil.copy2(find_artifact(row["cli"]), sdk / "bin" / row["cli"])
    if row["implib"]:
        (sdk / "lib").mkdir()
        shutil.copy2(find_artifact(row["implib"]), sdk / "lib" / row["implib"])
    # ★387 参数说明：向要发出去的这个库要（打包脚本不另写一份），先过形状闸再落盘；人读版由它逐行生成
    schema_text = PS.read_schema_text(lib)
    try:
        schema = json.loads(schema_text)
    except ValueError as e:
        raise SystemExit("✗ 库自报的参数说明不是合法 JSON：%s" % e)
    problems = PS.schema_problems(schema)
    if problems:
        raise SystemExit("✗ 库自报的参数说明不合格：\n  " + "\n  ".join(problems))
    lib_sha = PS.sha256_file(lib)
    schema_path = sdk / PS.SCHEMA_FILE_NAME_STR
    schema_path.write_text(json.dumps(schema, ensure_ascii=False, indent=1) + "\n", encoding="utf-8", newline="\n")
    (sdk / PS.DOC_FILE_NAME_STR).write_text(PS.render_markdown(schema, version, row["tag"], lib_sha), encoding="utf-8", newline="\n")
    print("  参数说明：%s（%s，%d 个参数）+ %s" % (PS.SCHEMA_FILE_NAME_STR, schema["schema"], len(schema["params"]), PS.DOC_FILE_NAME_STR))
    (sdk / "VERSION").write_text(version + "\n", encoding="utf-8", newline="\n")
    # ★393 交付完整性：头文件 / 消费方说明 / 变更历史 / 许可与第三方声明 / 对方自检脚本 / 示例 —— 少一样，对方就得回来问人
    for dst_rel, src_rel in SHIPPED_VERBATIM_DICT.items():
        src = REPO / src_rel
        if not src.is_file():
            raise SystemExit("✗ 缺随包文件 %s —— ★393 起它是必需项（见 tools/fry_delivery_contract.py 的清单）" % src_rel)
        (sdk / dst_rel).parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, sdk / dst_rel)
    for dst_rel, src_rel in SHIPPED_VERBATIM_DIR_DICT.items():
        shutil.copytree(REPO / src_rel, sdk / dst_rel)
    (sdk / "sdk_info.json").write_text(json.dumps(
        {"package_str": PACKAGE_NAME, "version_str": version, "platform_str": row["tag"],
         "algorithm_str": "water_transfer_depth", "engine_str": "cpp",
         # ★449 algorithm_str 是 dll 自报的名字（verify_delivery 逐字核对，不能改）⇒ 统一引擎另记一项：
         #   库认哪些引擎 / 预设（取自库自报的参数说明，不是手写），一眼看出这是不是「HE500/510/520 统一版」的包
         "wt_engine_choices_dict": {p["name"]: list(p.get("choices") or []) for p in schema["params"]
                                    if p["name"] in ("wt_engine", "wt_preset")},
         "algorithm_fingerprint_str": lock["tree_sha256_str"],
         "source_commit_str": lock.get("source_dict", {}).get("commit_str", ""),
         "payload_file_count_int": lock["file_count_int"],
         "library_file_str": "bin/" + row["lib"],
         # ★387 以前只有 fry_deliver.py 交付进算法仓时才补写 sha256 ⇒ 直接选 SDK 包时「dll 与说明是否配套」这一项核对被跳过
         "library_sha256_str": lib_sha,
         "import_library_file_str": ("lib/" + row["implib"]) if row["implib"] else "",
         "import_library_sha256_str": PS.sha256_file(sdk / "lib" / row["implib"]) if row["implib"] else "",
         "header_file_str": "include/fry_halftone.h",
         "params_schema_file_str": PS.SCHEMA_FILE_NAME_STR,
         "params_schema_id_str": schema["schema"],
         "params_schema_sha256_str": PS.sha256_file(schema_path),
         "param_count_int": len(schema["params"]),
         "params_doc_file_str": PS.DOC_FILE_NAME_STR,
         "built_at_str": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
         "built_on_str": "%s %s" % (platform.system(), platform.machine()),
         # ★393 集成信息：这些是对接方一定会问的，写在包里就不用再问人
         **integration_facts(version)},
        ensure_ascii=False, indent=1), encoding="utf-8")
    # ★393 清单 + 校验和；★411 封包顺序只有一种：先清单、最后 SHA256SUMS（旧写法最后又重写清单 ⇒ SUMS 里清单那一行过期）
    DC.seal(sdk, "full", PACKAGE_NAME)
    size_mb = sum(p.stat().st_size for p in sdk.rglob("*") if p.is_file()) / 1048576.0
    print("  装配完成：%s（%.2f MB，%d 个文件）" % (sdk, size_mb, sum(1 for p in sdk.rglob("*") if p.is_file())))
    return sdk


# ───────────────────────────── ④ 冒烟 ─────────────────────────────
def header_api_names() -> List[str]:
    """头文件里声明的全部 C 接口名 —— 导出面的**唯一真源**（头文件就是跨仓契约）。"""
    text = (REPO / "include" / "fry_halftone.h").read_text(encoding="utf-8")
    return sorted(set(re.findall(r"FRY_API\s+[^;{]*?\b(FryHalftone_\w+)\s*\(", text)))


def export_surface_problems(exported: List[str], expected: List[str]) -> List[str]:
    """导出面闸的判据（纯函数）：多导出 = 内部符号漏出去了；少导出 = 头文件承诺了但库里没有。"""
    ex, want = set(exported), set(expected)
    return (["库里多导出了：%s" % n for n in sorted(ex - want)] +
            ["头文件声明了但库里没导出：%s" % n for n in sorted(want - ex)])


def list_exports(lib: Path) -> Optional[List[str]]:
    """读动态库的导出表；拿不到工具时返回 None（如实说「没查」，不假装查过）。"""
    sysname = platform.system()
    try:
        if sysname == "Windows":
            texts = [(BUILDDIR / "CMakeCache.txt").read_text(encoding="utf-8", errors="replace")]
            texts += [p.read_text(encoding="utf-8", errors="replace") for p in BUILDDIR.glob("CMakeFiles/*/CMakeCXXCompiler.cmake")]
            m = None
            for t in texts:
                m = re.search(r"CMAKE_LINKER:FILEPATH=(.+link\.exe)", t) or re.search(r'CMAKE_CXX_COMPILER "(.+cl\.exe)"', t)
                if m:
                    break
            dumpbin = Path(m.group(1).strip()).with_name("dumpbin.exe") if m else None
            if not dumpbin or not dumpbin.is_file():
                return None
            out = subprocess.run([str(dumpbin), "/exports", str(lib)], capture_output=True, text=True,
                                 encoding="utf-8", errors="replace").stdout
            return re.findall(r"^\s+\d+\s+[0-9A-F]+\s+[0-9A-F]+\s+(\S+)\s*$", out, flags=re.M)
        if sysname == "Linux":
            out = subprocess.run(["nm", "-D", "--defined-only", str(lib)], capture_output=True, text=True).stdout
            return [ln.split()[-1] for ln in out.splitlines() if ln.strip() and ln.split()[-2] in ("T", "W")]
        out = subprocess.run(["nm", "-gU", str(lib)], capture_output=True, text=True).stdout      # macOS：名字前有 _
        return macho_names_from_nm([ln.split()[-1] for ln in out.splitlines() if ln.strip() and ln.split()[-2] in ("T",)])
    except (OSError, IndexError):
        return None


# ★409 链接器自己合成的「本映像」标记，不是我们的代码：zig 的 Mach-O 链接器会把它们也放进导出表（Apple 的不放）；
#   每个映像各有一份、按两级命名空间各自解析 ⇒ 顶替不了别人，也不会被别人顶替 ⇒ 不算内部符号外泄
MACHO_LINKER_MARKER_SET = frozenset({"__dso_handle", "_mh_dylib_header"})


def macho_names_from_nm(raw: List[str]) -> List[str]:
    """Mach-O 符号名 → C 名（纯函数）：只去掉 Mach-O 自动加的**那一个** `_`，再剔除链接器标记。

    ⚠409 以前用 `lstrip("_")` 会把 `__Znwm`（C++ 的 `_Znwm` + Mach-O 前缀）削成 `Znwm`、`___dso_handle` 削成
      `dso_handle` —— 闸照样红，但报出来的名字对不上任何东西，没法排查。
    """
    names = [n[1:] if n.startswith("_") else n for n in raw]
    return [n for n in names if n not in MACHO_LINKER_MARKER_SET]


def smoke(sdk: Path, version: str) -> Dict[str, Any]:
    row = plat()
    lib = sdk / "bin" / row["lib"]
    report: Dict[str, Any] = {}
    exported, expected = list_exports(lib), header_api_names()
    if exported is None:
        print("⚠ 导出面闸：本机找不到导出表工具（dumpbin / nm），这一项**没查**")
        report["export_surface_str"] = "not_checked"
    else:
        problems = export_surface_problems(exported, expected)
        if problems:
            raise SystemExit("✗ 导出面闸：\n  " + "\n  ".join(problems))
        print("✓ 导出面闸：库导出 %d 个名字 = 头文件声明的 %d 个 C 接口，一个不多一个不少" % (len(exported), len(expected)))
        report["export_surface_str"] = "ok_%d" % len(exported)
    # ★409 指纹闸：库**自报**的算法指纹 = 锁文件（= sdk_info 里写的那个）。原生编由 CMake 从锁文件读、天然一致；
    #   --prebuilt-dir 的二进制是别处编的 ⇒ 过期的预编件会让 sdk_info 与库各说各话，而其它闸全绿
    fp_lib, fp_lock = PS.read_lib_text(lib, "FryHalftone_GetAlgorithmFingerprint"), fry_payload.load_lock()["tree_sha256_str"]
    if fp_lib != fp_lock:
        raise SystemExit("✗ 指纹闸：库自报 %s ≠ 锁文件 %s —— 这个库不是用这份算法源码编的" % (fp_lib, fp_lock))
    print("✓ 指纹闸：库自报的算法指纹 = 锁文件（%s…）" % fp_lock[:16])
    report["fingerprint_str"] = "ok"
    # ★387 包内说明闸：说明文件与包里这个库是同一次出包的（行为上说的是不是真话，由下面 test_c_abi 的 ⑩⑪ 真调库核对）
    live_text = PS.read_schema_text(lib)
    problems = PS.package_problems(sdk, "bin/" + row["lib"], ("lib/" + row["implib"]) if row["implib"] else "", live_text)
    if problems:
        raise SystemExit("✗ 包内说明闸：\n  " + "\n  ".join(problems))
    n_param = len(json.loads(live_text)["params"])
    print("✓ 包内说明闸：sdk_info 的 sha256 = bin/%s 现算 ｜ %s = 库现场自报（%d 个参数）｜ %s 每个参数一行"
          % (row["lib"], PS.SCHEMA_FILE_NAME_STR, n_param, PS.DOC_FILE_NAME_STR))
    report["package_info_str"] = "ok_%d" % n_param
    run([str(find_artifact(row["probe"])), str(lib), version])
    run([sys.executable, str(REPO / "tests" / "test_c_abi.py"), "--lib", str(lib), "--version", version])
    run([sys.executable, str(REPO / "tests" / "test_golden.py"), "--lib", str(lib)])
    demo_dir = OUT / "smoke_c_demo"
    if demo_dir.exists():
        shutil.rmtree(demo_dir)
    run([str(find_artifact(row["demo"])), str(REPO / "tests" / "data" / "vertex_gray_box.glb"), str(demo_dir), "1"])
    n_demo = len(list(demo_dir.glob("*.bmp")))
    if n_demo <= 0:
        raise SystemExit("✗ 纯 C 示例说成功了，但一张 BMP 都没出")
    print("✓ 纯 C 示例真跑通过：%d 张 BMP" % n_demo)
    report["demo_slices_int"] = n_demo
    # ★409 对外命令行：lmst-cli 同构协议 + golden 全部经 CLI 逐字节（用**包里**那一份，不用构建目录里的）
    run([sys.executable, str(REPO / "tests" / "test_cli_contract.py"), "--cli", str(sdk / "bin" / row["cli"]), "--version", version])
    report["cli_contract_str"] = "ok"
    # ★393 交付清单闸：包里该有的都在吗？版本号四 / 五处一致吗？
    #   ⚠ 前面几道闸查的都是「做的对不对」，这一道查的是「做完了没有」—— 漏一个文件，前面全绿（B.1-43）
    res = DC.check(sdk, "full", package_name="%s-%s-%s" % (PACKAGE_NAME, version, row["tag"]))
    if not res["ok_bool"]:
        DC.report(res, "出包冒烟")
        raise SystemExit("✗ 交付清单闸没过 —— 不出包")
    print("✓ 交付清单闸：full 等级 %d 项齐全 ｜ 版本号 %s 处处一致（%s）"
          % (res["checked_int"], res["versions_dict"].get("dll 自报 GetVersion()", "?"),
             "、".join(k for k, v in res["versions_dict"].items() if v)))
    report["delivery_items_int"] = res["checked_int"]
    report["delivery_versions_dict"] = res["versions_dict"]
    return report


# ───────────────────────────── ⑤ 打包 ─────────────────────────────
def archive(sdk: Path, version: str, kind: str) -> Path:
    row = plat()
    base = "%s-%s-%s" % (PACKAGE_NAME, version, row["tag"])
    staging = OUT / "pack"
    if staging.exists():
        shutil.rmtree(staging)
    staging.mkdir(parents=True)
    shutil.copytree(sdk, staging / PACKAGE_NAME)
    if kind == "zip":
        path = Path(shutil.make_archive(str(OUT / base), "zip", str(staging), PACKAGE_NAME))
    elif kind == "tar.zst":
        path = OUT / (base + ".tar.zst")
        if shutil.which("zstd") is None:
            raise SystemExit("✗ 没装 zstd —— 产物格式是跨仓契约的一部分，这里不偷偷换成 .tar.gz")
        run(["tar", "--zstd", "-cf", str(path), "-C", str(staging), PACKAGE_NAME])
    else:
        raise SystemExit("✗ 不认识的打包格式 %r" % kind)
    print("  产物：%s（%.2f MB）" % (path, path.stat().st_size / 1048576.0))
    return path


def main(argv: Optional[List[str]] = None) -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    ap = argparse.ArgumentParser(description="水转印加网 SDK：一条命令出包")
    ap.add_argument("--version", default=os.environ.get("VERSION", "0.0.0-dev"),
                    help="版本号（CI 传 $VERSION；本地不传 = 0.0.0-dev）")
    ap.add_argument("--generator", default=os.environ.get("FRY_CMAKE_GENERATOR") or None, help="CMake 生成器（不给 = CMake 默认）")
    ap.add_argument("--skip-smoke", action="store_true", help="跳过冒烟（⚠ 只给排障用，CI 绝不许）")
    ap.add_argument("--no-archive", action="store_true", help="只装配不压缩")
    ap.add_argument("--python", default=None, help="（382 兼容参数，384 起不用）")
    ap.add_argument("--prebuilt-dir", default=None,
                    help="★409 不编译：用这个目录里现成的库 / 探针 / 示例 / 命令行做装配 + 冒烟 + 打包（在 A 机编、在本机验收）")
    ns = ap.parse_args(argv)
    global BUILDDIR
    if ns.prebuilt_dir:
        BUILDDIR = Path(ns.prebuilt_dir).resolve()
    t0 = time.perf_counter()
    steps: Dict[str, float] = {}
    last = [time.perf_counter()]

    def lap(name: str) -> None:
        now = time.perf_counter()
        steps[name] = round(now - last[0], 2)
        last[0] = now

    if ns.prebuilt_dir and not fry_payload.PAYLOAD_DIR.is_dir():
        # ★409 目标机验收包（tools/fry_target_kit.py）不带算法源码 ⇒ 这一步改查「预编件的指纹 = 锁文件」；
        #   库**自报**的指纹在④冒烟的指纹闸里再对一次（那一道原生编也跑）
        say("① 指纹闸（验收包不带源码）", "prebuilt_info.json 的算法指纹 = cpp.lock.json")
        lock = fry_payload.load_lock()
        pinfo_path = BUILDDIR / PREBUILT_INFO_NAME
        pinfo = json.loads(pinfo_path.read_text(encoding="utf-8")) if pinfo_path.is_file() else {}
        problem = prebuilt_fingerprint_problem(pinfo, lock)
        if problem:
            raise SystemExit("✗ " + problem)
        print("✓ 指纹一致：%s" % lock["tree_sha256_str"][:16])
    else:
        say("① 载荷闸", "cpp/ 与 cpp.lock.json 必须逐文件一致（换行符规范化后）")
        if fry_payload.do_check() != 0:
            return 1
        lock = fry_payload.load_lock()
    wrapper = wrapper_fingerprint()
    if ns.prebuilt_dir:
        pinfo_path = BUILDDIR / PREBUILT_INFO_NAME
        recorded = (json.loads(pinfo_path.read_text(encoding="utf-8")) if pinfo_path.is_file() else {}).get("wrapper_sha256_str", "")
        problem = prebuilt_wrapper_problem(recorded, wrapper)
        if problem:
            raise SystemExit("✗ " + problem)
        print("✓ 外壳指纹：%s…（%s）" % (recorded[:16], "预编件记录 = 当前源码" if wrapper else "预编件记录；本机没有外壳源码"))
        wrapper = recorded
    elif not wrapper:
        raise SystemExit("✗ 算不出外壳指纹：缺 %s 之一" % "、".join(WRAPPER_INPUT_LIST))
    lap("①载荷闸")

    if ns.prebuilt_dir:
        say("② 编译（跳过）", "★409 用现成二进制：%s" % BUILDDIR)
        missing = [plat()[k] for k in ("lib", "probe", "demo", "cli") if not any(p.is_file() for p in BUILDDIR.rglob(plat()[k]))]
        if missing:
            raise SystemExit("✗ --prebuilt-dir 里缺：%s" % "、".join(missing))
    else:
        say("② 编译", "CMake → %s（算法指纹由 CMake 从 cpp.lock.json 读）" % plat()["lib"])
        build_native(ns.version, ns.generator)
    lap("②编译")

    say("③ 装配", "bin/ + include/ + examples/ + VERSION + 参数说明（库自报）+ sdk_info（含 dll 的 sha256）")
    sdk = assemble(ns.version, lock)
    lap("③装配")

    smoke_report: Dict[str, Any] = {}
    if ns.skip_smoke:
        print("\n⚠⚠ 跳过了冒烟 —— 这个包**没有被验证过能跑**，别发出去")
    else:
        say("④ 冒烟", "导出面 → 包内说明 → 版本探针 → C 接口用例（含说明文件默认值 / 范围真跑）→ golden 逐字节 → 纯 C 示例")
        smoke_report = smoke(sdk, ns.version)
    lap("④冒烟")

    archive_path = None
    if not ns.no_archive:
        say("⑤ 打包", plat()["archive"])
        archive_path = archive(sdk, ns.version, plat()["archive"])
    lap("⑤打包")

    total = round(time.perf_counter() - t0, 1)
    facts = json.loads((sdk / "sdk_info.json").read_text(encoding="utf-8")) if (sdk / "sdk_info.json").is_file() else {}
    report = {"version_str": ns.version, "platform_str": plat()["tag"], "fingerprint_str": lock["tree_sha256_str"],
              "wrapper_sha256_str": wrapper,        # ★410 外壳指纹（cpp/ 之外会编进二进制的源码）：全交付目录拿它核对各平台
              "build_origin_str": (facts.get("integration_dict") or facts).get("build_origin_str", "native"),
              "min_os_str": (facts.get("integration_dict") or facts).get("min_os_str", ""),
              "host_str": "%s %s（%s）" % (platform.system(), platform.machine(), platform.platform()),
              "total_s_float": total, "step_s_dict": steps, "smoke_bool": not ns.skip_smoke, "smoke_dict": smoke_report,
              "sdk_mb_float": round(sum(p.stat().st_size for p in sdk.rglob("*") if p.is_file()) / 1048576.0, 2),
              "sdk_file_count_int": sum(1 for p in sdk.rglob("*") if p.is_file()),
              "archive_str": str(archive_path or ""),
              "archive_mb_float": round(archive_path.stat().st_size / 1048576.0, 2) if archive_path else 0.0}
    (OUT / "build_report.json").write_text(json.dumps(report, ensure_ascii=False, indent=1), encoding="utf-8")
    print("\n★ 逐步耗时：" + " ｜ ".join("%s %.1fs" % kv for kv in steps.items()))
    print("✓ 全部完成，用时 %.1f s ｜ 版本 %s ｜ 平台 %s" % (total, ns.version, plat()["tag"]))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
