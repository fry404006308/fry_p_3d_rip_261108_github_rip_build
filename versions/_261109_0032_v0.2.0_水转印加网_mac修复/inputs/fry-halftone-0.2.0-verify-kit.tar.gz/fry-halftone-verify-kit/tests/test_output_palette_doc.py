# -*- coding: utf-8 -*-
r"""test_output_palette_doc.py —— ★411 说明里的「BMP 像素值 → 材料」对照表必须与 C++ 源码一致（中英两份说明都查）。

为什么要有它：BMP 的调色板本身是灰度，同事只能**按像素值**认材料；这张表写错一行（例如把 5 写成白），
对方就会把黄墨当成白底 —— 而切片本身一个字节都没错、所有冒烟全绿（B.1-43 ⑩「测错了东西」的反面：说明错了没人测）。
真源：`cpp/src/output/assemble.h` 的材料编号 + `cpp/src/output/assemble.cpp` 的 `kPal`（材料编号 → 像素值）。
"""
from __future__ import annotations

import re
from pathlib import Path

import pytest

REPO = Path(__file__).resolve().parents[1]
ASM_CPP = REPO / "cpp" / "src" / "output" / "assemble.cpp"
ASM_H = REPO / "cpp" / "src" / "output" / "assemble.h"
needs_cpp = pytest.mark.skipif(not ASM_CPP.is_file(), reason="没有 C++ 载荷（先同步算法仓）")


def source_table() -> dict:
    """{像素值: 材料代号}，从 C++ 源码现算。"""
    pal = [int(x) for x in re.search(r"kPal\[8\]\s*=\s*\{([^}]*)\}", ASM_CPP.read_text(encoding="utf-8")).group(1).split(",")]
    names = dict((int(n), tok) for tok, n in re.findall(r"(\w+) (\d)", ASM_H.read_text(encoding="utf-8").split("材料：", 1)[1].split("；", 1)[0]))
    assert sorted(names) == list(range(8)) and len(pal) == 8, (names, pal)
    return {pal[ch]: tok for ch, tok in names.items()}


def doc_table(text: str, title: str, token) -> dict:
    sec = text.replace("\r\n", "\n").split(title, 1)[1].split("\n#", 1)[0]
    rows = {}
    for ln in sec.splitlines():
        cells = [c.strip() for c in ln.strip().strip("|").split("|")]
        if len(cells) >= 2 and cells[0].isdigit():
            rows[int(cells[0])] = token(cells[1])
    return rows


CN_TOKEN = lambda cell: re.search(r"（(\w+)）", cell).group(1)            # noqa: E731   青（C） → C
EN_TOKEN = lambda cell: cell.split()[0]                                    # noqa: E731   C (cyan) → C
DOCS = [("SDK_使用说明.md", "★411 BMP 像素值（调色板索引）→ 材料", CN_TOKEN),
        ("SDK_README_EN.md", "★411 Output: BMP pixel value (palette index) → material", EN_TOKEN)]


@needs_cpp
@pytest.mark.parametrize("name,title,token", DOCS)
def test_doc_palette_table_equals_cpp_source(name, title, token):
    want = source_table()
    text = (REPO / "docs" / name).read_text(encoding="utf-8")
    assert doc_table(text, title, token) == want
    # 「其余值不会出现」那一句也从源码算：16 个索引里没用到的那几个
    unused = sorted(set(range(16)) - set(want))
    sep = "、" if name.endswith("说明.md") else ", "
    assert sep.join(str(v) for v in unused) in text, unused


@needs_cpp
def test_source_parser_is_not_blind():
    """反向：把源码里的对照改掉一位，比对必须失败（证明这道闸真的在逐项比，不是永远绿）。"""
    want = source_table()
    assert want[5] == "Y" and want[9] == "White" and want[0] == "Null"
    bad = dict(want)
    bad[5], bad[9] = bad[9], bad[5]                                        # 黄 ↔ 白 对调：最像真的那种写错
    text = (REPO / "docs" / "SDK_使用说明.md").read_text(encoding="utf-8")
    assert doc_table(text, DOCS[0][1], CN_TOKEN) != bad
