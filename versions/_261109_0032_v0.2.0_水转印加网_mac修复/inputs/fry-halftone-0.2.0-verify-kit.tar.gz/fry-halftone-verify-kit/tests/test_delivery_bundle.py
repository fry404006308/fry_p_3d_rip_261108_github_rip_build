# -*- coding: utf-8 -*-
r"""test_delivery_bundle.py —— ★410/411 全交付目录（tools/fry_delivery_bundle.py）的闸，两个方向都验。

① 正向：三个平台齐全 ⇒ 目录结构、**展开的包**（与包里 SHA256SUMS 逐个核对）、各平台集成说明、对接文档（include/ examples/
   接口速查 命令行速查）、示例输出、验收证据、版本记录、清单、SHA256SUMS 都对，复查通过；
② ★ 反向（坏法 × 闸）：每一种「拷错 / 没验过 / 被动过 / 版本号倒退 / 同号换字节 / 实测的不是这个包」都必须**单独**让它拒绝；
③ 说明里的数与文字**从上游现算**：golden 件数、接口签名（头文件）、返回码含义（使用说明）、参数表（参数说明）、`--help`（真跑输出）；
④ 目录名 `_YYMMDD_HHMM_主题`（默认主题带版本号），同一分钟再跑一次不覆盖（_2）；--dry-run 一个文件都不写；
⑤ 复查：交付目录里的文件被改 / 多出清单外的文件 ⇒ 复查报出来；整包 zip 记 UTF-8 文件名与 Unix 权限；
⑥ main：成功后把版本号记进 delivery_versions.json；同一批包可以再出一次目录；换了字节就拒绝；
⑦ fry_release --bundle 的计划（纯函数）。
示例输出（要真跑 Windows 命令行）在这里用假的 run_sample 代替；真跑的那条路由出包后的交付实测覆盖（docs 411）。
"""
from __future__ import annotations

import hashlib
import io
import json
import re
import struct
import sys
import tarfile
import time
import zipfile
from pathlib import Path

import pytest

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO / "tools"))
import fry_delivery_bundle as B  # noqa: E402
import fry_delivery_contract as DC  # noqa: E402
import fry_delivery_version as DV  # noqa: E402
import fry_integration_guide as G  # noqa: E402
import fry_surface as SF  # noqa: E402

V = "0.3.7"
FP = "ab" * 32
MD5 = "cd" * 16
SCHEMA = b'{"schema_str": "fry-halftone-params/3", "params": []}'
LIB_SHA = {"win": "11" * 32, "linux_prebuilt": "22" * 32, "linux_native": "33" * 32}   # 各平台交付 SDK 里 sdk_info 记的库 sha256

HEADER = """#ifndef FRY_HALFTONE_H
#define FRY_HALFTONE_H
#  define FRY_API FRY_EXTERN_C __attribute__((visibility("default")))
#define FRY_HALFTONE_OK             0   /* 成功                                        success            */
#define FRY_HALFTONE_BUSY           6   /* 已经有一个作业在跑                          another job running*/
FRY_API const char* FRY_CALL FryHalftone_GetVersion(void);
FRY_API int FRY_CALL FryHalftone_SliceModelJsonUtf8(const char* requestJson,
                                                    char* resultBuffer, int resultBufferSize);
#endif
"""
USAGE = """# SDK 使用说明

## 四、接口一览

| 函数 | 作用 |
| --- | --- |
| `FryHalftone_GetVersion()` | 版本号（测试文档） |
| `FryHalftone_SliceModelJsonUtf8` | 参数走 JSON（测试文档） |

### 返回码

| 值 | 名字 | 含义 |
| ---: | --- | --- |
| 0 | `FRY_HALFTONE_OK` | 成功（文档版） |
| 6 | `FRY_HALFTONE_BUSY` | 已经有一个作业在跑（文档版） |

## 五、下一节
"""
CHANGELOG = ("# CHANGELOG\n\n## 未发布\n\n%s\n\n## %s（2026-09-23）\n\n### ★测试变更一\n- 细节\n\n### ★测试变更二\n- 细节\n"
             % (DV.PLACEHOLDER, V))
PARAM_DOC = "# 参数说明\n\n## 一、参数表 / Parameters\n\n| # | 参数 |\n| --- | --- |\n| 1 | `target_height_mm` |\n\n## 二、别的\n"
HELP = ("fry-halftone-cli —— 测试帮助\n\nUsage:\n"
        "  fry-halftone-cli slice <input-model> --out <directory> --target-longest-edge <mm> [--json]\n"
        "  fry-halftone-cli run <request.json> [--json]\n  fry-halftone-cli --version | --help\n")
# 与 HELP 一致的命令行源码（★412 两把尺子：源码解析 = 真跑 --help）
CLI_SRC = ('if (a[1] == "--help" || a[1] == "help") {}\nif (a[1] == "--version") {}\nif (a[1] == "slice") {}\nif (a[1] == "run") {}\n'
           'if (k == "--out") {}\nelse if (k == "--target-longest-edge") {}\nif (k == "--json") {}\n')
# ★412 三个示例（与 B.SAMPLES 同名的 golden 件）+ 每个示例的像素值（7 只在黑墨；9 在黑墨与白底两个里）
SAMPLE_CASES = [
    {"name_str": "gltf_modes_mix_l12", "model_str": "gltf_modes_mix.glb", "params_dict": {"target_longest_edge_mm": 12.0},
     "bmp_md5_str": MD5, "slice_count_int": 3},
    {"name_str": "sphere_l5_k400_amt05_band08", "model_str": "gray_ramp_sphere.glb",
     "params_dict": {"target_longest_edge_mm": 5.0, "use_black_k": True, "ink_k_um": 400.0, "black_k_amount": 0.5, "color_thickness_mm": 0.8},
     "bmp_md5_str": "e1" * 16, "slice_count_int": 2},
    {"name_str": "sphere_l5_white_nosup_w64", "model_str": "gray_ramp_sphere.glb",
     "params_dict": {"target_longest_edge_mm": 5.0, "band_uninked_fill": "white", "support_enable": False, "output_width_px": 64},
     "bmp_md5_str": "e2" * 16, "slice_count_int": 2},
]
SAMPLE_PIXELS = {"1_默认参数": [[0, 1, 3], [5, 11, 13]], "2_黑墨K": [[0, 1, 7, 9], [5, 11, 13, 9]], "3_白底填充": [[0, 1, 3, 0], [5, 9, 9, 0]]}
# ★412 与真件同构：7 只在黑墨示例；9 在黑墨示例（真件球心默认是白，467,577 个）和白底示例里都有 —— 第一版这里只让 9 出现在白底示例，
#   于是说明里写死的「9 只在白底示例里有」也跟着全绿（假数据复述了我的假设；D.1-15）
# ★412 白底示例给了 output_width_px（真件：64 > 原生 45）⇒ BMP 比原生网格宽，右边补的列是 0（空）；库自报的体素数不含补边
SAMPLE_NATIVE_W = {"3_白底填充": 3}
MAT_OF = {0: "null", 1: "c", 3: "m", 5: "y", 7: "k", 9: "white", 11: "transparent", 13: "support"}


def _w(p: Path, data) -> Path:
    p.parent.mkdir(parents=True, exist_ok=True)
    if isinstance(data, (dict, list)):
        p.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
    elif isinstance(data, bytes):
        p.write_bytes(data)
    else:
        p.write_text(data, encoding="utf-8", newline="\n")
    return p


def sha(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


# 原样随包的文件（包内路径 → 内容）：按 fry_build 的唯一真源展开（examples/ 下放两个文件）
SHIPPED = {rel: ("随包 %s\n" % rel).encode("utf-8") for rel in B.fry_build.SHIPPED_VERBATIM_DICT}
SHIPPED.update({"include/fry_halftone.h": HEADER.encode("utf-8"), "SDK_使用说明.md": USAGE.encode("utf-8"),
                "CHANGELOG.md": CHANGELOG.encode("utf-8"),
                "examples/c/demo.c": b"int main(){}\n", "examples/python/demo.py": b"print(1)\n"})


def tiny_bmp(w: int = 4, h: int = 2) -> bytes:
    row = ((w * 4 + 31) // 32) * 4
    off = 14 + 40 + 64
    return (b"BM" + struct.pack("<IHHI", off + row * h, 0, 0, off)
            + struct.pack("<IiiHHIIiiII", 40, w, h, 1, 4, 0, row * h, 0, 0, 16, 0) + b"\0" * (64 + row * h))


def make_kit(path: Path, shipped: dict) -> Path:
    """真的 tar.gz：验收包里存的是**仓库路径**（docs/…、packaging/…），与 fry_target_kit 同形；带一份 README_验收.md。"""
    path.parent.mkdir(parents=True, exist_ok=True)
    members = {"fry-halftone-verify-kit/" + B.repo_rel_of(rel): data for rel, data in shipped.items()}
    members["fry-halftone-verify-kit/README_验收.md"] = "# 验收包说明（测试）\n".encode("utf-8")
    with tarfile.open(path, "w:gz") as tf:
        for name, data in members.items():
            ti = tarfile.TarInfo(name)
            ti.size = len(data)
            tf.addfile(ti, io.BytesIO(data))
    return path


def make_sdk(d: Path, platform_: str, lib_sha: str, shipped=None) -> Path:
    """一个结构真实的 SDK 目录（封好包：SHA256SUMS 最后写）。"""
    for rel, data in (shipped or SHIPPED).items():
        _w(d / rel, data)
    _w(d / "params_schema.json", SCHEMA)
    _w(d / "SDK_参数说明.md", PARAM_DOC)
    _w(d / "VERSION", V + "\n")
    _w(d / "sdk_info.json", {"library_sha256_str": lib_sha, "version_str": V, "algorithm_fingerprint_str": FP})
    if platform_ == "win":
        _w(d / "bin" / "fry_halftone.dll", b"MZ fake dll")
        _w(d / "bin" / "fry-halftone-cli.exe", b"MZ fake cli")
        _w(d / "lib" / "fry_halftone.lib", b"!<arch> fake")
    else:
        _w(d / "bin" / "libfry_halftone.so", b"\x7fELF fake so")
        _w(d / "bin" / "fry-halftone-cli", b"\x7fELF fake cli")
    DC.write_sums(d)
    return d


def zip_sdk(sdk: Path, zp: Path) -> Path:
    zp.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as zf:
        for p in sorted(sdk.rglob("*")):
            if p.is_file():
                zf.write(p, "fry-halftone/" + p.relative_to(sdk).as_posix())
    return zp


def tar_zst_sdk(sdk: Path, dst: Path) -> Path:
    """真的 .tar.zst（与 Linux 包同形：顶层 fry-halftone/，GNU 格式，文件名 UTF-8）。"""
    zstandard = pytest.importorskip("zstandard")
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode="w", format=tarfile.GNU_FORMAT) as tf:
        for p in sorted(sdk.rglob("*")):
            if p.is_file():
                ti = tarfile.TarInfo("fry-halftone/" + p.relative_to(sdk).as_posix())
                data = p.read_bytes()
                ti.size, ti.mode = len(data), 0o777              # 与真包一样：DrvFs 上打的，全是 0777
                tf.addfile(ti, io.BytesIO(data))
    dst.parent.mkdir(parents=True, exist_ok=True)
    dst.write_bytes(zstandard.ZstdCompressor().compress(buf.getvalue()))
    return dst


def _fake_wrapper_sources(repo: Path) -> str:
    """造外壳源码（与 fry_build.WRAPPER_INPUT_LIST 一一对应），返回它现算的外壳指纹。
    ★412 头文件与命令行源码写真实形状（对外接口面从这里解析，要与交付的头文件 / 真跑 --help 一致）。"""
    for rel in B.fry_build.WRAPPER_INPUT_LIST:
        if Path(rel).suffix:
            _w(repo / rel, "// %s\n" % rel)
        else:
            _w(repo / rel / "a.cpp", "int a;\n")
    _w(repo / "include" / "fry_halftone.h", HEADER)
    _w(repo / "src" / "cli" / "fry_halftone_cli.cpp", CLI_SRC)
    return B.fry_build.wrapper_fingerprint(repo)


def _report(platform_str: str, delivery: int, **over) -> dict:
    rep = {"version_str": V, "platform_str": platform_str, "fingerprint_str": FP, "min_os_str": "测试系统（实测）",
           "host_str": "测试宿主", "build_origin_str": "测试", "smoke_bool": True,
           "smoke_dict": {"export_surface_str": "ok_11", "cli_contract_str": "ok", "delivery_items_int": delivery}}
    rep.update(over)
    return rep


def make_tree(tmp: Path, golden_n: int = 7, linux_modes=("prebuilt",), shipped=None) -> tuple:
    """造一个最小但**结构真实**的仓库 + out/：Windows 包 + SDK、Linux 包 + SDK + 报告、macOS 验收包 + kit_info、交叉编译报告。"""
    repo = tmp / "repo"
    out = repo / "out"
    _w(repo / "cpp.lock.json", {"tree_sha256_str": FP})
    cases = [dict(c) for c in SAMPLE_CASES] + [{"name_str": "c%d" % i} for i in range(golden_n - len(SAMPLE_CASES))]
    _w(repo / "tests" / "data" / "golden.json", {"case_list": cases})
    for c in SAMPLE_CASES:
        _w(repo / "tests" / "data" / c["model_str"], b"glTF fake")
    wr = _fake_wrapper_sources(repo)
    assert len(wr) == 64
    _w(out / "build_report.json", _report("win32-x64", 18, wrapper_sha256_str=wr))
    sdk = make_sdk(out / "sdk" / "fry-halftone-sdk", "win", LIB_SHA["win"], shipped)
    zip_sdk(sdk, out / ("fry-halftone-%s-win32-x64.zip" % V))
    for mode in linux_modes:
        d = out / "linux" / mode
        _w(d / "build_report.json", _report("linux-x64", 17, min_os_str="glibc ≥ 2.17（实测：GLIBC_2.17）x86-64",
                                            wrapper_sha256_str=wr))
        lsdk = make_sdk(d / "sdk", "linux", LIB_SHA["linux_" + mode], shipped)
        tar_zst_sdk(lsdk, d / ("fry-halftone-%s-linux-x64.tar.zst" % V))
        _w(d / "linux_env.json", {"os_str": "Debian 13", "glibc_str": "glibc 2.41", "kernel_str": "6.x-WSL2"})
    kit = make_kit(out / "kit" / ("fry-halftone-%s-verify-kit.tar.gz" % V), shipped or SHIPPED)
    _w(out / "kit" / "kit_info.json", {
        "version_str": V, "algorithm_fingerprint_str": FP, "wrapper_sha256_str": wr, "verified_on_target_bool": False,
        "kit_sha256_str": sha(kit),
        "targets_dict": {"macos-arm64": {"min_os_str": "macOS 13.0"}, "macos-x64": {"min_os_str": "macOS 13.0"},
                         "linux-x64": {"min_os_str": "glibc 2.17"}}})
    _w(out / "cross" / "cross_info.json", {"targets_list": [{"target_str": "macos-arm64", "ok_bool": True, "static_problems_list": [],
                                                             "binaries_dict": {"x": {"huge": 1}}}]})
    return repo, out


def fake_run_sample(win_sdk: Path, spec: dict, case: dict, model: Path, dest: Path, md5: str = "", leaks=(),
                    counts_over=None, ok: bool = True) -> dict:
    """假的示例（真的要跑 Windows 命令行）：按示例写 BMP（像素值见 SAMPLE_PIXELS）+ 元数据（各材料计数 = 像素数）+ JSON 事件。"""
    dest.mkdir(parents=True, exist_ok=True)
    _w(dest / model.name, b"glTF fake")
    args, req = B.sample_command(spec, case)
    if req is not None:
        _w(dest / "request.json", req)
    rows = SAMPLE_PIXELS[spec["key_str"]]
    n = case["slice_count_int"]
    sl = dest / "slices"
    for i in range(n):
        _w(sl / ("%06d.bmp" % i), bmp4(rows))
    # ★412 与真库同构：给了 output_width_px（比原生宽）⇒ BMP 右边多出的列是 0，库只数原生网格里的体素
    nat_w = SAMPLE_NATIVE_W.get(spec["key_str"], len(rows[0]))
    counts = {m: 0 for m in MAT_OF.values()}
    for r in rows:
        for val in r[:nat_w]:
            counts[MAT_OF[val]] += n
    counts.update(counts_over or {})
    _w(sl / "slice_metadata.json", {"slice_count_int": n, "sdk_version_str": V, "material_count_dict": counts,
                                    "output_width_px_int": len(rows[0]), "native_width_px_int": nat_w,
                                    "grid_list": [nat_w, len(rows), n]})
    ev = [{"type": "progress", "percent": 50, "stage": "测试"},
          {"type": "result", "result": {"success": ok, "sliceCount": n, "outputDirectory": "<示例目录>\\slices",
                                        "sdkResult": {"bmpMd5": md5 or case["bmp_md5_str"]}}}]
    return {"spec_dict": spec, "case_str": case["name_str"], "model_str": model.name, "ok": ok, "rc_int": 0 if ok else 11,
            "seconds_float": 0.1, "args_list": args, "request_dict": req, "events_list": ev, "stderr_str": "",
            "result_dict": ev[-1]["result"], "slice_dir": sl, "path_leaks_list": list(leaks),
            "edge_mm_float": case["params_dict"].get("target_longest_edge_mm")}


def fake_capture_cli_texts(win_sdk: Path, dest: Path, version: str = V, help_str: str = HELP) -> dict:
    dest.mkdir(parents=True, exist_ok=True)
    _w(dest / "命令行_help.txt", help_str)
    _w(dest / "命令行_info.json", '{"name":"fry-halftone-cli"}\n')
    return {"ok": True, "help_str": help_str, "info_str": '{"name":"fry-halftone-cli"}', "version_str": "fry-halftone-cli %s" % version}


@pytest.fixture(autouse=True)
def _no_real_cli(monkeypatch):
    monkeypatch.setattr(B, "run_sample", fake_run_sample)
    monkeypatch.setattr(B, "capture_cli_texts", fake_capture_cli_texts)


def _parity(tmp: Path, **over) -> Path:
    """410 格式的一致性证据：记了每个平台跑的是哪份库（lib_sha256_dict）与库自报的算法指纹。"""
    s = {"model_count": 54, "edge_mm": 10.0, "total_slices_win": 39486, "all_identical": True,
         "pair_identical_models": {"win=linux_prebuilt": 54},
         "rc_nonzero": {"m24.glb": {"win": 11}},
         "cli_versions": {"win": "fry-halftone-cli %s" % V, "linux_prebuilt": "fry-halftone-cli %s" % V},
         "lib_sha256_dict": {"win": LIB_SHA["win"], "linux_prebuilt": LIB_SHA["linux_prebuilt"]},
         "algorithm_fingerprint_dict": {"win": FP, "linux_prebuilt": FP}}
    s.update(over)
    return _w(tmp / ("parity_%d.json" % len(list(tmp.glob("parity_*.json")))), {"summary": s, "rows": []})


def _integ(tmp: Path, out: Path, skip_cs: bool = False, **over) -> Path:
    """★411 集成命令实测结果（与 tools/fry_integration_check.py 同形）。"""
    win = {s["key"]: {"ok": True, "rc_int": 0} for s in G.STEPS["win32-x64"]["steps"]}
    if skip_cs:
        for k in [k for k in win if k.startswith("cs_")]:
            win[k] = {"ok": None, "skipped_bool": True, "why_str": "本机没有 .NET SDK"}
    lin = {s["key"]: {"ok": True, "rc_int": 0} for s in G.STEPS["linux-x64"]["steps"]}
    d = {"version_str": V, "all_ok_bool": True,
         "package_sha256_dict": {"win32-x64": sha(out / ("fry-halftone-%s-win32-x64.zip" % V)),
                                 "linux-x64": sha(out / "linux" / "prebuilt" / ("fry-halftone-%s-linux-x64.tar.zst" % V))},
         "windows": {"where_str": "测试 Windows", "steps_dict": win}, "linux": {"where_str": "测试 Linux", "steps_dict": lin}}
    d.update(over)
    return _w(tmp / ("integ_%d.json" % len(list(tmp.glob("integ_*.json")))), d)


def _bundle(tmp: Path, repo: Path, out: Path, **kw) -> Path:
    inp, probs = B.collect(out, kw.get("modes", ["prebuilt"]), kw.get("parity", []), repo, kw.get("integration"))
    assert probs == []
    dest = B.unique_dir(out / B.BUNDLE_ROOT_NAME, "_260923_1852_测试")
    man = B.build(inp, dest, [], B.expected_counts(repo))
    assert man["build_problems_list"] == [], man["build_problems_list"]
    return dest


def _read(dest: Path, rel: str) -> str:
    return (dest / rel).read_text(encoding="utf-8")


# ───────────────────────────── ① 正向 ─────────────────────────────
def test_happy_path_layout_and_checksums(tmp_path):
    repo, out = make_tree(tmp_path)
    dest = _bundle(tmp_path, repo, out)
    for d in B.DIRS.values():
        assert (dest / d).is_dir(), d
    must = ["00_先读我_交付说明.md", "bundle_manifest.json", "SHA256SUMS.txt",
            "01_Windows_x64/fry-halftone-%s-win32-x64.zip" % V,
            "02_Linux_x64/fry-halftone-%s-linux-x64.tar.zst" % V,
            "03_macOS_需在Mac上验收/fry-halftone-%s-verify-kit.tar.gz" % V,
            # ★411 展开的包：include / lib / examples / 说明直接可见
            "01_Windows_x64/fry-halftone/include/fry_halftone.h", "01_Windows_x64/fry-halftone/lib/fry_halftone.lib",
            "01_Windows_x64/fry-halftone/bin/fry_halftone.dll", "01_Windows_x64/fry-halftone/examples/c/demo.c",
            "01_Windows_x64/fry-halftone/SDK_使用说明.md", "01_Windows_x64/fry-halftone/SHA256SUMS.txt",
            "02_Linux_x64/fry-halftone/bin/libfry_halftone.so", "02_Linux_x64/fry-halftone/SDK_参数说明.md",
            # ★411 各平台集成说明 + 给业务的说明
            "01_Windows_x64/Windows_集成说明.md", "01_Windows_x64/给业务_使用说明.md", "02_Linux_x64/Linux_集成说明.md",
            "03_macOS_需在Mac上验收/macOS验收步骤.md", "03_macOS_需在Mac上验收/macOS_集成说明.md",
            "03_macOS_需在Mac上验收/验收包说明_README_验收.md",
            # 对接文档：说明副本 + include/ + examples/ + 速查
            "04_对接文档/SDK_使用说明.md", "04_对接文档/params_schema.json", "04_对接文档/include/fry_halftone.h",
            "04_对接文档/examples/python/demo.py", "04_对接文档/接口速查.md", "04_对接文档/命令行速查.md",
            # 示例输出
            "05_示例输出/示例说明.md", "05_示例输出/命令行_help.txt", "05_示例输出/命令行_info.json",
            "05_示例输出/1_默认参数/slices/000000.bmp", "05_示例输出/1_默认参数/slices/slice_metadata.json",
            "05_示例输出/1_默认参数/示例说明.md", "05_示例输出/1_默认参数/gltf_modes_mix.glb",
            "05_示例输出/2_黑墨K/request.json", "05_示例输出/2_黑墨K/slices/000001.bmp", "05_示例输出/3_白底填充/request.json",
            "06_验收证据/build_report_windows.json", "06_验收证据/build_report_linux_prebuilt.json",
            "06_验收证据/linux_env_prebuilt.json", "06_验收证据/macos_verify_kit_info.json", "06_验收证据/cross_static_gate.json",
            "07_版本记录/版本记录.md", "07_版本记录/本版变更.md"]
    for rel in must:
        assert (dest / rel).is_file(), rel
    # 包的字节 = out/ 里那一份（拷的就是验过的那一份）；展开的 = 包里的（按包里的 SHA256SUMS 逐个对过）
    assert (dest / must[3]).read_bytes() == (out / ("fry-halftone-%s-win32-x64.zip" % V)).read_bytes()
    assert (dest / "01_Windows_x64/fry-halftone/include/fry_halftone.h").read_bytes() == HEADER.encode("utf-8")
    assert B.check_extracted(dest / "01_Windows_x64/fry-halftone") == []
    assert B.check_extracted(dest / "02_Linux_x64/fry-halftone") == []
    assert B.recheck(dest) == []
    lines = (dest / "SHA256SUMS.txt").read_text(encoding="utf-8").splitlines()
    n_files = sum(1 for p in dest.rglob("*") if p.is_file())
    assert len(lines) == n_files - 1                                  # 除了它自己，每个文件一行（展开包里的 SUMS 也列）
    man = json.loads(_read(dest, "bundle_manifest.json"))
    assert [r["status"] for r in man["packages_list"]] == ["verified", "verified", "pending_mac_verification"]
    assert man["algorithm_fingerprint_str"] == FP and man["version_str"] == V and man["previous_version_str"] == ""
    assert man["samples_list"][0] == {"key_str": "1_默认参数", "golden_case_str": "gltf_modes_mix_l12", "slices_int": 3,
                                      "bmp_md5_str": MD5, "pixel_values_list": [0, 1, 3, 5, 11, 13],
                                      # ★412 同事角度复验照清单里这条命令跑（= 示例说明里写给同事的那条）
                                      "model_str": "gltf_modes_mix.glb",
                                      "command_list": ["slice", "gltf_modes_mix.glb", "--target-longest-edge", "12", "--out", "slices", "--json"]}
    assert man["samples_list"][1]["command_list"] == ["run", "request.json", "--json"]
    assert [s["key_str"] for s in man["samples_list"]] == ["1_默认参数", "2_黑墨K", "3_白底填充"]
    assert json.loads(_read(dest, "05_示例输出/2_黑墨K/request.json"))["params"]["use_black_k"] is True
    slim = json.loads(_read(dest, "06_验收证据/cross_static_gate.json"))
    assert "binaries_dict" not in slim[0] and slim[0]["ok_bool"] is True


def test_readme_is_rich_and_comes_from_upstream(tmp_path):
    """★411「信息尽量多」：说明里的接口 / 返回码 / 参数 / 命令行帮助 / 输出格式 / 本版变更都从随包原文与真跑输出生成。"""
    repo, out = make_tree(tmp_path)
    dest = _bundle(tmp_path, repo, out)
    readme = _read(dest, "00_先读我_交付说明.md")
    for needle in (FP, "v%s" % V, "首个编号交付版", "★测试变更一", "★测试变更二",                  # 版本与本版变更（CHANGELOG 那一节）
                   "FryHalftone_GetVersion", "const char* FryHalftone_GetVersion(void)", "版本号（测试文档）",   # 接口：头文件 + 使用说明
                   "int FryHalftone_SliceModelJsonUtf8(const char* requestJson, char* resultBuffer, int resultBufferSize)",
                   "成功（文档版）", "another job running",                                          # 返回码：使用说明的中文 + 头文件的英文
                   "`target_height_mm`",                                                             # 参数表：库自报说明
                   HELP,                                                                             # --help：真跑输出
                   "宽 3 × 高 2 像素，4 位调色板（16 色）",                                            # BMP 格式：读的真文件
                   "slice_count", "= 标准答案",
                   "01_Windows_x64/fry-halftone/", "bin/fry-halftone-cli", "done. slices=N", "⏳", "✅", "English",
                   "也带 linux-x64 的目标", "chmod +x"):
        assert needle in readme, needle
    for cmd in (G.STEPS["win32-x64"]["steps"][3]["cmd"], G.STEPS["linux-x64"]["steps"][3]["cmd"]):      # C 编译命令 = 唯一真源
        assert cmd.replace("|", "\\|") in readme, cmd
    wr = B.fry_build.wrapper_fingerprint(repo)
    guide = _read(dest, "03_macOS_需在Mac上验收/macOS验收步骤.md")
    assert wr in readme and '"wrapper_sha256_str": "%s"' % wr in guide
    for needle in ("run_on_target.sh --also-x64", "退出码 = 0", "✓ macos-arm64：可交付", "SHA256SUMS.txt", FP, "v%s" % V,
                   "xcode-select --install", "brew install zstd", "com.apple.quarantine", "results/", "darwin-arm64",
                   "macOS_集成说明.md"):
        assert needle in guide, needle
    assert "\r" not in guide and "\r" not in readme
    api = _read(dest, "04_对接文档/接口速查.md")
    assert "FryHalftone_SliceModelJsonUtf8" in api and "成功（文档版）" in api and "another job running" in api
    assert HELP in _read(dest, "04_对接文档/命令行速查.md")
    assert "★测试变更一" in _read(dest, "07_版本记录/本版变更.md")
    rec = _read(dest, "07_版本记录/版本记录.md")
    assert "| **%s** |" % V in rec and "首个编号交付版" in rec


def test_api_rows_skip_macro_definitions():
    """头文件前面 `#  define FRY_API …` 那几行也含 FRY_API：不锚行首会把宏定义吞进第一个函数的返回类型。"""
    rows = B.api_rows(HEADER, USAGE)
    assert [r[0] for r in rows] == ["FryHalftone_GetVersion", "FryHalftone_SliceModelJsonUtf8"]
    assert rows[0][1] == "const char* FryHalftone_GetVersion(void)" and rows[0][2] == "版本号（测试文档）"
    rcs = B.return_code_rows(HEADER, USAGE)
    assert rcs == [("0", "FRY_HALFTONE_OK", "成功（文档版）", "success"), ("6", "FRY_HALFTONE_BUSY", "已经有一个作业在跑（文档版）",
                                                                         "another job running")]
    assert B.return_code_rows(HEADER)[0][2] == "成功"                 # 没有使用说明就退回头文件的中文注释


def test_doc_section_refs_are_rewritten():
    """从使用说明原样取来的「见第六节」指的是**那份文档**的章节；放进交付说明必须改写，否则读者翻到交付说明自己的第六节。"""
    usage = USAGE.replace("参数走 JSON（测试文档）", "参数走 JSON（见第五节）").replace("成功（文档版）", "成功（见第十二节）")
    rows = B.api_rows(HEADER, usage)
    assert rows[1][2] == "参数走 JSON（见 `SDK_使用说明.md` 第五节）"
    assert B.return_code_rows(HEADER, usage)[0][2] == "成功（见 `SDK_使用说明.md` 第十二节）"


def _kit_report(out: Path, tmp: Path, **over) -> Path:
    rep = _report("linux-x64", 17, wrapper_sha256_str=B.fry_build.wrapper_fingerprint(out.parent), host_str="Linux x86_64（测试 WSL2）")
    rep.update(over)
    return _w(tmp / "kit_linux_report.json", rep)


def test_kit_linux_report_goes_into_readme_and_mac_guide(tmp_path):
    """★411 验收包在真 Linux 上跑通的报告：过闸后写进说明与 Mac 验收步骤（Mac 上跑的是同一个脚本），并进 06_验收证据/。"""
    repo, out = make_tree(tmp_path)
    inp, probs = B.collect(out, ["prebuilt"], [], repo, None, _kit_report(out, tmp_path))
    assert probs == []
    dest = B.unique_dir(out / B.BUNDLE_ROOT_NAME, "_260923_1852_kit")
    B.build(inp, dest, [], B.expected_counts(repo))
    readme = _read(dest, "00_先读我_交付说明.md")
    assert "同一个验收包、同一个 `run_on_target.sh`" in readme and "测试 WSL2" in readme
    assert "这套流程我们已经在真 Linux 上完整跑通过" in _read(dest, "03_macOS_需在Mac上验收/macOS验收步骤.md")
    assert (dest / "06_验收证据" / B.KIT_LINUX_REPORT_NAME).is_file()
    # 06_验收证据 逐文件说明
    assert "| `build_report_windows.json` | Windows 出包报告" in readme and "| `%s` |" % B.KIT_LINUX_REPORT_NAME in readme


@pytest.mark.parametrize("over,needle", [
    ({"version_str": "0.3.6"}, "版本"),
    ({"smoke_bool": False}, "冒烟"),
    ({"fingerprint_str": "ef" * 32}, "指纹"),
    ({"platform_str": "darwin-arm64"}, "不是 Linux 目标"),
])
def test_kit_linux_report_must_be_this_kit_and_green(tmp_path, over, needle):
    repo, out = make_tree(tmp_path)
    probs = B.collect(out, ["prebuilt"], [], repo, None, _kit_report(out, tmp_path, **over))[1]
    assert any(needle in p for p in probs), probs


PALETTE_MD = """
### ★411 BMP 像素值（调色板索引）→ 材料

| 像素值 | 材料 | 打印机喷不喷 | 什么时候出现 |
| ---: | --- | --- | --- |
| 0 | 空（Null） | 不喷 | 模型外 |
| 1 | 青（C） | 喷 | 彩墨 |
| 3 | 品红（M） | 喷 | 彩墨 |
| 5 | 黄（Y） | 喷 | 彩墨 |
| 7 | 黑（K） | 喷 | 彩墨 |
| 9 | 白（White） | 喷 | 白底 |
| 11 | 透明（Transparent） | 喷 | 透明壳 |
| 13 | 支撑（Support） | 喷 | 支撑 |

## 八、下一节
"""


def bmp4(rows) -> bytes:
    """4 位 BMP（自下而上存行）：rows[0] 是最上面一行；宽可以是奇数（最后一个字节的低半字节是补齐）。"""
    h, w = len(rows), len(rows[0])
    stride = ((w * 4 + 31) // 32) * 4
    data = b""
    for r in reversed(rows):
        vals = list(r) + [0] * (w % 2)
        line = bytes((vals[i] << 4) | vals[i + 1] for i in range(0, len(vals), 2))
        data += line + b"\0" * (stride - len(line))
    off = 14 + 40 + 64
    pal = b"".join(bytes((g, g, g, 255)) for g in range(0, 256, 17))
    return (b"BM" + struct.pack("<IHHI", off + len(data), 0, 0, off)
            + struct.pack("<IiiHHIIiiII", 40, w, h, 1, 4, 0, len(data), 0, 0, 16, 0) + pal + data)


def test_palette_usage_counts_pixels_not_padding(tmp_path):
    _w(tmp_path / "000000.bmp", bmp4([[1, 5, 5], [9, 0, 1]]))          # 宽 3（奇数）：每行最后半字节是补齐，不能算成 0
    _w(tmp_path / "000001.bmp", bmp4([[0, 0, 0], [5, 5, 5]]))
    assert B.palette_usage(tmp_path) == {0: 4, 1: 2, 5: 5, 9: 1}


def test_palette_check_is_open_loop():
    """按表数出的像素数必须 = 库自报的材料计数；表里黄 ↔ 白写反 ⇒ 对不上（这正是最像真的那种写错）。"""
    rows = B.palette_rows(PALETTE_MD)
    usage = {0: 4, 1: 2, 5: 5, 9: 1}
    meta = {"null": 4, "c": 2, "y": 5, "white": 1}
    assert B.palette_check(rows, usage, meta) == {"checked_int": 4, "padding_int": 0, "problem_str": ""}
    swapped = [[r[0], {"黄（Y）": "白（White）", "白（White）": "黄（Y）"}.get(r[1], r[1])] + r[2:] for r in rows]
    assert "对不上" in B.palette_check(swapped, usage, meta)["problem_str"]
    assert B.palette_check([], usage, meta)["checked_int"] == 0                 # 旧包没有这张表：不核对，也不声称核对过


def test_palette_check_accounts_for_output_width_padding():
    """★412 真跑撞上的：白底示例 output_width_px=64 > 原生 45 ⇒ BMP 多 19 列 0，库只数原生网格 ⇒ null 差 (64−45)×151×509 = 1,460,321。
    真数字原样放进来：按宽度补上才对得上；不补（411 的核对）必红；比原生窄（裁掉体素）⇒ 明说没法核对。"""
    rows = B.palette_rows(PALETTE_MD)
    counts = {"null": 2020344, "c": 212873, "m": 272073, "y": 160809, "k": 0, "white": 792556, "transparent": 0, "support": 0}
    usage = {0: 3480665, 1: 212873, 3: 272073, 5: 160809, 9: 792556}              # 真件按表从 BMP 数出来的
    meta = {"output_width_px_int": 64, "native_width_px_int": 45, "grid_list": [45, 151, 509], "slice_count_int": 509}
    got = B.palette_check(rows, usage, counts, meta)
    assert got["problem_str"] == "" and got["padding_int"] == 1460321 == 3480665 - 2020344
    assert got["padding_note_str"] == "(64 − 45) × 151 × 509"
    assert "null" in B.palette_check(rows, usage, counts)["problem_str"]                    # 不给宽度（411 的口径）⇒ 红
    assert "裁掉" in B.palette_check(rows, usage, counts, dict(meta, output_width_px_int=40))["problem_str"]
    bad_total = B.palette_check(rows, {**usage, 0: 3480664, 13: 1}, counts, meta)["problem_str"]
    assert "对不上" in bad_total                                                             # 一个像素挪到表里别的值也抓得到
    bad_meta = B.palette_check(rows, usage, counts, dict(meta, grid_list=[45, 150, 509]))["problem_str"]
    assert "BMP 像素总数" in bad_meta and "体素总数" in bad_meta                              # 高写错：两个总数都对不上


def _palette_tree(tmp_path):
    sh = dict(SHIPPED)
    sh["SDK_使用说明.md"] = (USAGE + PALETTE_MD).encode("utf-8")
    return make_tree(tmp_path, shipped=sh)


def test_readme_has_palette_table_with_sample_counts(tmp_path, monkeypatch):
    """★412 三个示例各一列；8 个像素值每个都在某个示例里出现过 ⇒ 每一行都被开环核对到。
    「哪个值只在哪个示例里有」从计数现算：7 只在黑墨示例；9 在黑墨（球心）和白底两个示例里（与真件同构）。"""
    repo, out = _palette_tree(tmp_path)
    dest = _bundle(tmp_path, repo, out)
    readme = _read(dest, "00_先读我_交付说明.md")
    assert "| 7 | 黑（K） | 喷 | 彩墨 | 0 | 2（12.5%） | 0 |" in readme            # 黑墨示例：2 张 × 每张 1 个 / 共 16 个
    assert "| 9 | 白（White） | 喷 | 白底 | 0 | 4（25.0%） | 4（25.0%） |" in readme   # 两个示例各 2 张 × 每张 2 个 / 共 16 个
    assert "每一个都在示例里真实出现过" in readme and "逐项相等" in readme
    assert "7 只在示例 2_黑墨K 里有" in readme and "9 在示例 2_黑墨K、3_白底填充 里有" in readme
    assert "9 只在" not in readme                                                   # 412 第一版写死的那句错话
    why = _read(dest, "05_示例输出/示例说明.md")
    assert "只在白底" not in why and "球心是白（9）" in why
    # ★412 白底示例比原生宽 ⇒ 说明里写明 0 那一项含补边（(4 − 3) × 2 × 2 = 4 个像素）；示例说明里也写
    assert "示例 3_白底填充 给了 `output_width_px`" in readme and "补边 4 个像素 = (4 − 3) × 2 × 2" in readme
    assert "0（空）那一项含补边 4 个像素" in _read(dest, "05_示例输出/3_白底填充/示例说明.md")
    assert "补边" not in _read(dest, "05_示例输出/1_默认参数/示例说明.md")
    man = json.loads(_read(dest, "bundle_manifest.json"))
    assert man["palette_coverage_dict"] == {"covered_list": [0, 1, 3, 5, 7, 9, 11, 13], "uncovered_list": []}
    # 反向 ①：黑墨示例的库自报计数与按表数出来的不一样 ⇒ 装配时拒绝并点名示例
    monkeypatch.setattr(B, "run_sample", lambda *a: fake_run_sample(*a, counts_over={"y": 999}) if a[1]["key_str"] == "2_黑墨K"
                        else fake_run_sample(*a))
    probs = _build_probs(tmp_path, repo, out)
    assert any("2_黑墨K" in x and "对不上" in x for x in probs), probs


def test_data_dependent_readme_claims_are_computed(tmp_path):
    """★412（412_08 的推广）：说明里跟数据走的话从数据现算 —— glibc 下限取 Linux 出包报告（CentOS 7 那句只在正好 2.17 时写），
    示例名取 SAMPLES。报告里的下限换成 2.28 ⇒ 说明跟着变，不再说 CentOS 7 能加载。"""
    repo, out = make_tree(tmp_path)
    readme = _read(_bundle(tmp_path, repo, out), "00_先读我_交付说明.md")
    assert "库实测只要求 glibc ≥ 2.17（CentOS 7 起都能加载）" in readme
    assert "个示例真跑**（默认参数 / 黑墨 / 白底填充）" in readme
    rp = out / "linux" / "prebuilt" / "build_report.json"
    rep = json.loads(rp.read_text(encoding="utf-8"))
    rp.write_text(json.dumps(dict(rep, min_os_str="glibc ≥ 2.28（实测：GLIBC_2.28）x86-64"), ensure_ascii=False), encoding="utf-8")
    readme2 = _read(_bundle(tmp_path, repo, out), "00_先读我_交付说明.md")
    assert "库实测只要求 glibc ≥ 2.28，" in readme2 and "CentOS 7" not in readme2


def test_where_values_appear_is_computed_from_counts():
    """★412 真件的计数（v0.1.2 交付说明第七节）：7 只在示例 2；9 在示例 2（球心 467,577）和 3（792,556）；11 / 13 在示例 1、2。"""
    usage = {"1_默认参数": {0: 2378667, 1: 307012, 3: 396513, 5: 222411, 11: 1139105, 13: 53988},
             "2_黑墨K": {0: 1655584, 1: 171975, 3: 222001, 5: 133148, 7: 77855, 9: 467577, 11: 365755, 13: 364760},
             "3_白底填充": {0: 3480665, 1: 212873, 3: 272073, 5: 160809, 9: 792556}}
    samples = [{"spec_dict": {"key_str": k}, "usage_dict": u} for k, u in usage.items()]
    assert B.where_values_appear(samples, [0, 1, 3, 5, 7, 9, 11, 13]) == (
        "7 只在示例 2_黑墨K 里有；9 在示例 2_黑墨K、3_白底填充 里有；11 在示例 1_默认参数、2_黑墨K 里有；13 在示例 1_默认参数、2_黑墨K 里有")
    assert B.where_values_appear(samples, [0, 1]) == "每个值在每个示例里都有"


def test_palette_uncovered_rows_are_reported(tmp_path, monkeypatch):
    """反向 ②：像素值 7 在所有示例里都没出现 ⇒ 说明里写明「这几行只由源码闸管」，不冒充「每一行都核对过」。"""
    monkeypatch.setitem(SAMPLE_PIXELS, "2_黑墨K", [[0, 1, 3, 9], [5, 11, 13, 9]])
    repo, out = _palette_tree(tmp_path)
    readme = _read(_bundle(tmp_path, repo, out), "00_先读我_交付说明.md")
    assert "像素值 [7] 在这几个示例里都没出现" in readme and "每一个都在示例里真实出现过" not in readme


def test_sample_command_slice_and_run():
    """示例怎么跑（纯函数）：只有尺寸参数走 slice；别的参数一律走 run + request.json（= C 接口的请求 JSON）。"""
    assert B.sample_command(B.SAMPLES[0], SAMPLE_CASES[0]) == (
        ["slice", "gltf_modes_mix.glb", "--target-longest-edge", "12", "--out", "slices", "--json"], None)
    args, req = B.sample_command(B.SAMPLES[1], SAMPLE_CASES[1])
    assert args == ["run", "request.json", "--json"] and req == {"model": "gray_ramp_sphere.glb", "out": "slices",
                                                              "params": SAMPLE_CASES[1]["params_dict"]}
    with pytest.raises(ValueError):
        B.sample_command(B.SAMPLES[0], SAMPLE_CASES[1])                      # slice 放不下黑墨那几个参数
    real = json.loads((REPO / "tests" / "data" / "golden.json").read_text(encoding="utf-8"))["case_list"]
    for spec in B.SAMPLES:                                                    # 真仓：三个示例都是 golden 件、模型都在、跑法放得下参数
        c = next(c for c in real if c["name_str"] == spec["case_str"])
        assert (REPO / "tests" / "data" / c["model_str"]).is_file(), c["model_str"]
        B.sample_command(spec, c)
    assert any(c["params_dict"].get("use_black_k") for c in real if c["name_str"] == B.SAMPLES[1]["case_str"])
    assert any(c["params_dict"].get("band_uninked_fill") == "white" for c in real if c["name_str"] == B.SAMPLES[2]["case_str"])


def test_counts_come_from_upstream_not_hardcoded(tmp_path):
    """★ golden 造成 7 件 ⇒ 说明与验收步骤里必须是 7 / 7；交付清单项数 = 交付合同现算（写死 13 / 17 的实现在这里红）。"""
    repo, out = make_tree(tmp_path, golden_n=7)
    dest = _bundle(tmp_path, repo, out)
    guide = _read(dest, "03_macOS_需在Mac上验收/macOS验收步骤.md")
    readme = _read(dest, "00_先读我_交付说明.md")
    assert "golden 7 / 7 件逐字节一致" in guide and "golden 13 / 13" not in guide
    assert "golden 7 / 7" in readme
    n_mac = len(B.fry_delivery_contract.items_for("full", "Darwin"))
    assert "full 等级 %d 项齐全" % n_mac in guide
    assert json.loads(_read(dest, "bundle_manifest.json"))["expected_counts_dict"]["golden_int"] == 7


def test_integration_marks_in_guides(tmp_path):
    """★411 给了集成命令实测 ⇒ 各平台集成说明逐条标 ✅；跳过的（本机没有 .NET）标「未实测 + 原因」，不冒充 ✅。"""
    repo, out = make_tree(tmp_path)
    dest0 = _bundle(tmp_path, repo, out)
    assert "还没有逐条实测" in _read(dest0, "01_Windows_x64/Windows_集成说明.md")      # 没给实测：明说没测
    ij = _integ(tmp_path, out, skip_cs=True)
    dest = _bundle(tmp_path, repo, out, integration=ij)
    win = _read(dest, "01_Windows_x64/Windows_集成说明.md")
    lin = _read(dest, "02_Linux_x64/Linux_集成说明.md")
    mac = _read(dest, "03_macOS_需在Mac上验收/macOS_集成说明.md")
    assert "原样真跑过" in win and win.count("✅") == 6 and "未实测：本机没有 .NET SDK" in win
    assert "原样真跑过" in lin and lin.count("✅") == len(G.STEPS["linux-x64"]["steps"])
    assert "还没有逐条实测" in mac and "✅" not in mac
    assert "..\\..\\05_示例输出\\1_默认参数\\%s" % G.SAMPLE_MODEL in win and "../../05_示例输出/1_默认参数/%s" % G.SAMPLE_MODEL in lin
    readme = _read(dest, "00_先读我_交付说明.md")
    assert "集成命令实测" in readme and "跳过 cs_new" in readme
    assert (dest / "06_验收证据" / "集成命令实测.json").is_file()


def test_parity_summary_only_when_given(tmp_path):
    repo, out = make_tree(tmp_path)
    dest = _bundle(tmp_path, repo, out)
    assert "一致性实验" not in _read(dest, "00_先读我_交付说明.md")
    p1 = _parity(tmp_path)
    p2 = _parity(tmp_path, edge_mm=30.0, total_slices_win=117508)
    dest2 = _bundle(tmp_path, repo, out, parity=[p1, p2])
    readme = _read(dest2, "00_先读我_交付说明.md")
    assert "54 个真实模型 × 最长边 10 / 30 mm" in readme and "156,994 张" in readme
    assert "Windows = Linux prebuilt" in readme and "1 个模型在所有平台上都按设计拒收" in readme
    assert "sha256 已逐个核对" in readme
    assert (dest2 / "06_验收证据" / p1.name).is_file()


def test_linux_both_goes_to_two_subdirs(tmp_path):
    repo, out = make_tree(tmp_path, linux_modes=("prebuilt", "native"))
    dest = _bundle(tmp_path, repo, out, modes=["prebuilt", "native"])
    for mode, tag in (("prebuilt", "推荐"), ("native", "对照")):
        sub = dest / "02_Linux_x64" / ("%s_%s" % (mode, tag))
        assert (sub / ("fry-halftone-%s-linux-x64.tar.zst" % V)).read_bytes() == \
            (out / "linux" / mode / ("fry-halftone-%s-linux-x64.tar.zst" % V)).read_bytes()
        assert B.check_extracted(sub / "fry-halftone") == []
    assert "../../../05_示例输出/" in _read(dest, "02_Linux_x64/Linux_集成说明.md")
    assert B.recheck(dest) == []


# ───────────────────────────── ② 反向：坏法 × 闸 ─────────────────────────────
def _edit_json(p: Path, fn) -> None:
    d = json.loads(p.read_text(encoding="utf-8"))
    fn(d)
    p.write_text(json.dumps(d, ensure_ascii=False), encoding="utf-8")


def _kit_with(out: Path, rel: str, data: bytes) -> None:
    """重打一个只改了一份随包文件的验收包，并同步 kit_info 的 sha256（只让「随包文件」这一道闸响）。"""
    s = dict(SHIPPED)
    s[rel] = data
    kit = make_kit(out / ("kit/fry-halftone-%s-verify-kit.tar.gz" % V), s)
    _edit_json(out / "kit/kit_info.json", lambda d: d.update(kit_sha256_str=sha(kit)))


def _delivered(repo: Path, version: str, packages: dict) -> None:
    DV.record({"version_str": version, "created_at_str": "2026-09-01T00:00:00", "dir_str": "_旧", "packages_dict": packages}, repo)


def _pk(out: Path) -> dict:
    return {"win32-x64": sha(out / ("fry-halftone-%s-win32-x64.zip" % V)),
            "linux-x64": sha(out / "linux" / "prebuilt" / ("fry-halftone-%s-linux-x64.tar.zst" % V)),
            "verify-kit": sha(out / "kit" / ("fry-halftone-%s-verify-kit.tar.gz" % V))}


BREAKS = {
    "Linux 是上一轮的版本": (lambda r, o: _edit_json(o / "linux/prebuilt/build_report.json", lambda d: d.update(version_str="0.0.1")),
                          "版本"),
    "Windows 指纹 ≠ 锁文件": (lambda r, o: _edit_json(o / "build_report.json", lambda d: d.update(fingerprint_str="cd" * 32)),
                          "算法指纹"),
    "Linux 没跑冒烟": (lambda r, o: _edit_json(o / "linux/prebuilt/build_report.json", lambda d: d.update(smoke_bool=False)),
                    "没跑冒烟"),
    "Windows 命令行契约没过": (lambda r, o: _edit_json(o / "build_report.json", lambda d: d["smoke_dict"].update(cli_contract_str="red")),
                          "命令行契约"),
    "验收包打完被动过": (lambda r, o: (o / ("kit/fry-halftone-%s-verify-kit.tar.gz" % V)).write_bytes(b"tampered"), "sha256"),
    "验收包缺 macOS x64": (lambda r, o: _edit_json(o / "kit/kit_info.json", lambda d: d["targets_dict"].pop("macos-x64")),
                        "macos-x64"),
    "验收包缺 Linux x64（说明承诺了拿它上服务器验）": (
        lambda r, o: _edit_json(o / "kit/kit_info.json", lambda d: d["targets_dict"].pop("linux-x64")), "linux-x64"),
    "验收包自称已验证": (lambda r, o: _edit_json(o / "kit/kit_info.json", lambda d: d.update(verified_on_target_bool=True)),
                     "verified_on_target_bool"),
    "验收包指纹 ≠ 锁文件": (lambda r, o: _edit_json(o / "kit/kit_info.json", lambda d: d.update(algorithm_fingerprint_str="ef" * 32)),
                        "源码变过"),
    "Linux 参数说明与 Windows 不同": (lambda r, o: (o / "linux/prebuilt/sdk/params_schema.json").write_bytes(SCHEMA + b" "),
                                 "参数说明"),
    "缺 Linux 包": (lambda r, o: (o / ("linux/prebuilt/fry-halftone-%s-linux-x64.tar.zst" % V)).unlink(), "缺 Linux"),
    "缺 macOS 验收包": (lambda r, o: (o / "kit/kit_info.json").unlink(), "缺 macOS 验收包"),
    "Windows 报告是别的平台": (lambda r, o: _edit_json(o / "build_report.json", lambda d: d.update(platform_str="linux-x64")),
                          "不是 Windows"),
    # ★410 外壳指纹（算法指纹管不到的命令行 / dll 外壳 / 导出表）
    "外壳源码改过没重出包": (lambda r, o: _w(r / "src" / "a.cpp", "int changed;\n"), "当前源码"),
    "Linux 是另一份外壳编的": (lambda r, o: _edit_json(o / "linux/prebuilt/build_report.json",
                                                   lambda d: d.update(wrapper_sha256_str="9" * 64)), "Linux prebuilt 包 的外壳指纹"),
    "验收包是另一份外壳编的": (lambda r, o: _edit_json(o / "kit/kit_info.json", lambda d: d.update(wrapper_sha256_str="9" * 64)),
                         "macOS 验收包 的外壳指纹"),
    "旧产物没记外壳指纹": (lambda r, o: _edit_json(o / "build_report.json", lambda d: d.pop("wrapper_sha256_str")), "没记外壳指纹"),
    # ★410 随包文本（说明 / 变更历史 / 头文件 / 示例）三个平台必须逐字节相同
    "Linux 的 CHANGELOG 与 Windows 不同": (lambda r, o: _w(o / "linux/prebuilt/sdk/CHANGELOG.md", "旧的一版\n"),
                                        "随包文件与 Windows 包不同（Linux prebuilt）"),
    "验收包里的 CHANGELOG 更新过（只重打了验收包）": (lambda r, o: _kit_with(o, "CHANGELOG.md", b"newer\n"), "验收包 → Mac"),
    "Linux 的示例少了一个": (lambda r, o: (o / "linux/prebuilt/sdk/examples/python/demo.py").unlink(), "examples/python/demo.py"),
    "Windows SDK 缺头文件": (lambda r, o: (o / "sdk/fry-halftone-sdk/include/fry_halftone.h").unlink(), "Windows SDK 里没有"),
    # ★411 版本号：只增不减、同号同字节、调试构建不许交付
    "版本号比已交付的小": (lambda r, o: _delivered(r, "0.4.0", {}), "只能递增"),
    "同一个版本号换了字节": (lambda r, o: _delivered(r, V, {"win32-x64": "0" * 64}), "已经交付过"),
    "本地调试构建（0.0.0-dev）": (lambda r, o: [_edit_json(p, lambda d: d.update(version_str="0.0.0-dev")) for p in (
        o / "build_report.json", o / "linux/prebuilt/build_report.json", o / "kit/kit_info.json")], "0.0.0-dev"),
}


@pytest.mark.parametrize("name", sorted(BREAKS))
def test_each_break_refuses_on_its_own(tmp_path, name):
    repo, out = make_tree(tmp_path)
    assert B.collect(out, ["prebuilt"], [], repo)[1] == []           # 对照：没搞坏时是绿的（否则「红」不说明任何事）
    breaker, needle = BREAKS[name]
    breaker(repo, out)
    probs = B.collect(out, ["prebuilt"], [], repo)[1]
    assert probs, "%s：闸没响" % name
    assert any(needle in p for p in probs), (name, probs)


def test_same_version_same_bytes_may_be_reissued(tmp_path):
    """同一批包（三个 sha256 全同）已经交付过：允许再出一次目录（补文档 / 证据），说明里写明是同一批包。"""
    repo, out = make_tree(tmp_path)
    _delivered(repo, V, _pk(out))
    inp, probs = B.collect(out, ["prebuilt"], [], repo)
    assert probs == []
    dest = B.unique_dir(out / B.BUNDLE_ROOT_NAME, "_260923_1852_重出")
    B.build(inp, dest, [], B.expected_counts(repo))
    readme = _read(dest, "00_先读我_交付说明.md")
    assert "再出一次目录" in readme and "逐字节相同" in readme
    assert "这是第一个编号版" in readme                     # 判据是「有没有更早的版本号」，不是「有没有上一条记录」
    assert "同一版本、同一批包重出目录" in _read(dest, "07_版本记录/版本记录.md")


def test_version_record_marks_voided_dirs(tmp_path):
    """记录不删、只标：某一行的目录已经挪进 _作废/ ⇒ 版本记录那一行写明「已作废」。"""
    root = tmp_path / B.BUNDLE_ROOT_NAME
    (root / B.VOID_DIR_NAME / "_旧目录").mkdir(parents=True)
    st = {"deliveries_list": [{"version_str": "0.1.0", "dir_str": "_旧目录"}, {"version_str": "0.1.0", "dir_str": "_新目录"}]}
    lines = B.version_record_text(st, root).splitlines()
    assert "已作废" in next(ln for ln in lines if "_旧目录" in ln)
    assert "已作废" not in next(ln for ln in lines if "_新目录" in ln)


@pytest.mark.parametrize("over,needle", [
    ({"all_identical": False}, "不全一致"),
    ({"cli_versions": {"win": "fry-halftone-cli 0.0.1"}}, "不是用这个版本跑的"),
    ({"cli_versions": {}}, "没记版本"),
    # ★410 证据必须是交付的那份字节跑的
    ({"lib_sha256_dict": {}}, "没记是哪份库跑的"),                                   # 409 的旧格式
    ({"lib_sha256_dict": {"win": "99" * 32, "linux_prebuilt": LIB_SHA["linux_prebuilt"]}}, "证据不是这份字节跑的"),
    ({"lib_sha256_dict": {"win": LIB_SHA["win"], "linux_native": LIB_SHA["linux_native"]}}, "找不到对应的交付 SDK"),
    ({"algorithm_fingerprint_dict": {"win": "cd" * 32}}, "库自报算法指纹"),
])
def test_parity_evidence_must_agree(tmp_path, over, needle):
    repo, out = make_tree(tmp_path)
    assert B.collect(out, ["prebuilt"], [_parity(tmp_path)], repo)[1] == []       # 对照：没改时是绿的
    probs = B.collect(out, ["prebuilt"], [_parity(tmp_path, **over)], repo)[1]
    assert any(needle in p for p in probs), probs


@pytest.mark.parametrize("over,needle", [
    ({"package_sha256_dict": {"win32-x64": "0" * 64, "linux-x64": "1" * 64}}, "测的不是这次交付的包"),
    ({"all_ok_bool": False}, "没有全过"),
    ({"version_str": "0.3.6"}, "的版本"),
])
def test_integration_evidence_must_be_this_package_and_green(tmp_path, over, needle):
    """★411 说明里写「实测过」的前提：实测的就是这两个包（sha256）、全过、同一版本。"""
    repo, out = make_tree(tmp_path)
    assert B.collect(out, ["prebuilt"], [], repo, _integ(tmp_path, out))[1] == []   # 对照
    probs = B.collect(out, ["prebuilt"], [], repo, _integ(tmp_path, out, **over))[1]
    assert any(needle in p for p in probs), probs
    probs = B.collect(out, ["prebuilt"], [], repo, tmp_path / "没有这个文件.json")[1]
    assert any("不存在" in p for p in probs), probs


def _build_probs(tmp: Path, repo: Path, out: Path) -> list:
    inp, probs = B.collect(out, ["prebuilt"], [], repo)
    assert probs == []
    dest = B.unique_dir(out / B.BUNDLE_ROOT_NAME, "_260923_1852_坏")
    return B.build(inp, dest, [], B.expected_counts(repo))["build_problems_list"]


def test_build_catches_package_that_disagrees_with_its_own_sums(tmp_path):
    """★411 展开的包要与包里的 SHA256SUMS 逐个对上 —— 393~410 真包就栽在这里（SUMS 里清单那一行过期）。"""
    repo, out = make_tree(tmp_path)
    sdk = out / "sdk" / "fry-halftone-sdk"
    _w(sdk / "delivery_manifest.json", {"late": "封包之后又重写了一次清单"})     # 旧封包顺序的后果
    zp = out / ("fry-halftone-%s-win32-x64.zip" % V)
    zp.unlink()
    zip_sdk(sdk, zp)
    probs = _build_probs(tmp_path, repo, out)
    assert any("展开的" in p and "delivery_manifest.json" in p for p in probs), probs


@pytest.mark.parametrize("kw,needle", [
    ({"md5": "ee" * 16}, "与标准答案不一致"),
    ({"leaks": ["C:\\\\Users\\\\x"]}, "绝对路径"),
    ({"ok": False}, "没跑成"),
])
def test_sample_output_must_match_golden(tmp_path, monkeypatch, kw, needle):
    """三个示例里任何一个跑不成 / 与标准答案不同 / 漏了本机路径 ⇒ 装配时拒绝，并点名是哪个示例。"""
    repo, out = make_tree(tmp_path)
    monkeypatch.setattr(B, "run_sample", lambda *a: fake_run_sample(*a, **kw) if a[1]["key_str"] == "3_白底填充" else fake_run_sample(*a))
    probs = _build_probs(tmp_path, repo, out)
    assert any(needle in x and "3_白底填充" in x for x in probs), probs


def test_cli_version_must_be_this_version(tmp_path, monkeypatch):
    repo, out = make_tree(tmp_path)
    monkeypatch.setattr(B, "capture_cli_texts", lambda *a: fake_capture_cli_texts(*a, version="0.3.6"))
    assert any("跑的不是这一版" in x for x in _build_probs(tmp_path, repo, out))


# ───────────────────────────── ★412 对外接口面 + 升级位 ─────────────────────────────
def _deliver(repo: Path, version: str, surface, algo: str = FP, wrapper: str = "", packages=None) -> None:
    DV.record({"version_str": version, "created_at_str": "2026-09-01T00:00:00", "dir_str": "_旧", "algorithm_fingerprint_str": algo,
               "wrapper_sha256_str": wrapper, "packages_dict": packages or {}, "surface_dict": surface}, repo)


def test_bump_gate_patch_is_enough_when_nothing_public_changed(tmp_path):
    repo, out = make_tree(tmp_path)
    _deliver(repo, "0.3.6", SF.source_surface(repo), wrapper=B.fry_build.wrapper_fingerprint(repo))
    inp, probs = B.collect(out, ["prebuilt"], [], repo)
    assert probs == [] and inp["bump_required_dict"]["level_str"] == "patch"
    assert "只有文档 / 打包变化" in "".join(inp["bump_required_dict"]["reasons_list"])


@pytest.mark.parametrize("change,needle", [
    (lambda s: dict(s, api_list=s["api_list"][:1]), "C 接口加了"),                       # 上一版少一个函数 ⇒ 这一版加了 ⇒ 至少次版本
    (lambda s: dict(s, api_list=s["api_list"] + ["int FryHalftone_Old(void)"]), "C 接口有不兼容的改动"),   # 这一版删了 ⇒ 0.x 升次版本
    (lambda s: dict(s, cli_list=[x for x in s["cli_list"] if x != "--json"]), "命令行加了"),
    (lambda s: dict(s, params_list=["gone_mm:number"]), "参数有不兼容的改动"),
])
def test_bump_gate_refuses_patch_when_public_surface_changed(tmp_path, change, needle):
    """接口面有增删 / 改签名而版本号只升了修订号（0.3.6 → 0.3.7）⇒ 拒收，并写出原因。"""
    repo, out = make_tree(tmp_path)
    _deliver(repo, "0.3.6", change(SF.source_surface(repo)), wrapper=B.fry_build.wrapper_fingerprint(repo))
    probs = B.collect(out, ["prebuilt"], [], repo)[1]
    assert any("只升了修订号" in x and "次版本" in x and needle in x for x in probs), probs


def test_bump_gate_algorithm_change_needs_minor(tmp_path):
    repo, out = make_tree(tmp_path)
    _deliver(repo, "0.3.6", SF.source_surface(repo), algo="cd" * 32, wrapper=B.fry_build.wrapper_fingerprint(repo))
    probs = B.collect(out, ["prebuilt"], [], repo)[1]
    assert any("算法指纹变了" in x for x in probs), probs


def test_bump_gate_unknown_when_old_record_has_no_surface_and_fingerprints_moved(tmp_path):
    """上一版没记接口面、指纹又变了 ⇒ 判「不知道」：交付时放行但写明没核对（出包时 fry_release 会要求人工 --bump）。"""
    repo, out = make_tree(tmp_path)
    DV.record({"version_str": "0.3.6", "algorithm_fingerprint_str": "cd" * 32, "wrapper_sha256_str": "", "packages_dict": {}}, repo)
    inp, probs = B.collect(out, ["prebuilt"], [], repo)
    assert probs == [] and inp["bump_required_dict"]["level_str"] == "unknown"


def test_surface_rulers_must_agree(tmp_path, monkeypatch):
    """两把尺子：参数表（源码 vs 库自报 schema）在 collect 比；命令行（源码 vs 真跑 --help）在 build 比。"""
    repo, out = make_tree(tmp_path)
    _w(repo / "cpp" / "src" / "api" / "job.cpp", 'const Spec kSpecs[] = {\n    {"target_height_mm", "number_or_null", 0.0},\n};\n')
    assert any("参数：源码解析 ≠ 产物" in x for x in B.collect(out, ["prebuilt"], [], repo)[1])
    (repo / "cpp" / "src" / "api" / "job.cpp").unlink()
    monkeypatch.setattr(B, "capture_cli_texts", lambda *a: fake_capture_cli_texts(*a, help_str=HELP + "  --frobnicate\n"))
    assert any("命令行：源码解析 ≠ 产物" in x for x in _build_probs(tmp_path, repo, out))


def test_missing_evidence_is_stated_not_silent(tmp_path):
    """没给一致性 / 集成实测 / 验收包 Linux 报告时，说明第八节逐条写「这一版没做」（B.1-43 ⑨：默认不跑的东西不能不提）。"""
    repo, out = make_tree(tmp_path)
    readme = _read(_bundle(tmp_path, repo, out), "00_先读我_交付说明.md")
    for needle in ("| 跨平台一致性复核 | —— | ⚠ **这一版没做**", "| 集成命令实测 | —— | ⚠ **这一版没做**", "这一版没在真 Linux 上跑过验收包"):
        assert needle in readme, needle
    full = _read(_bundle(tmp_path, repo, out, parity=[_parity(tmp_path)], integration=_integ(tmp_path, out)), "00_先读我_交付说明.md")
    assert "跨平台一致性复核 | —— |" not in full and "| 集成命令实测 | —— |" not in full
    table = next(b for b in full.split("## 八、", 1)[1].split("\n\n") if "| Windows x64 |" in b)
    assert "集成命令实测（本说明第三节" in table and "验收包的整条流程" in table   # 同一个块 = 中间没有空行把表断开


def test_changelog_must_have_this_version_section(tmp_path):
    """交付版的 CHANGELOG 必须已经按版本号分节（三个平台同一份）；还在「未发布」下 ⇒ 装配时拒绝并点名要哪一节。"""
    sh = dict(SHIPPED)
    sh["CHANGELOG.md"] = "# CHANGELOG\n\n## 未发布\n\n### 还没分节\n".encode("utf-8")
    repo, out = make_tree(tmp_path, shipped=sh)
    probs = [p for p in _build_probs(tmp_path, repo, out) if "CHANGELOG" in p]
    assert probs and "## %s" % V in probs[0]


def test_recheck_catches_tamper_and_strays(tmp_path):
    repo, out = make_tree(tmp_path)
    dest = _bundle(tmp_path, repo, out)
    zip_ = dest / ("01_Windows_x64/fry-halftone-%s-win32-x64.zip" % V)
    zip_.write_bytes(b"changed")
    assert any("不符" in p for p in B.recheck(dest))
    dest2 = _bundle(tmp_path, repo, out)
    _w(dest2 / "06_验收证据" / "stray.txt", "多出来的")
    assert any("对不上" in p for p in B.recheck(dest2))


# ───────────────────────────── ④ 目录名 / 不覆盖 / zip ─────────────────────────────
def test_dir_name_pattern_and_sanitize():
    t = time.strptime("2026-09-23 18:52", "%Y-%m-%d %H:%M")
    assert B.bundle_dir_name(B.default_topic("0.1.0"), t) == "_260923_1852_水转印加网SDK_v0.1.0_三平台交付"
    assert B.bundle_dir_name("a/b c:d", t) == "_260923_1852_a_b_c_d"
    assert B.bundle_dir_name("   ", t) == "_260923_1852_" + B.DEFAULT_TOPIC
    assert re.fullmatch(r"_\d{6}_\d{4}_.+", B.bundle_dir_name("x"))


def test_same_minute_never_overwrites(tmp_path):
    repo, out = make_tree(tmp_path)
    d1 = _bundle(tmp_path, repo, out)
    d2 = _bundle(tmp_path, repo, out)
    d3 = _bundle(tmp_path, repo, out)
    assert (d1.name, d2.name, d3.name) == ("_260923_1852_测试", "_260923_1852_测试_2", "_260923_1852_测试_3")
    _w(out / B.BUNDLE_ROOT_NAME / "_260923_1852_占用.zip", b"PK")
    assert B.unique_dir(out / B.BUNDLE_ROOT_NAME, "_260923_1852_占用").name == "_260923_1852_占用_2"


def test_zip_is_the_same_directory_with_utf8_names_and_unix_modes(tmp_path):
    """★ 整包 zip：解开就是这个目录（逐字节）；中文名带 UTF-8 标记；★411 记 Unix 权限（ELF 0755，其余 0644；不照抄 tar 里的 0777）。"""
    repo, out = make_tree(tmp_path)
    dest = _bundle(tmp_path, repo, out)
    zp, probs = B.make_zip(dest)
    assert probs == [] and zp.name == dest.name + ".zip" and zp.parent == dest.parent
    with zipfile.ZipFile(zp) as zf:
        infos = {i.filename: i for i in zf.infolist()}
        assert all(n.startswith(dest.name + "/") for n in infos)
        cn = [i for i in infos.values() if not i.filename.isascii()]
        assert cn and all(i.flag_bits & 0x800 for i in cn)
        cli = infos[dest.name + "/02_Linux_x64/fry-halftone/bin/fry-halftone-cli"]
        md = infos[dest.name + "/00_先读我_交付说明.md"]
        assert cli.create_system == 3 and (cli.external_attr >> 16) == 0o100755
        assert (md.external_attr >> 16) == 0o100644
        un = tmp_path / "unzipped"
        zf.extractall(un)
    for p in dest.rglob("*"):
        if p.is_file():
            assert (un / dest.name / p.relative_to(dest)).read_bytes() == p.read_bytes()
    assert B.make_zip(dest)[1], "同名 zip 已存在时必须拒绝（不覆盖）"


def test_zip_gate_catches_missing_utf8_flag(tmp_path, monkeypatch):
    """反向：模拟「不打 UTF-8 标记的压缩程序」（Windows 资源管理器右键压缩就是这样）⇒ 复查必须报出来。"""
    repo, out = make_tree(tmp_path)
    dest = _bundle(tmp_path, repo, out)
    monkeypatch.setattr(zipfile.ZipInfo, "_encodeFilenameFlags", lambda self: (self.filename.encode("utf-8"), self.flag_bits))
    zp, probs = B.make_zip(dest)
    assert zp.is_file() and any("UTF-8 标记" in p for p in probs), probs


# ───────────────────────────── ⑥ main：版本号记录 ─────────────────────────────
def test_main_dry_run_records_and_refuses(tmp_path, monkeypatch, capsys):
    repo, out = make_tree(tmp_path)
    monkeypatch.setattr(B, "REPO", repo)
    monkeypatch.setattr(B, "OUT", out)
    rj = tmp_path / "r.json"
    assert B.main(["--next-version"]) == 0 and capsys.readouterr().out.strip() == DV.FIRST_VERSION
    assert B.main(["--dry-run", "--result-json", str(rj)]) == 0
    assert not (out / B.BUNDLE_ROOT_NAME).exists() and not DV.state_path(repo).exists()
    assert json.loads(rj.read_text(encoding="utf-8"))["ok_bool"] is True
    # 真跑：默认主题带版本号；记进 delivery_versions.json（打包仓根，进 git）
    assert B.main(["--result-json", str(rj)]) == 0
    res = json.loads(rj.read_text(encoding="utf-8"))
    dest = Path(res["dir_str"])
    assert res["ok_bool"] and dest.is_dir() and dest.name.endswith("_水转印加网SDK_v%s_三平台交付" % V) and res["file_count_int"] > 40
    assert Path(res["zip_str"]).is_file() and len(res["zip_sha256_str"]) == 64 and res["version_str"] == V
    state = DV.load(repo)
    assert [d["version_str"] for d in state["deliveries_list"]] == [V]
    assert state["deliveries_list"][0]["packages_dict"] == _pk(out) and state["deliveries_list"][0]["dir_str"] == dest.name
    log = (out / B.BUNDLE_ROOT_NAME / "_交付记录.md").read_text(encoding="utf-8")
    assert dest.name in log and V in log
    capsys.readouterr()
    assert B.main(["--next-version"]) == 0 and capsys.readouterr().out.strip() == "0.3.8"
    # 同一批包再出一次：允许（同号同字节），记第二行；附加证据带「=说明」时说明进交付说明
    extra = _w(tmp_path / "额外.json", {"x": 1})
    assert B.main(["--topic", "补文档", "--extra-evidence", "%s=一份测试用的附加证据" % extra, "--result-json", str(rj)]) == 0
    assert [d["version_str"] for d in DV.load(repo)["deliveries_list"]] == [V, V]
    dest2 = Path(json.loads(rj.read_text(encoding="utf-8"))["dir_str"])
    assert "| `额外.json` | 一份测试用的附加证据 |" in _read(dest2, "00_先读我_交付说明.md")
    # 换了字节还用同一个版本号 ⇒ 拒绝、不新建目录、不记
    zp = out / ("fry-halftone-%s-win32-x64.zip" % V)
    with zipfile.ZipFile(zp, "a") as zf:
        zf.writestr("fry-halftone/多了.txt", "x")
    before = sorted(p.name for p in (out / B.BUNDLE_ROOT_NAME).iterdir())
    assert B.main(["--result-json", str(rj)]) == 1
    assert "已经交付过" in json.loads(rj.read_text(encoding="utf-8"))["message_str"]
    assert sorted(p.name for p in (out / B.BUNDLE_ROOT_NAME).iterdir()) == before
    assert len(DV.load(repo)["deliveries_list"]) == 2


def test_main_colleague_check_pass_records_and_readme_says_so(tmp_path, monkeypatch):
    """★412 --colleague-check：复验读的是**刚打好的整包 zip**（清单里的示例命令 = 示例说明里那条）；过了才记版本号，说明第八节写明。"""
    import fry_bundle_check as BC
    repo, out = make_tree(tmp_path)
    monkeypatch.setattr(B, "REPO", repo)
    monkeypatch.setattr(B, "OUT", out)
    seen = {}

    def fake_run(zp, version, out_dir):
        seen["dir"], seen["samples"] = BC.samples_from_zip(zp)                  # 真函数读真 zip
        seen["version"], seen["recorded_before"] = version, DV.state_path(repo).exists()
        return {"ok_bool": True, "samples_match_bool": True, "markers_dict": {"X": 1}}
    monkeypatch.setattr(BC, "run", fake_run)
    rj = tmp_path / "r.json"
    assert B.main(["--colleague-check", "--result-json", str(rj)]) == 0
    res = json.loads(rj.read_text(encoding="utf-8"))
    assert res["colleague_check_dict"] == {"ok_bool": True, "samples_match_bool": True}       # 原始标记不进结论
    assert seen["version"] == V and seen["recorded_before"] is False                          # 先复验、后记版本号
    assert seen["dir"] == Path(res["dir_str"]).name
    assert [s["key_str"] for s in seen["samples"]] == [s["key_str"] for s in B.SAMPLES]
    assert seen["samples"][0]["command_list"][:2] == ["slice", "gltf_modes_mix.glb"] and seen["samples"][2]["command_list"][0] == "run"
    assert [d["version_str"] for d in DV.load(repo)["deliveries_list"]] == [V]
    readme = _read(Path(res["dir_str"]), "00_先读我_交付说明.md")
    assert "| 站在你的角度复验整包（打完 zip 之后） | WSL 真 Linux |" in readme and "你拿到的这个目录就是过了的" in readme


def test_readme_says_colleague_check_not_done_without_the_flag(tmp_path):
    repo, out = make_tree(tmp_path)
    readme = _read(_bundle(tmp_path, repo, out), "00_先读我_交付说明.md")
    assert "| 站在你的角度复验整包 | —— | ⚠ **这一版没做**" in readme and "你拿到的这个目录就是过了的" not in readme


@pytest.mark.parametrize("outcome", ["fail", "raise"])
def test_main_colleague_check_failure_voids_and_is_not_recorded(tmp_path, monkeypatch, outcome):
    """★412 复验没过（或 WSL 起不来 = 没验过）⇒ 目录与整包挪进 _作废/、交付记录追加作废行、**不记版本号**、返回 1。"""
    import fry_bundle_check as BC
    repo, out = make_tree(tmp_path)
    monkeypatch.setattr(B, "REPO", repo)
    monkeypatch.setattr(B, "OUT", out)

    def fake_run(zp, version, out_dir):
        if outcome == "raise":
            raise RuntimeError("本机没有可用的 WSL 发行版")
        return {"ok_bool": False, "bundle_sums_ok_bool": True, "samples_match_bool": False, "markers_dict": {}}
    monkeypatch.setattr(BC, "run", fake_run)
    rj = tmp_path / "r.json"
    assert B.main(["--colleague-check", "--result-json", str(rj)]) == 1
    msg = json.loads(rj.read_text(encoding="utf-8"))["message_str"]
    assert ("samples_match" in msg) if outcome == "fail" else ("WSL" in msg)
    root = out / B.BUNDLE_ROOT_NAME
    assert sorted(p.name for p in root.iterdir()) == ["_交付记录.md", B.VOID_DIR_NAME]      # 根上不留能被误拿的目录 / zip
    void = sorted(p.name for p in (root / B.VOID_DIR_NAME).iterdir())
    assert len(void) == 2 and void[1] == void[0] + ".zip"
    log = (root / "_交付记录.md").read_text(encoding="utf-8")
    assert "~~%s~~ 作废（未记版本号）" % V in log and "已挪进 `%s/`" % B.VOID_DIR_NAME in log
    assert not DV.state_path(repo).exists()


def test_void_bundle_never_overwrites_an_earlier_void(tmp_path):
    root = tmp_path / "全交付目录"
    man = {"created_at_str": "2026-09-24 01:00", "version_str": "0.1.2", "algorithm_fingerprint_str": FP}
    for i in range(2):
        d = root / "_260924_0100_同名"
        (d / "a").mkdir(parents=True)
        (d / "a" / "f.txt").write_text(str(i), encoding="utf-8")
        z = root / (d.name + ".zip")
        z.write_bytes(b"zip%d" % i)
        B.void_bundle(root, d, z, man, "第 %d 次|没过" % i)                   # 半角竖线：进表格前必须换掉
        assert not d.exists() and not z.exists()
    void = root / B.VOID_DIR_NAME
    assert sorted(p.name for p in void.iterdir()) == ["_260924_0100_同名", "_260924_0100_同名.zip", "_260924_0100_同名_2",
                                                      "_260924_0100_同名_2.zip"]
    assert (void / "_260924_0100_同名" / "a" / "f.txt").read_text(encoding="utf-8") == "0"
    assert (void / "_260924_0100_同名_2.zip").read_bytes() == b"zip1"
    log = (root / "_交付记录.md").read_text(encoding="utf-8")
    assert log.count("作废（未记版本号）") == 2 and "第 0 次／没过" in log                  # 竖线换掉：不拆表格


def test_main_build_problem_is_not_recorded(tmp_path, monkeypatch):
    """装配阶段查出问题（示例输出与标准答案不一致）⇒ 返回 1、**不记版本号**、不打 zip；
    ★412 装了一半的目录挪进 _作废/（根上不留一个像是能交付的目录），交付记录写明。"""
    repo, out = make_tree(tmp_path)
    monkeypatch.setattr(B, "REPO", repo)
    monkeypatch.setattr(B, "OUT", out)
    monkeypatch.setattr(B, "run_sample", lambda *a: fake_run_sample(*a, md5="ee" * 16))
    rj = tmp_path / "r.json"
    assert B.main(["--result-json", str(rj)]) == 1
    assert "与标准答案不一致" in json.loads(rj.read_text(encoding="utf-8"))["message_str"]
    assert not DV.state_path(repo).exists()
    root = out / B.BUNDLE_ROOT_NAME
    assert not list(root.glob("*.zip")) and not list((root / B.VOID_DIR_NAME).glob("*.zip"))   # 没打整包 zip
    assert sorted(p.name for p in root.iterdir()) == ["_交付记录.md", B.VOID_DIR_NAME]
    assert len(list((root / B.VOID_DIR_NAME).iterdir())) == 1
    assert "装配 / 复查没过" in (root / "_交付记录.md").read_text(encoding="utf-8")


# ───────────────────────────── ⑦ fry_release --bundle 的计划 ─────────────────────────────
def test_release_bundle_plan():
    import fry_release as R
    assert R.bundle_plan("none", False, False) == {"linux_str": "none", "mac_kit_bool": False, "bundle_linux_str": "none",
                                                   "cross_str": "none", "kit_target_str": "macos-arm64,macos-x64"}
    p = R.bundle_plan("none", False, True)
    assert (p["linux_str"], p["mac_kit_bool"], p["bundle_linux_str"]) == ("prebuilt", True, "prebuilt")
    assert R.bundle_plan("both", True, True)["bundle_linux_str"] == "prebuilt"
    assert R.bundle_plan("native", False, True)["bundle_linux_str"] == "native"
    assert (p["cross_str"], p["kit_target_str"]) == ("all", "auto")
    assert R.cross_targets_for(p["cross_str"], p["linux_str"], p["mac_kit_bool"]) == list(R.ALL_CROSS)
    # ★411 不打交付目录、但交叉编全部 + 要验收包 ⇒ 验收包也带全部（之后单独打交付目录时过得了「验收包带 linux-x64」闸）
    assert R.bundle_plan("prebuilt", True, False, "all")["kit_target_str"] == "auto"
    assert R.bundle_plan("prebuilt", True, False, "macos-arm64")["kit_target_str"] == "macos-arm64,macos-x64"
