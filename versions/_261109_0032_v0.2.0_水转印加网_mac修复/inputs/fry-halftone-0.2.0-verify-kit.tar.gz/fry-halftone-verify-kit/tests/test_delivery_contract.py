# -*- coding: utf-8 -*-
r"""test_delivery_contract.py —— ★393 交付清单（`tools/fry_delivery_contract.py`）的闸，两个方向都验。

① 清单本身的形状：三个等级是**包含**关系、每一项都写了「为什么必需」、路径不重复；
② 真包（出过包才跑）：full 等级全齐、版本号处处一致；
③ ★ 搞坏必响：逐项删掉 / 改内容 / 把版本号改花，闸都要报红并点名；
④ ★ Windows 文件属性：dll 里的 VERSIONINFO 必须与构建时打算写的**逐字相同**
   —— 有资源 ≠ 资源是对的（rc 代码页不对会写出一堆乱码，而版本号那一栏照样对）。
"""
from __future__ import annotations

import json
import platform
import shutil
import sys
from pathlib import Path

import pytest

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO / "tools"))
import fry_delivery_contract as DC  # noqa: E402

SDK = REPO / "out" / "sdk" / "fry-halftone-sdk"
needs_pkg = pytest.mark.skipif(not (SDK / "sdk_info.json").is_file(), reason="还没出包（python tools/fry_build.py）")


# ───────────────────────────── ① 清单形状
def test_levels_are_nested_and_documented():
    runtime = {it["path"] for it in DC.items_for("runtime")}
    integration = {it["path"] for it in DC.items_for("integration")}
    full = {it["path"] for it in DC.items_for("full")}
    assert runtime < integration < full, (sorted(runtime), sorted(integration), sorted(full))
    for it in DC.ITEM_LIST:
        assert it["level"] in DC.LEVEL_TUPLE and it["kind"] in ("bin", "text", "json", "dir")
        assert len(it["why"]) >= 8, it            # 每一项都要写清「为什么必需」，否则以后没人敢删也没人敢加
        assert it["cat"], it
    paths = [it["path"] for it in DC.ITEM_LIST]
    assert len(paths) == len(set(paths))


def test_runtime_level_is_what_the_install_dir_needs():
    """手写期望：装机目录（算法仓 _bin/<平台>/）到底要哪几样 —— 6 项，一样都不能少。"""
    assert {it["path"] for it in DC.items_for("runtime")} == {
        "bin/fry_halftone.dll" if platform.system() == "Windows" else
        ("bin/libfry_halftone.so" if platform.system() == "Linux" else "bin/libfry_halftone.dylib"),
        "VERSION", "sdk_info.json", "params_schema.json", "SDK_参数说明.md", DC.MANIFEST_NAME_STR}


# ───────────────────────────── ② 真包
@needs_pkg
def test_built_package_is_complete():
    res = DC.check(SDK, "full", package_name="fry-halftone-%s" % (SDK / "VERSION").read_text(encoding="utf-8").strip())
    assert res["ok_bool"], res["problems_list"]
    assert res["checked_int"] == len(DC.items_for("full")), res["checked_int"]
    vals = {v for k, v in res["versions_dict"].items() if v and k != "包名"}
    assert len(vals) == 1, res["versions_dict"]          # 版本号处处一致（含 Windows 文件属性）


@needs_pkg
def test_manifest_records_every_item_with_sha256():
    man = json.loads((SDK / DC.MANIFEST_NAME_STR).read_text(encoding="utf-8"))
    assert man["schema_str"] == DC.MANIFEST_SCHEMA_STR and man["level_str"] == "full"
    rows = {r["path_str"]: r for r in man["files_list"]}
    assert set(rows) == {it["path"] for it in DC.items_for("full")}
    for path, row in rows.items():
        if path in (DC.MANIFEST_NAME_STR, DC.SUMS_NAME_STR):   # 清单不记自己；★411 也不记 SUMS（SUMS 覆盖清单，互记成环）
            assert row["sha256_str"] == "", (path, row)
            continue
        assert len(row["sha256_str"]) == 64 and row["size_int"] > 0, (path, row)
        assert row["why_str"], path                      # 「为什么必需」随包走：对方看得到
    # ★ 清单是给别人看的 ⇒ 里面要写清楚怎么自检
    assert "verify_delivery.py" in man.get("how_to_verify_str", "")


@needs_pkg
def test_built_package_passes_sha256sum_c():
    """★411 对方会用 `sha256sum -c SHA256SUMS.txt`：真包的每一行都要对（393~410 清单那一行一直过期，没人发现）。"""
    assert DC.sums_problems(SDK) == []


def _fake_full_pkg(root: Path) -> Path:
    for it in DC.items_for("full"):
        if it["path"] not in (DC.MANIFEST_NAME_STR, DC.SUMS_NAME_STR):
            p = root / it["path"]
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text('{"x": "%s"}' % it["path"] if it["kind"] == "json" else "内容 " + it["path"], encoding="utf-8")
    return root


def test_seal_leaves_every_sum_line_true(tmp_path):
    """★411 封包顺序：DC.seal 之后 SUMS 每一行都对、清单也对（两把尺子同时绿）。"""
    pkg = _fake_full_pkg(tmp_path / "pkg")
    DC.seal(pkg, "full", "fake")
    assert DC.sums_problems(pkg) == []
    lines = (pkg / DC.SUMS_NAME_STR).read_text(encoding="utf-8").splitlines()
    assert any(ln.endswith("  " + DC.MANIFEST_NAME_STR) for ln in lines)          # SUMS 覆盖终版清单
    res = DC.check(pkg, "full", check_version=False)
    assert not [p for p in res["problems_list"] if "SHA256SUMS" in p or "sha256" in p], res["problems_list"]


def test_old_seal_order_turns_the_gate_red(tmp_path):
    """反向：照 393~410 的旧顺序（清单 → SUMS → 再写一次清单）封包，新闸必须当场红，而且点名清单那一行。"""
    pkg = _fake_full_pkg(tmp_path / "pkg")
    DC.write_manifest(pkg, "full", "fake")
    DC.write_sums(pkg)
    DC.write_manifest(pkg, "full", "fake", extra={"note_str": "旧写法第二次写清单"})
    probs = DC.sums_problems(pkg)
    assert probs and any(DC.MANIFEST_NAME_STR in p for p in probs), probs
    res = DC.check(pkg, "full", check_version=False)
    assert any(DC.MANIFEST_NAME_STR in p and DC.SUMS_NAME_STR in p for p in res["problems_list"]), res["problems_list"]


def test_extra_file_after_seal_turns_the_gate_red(tmp_path):
    """封包之后又往包里放东西（例如冒烟把输出写进了包目录）⇒ SUMS 与目录对不上，必须红。"""
    pkg = _fake_full_pkg(tmp_path / "pkg")
    DC.seal(pkg, "full", "fake")
    (pkg / "多出来的.txt").write_text("x", encoding="utf-8")
    assert any("多" in p for p in DC.sums_problems(pkg))


# ───────────────────────────── ③ 搞坏必响
@needs_pkg
@pytest.mark.parametrize("victim", ["include/fry_halftone.h", "params_schema.json", "examples/csharp/FryHalftoneDemo.cs",
                                    "LICENSE.txt", "verify_delivery.py"])
def test_missing_item_turns_the_gate_red(tmp_path, victim):
    pkg = tmp_path / "pkg"
    shutil.copytree(SDK, pkg)
    (pkg / victim).unlink()
    res = DC.check(pkg, "full", check_version=False)
    assert not res["ok_bool"] and any(victim in p for p in res["problems_list"]), res["problems_list"]


@needs_pkg
def test_tampered_content_turns_the_gate_red(tmp_path):
    pkg = tmp_path / "pkg"
    shutil.copytree(SDK, pkg)
    p = pkg / "SDK_使用说明.md"
    p.write_text(p.read_text(encoding="utf-8") + "\n偷偷加一行\n", encoding="utf-8")
    res = DC.check(pkg, "full", check_version=False)
    assert not res["ok_bool"] and any("sha256" in x for x in res["problems_list"]), res["problems_list"]


@needs_pkg
def test_version_drift_turns_the_gate_red(tmp_path):
    pkg = tmp_path / "pkg"
    shutil.copytree(SDK, pkg)
    (pkg / "VERSION").write_text("9.9.9\n", encoding="utf-8")
    res = DC.check(pkg, "full")
    assert not res["ok_bool"] and any("版本号不一致" in p for p in res["problems_list"]), res["problems_list"]


# ───────────────────────────── ④ Windows 文件属性
@needs_pkg
@pytest.mark.skipif(platform.system() != "Windows", reason="文件属性（VERSIONINFO）是 Windows 的东西")
def test_file_properties_match_what_the_build_intended():
    info = json.loads((SDK / "sdk_info.json").read_text(encoding="utf-8"))
    want = info.get("file_properties_dict") or {}
    assert want, "sdk_info.json 里没有 file_properties_dict —— 文件属性这一段就没人核对了"
    got = DC.read_fileinfo_strings(SDK / "bin" / "fry_halftone.dll")
    assert got, "dll 里根本没有版本资源（.rc 没编进去）—— 右键属性会是空白"
    for k, v in want.items():
        assert got.get(k) == v, (k, got.get(k), v)
    assert got["FileVersion"] == (SDK / "VERSION").read_text(encoding="utf-8").strip()


@needs_pkg
@pytest.mark.skipif(platform.system() != "Windows", reason="文件属性（VERSIONINFO）是 Windows 的东西")
def test_mojibake_in_file_properties_turns_the_gate_red(tmp_path):
    """★ 把期望值原样保留、把**实际**读到的值弄成乱码（改 sdk_info 里的期望等于改尺子，所以反过来做）：
    这里用「把期望改成乱码」等价地验证比对真的在逐字比 —— 只要两边不同，闸就必须红。"""
    pkg = tmp_path / "pkg"
    shutil.copytree(SDK, pkg)
    info = json.loads((pkg / "sdk_info.json").read_text(encoding="utf-8"))
    props = dict(info["file_properties_dict"])
    props["FileDescription"] = props["FileDescription"].encode("utf-8").decode("cp936", "replace")   # rc 代码页错了就是这个样子
    info["file_properties_dict"] = props
    (pkg / "sdk_info.json").write_text(json.dumps(info, ensure_ascii=False, indent=1), encoding="utf-8")
    res = DC.check(pkg, "full", check_version=False)
    assert not res["ok_bool"] and any("文件属性" in p for p in res["problems_list"]), res["problems_list"]
