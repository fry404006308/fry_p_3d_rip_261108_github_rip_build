# -*- coding: utf-8 -*-
r"""test_golden.py —— ★384 本仓最重要的一道闸：**dll 出的 BMP 必须与算法仓 Python 生产线逐字节相同**。

【标准答案从哪来】tests/data/golden.json 由算法仓 `docs/K_工程重构/_260916_0937_384_水转印加网cpp版dll/tools/c384_make_sdk_goldens.py`
  用 **Python 生产线**（XA100 流程表 + 覆盖项）真跑生成：每件记 BMP 总 md5、张数、落墨体素数、色带厚度。
  本仓没有 Python 算法 ⇒ 自己证明不了「和 Python 一样」⇒ 只能对着 Python 给的答案逐项比。

【十件覆盖了什么】尺寸两种口径（z 高度 / 最长边）· 贴图取色 / 顶点色取色 · K 墨（含替换强度 0.5）·
  色带厚度覆盖（0.8 mm）· 填白 · 不打支撑 · 输出宽度补齐 · 层高 20 µm · 三墨满喷厚度改值（容量 1.1 = Python sum 补偿求和）·
  ★391 白 factor × 顶点色（LMST 两件同构：391 之前这种件整件无色，golden 里却一件样本都没有）·
  ★391 上色方式全家桶（u16 顶点色、缺省白、贴图 × 基色 / × 顶点色、TEXCOORD_1、KHR_texture_transform、三种包裹、
  调色板 NEAREST、量化 uv / 坐标、高光光泽度、六种 PNG、JPEG、条带、扇形、稀疏、多图元实例、data URI + 交错、点线混排、WebP 回退）。

【判据】四项全等：BMP 总 md5、张数、落墨数、色带厚度（float 全精度）。任何一项不等就红 —— 不存在「差一点也算过」。
  ⚠ 若 Linux / macOS 上红而 Windows 绿：大概率是 C 数学库（pow / atan2）末位舍入不同（见算法仓 384 文档「跨平台逐位」一节），
     不是这里写错了 —— 把 md5 不同的件名与平台记下来，别改 golden。

【怎么跑】python tests/test_golden.py --lib <动态库>   或 pytest（环境变量 FRY_HALFTONE_LIB）
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import sys
import tempfile
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from test_c_abi import OK, Sdk, default_lib  # noqa: E402

DATA = HERE / "data"


def bmp_md5(d: Path) -> str:
    h = hashlib.md5()
    for f in sorted(d.glob("*.bmp")):
        h.update(f.read_bytes())
    return h.hexdigest()


def run_all(lib_path: Path) -> int:
    doc = json.loads((DATA / "golden.json").read_text(encoding="utf-8"))
    for name, sha in doc["model_sha256_dict"].items():
        got = hashlib.sha256((DATA / name).read_bytes()).hexdigest()
        if got != sha:
            print("✗ 测试模型 %s 被改过（sha256 %s ≠ golden 记录的 %s）—— golden 作废，请在算法仓重新生成" % (name, got[:12], sha[:12]))
            return 1
    sdk = Sdk(lib_path)
    tmp = Path(tempfile.mkdtemp(prefix="fry_sdk_golden_"))
    bad = 0
    print("golden：%d 件（Python 生产线标准答案）｜ 库 %s ｜ 引擎 %s" % (len(doc["case_list"]), lib_path.name, sdk.engine()))
    for case in doc["case_list"]:
        out = tmp / case["name_str"]
        t0 = time.perf_counter()
        rc, res, err = sdk.slice_json({"model": str(DATA / case["model_str"]), "out": str(out), "params": case["params_dict"]})
        dt = time.perf_counter() - t0
        if rc != OK:
            bad += 1
            print("✗ %-30s 返回码 %d：%s" % (case["name_str"], rc, err))
            continue
        got = {"bmp_md5_str": bmp_md5(out), "slice_count_int": res.get("sliceCount"), "inked_voxel_int": res.get("inkedVoxels"),
               "band_thickness_mm_float": res.get("bandThicknessMm")}
        want = {k: case[k] for k in got}
        same = got == want
        bad += 0 if same else 1
        print("%s %-30s md5 %s ｜ %d 张 ｜ 落墨 %d ｜ 色带 %s mm ｜ %.2f s%s"
              % ("✓" if same else "✗", case["name_str"], got["bmp_md5_str"][:12], got["slice_count_int"] or 0,
                 got["inked_voxel_int"] or 0, got["band_thickness_mm_float"], dt,
                 "" if same else "\n    期望 %s\n    实际 %s" % (want, got)))
    shutil.rmtree(tmp, ignore_errors=True)
    print("%s golden %d / %d 件逐字节一致" % ("✓" if not bad else "✗", len(doc["case_list"]) - bad, len(doc["case_list"])))
    return 1 if bad else 0


def test_golden_matches_python() -> None:
    import pytest
    lib = default_lib()
    if lib is None or not lib.is_file():
        pytest.skip("还没出包：先跑 python tools/fry_build.py")
    assert run_all(lib) == 0


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    ap = argparse.ArgumentParser()
    ap.add_argument("--lib", default=None)
    ns = ap.parse_args()
    path = Path(ns.lib) if ns.lib else default_lib()
    if path is None or not Path(path).is_file():
        raise SystemExit("✗ 找不到动态库；用 --lib 指一个，或先跑 python tools/fry_build.py")
    raise SystemExit(run_all(Path(path)))
