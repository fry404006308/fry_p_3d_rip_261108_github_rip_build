# -*- coding: utf-8 -*-
r"""test_release_tagging.py —— 「发正式版」那几道闸，在**临时 git 仓 + 临时本地远端**上验，绝不碰真远端。

【为什么这几道闸必须测】OPS-0027：正式 tag **不可移动**。闸要是假的，后果是作废一个版本号。
  ① tag 格式不对 → 拒绝
  ② ★★ 将要被打 tag 的 commit 里的载荷指纹 ≠ 刚冒烟通过的包的指纹 → 拒绝
     （防「自动提交程序还没把新载荷提交，tag 就打在旧 commit 上」—— CI 会用旧算法出新版本号的包，不报错）
  ③ 正常：先提交未提交的载荷 → 打 tag → 推送 → 远端真的看得到 tag
  ④ 同一个 tag 第二次 → 拒绝（本地有 / 远端有 都拒绝）
  ⑤ ★388 仓根 CI 已是内网模式 → 本地 --tag 在同步 / 出包之前就被拒绝（发版改在 GitLab 点 release:tag）；
     独立模式照旧放行；--force-manual-tag 放行（OPS-0027 的逃生口）
"""
from __future__ import annotations

import json
import shutil
import subprocess
import sys
from pathlib import Path

import pytest

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO / "tools"))
import fry_release  # noqa: E402

pytestmark = pytest.mark.skipif(shutil.which("git") is None, reason="没有 git")


def sh(cwd: Path, *args: str) -> str:
    r = subprocess.run(["git", "-C", str(cwd), *args], capture_output=True, text=True, encoding="utf-8")
    assert r.returncode == 0, r.stderr
    return r.stdout.strip()


@pytest.fixture()
def sandbox(tmp_path, monkeypatch):
    remote = tmp_path / "remote.git"
    subprocess.run(["git", "init", "--bare", "-q", str(remote)], check=True)
    work = tmp_path / "work"
    work.mkdir()
    sh(work, "init", "-q", "-b", "main")
    sh(work, "config", "user.email", "t@t")
    sh(work, "config", "user.name", "t")
    (work / "cpp.lock.json").write_text(json.dumps({"tree_sha256_str": "OLD"}), encoding="utf-8")
    sh(work, "add", "-A")
    sh(work, "commit", "-q", "-m", "init")
    sh(work, "remote", "add", "origin", str(remote))
    sh(work, "push", "-q", "origin", "main")
    monkeypatch.setattr(fry_release, "REPO", work)
    return work, remote


def write_lock(work: Path, fp: str) -> None:
    (work / "cpp.lock.json").write_text(json.dumps({"tree_sha256_str": fp}), encoding="utf-8")


def test_bad_tag_format_is_refused(sandbox):
    with pytest.raises(RuntimeError, match="格式"):
        fry_release.do_tag("0.1.0", False, "OLD", "abc")


def test_fingerprint_mismatch_is_refused(sandbox, monkeypatch):
    """模拟「HEAD 里的载荷是旧的」：让 git add 什么都不加（= 新载荷没进提交），闸必须拒绝打 tag。"""
    work, _remote = sandbox
    write_lock(work, "NEW")                               # 工作区里是新载荷……
    real_git = fry_release.git

    def git_without_add(*args, **kw):                     # ……但这次提交没把它带上（竞态的效果）
        if args and args[0] == "add":
            return subprocess.CompletedProcess(args, 0, "", "")
        return real_git(*args, **kw)

    monkeypatch.setattr(fry_release, "git", git_without_add)
    assert json.loads(sh(work, "show", "HEAD:cpp.lock.json"))["tree_sha256_str"] == "OLD"   # 证据：HEAD 里确实是旧的
    with pytest.raises(RuntimeError, match="拒绝打 tag"):
        fry_release.do_tag("v0.1.0", False, "NEW", "abc")
    assert sh(work, "tag", "--list", "v0.1.0") == "", "闸说拒绝了，tag 却已经打上了"


def test_normal_release_commits_tags_and_pushes(sandbox):
    work, remote = sandbox
    write_lock(work, "NEW")
    info = fry_release.do_tag("v0.1.0", True, "NEW", "abcdef123456")
    assert info["pushed_bool"] is True and info["tag_str"] == "v0.1.0"
    assert json.loads(sh(work, "show", "v0.1.0:cpp.lock.json"))["tree_sha256_str"] == "NEW"
    assert "v0.1.0" in sh(remote, "tag", "--list"), "远端看不到 tag"
    assert "同步算法载荷" in sh(work, "log", "-1", "--format=%s")


def test_same_tag_twice_is_refused(sandbox):
    work, _remote = sandbox
    write_lock(work, "NEW")
    fry_release.do_tag("v0.1.0", True, "NEW", "abc")
    with pytest.raises(RuntimeError, match="不可移动"):
        fry_release.do_tag("v0.1.0", True, "NEW", "abc")
    sh(work, "tag", "-d", "v0.1.0")                       # 本地删掉，远端还在 ⇒ 仍然要拒绝
    with pytest.raises(RuntimeError, match="远端已经有"):
        fry_release.do_tag("v0.1.0", True, "NEW", "abc")


def test_push_without_tag_is_refused():
    rc = fry_release.main(["--algo-repo", str(REPO), "--push"])
    assert rc == 1


def test_manual_tag_refusal_only_in_internal_mode():
    """手算真值表：只有「内网模式 + 给了 tag + 没加 --force-manual-tag」这一格拒绝。"""
    msg = fry_release.manual_tag_refusal("internal", "v0.1.0", False)
    assert "release:tag" in msg and "--force-manual-tag" in msg
    assert fry_release.manual_tag_refusal("internal", "v0.1.0", True) == ""
    assert fry_release.manual_tag_refusal("internal", None, False) == ""
    assert fry_release.manual_tag_refusal("standalone", "v0.1.0", False) == ""
    assert fry_release.manual_tag_refusal("missing", "v0.1.0", False) == ""


def test_active_ci_mode_reads_the_real_variants(tmp_path):
    for name, want in (("standalone.gitlab-ci.yml", "standalone"), ("internal.gitlab-ci.yml", "internal")):
        repo = tmp_path / want
        repo.mkdir()
        shutil.copy2(REPO / "ci" / name, repo / ".gitlab-ci.yml")
        assert fry_release.active_ci_mode(repo) == want
    assert fry_release.active_ci_mode(tmp_path / "no_such_repo") == "missing"


def test_internal_mode_refuses_tag_before_any_build(sandbox, monkeypatch, tmp_path):
    """内网模式下 --tag：返回 1、原因里点名 release:tag、**同步 / 出包一步都没开始**、本地没有打出 tag。"""
    work, _remote = sandbox
    shutil.copy2(REPO / "ci" / "internal.gitlab-ci.yml", work / ".gitlab-ci.yml")
    called = []
    monkeypatch.setattr(fry_release.fry_payload, "do_status", lambda *a: called.append(a) or 0)
    # ★411 与打包仓真实的交付记录无关（否则 0.1.0 一交付，「正式版号必须大于已交付」就会在查载荷之前拦下 v0.1.0）
    monkeypatch.setattr(fry_release.DV, "load", lambda repo=None: {"deliveries_list": []})
    out = tmp_path / "result.json"
    rc = fry_release.main(["--algo-repo", str(work), "--tag", "v0.1.0", "--push", "--result-json", str(out)])
    res = json.loads(out.read_text(encoding="utf-8"))
    assert rc == 1 and "release:tag" in res["message_str"], res["message_str"]
    assert called == [], "拒绝应该发生在查载荷 / 出包之前"
    assert sh(work, "tag", "--list") == ""
    # 反向：独立模式（仓根是 standalone 变体）同样的命令不会被这道闸拦下 —— 会走到查载荷那一步
    shutil.copy2(REPO / "ci" / "standalone.gitlab-ci.yml", work / ".gitlab-ci.yml")
    monkeypatch.setattr(fry_release.fry_payload, "do_status", lambda *a: called.append(a) or 2)   # 2 = 算法仓路径不对，在这里停住
    rc2 = fry_release.main(["--algo-repo", str(work), "--tag", "v0.1.0", "--result-json", str(out)])
    assert rc2 == 1 and called, "独立模式应当越过内网闸、走到查载荷"
    assert "release:tag" not in json.loads(out.read_text(encoding="utf-8"))["message_str"]
