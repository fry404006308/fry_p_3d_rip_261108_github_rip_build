# -*- coding: utf-8 -*-
r"""test_release_bundle_flow.py —— ★412 一键出包把「最全的证据」都在一条命令里产出，以及三个复核工具的判据。

① fry_release --bundle 的编排（各步用假的 run_step 代替，只验**顺序、传参、失败即停**）：
   出包 → 接口面两把尺子 → 交叉 / Linux / 验收包 → 集成实测 → 一致性复核 → 验收包 WSL 实测 → 交付目录（带齐证据 + 同事角度复验）；
   ★ 反向：接口面对不上 / 一致性没过 / 验收包没跑通 ⇒ 整次失败、**不打交付目录**；--parity none ⇒ 不跑、不传；旧的比对结果不许混进来；
② 一致性复核 compare / load_models（纯函数）：全一致才 all_identical；缺模型、个数不对都要报；
③ 验收包实测 verdict：反向篡改必须两把尺子都点名；「可交付」要认整句；
④ 同事角度复验 verdict：每个示例两把尺子（文件 md5 + 自报 md5）；**0 个示例 = 红**；两边都没出片（空文件 md5 相同）也是红。
真跑（WSL）的那条路由出包实测覆盖（docs 412）。
"""
from __future__ import annotations

import json
import sys
import zipfile
from pathlib import Path

import pytest

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO / "tools"))
import fry_build  # noqa: E402
import fry_bundle_check as BC  # noqa: E402
import fry_kit_check as KC  # noqa: E402
import fry_parity_check as PC  # noqa: E402
import fry_release as R  # noqa: E402
import fry_surface as SF  # noqa: E402

FP = "ab" * 32
WRAP = "cd" * 32


# ───────────────────────────── ① fry_release --bundle 编排 ─────────────────────────────
@pytest.fixture()
def flow(tmp_path, monkeypatch):
    """临时「打包仓」：真实接口面（与真实头文件一致，导出表那把尺子读的是真头文件）+ 上一次交付 0.1.1（带接口面）。"""
    surface = SF.source_surface(REPO)
    work = tmp_path / "pack"
    (work / "out").mkdir(parents=True)
    (work / "CHANGELOG.md").write_text("# CHANGELOG\n\n## 未发布\n\n### ★这一版\n- x\n\n## 0.1.1（2026-09-23）\n\n- y\n",
                                       encoding="utf-8", newline="\n")
    state = {"deliveries_list": [{"version_str": "0.1.1", "algorithm_fingerprint_str": FP, "wrapper_sha256_str": WRAP,
                                  "surface_dict": surface}]}
    monkeypatch.setattr(R, "REPO", work)
    monkeypatch.setattr(R.fry_payload, "do_status", lambda *a: 0)                  # 算法没变
    monkeypatch.setattr(R.fry_payload, "load_lock", lambda: {"tree_sha256_str": FP, "source_dict": {"commit_str": "c" * 40}})
    monkeypatch.setattr(R.DV, "load", lambda repo=None: state)
    monkeypatch.setattr(R, "current_facts", lambda repo=None, lock=None: {
        "algorithm_fingerprint_str": FP, "wrapper_sha256_str": WRAP, "surface_dict": surface})
    monkeypatch.setattr(R, "preflight_problems", lambda parity, cfg: [])          # 真的那份单独测（要读盘 / 问 WSL）
    ctl = {"calls": [], "fail": set(), "schema_extra": [], "bundle_ok": True}

    def fake_run_step(cmd):
        name = Path(cmd[1]).name
        ctl["calls"].append((name, list(cmd)))
        out = work / "out"
        v = cmd[cmd.index("--version") + 1] if "--version" in cmd else ""
        if name in ctl["fail"]:
            return 1
        if name == "fry_build.py":
            ctl["version"] = v                                                     # 验收包的号跟着这次出包的号（真工具读交叉编译的报告）
            sdk = out / "sdk" / "fry-halftone-sdk"
            sdk.mkdir(parents=True, exist_ok=True)
            (out / ("fry-halftone-%s-win32-x64.zip" % v)).write_bytes(b"zip")
            (sdk / "sdk_info.json").write_text(json.dumps({"library_sha256_str": "11" * 32, "param_count_int": 18}), encoding="utf-8")
            params = [{"name": p.split(":")[0], "kind": p.split(":")[1]} for p in surface["params_list"] + ctl["schema_extra"]]
            (sdk / "params_schema.json").write_text(json.dumps({"params": params}), encoding="utf-8")
            (out / "build_report.json").write_text(json.dumps({"smoke_dict": {"export_surface_str": "ok_11"}}), encoding="utf-8")
        elif name == "fry_build_linux_native.py":
            d = out / "linux" / cmd[cmd.index("--mode") + 1]
            d.mkdir(parents=True, exist_ok=True)
            (d / ("fry-halftone-%s-linux-x64.tar.zst" % v)).write_bytes(b"zst")
        elif name == "fry_target_kit.py":
            (out / "kit").mkdir(exist_ok=True)
            (out / "kit" / ("fry-halftone-%s-verify-kit.tar.gz" % ctl["version"])).write_bytes(b"kit")
        elif name == "fry_parity_check.py":
            d = Path(cmd[cmd.index("--out-dir") + 1])
            d.mkdir(parents=True, exist_ok=True)
            (d / "compare_e10.json").write_text("{}", encoding="utf-8")
        elif name == "fry_delivery_bundle.py":
            Path(cmd[cmd.index("--result-json") + 1]).write_text(json.dumps(
                {"ok_bool": ctl["bundle_ok"], "dir_str": str(out / "全交付目录" / "_x"), "file_count_int": 99,
                 "message_str": "" if ctl["bundle_ok"] else "同事角度复验没过（samples_match）",
                 "colleague_check_dict": {"ok_bool": ctl["bundle_ok"]}}), encoding="utf-8")
            return 0 if ctl["bundle_ok"] else 1
        return 0

    monkeypatch.setattr(R, "run_step", fake_run_step)
    return work, ctl


def _names(ctl) -> list:
    return [n for n, _ in ctl["calls"]]


def _cmd(ctl, name) -> list:
    return next(c for n, c in ctl["calls"] if n == name)


def test_bundle_runs_every_evidence_step_in_order(flow, tmp_path):
    work, ctl = flow
    stale = work / "out" / "parity" / "compare_e99.json"                          # 上一次留下的比对结果
    stale.parent.mkdir(parents=True)
    stale.write_text("{}", encoding="utf-8")
    rj = tmp_path / "r.json"
    assert R.main(["--algo-repo", str(tmp_path), "--bundle", "--result-json", str(rj)]) == 0
    assert _names(ctl) == ["fry_build.py", "fry_cross_build.py", "fry_build_linux_native.py", "fry_target_kit.py",
                           "fry_integration_check.py", "fry_parity_check.py", "fry_kit_check.py", "fry_delivery_bundle.py"]
    res = json.loads(rj.read_text(encoding="utf-8"))
    key = res["key_output_dict"]
    assert res["ok_bool"] and key["delivery_version_str"] == "0.1.2" and key["colleague_check_ok_bool"] is True
    assert key["version_decision_dict"]["level_str"] == "patch"                    # 算法、外壳、接口面都没变
    assert key["surface_checked_list"] == ["api_names_list", "params_list"]         # 假包里没有命令行 ⇒ 那把尺子如实没量
    dec = json.loads((work / "out" / "version_decision.json").read_text(encoding="utf-8"))
    assert dec["version_str"] == "0.1.2" and dec["facts_dict"]["algorithm_fingerprint_str"] == FP
    assert "## 0.1.2（" in (work / "CHANGELOG.md").read_text(encoding="utf-8")
    b = _cmd(ctl, "fry_delivery_bundle.py")
    assert "--colleague-check" in b and b[b.index("--kit-linux-report") + 1].endswith("kit_linux_build_report.json")
    pj = b[b.index("--parity-json") + 1:]
    assert [Path(p).name for p in pj if p.endswith(".json")] == ["compare_e10.json"]    # 旧的 e99 已删，没混进来
    assert not stale.exists()
    p = _cmd(ctl, "fry_parity_check.py")
    assert p[p.index("--linux") + 1].startswith("prebuilt=") and p[p.index("--linux") + 1].endswith("fry-halftone-0.1.2-linux-x64.tar.zst")


def test_parity_none_skips_and_says_so(flow, tmp_path):
    work, ctl = flow
    assert R.main(["--algo-repo", str(tmp_path), "--bundle", "--parity", "none"]) == 0
    assert "fry_parity_check.py" not in _names(ctl)
    assert "--parity-json" not in _cmd(ctl, "fry_delivery_bundle.py")


@pytest.mark.parametrize("failing, needle", [("fry_parity_check.py", "一致性复核没过"), ("fry_kit_check.py", "验收包在真 Linux 上没跑通"),
                                             ("fry_integration_check.py", "集成命令没有全部跑通")])
def test_a_failed_evidence_step_stops_before_the_bundle(flow, tmp_path, failing, needle):
    work, ctl = flow
    ctl["fail"].add(failing)
    rj = tmp_path / "r.json"
    assert R.main(["--algo-repo", str(tmp_path), "--bundle", "--result-json", str(rj)]) == 1
    assert "fry_delivery_bundle.py" not in _names(ctl)
    assert needle in json.loads(rj.read_text(encoding="utf-8"))["message_str"]


def test_colleague_check_failure_fails_the_release(flow, tmp_path):
    work, ctl = flow
    ctl["bundle_ok"] = False
    rj = tmp_path / "r.json"
    assert R.main(["--algo-repo", str(tmp_path), "--bundle", "--result-json", str(rj)]) == 1
    assert "同事角度复验没过" in json.loads(rj.read_text(encoding="utf-8"))["message_str"]


def test_surface_rulers_disagree_stops_right_after_the_build(flow, tmp_path):
    """库自报参数表比源码解析多一个参数 ⇒ 源码解析器漏看了 ⇒ 按它定的版本号不可信：出包后立刻停，后面一步都不跑。"""
    work, ctl = flow
    ctl["schema_extra"] = ["zzz_new:number"]
    rj = tmp_path / "r.json"
    assert R.main(["--algo-repo", str(tmp_path), "--bundle", "--result-json", str(rj)]) == 1
    assert _names(ctl) == ["fry_build.py"]
    msg = json.loads(rj.read_text(encoding="utf-8"))["message_str"]
    assert "接口面" in msg and "zzz_new:number" in msg


def test_preflight_failure_stops_before_anything_runs(flow, tmp_path, monkeypatch):
    """★412 一致性清单 / WSL 不在：一开始就停（一步都不跑、不定版本号、不动 CHANGELOG）。"""
    work, ctl = flow
    monkeypatch.setattr(R, "preflight_problems", lambda parity, cfg: ["一致性复核：模型目录不存在：D:\\没有"])
    before = (work / "CHANGELOG.md").read_bytes()
    rj = tmp_path / "r.json"
    assert R.main(["--algo-repo", str(tmp_path), "--bundle", "--result-json", str(rj)]) == 1
    assert ctl["calls"] == [] and (work / "CHANGELOG.md").read_bytes() == before
    assert "出包前自检没过" in json.loads(rj.read_text(encoding="utf-8"))["message_str"]
    assert not (work / "out" / "version_decision.json").exists()


def test_preflight_problems_reads_the_config_and_asks_wsl(tmp_path, monkeypatch):
    import fry_wsl
    monkeypatch.setattr(fry_wsl, "distro", lambda: "Debian")
    cfg = tmp_path / "cfg.json"
    cfg.write_text(json.dumps({"dirs_list": [str(tmp_path / "没有")], "expect_count_int": 1}), encoding="utf-8")
    probs = R.preflight_problems("auto", cfg)
    assert len(probs) == 2 and "不存在" in probs[0] and "--parity none" in probs[1]
    assert R.preflight_problems("none", cfg) == []                                   # 明确不做一致性：不查清单
    monkeypatch.setattr(fry_wsl, "distro", lambda: "")
    assert "WSL" in R.preflight_problems("none", cfg)[0]


def test_explicit_bump_too_small_is_refused_before_building(flow, tmp_path, monkeypatch):
    work, ctl = flow
    monkeypatch.setattr(R, "current_facts", lambda repo=None, lock=None: {
        "algorithm_fingerprint_str": "ef" * 32, "wrapper_sha256_str": WRAP, "surface_dict": SF.source_surface(REPO)})
    rj = tmp_path / "r.json"
    assert R.main(["--algo-repo", str(tmp_path), "--bundle", "--bump", "patch", "--result-json", str(rj)]) == 1
    assert ctl["calls"] == [] and "不够" in json.loads(rj.read_text(encoding="utf-8"))["message_str"]
    # auto：算法指纹变了 ⇒ 次版本
    assert R.main(["--algo-repo", str(tmp_path), "--bundle", "--result-json", str(rj)]) == 0
    assert json.loads(rj.read_text(encoding="utf-8"))["key_output_dict"]["delivery_version_str"] == "0.2.0"


# ───────────────────────────── ② 一致性复核 ─────────────────────────────
def _run(tag, digests, rc=0) -> dict:
    return {"tag": tag, "host": tag, "edge_mm": 10.0, "params": PC.PARAMS, "cli_version": "fry-halftone-cli 0.1.2",
            "lib_sha256": tag * 2, "cli_sha256": tag * 3, "info": {"algorithmFingerprint": "f" * 64},
            "models": {m: {"rc": rc, "seconds": 1.0, "slices": 2, "bytes": 10, "digest": d,
                           "md5_list": [["000000.bmp", d[:32]], ["000001.bmp", "0" * 32]]} for m, d in digests.items()}}


def test_parity_compare_all_identical_and_differences():
    same = {"a.glb": "1" * 64, "b.glb": "2" * 64}
    s = PC.compare({"win": _run("win", same), "linux_prebuilt": _run("linux_prebuilt", same)}, "_e10")["summary"]
    assert s["all_identical"] is True and s["model_count"] == 2 and s["pair_identical_models"] == {"win=linux_prebuilt": 2}
    assert s["algorithm_fingerprint_dict"]["win"] == "f" * 64 and s["cli_versions"]["win"] == "fry-halftone-cli 0.1.2"
    res = PC.compare({"win": _run("win", same), "linux_prebuilt": _run("linux_prebuilt", dict(same, **{"b.glb": "3" * 64}))})
    assert res["summary"]["all_identical"] is False
    assert [r["win=linux_prebuilt"]["diff_slices"] for r in res["rows"]] == [0, 1]
    s = PC.compare({"win": _run("win", same), "linux_prebuilt": _run("linux_prebuilt", {"a.glb": "1" * 64})})["summary"]
    assert s["all_identical"] is False and s["missing_models_dict"] == {"win": ["b.glb"]}   # 少跑了一个也不算一致
    s = PC.compare({"win": _run("win", {}), "linux_prebuilt": _run("linux_prebuilt", {})})["summary"]
    assert s["all_identical"] is False                                                    # 0 个模型 = 没比过
    with pytest.raises(ValueError):
        PC.compare({"win": _run("win", same)})


def test_parity_load_models_checks_the_count(tmp_path):
    d = tmp_path / "models"
    d.mkdir()
    for n in ("b.glb", "a.glb", "note.txt"):
        (d / n).write_bytes(b"x")
    cfg = tmp_path / "cfg.json"
    cfg.write_text(json.dumps({"dirs_list": [str(d)], "expect_count_int": 2, "edge_mm_list": [10]}), encoding="utf-8")
    got = PC.load_models(cfg)
    assert got["problems_list"] == [] and [Path(m).name for m in got["models_list"]] == ["a.glb", "b.glb"]
    assert got["edge_mm_list"] == [10.0]
    cfg.write_text(json.dumps({"dirs_list": [str(d), str(tmp_path / "没有")], "expect_count_int": 3}), encoding="utf-8")
    probs = PC.load_models(cfg)["problems_list"]
    assert len(probs) == 2 and "不存在" in probs[0] and "个数 2 ≠" in probs[1]
    assert PC.load_models(tmp_path / "无.json")["problems_list"]


def test_real_parity_config_is_well_formed():
    cfg = json.loads((REPO / "tools" / "fry_parity_models.json").read_text(encoding="utf-8"))
    assert cfg["dirs_list"] and int(cfg["expect_count_int"]) > 0 and cfg["edge_mm_list"]


# ───────────────────────────── ③ 验收包 WSL 实测 ─────────────────────────────
GOOD_KIT = {"RUNNER_RC": 0, "DELIVERABLE": 1, "RESULTS_SUMS_RC": 0, "PKG_SUMS_RC": 0, "PKG_SUMS_LINES": 40, "VERIFY_RC": 0, "TAMPER_RC": 1}
TAMPER_LOG = "✗ SDK_README_EN.md 内容与清单不符\n✗ SHA256SUMS.txt 里的 SDK_README_EN.md 对不上\n"


def test_kit_verdict_both_directions():
    assert KC.verdict(GOOD_KIT, TAMPER_LOG)["ok_bool"] is True
    assert KC.verdict(GOOD_KIT, "✗ SDK_README_EN.md 内容与清单不符\n")["tamper_caught_bool"] is False   # 只有一把尺子点名
    assert KC.verdict(dict(GOOD_KIT, TAMPER_RC=0), TAMPER_LOG)["tamper_caught_bool"] is False           # 改了还返回 0
    assert KC.verdict(dict(GOOD_KIT, DELIVERABLE=0), TAMPER_LOG)["runner_ok_bool"] is False
    assert KC.verdict(dict(GOOD_KIT, PKG_SUMS_LINES=0), TAMPER_LOG)["package_sums_ok_bool"] is False     # 0 行 OK = 没验
    assert KC.verdict({}, "")["ok_bool"] is False                                                        # 什么都没跑
    assert KC.parse_markers("x\n@@RUNNER_RC=0\n@@TAMPER_RC=-1\n@@BAD=x\n") == {"RUNNER_RC": 0, "TAMPER_RC": -1}


def test_kit_script_requires_the_full_deliverable_sentence():
    """结尾那句提示「里面有可交付的包…」成败都会打印 ⇒ 判据必须认「✓ linux-x64：可交付」整句。"""
    lines = KC.script_lines("/mnt/k.tar.gz", "/mnt/o")
    assert any('grep -q "✓ linux-x64：可交付"' in ln for ln in lines)
    assert any("printf \"x\" >> SDK_README_EN.md" in ln for ln in lines)                                # 反向篡改在脚本里


# ───────────────────────────── ④ 同事角度复验 ─────────────────────────────
SAMPLES = [{"key_str": "1_默认参数", "model_str": "gltf_modes_mix.glb", "bmp_md5_str": "a" * 32,
            "command_list": ["slice", "gltf_modes_mix.glb", "--target-longest-edge", "12", "--out", "slices", "--json"]},
           {"key_str": "2_黑墨K", "model_str": "gray_ramp_sphere.glb", "bmp_md5_str": "b" * 32,
            "command_list": ["run", "request.json", "--json"]}]


def _good_markers() -> dict:
    m = {"BUNDLE_SUMS_RC": 0, "BUNDLE_SUMS_LINES": 300, "CLI_EXEC": 1, "CLI_VERSION_TEXT": "fry-halftone-cli 0.1.2", "VERIFY_RC": 0,
         "PKG_SUMS_RC": 0, "UNZIP": "python"}
    for i, s in enumerate(SAMPLES, 1):
        m.update({"S%d_RC" % i: 0, "S%d_N" % i: 3, "S%d_WANT_N" % i: 3, "S%d_MD5" % i: "9" * 32, "S%d_WANT_MD5" % i: "9" * 32,
                  "S%d_SDK_MD5" % i: s["bmp_md5_str"]})
    return m


def test_bundle_check_verdict_both_directions():
    ok = BC.verdict(_good_markers(), "0.1.2", SAMPLES)
    assert ok["ok_bool"] is True and ok["samples_checked_int"] == 2
    assert BC.verdict(_good_markers(), "0.1.3", SAMPLES)["cli_exec_ok_bool"] is False                    # 自报版本不对
    for k, v in (("S2_MD5", "8" * 32), ("S1_SDK_MD5", "c" * 32), ("S1_RC", 3), ("S2_N", 2), ("BUNDLE_SUMS_LINES", 0),
                 ("CLI_EXEC", 0), ("VERIFY_RC", 1), ("PKG_SUMS_RC", 1)):
        assert BC.verdict(dict(_good_markers(), **{k: v}), "0.1.2", SAMPLES)["ok_bool"] is False, k
    # 两边都没出片：空输入的 md5 相同（d41d8…），张数也「相同」（0 = 0）—— 必须判红
    empty = dict(_good_markers(), S1_N=0, S1_WANT_N=0, S1_MD5="d41d8cd98f00b204e9800998ecf8427e",
                 S1_WANT_MD5="d41d8cd98f00b204e9800998ecf8427e")
    assert BC.verdict(empty, "0.1.2", SAMPLES)["samples_list"][0]["files_match_bool"] is False
    assert BC.verdict(_good_markers(), "0.1.2", [])["samples_match_bool"] is False                       # 0 个示例 = 没验 = 红
    assert BC.verdict({}, "0.1.2", SAMPLES)["ok_bool"] is False


def test_bundle_check_parse_and_script():
    m = BC.parse("@@UNZIP=python\n@@BUNDLE_SUMS_RC=0\n@@CLI_VERSION_TEXT fry-halftone-cli 0.1.2\n@@S1_MD5 abc\n")
    assert m["UNZIP"] == "python" and m["BUNDLE_SUMS_RC"] == 0 and m["CLI_VERSION_TEXT"] == "fry-halftone-cli 0.1.2" and m["S1_MD5"] == "abc"
    text = "\n".join(BC.script_lines("/mnt/z.zip", "/mnt/o", "_260924_0100_x", SAMPLES))
    assert 'B="$W/_260924_0100_x"' in text                                        # 目录名来自清单，不靠猜
    assert 'fry-halftone-cli" slice gltf_modes_mix.glb --target-longest-edge 12 --out slices --json)' in text
    assert 'fry-halftone-cli" run request.json --json)' in text
    assert text.count("cat /dev/null $(ls") == 4                                   # 一张都没出时 cat 不等标准输入
    assert 'cp "$S/gray_ramp_sphere.glb" "$T/"' in text and "05_示例输出/2_黑墨K" in text


def test_bundle_check_reads_samples_from_the_zip(tmp_path):
    zp = tmp_path / "_260924_0100_x.zip"
    with zipfile.ZipFile(zp, "w") as zf:
        zf.writestr("_260924_0100_x/bundle_manifest.json", json.dumps({"samples_list": SAMPLES}, ensure_ascii=False))
        zf.writestr("_260924_0100_x/05_示例输出/1_默认参数/bundle_manifest.json", "{}")   # 深层同名文件不认
    name, samples = BC.samples_from_zip(zp)
    assert name == "_260924_0100_x" and samples == SAMPLES
