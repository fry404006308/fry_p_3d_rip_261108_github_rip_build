# -*- coding: utf-8 -*-
r"""test_cross_build.py —— ★394 跨平台交叉编译工具的闸，两个方向都验。

① 目标表的形状：三元组 / 产物名 / 格式 三者必须自洽（Linux→.so+ELF、macOS→.dylib+Mach-O）；
② 二进制解析器：对**真产物**解析得出正确结论；对**假文件**必须判「不是」（尺子要有判别力）；
③ ★★ `verified_on_target_bool` **恒为 false** —— 这是本工具的核心约束：
   交叉编译产物没在目标平台跑过 golden，任何人都不许把它标成「已验证」；
④ 导出面**两头查**：少了 = 消费方链接不上；多了 = 内部符号漏出去（出包冒烟是严格相等）；
⑤ CMakeLists 里的导出面白名单接线不许被删（静态查，删了 Linux 出包会当场红）；
⑥ ★409 静态闸（四个二进制：格式 / 架构 / rpath / 签名 / 装载路径）—— 好的全静、每种坏法各自响；
   真产物：Mach-O 导出表（export trie）只剩 11 个接口 + 2 个链接器标记；ELF 的 RUNPATH 只有 $ORIGIN、调试信息已剥。
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO / "tools"))
import fry_cross_build as CB  # noqa: E402

CROSS_OUT = REPO / "out" / "cross"
needs_artifact = pytest.mark.skipif(not (CROSS_OUT / "cross_info.json").is_file(),
                                    reason="还没跑过 python tools/fry_cross_build.py")


# ───────────────────────────── ① 目标表
def test_target_table_is_self_consistent():
    assert set(CB.TARGET_DICT) == {"linux-x64", "linux-arm64", "macos-arm64", "macos-x64"}
    for name, row in CB.TARGET_DICT.items():
        assert row["why"], name                                   # 每个目标都要写「给谁用」
        if name.startswith("linux"):
            assert row["lib"] == "libfry_halftone.so" and row["fmt"] == "elf" and row["cmake_system"] == "Linux"
            assert "-linux-gnu" in row["zig_triple"]
        else:
            assert row["lib"] == "libfry_halftone.dylib" and row["fmt"] == "macho" and row["cmake_system"] == "Darwin"
            assert "-macos" in row["zig_triple"]


def test_header_api_names_are_the_eleven_c_functions():
    names = CB.header_api_names()
    assert len(names) == 11 and all(n.startswith("FryHalftone_") for n in names), names


# ───────────────────────────── ② 解析器：正向 + 反向
@needs_artifact
def test_elf_parser_reads_a_real_linux_so():
    so = CROSS_OUT / "linux-x64" / "libfry_halftone.so"
    if not so.is_file():
        pytest.skip("没有 linux-x64 产物")
    info = CB.inspect_elf(so)
    assert info["ok_bool"] and info["format_str"] == "ELF"
    assert info["class_str"] == "64 位" and info["machine_str"] == "x86-64" and info["type_str"].startswith("DYN")
    assert info["soname_str"] == "libfry_halftone.so"
    assert "libc.so.6" in info["needed_list"] and "libm.so.6" in info["needed_list"]
    # ★ 导出面：加了 version script 之后必须**正好**是头文件那 11 个
    assert sorted(info["exports_list"]) == CB.header_api_names(), info["exports_list"]


@needs_artifact
def test_macho_parser_reads_a_real_dylib():
    dy = CROSS_OUT / "macos-arm64" / "libfry_halftone.dylib"
    if not dy.is_file():
        pytest.skip("没有 macos-arm64 产物")
    info = CB.inspect_macho(dy)
    assert info["ok_bool"] and info["format_str"] == "Mach-O" and info["machine_str"] == "arm64"
    assert info["type_str"].startswith("DYLIB")
    # ⚠ install_name 必须是正斜杠：Windows 宿主上 CMake 曾拼出 `@rpath\...`，真机 dyld 找不到（394 实测）
    assert info["install_name_str"] == "@loader_path/libfry_halftone.dylib", info["install_name_str"]
    assert "\\" not in info["install_name_str"]
    assert set(CB.header_api_names()) <= set(info["exports_list"])


def test_parsers_reject_a_fake_file(tmp_path):
    """反向：随便一个文件不能被当成 ELF / Mach-O（否则这把尺子没有判别力）。"""
    fake = tmp_path / "not_a_library.bin"
    fake.write_bytes(b"MZ\x90\x00" + b"\0" * 512)                 # 故意用 Windows PE 的魔数
    assert CB.inspect_elf(fake)["ok_bool"] is False
    assert CB.inspect_macho(fake)["ok_bool"] is False


# ───────────────────────────── ③ 核心约束：永远「未在目标平台验证」
@needs_artifact
def test_cross_artifacts_are_never_marked_verified():
    """★★ 交叉编译产物**不许**被标成已验证 —— 它没在目标平台跑过 golden。

    这条不是形式主义：392 实测 1 ulp 就能让 402/433 张 BMP 不同，而三平台的 libm 是三份实现。
    """
    report = json.loads((CROSS_OUT / "cross_info.json").read_text(encoding="utf-8"))
    assert report["targets_list"], "报告里一个目标都没有"
    for row in report["targets_list"]:
        assert row["verified_on_target_bool"] is False, row["target_str"]
        assert "golden" in row["verify_note_str"]
    assert "verified_on_target=false" in report["note_str"]


def test_source_code_never_sets_verified_true():
    """静态查：源码里不许出现把它设成 True 的写法（比「运行时没发生」更硬）。"""
    text = (REPO / "tools" / "fry_cross_build.py").read_text(encoding="utf-8")
    assert '"verified_on_target_bool": False' in text
    assert '"verified_on_target_bool": True' not in text


# ───────────────────────────── ④ 导出面两头查
@needs_artifact
def test_export_surface_checked_in_both_directions():
    report = json.loads((CROSS_OUT / "cross_info.json").read_text(encoding="utf-8"))
    for row in report["targets_list"]:
        if row["stage_str"] != "done":
            continue
        assert "api_missing_list" in row and "api_extra_list" in row, row["target_str"]
        # ok 的定义必须同时管「少」和「多」（★409 起还要管静态闸，见下面 test_ok_means_static_gate_too）
        assert row["ok_bool"] == (not row["api_missing_list"] and not row["api_extra_list"]
                                  and not row.get("static_problems_list")), row["target_str"]


# ───────────────────────────── ⑤ CMakeLists 的接线不许被删
def test_cmake_keeps_export_whitelist_wiring():
    """Linux 的 version script / macOS 的 exported_symbols_list 是 394 加的**必需**接线：
    删掉它，Linux 会多导出 12 个 `operator new/delete`，出包冒烟的导出面闸当场红（394 实测）。"""
    text = (REPO / "CMakeLists.txt").read_text(encoding="utf-8")
    assert "packaging/export/linux_version_script.map" in text
    assert "packaging/export/macos_exported_symbols.txt" in text
    assert "-Wl,-install_name,@loader_path/libfry_halftone.dylib" in text      # 反斜杠那个坑
    assert (REPO / "packaging" / "export" / "linux_version_script.map").is_file()
    assert (REPO / "packaging" / "export" / "macos_exported_symbols.txt").is_file()


def test_release_script_exposes_cross_and_defaults_to_none():
    """一键出包脚本要能顺手做探针，但**默认不做**（不拖慢日常出包）。"""
    text = (REPO / "tools" / "fry_release.py").read_text(encoding="utf-8")
    assert '"--cross"' in text and 'default="none"' in text
    assert "cross_verified_on_target_bool" in text


# ───────────────────────────── ⑥ ★409 静态闸：好的全静、每种坏法各自响
def _good_facts(target):
    """按「交付要求」手写一份全对的四个二进制事实（与 inspect_elf / inspect_macho 的输出同形）。"""
    row = CB.TARGET_DICT[target]
    lib = row["lib"]
    fmt = "ELF" if row["fmt"] == "elf" else "Mach-O"
    base = {"ok_bool": True, "format_str": fmt, "machine_str": CB.EXPECTED_MACHINE_DICT[target],
            "codesig_bool": True, "rpaths_list": [], "needed_list": []}
    facts = {lib: dict(base, install_name_str="@loader_path/" + lib)}
    if fmt == "ELF":
        facts[lib]["rpaths_list"] = ["$ORIGIN"]
    for key, name in CB.EXE_NAMES.items():
        f = dict(base)
        if key in ("demo", "cli"):
            if fmt == "Mach-O":
                f["needed_list"] = ["@loader_path/" + lib, "/usr/lib/libSystem.B.dylib"]
            else:
                f["needed_list"], f["rpaths_list"] = [lib, "libc.so.6"], ["$ORIGIN"]
        facts[name] = f
    return facts


@pytest.mark.parametrize("target", sorted(CB.TARGET_DICT))
def test_static_gate_quiet_on_good_binaries(target):
    assert CB.static_problems(target, _good_facts(target)) == []


def _host_rpath(t, f):
    f[CB.EXE_NAMES["cli"]]["rpaths_list"] = ["$ORIGIN", "C:/work/out/cross/%s/cmake" % t]


def _wrong_arch(t, f):
    f[CB.TARGET_DICT[t]["lib"]]["machine_str"] = "PowerPC"


def _missing_cli(t, f):
    f.pop(CB.EXE_NAMES["cli"])


def _not_binary(t, f):
    f[CB.EXE_NAMES["probe"]] = {"ok_bool": False, "why_str": "开头不是魔数"}


@pytest.mark.parametrize("target", sorted(CB.TARGET_DICT))
@pytest.mark.parametrize("breaker,needle", [(_host_rpath, "构建机路径"), (_wrong_arch, "目标要"),
                                            (_missing_cli, "缺文件"), (_not_binary, "缺文件或不是")])
def test_static_gate_fires_on_each_breakage(target, breaker, needle):
    facts = _good_facts(target)
    breaker(target, facts)
    probs = CB.static_problems(target, facts)
    assert any(needle in p for p in probs), (breaker.__name__, probs)


def test_static_gate_platform_specific_rules():
    f = _good_facts("macos-arm64")
    f["libfry_halftone.dylib"]["codesig_bool"] = False
    assert any("代码签名" in p for p in CB.static_problems("macos-arm64", f))
    f = _good_facts("macos-x64")
    f["libfry_halftone.dylib"]["codesig_bool"] = False
    assert CB.static_problems("macos-x64", f) == []          # Intel Mac 不强制签名 —— 这条只管 arm64
    f = _good_facts("macos-arm64")
    f["libfry_halftone.dylib"]["install_name_str"] = "@rpath\\libfry_halftone.dylib"   # 394 的反斜杠坑
    assert any("install_name" in p for p in CB.static_problems("macos-arm64", f))
    f = _good_facts("macos-arm64")
    f["fry-halftone-cli"]["needed_list"] = ["/usr/lib/libSystem.B.dylib"]
    assert any("@loader_path" in p for p in CB.static_problems("macos-arm64", f))
    f = _good_facts("linux-x64")
    f["fry-halftone-cli"]["rpaths_list"] = []
    assert any("RUNPATH $ORIGIN" in p for p in CB.static_problems("linux-x64", f))


@needs_artifact
def test_ok_means_static_gate_too():
    report = json.loads((CROSS_OUT / "cross_info.json").read_text(encoding="utf-8"))
    for row in report["targets_list"]:
        if row["stage_str"] != "done":
            continue
        assert "static_problems_list" in row, row["target_str"]
        assert row["ok_bool"] == (not row["api_missing_list"] and not row["api_extra_list"]
                                  and not row["static_problems_list"]), row["target_str"]


@needs_artifact
def test_macho_export_trie_has_no_new_delete():
    """★409 zig 的 Mach-O 链接器静默忽略 -exported_symbols_list ⇒ 靠库里隐藏的 new/delete 压下去。"""
    seen = 0
    for t in ("macos-arm64", "macos-x64"):
        dy = CROSS_OUT / t / "libfry_halftone.dylib"
        if not dy.is_file():
            continue
        seen += 1
        info = CB.inspect_macho(dy)
        assert info["export_source_str"] == "export trie"
        extra = sorted(set(info["exports_list"]) - set(CB.header_api_names()))
        assert extra == ["__dso_handle", "_mh_dylib_header"], extra
        assert info["min_os_str"].startswith("macOS ")
        assert info["codesig_bool"] or t == "macos-x64"
    if not seen:
        pytest.skip("没有 macOS 交叉产物")


@needs_artifact
def test_elf_cross_artifacts_only_origin_runpath_and_no_debug_bloat():
    seen = 0
    for t in ("linux-x64", "linux-arm64"):
        pre = CROSS_OUT / t / "prebuilt"
        if not pre.is_dir():
            continue
        seen += 1
        for name in ("fry-halftone-cli", "FryHalftoneDemoC"):
            assert CB.inspect_elf(pre / name)["rpaths_list"] == ["$ORIGIN"], (t, name)
        # 409 实测：不剥时 9.18 MB 里 8.01 MB 是 zig 预编 libc++ 的 .debug_*
        assert (pre / "libfry_halftone.so").stat().st_size < 3 * 1048576, t
    if not seen:
        pytest.skip("没有 Linux 交叉产物")


def test_toolchain_file_strips_debug_per_format_and_marks_zig(tmp_path):
    """ELF 用 --strip-debug（剥 .debug_*）；★410 Mach-O 用 -S（去掉调试映射：构建机路径 + .o 修改时间）。"""
    zig = tmp_path / "zig.exe"
    zig.write_text("")
    tc_linux = CB.write_toolchain(tmp_path / "l", zig, "linux-x64").read_text(encoding="utf-8")
    tc_mac = CB.write_toolchain(tmp_path / "m", zig, "macos-arm64").read_text(encoding="utf-8")
    assert "--strip-debug" in tc_linux and "--strip-debug" not in tc_mac
    assert '"-Wl,-S"' in tc_mac and '"-Wl,-S"' not in tc_linux
    assert "set(FRY_ZIG_CROSS ON)" in tc_linux and "set(FRY_ZIG_CROSS ON)" in tc_mac


@pytest.mark.parametrize("target", sorted(CB.TARGET_DICT))
def test_static_gate_catches_debug_map_and_host_paths(target):
    """★410 两向：好的全静；带调试映射（Mach-O）/ 带构建机路径（任一格式）⇒ 点名响。"""
    assert CB.static_problems(target, _good_facts(target)) == []
    f = _good_facts(target)
    f[CB.EXE_NAMES["cli"]]["host_path_hits_int"] = 35
    assert any("构建机路径" in p and "35" in p for p in CB.static_problems(target, f))
    f = _good_facts(target)
    f[CB.TARGET_DICT[target]["lib"]]["stab_count_int"] = 52
    assert any("调试映射" in p for p in CB.static_problems(target, f))


def test_host_path_hits_counts_both_slash_styles():
    posix, win = CB.REPO.as_posix().encode(), str(CB.REPO).encode()
    assert CB.host_path_hits(b"xx" + posix + b"/a.o\0" + win.upper() + b"\\b.o\0") == 2
    assert CB.host_path_hits(b"no build paths here") == 0


@needs_artifact
def test_cross_artifacts_carry_no_debug_map_or_host_paths():
    """★410 真产物：Mach-O 的调试映射条数 = 0，四个目标的每个二进制里构建机路径 = 0（409 的 macOS 库实测 52 条 / 73 处）。"""
    seen = 0
    for t, row in CB.TARGET_DICT.items():
        pre = CROSS_OUT / t / "prebuilt"
        if not pre.is_dir():
            continue
        seen += 1
        for name in (row["lib"],) + tuple(CB.EXE_NAMES.values()):
            info = (CB.inspect_macho if row["fmt"] != "elf" else CB.inspect_elf)(pre / name)
            assert info.get("stab_count_int", 0) == 0 and info["host_path_hits_int"] == 0, (t, name, info.get("stab_count_int"),
                                                                                            info["host_path_hits_int"])
    if not seen:
        pytest.skip("没有交叉产物")


def test_cmake_keeps_409_wiring():
    text = (REPO / "CMakeLists.txt").read_text(encoding="utf-8")
    assert "if(APPLE AND FRY_ZIG_CROSS)" in text and "-fvisibility-global-new-delete=force-hidden" in text
    src = (REPO / "src" / "dll" / "fry_hidden_new_delete.cpp").read_text(encoding="utf-8")
    assert src.count("void* operator new") == 8 and src.count("void operator delete") == 12   # 20 个可替换分配函数
    # 构建机路径不许烙进可执行文件（409 静态闸抓到：BUILD_RPATH 是「追加」不是「替换」）
    assert text.count("BUILD_WITH_INSTALL_RPATH ON") >= 2 and text.count("SKIP_BUILD_RPATH ON") >= 2


# ───────────────────────────── ⑦ ★409 一键出包：交叉编译目标并成一次
def test_release_cross_targets_are_one_union_in_fixed_order():
    import fry_release as R
    assert R.cross_targets_for("none", "none", False) == []
    assert R.cross_targets_for("none", "native", False) == []              # native 在 WSL 里编，不需要交叉编
    assert R.cross_targets_for("linux-x64", "prebuilt", True) == ["linux-x64", "macos-arm64", "macos-x64"]
    assert R.cross_targets_for("all", "both", True) == ["linux-x64", "linux-arm64", "macos-arm64", "macos-x64"]
    assert set(R.ALL_CROSS) == set(CB.TARGET_DICT) and set(R.MAC_KIT_TARGETS) <= set(CB.TARGET_DICT)


def test_release_exposes_linux_and_mac_kit_switches():
    text = (REPO / "tools" / "fry_release.py").read_text(encoding="utf-8")
    assert '"--linux"' in text and '"--mac-kit"' in text
    assert 'key["mac_kit_verified_on_target_bool"] = False' in text          # 验收包永远未验证


# ───────────────────────────── ⑧ ★409 本机能不能出 Linux 包：WSL 判定只有一份、两向都验
def _fake_wsl(tmp_path, monkeypatch, text, rc):
    """在 PATH 最前面放一个假的 wsl：打印 text、返回 rc（Windows 用 .cmd，其它系统用 sh 脚本）。"""
    import os
    import stat
    d = tmp_path / "fakebin"
    d.mkdir()
    if os.name == "nt":
        body = "@echo off\r\n" + "".join("echo %s\r\n" % ln for ln in text.splitlines()) + "exit /b %d\r\n" % rc
        (d / "wsl.cmd").write_bytes(body.encode("ascii"))
    else:
        f = d / "wsl"
        f.write_text("#!/bin/sh\n" + "".join("echo '%s'\n" % ln for ln in text.splitlines()) + "exit %d\n" % rc)
        f.chmod(f.stat().st_mode | stat.S_IEXEC)
    monkeypatch.setenv("PATH", str(d) + os.pathsep + os.environ.get("PATH", ""))


def test_wsl_detector_refuses_no_distribution(tmp_path, monkeypatch):
    """409 开工时本机的真实状态：WSL 装了、发行版没注册 ——「has no installed distributions」+ 非 0 返回码 ⇒ 不可用。
    以前体检脚本只看文字里有没有 "not installed" ⇒ 这句话被**误判成可用**。"""
    import fry_build_linux_native as LN
    _fake_wsl(tmp_path, monkeypatch, "Windows Subsystem for Linux has no installed distributions.", 1)
    assert LN.wsl_distro() == ""


def test_wsl_detector_accepts_a_distribution(tmp_path, monkeypatch):
    import fry_build_linux_native as LN
    _fake_wsl(tmp_path, monkeypatch, "FakeDistro409", 0)      # 名字独一无二：证明读到的是假的那个，不是本机真 WSL
    assert LN.wsl_distro() == "FakeDistro409"


def test_platform_probe_uses_the_one_wsl_detector():
    text = (REPO / "tools" / "fry_platform_probe.py").read_text(encoding="utf-8")
    assert "LN.wsl_distro()" in text and '"not installed" not in' not in text

