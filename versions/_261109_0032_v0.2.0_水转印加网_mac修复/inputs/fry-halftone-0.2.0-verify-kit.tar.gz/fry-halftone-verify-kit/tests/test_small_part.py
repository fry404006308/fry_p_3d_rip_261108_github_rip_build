# -*- coding: utf-8 -*-
r"""test_small_part.py —— 尺寸口径回归（383 定的：target_height_mm = 摆正后的 z 高度，与 lmst targetHeightMm 同义）。

2×1×0.5 的长方体（三边不等 —— 立方体上两种口径分不开，B.1-37：测试件要落在被测量最敏感处）：
  ① z 高度 1 mm ⇔ 最长边 4 mm ⇒ 两种说法必须**逐字节**出同一叠 BMP；
  ② 382 的旧口径（最长边 = 1 mm）z 只有 0.25 mm ⇒ 层数应远少于 ①；
  ③ targetHeightMm = 0 ⇒ 保持模型自带尺寸（这件自带 2 mm，metadata 记「模型自带尺寸」、缩放 1.0）。
"""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

import pytest

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from test_c_abi import BOX, OK, Sdk, default_lib  # noqa: E402


def _md5_dir(d: Path) -> str:
    h = hashlib.md5()
    for f in sorted(d.glob("*.bmp")):
        h.update(f.read_bytes())
    return h.hexdigest()


@pytest.fixture(scope="module")
def sdk():
    lib = default_lib()
    if lib is None or not lib.is_file():
        pytest.skip("还没出包：先跑 python tools/fry_build.py")
    return Sdk(lib)


def test_z_height_equals_longest_edge_on_non_cube(sdk, tmp_path):
    rc1, r1, e1 = sdk.slice_json({"model": str(BOX), "out": str(tmp_path / "h"), "params": {"target_height_mm": 1.0}})
    rc2, r2, e2 = sdk.slice_json({"model": str(BOX), "out": str(tmp_path / "l"), "params": {"target_longest_edge_mm": 4.0}})
    rc3, r3, e3 = sdk.slice_json({"model": str(BOX), "out": str(tmp_path / "old"), "params": {"target_longest_edge_mm": 1.0}})
    assert rc1 == rc2 == rc3 == OK, (e1, e2, e3)
    assert r1["size"]["height_z_mm_float"] == pytest.approx(1.0) and r1["size"]["longest_edge_mm_float"] == pytest.approx(4.0)
    assert _md5_dir(tmp_path / "h") == _md5_dir(tmp_path / "l"), "z 高度 1 mm 与最长边 4 mm 是同一个件，BMP 必须逐字节相同"
    assert r3["sliceCount"] < r1["sliceCount"] / 2, "最长边 1 mm 的件 z 只有 0.25 mm，层数应远少于 z 高度 1 mm 的件"


def test_zero_keeps_authored_size(sdk, tmp_path):
    rc, err = sdk.slice_utf8(BOX, tmp_path / "keep", 0.0)
    assert rc == OK, err
    meta = json.loads((tmp_path / "keep" / "slice_metadata.json").read_text(encoding="utf-8"))
    assert meta["size_dict"]["rule_str"] == "模型自带尺寸" and meta["size_dict"]["scale_float"] == 1.0, meta["size_dict"]
