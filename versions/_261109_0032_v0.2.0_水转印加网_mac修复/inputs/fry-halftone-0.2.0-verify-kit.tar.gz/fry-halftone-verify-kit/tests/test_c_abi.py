# -*- coding: utf-8 -*-
r"""test_c_abi.py —— **按消费方的姿势**把动态库用一遍（ctypes 就是最小的 C 消费方）。

【十一条用例 —— 正向和反向都要有（只验一个方向 = 只证明了一半）】
  ① 自报家门：版本 / 算法名 / 指纹 / 引擎 = cpp / 参数白名单 JSON 能解析 / 老的 worker 两个函数保持 ABI
  ② 正常跑通：一个长方体 → 一叠 BMP + slice_metadata.json + _orient.json；进度单调、带中文阶段名
  ③ 中文路径：输出目录带中文（宽字符 API）—— 编码写错在这里现形，不在客户那里
  ④ JSON 接口：换尺寸层数跟着变；★384 恢复的 K 墨 / 色带厚度**真的改变输出**（不是只进了白名单）
  ⑤ 反向 · 参数错：不认识的键 / 类型错 / 尺寸两个都给 / K 墨没给厚度 / NaN → 返回 2 且说人话
  ⑥ 反向 · 暂不支持：渐进式 JPEG / 实例化节点 / 近刚体矩阵 → 返回 7（UNSUPPORTED）；坏 JPEG → 返回 1 —— 绝不静默出一个与 Python 不同的结果
     （★384 第二期起基线 JPEG 与节点变换已支持 ⇒ 平移节点改当正向对照组）
  ⑦ 反向 · 中止：跑起来后 Cancel → 返回 CANCELLED
  ⑧ 反向 · 并发：一个作业在跑时再调一次 → 返回 BUSY
  ⑨ 结果缓冲太小 → 返回 2 并说要多少字节
  ⑩ ★387 参数说明的默认值是真的：只给尺寸 vs 把说明里的默认值全写出来 ⇒ 回显与 BMP md5 相同；反向：写错一个默认值 ⇒ md5 变
  ⑪ ★387 参数说明的取值范围是真的：按说明生成压线值（下限 / 刚过 / 越过 / 上限 / null / 错类型 / 非可选值）逐个喂给库，收拒与说明一致

【怎么跑】python tests/test_c_abi.py --lib out/sdk/fry-halftone-sdk/bin/fry_halftone.dll [--version 1.2.3]
  或 pytest（环境变量 FRY_HALFTONE_LIB 指向动态库）
"""
from __future__ import annotations

import argparse
import ctypes
import json
import math
import os
import platform
import shutil
import struct
import sys
import tempfile
import threading
import time
from pathlib import Path
from typing import Optional, Tuple

OK, FAILED, BAD_ARGUMENT, NO_WORKER, PROTOCOL, CANCELLED, BUSY, UNSUPPORTED = 0, 1, 2, 3, 4, 5, 6, 7
IS_WIN = platform.system() == "Windows"
FUNCTYPE = ctypes.WINFUNCTYPE if IS_WIN else ctypes.CFUNCTYPE
ProgressU8 = FUNCTYPE(None, ctypes.c_int, ctypes.c_char_p, ctypes.c_void_p)
ProgressW = FUNCTYPE(None, ctypes.c_int, ctypes.c_wchar_p, ctypes.c_void_p)
DATA = Path(__file__).resolve().parent / "data"
BOX = DATA / "vertex_gray_box.glb"
SPHERE = DATA / "gray_ramp_sphere.glb"
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "tools"))
import fry_param_schema as PS  # noqa: E402   ★387 参数说明怎么读（⑩⑪ 用它从说明推出期望）


def default_lib() -> Optional[Path]:
    env = os.environ.get("FRY_HALFTONE_LIB")
    if env:
        return Path(env)
    name = {"Windows": "fry_halftone.dll", "Darwin": "libfry_halftone.dylib"}.get(platform.system(), "libfry_halftone.so")
    cand = Path(__file__).resolve().parents[1] / "out" / "sdk" / "fry-halftone-sdk" / "bin" / name
    return cand if cand.is_file() else None


class Sdk:
    """把动态库包成一个薄薄的 Python 对象 —— 这段代码同时也是**给消费方看的最小示例**。"""

    def __init__(self, lib_path: Path) -> None:
        self.path = Path(lib_path)
        self.lib = ctypes.WinDLL(str(self.path)) if IS_WIN else ctypes.CDLL(str(self.path))
        for name, restype, argtypes in (
            ("FryHalftone_GetVersion", ctypes.c_char_p, []),
            ("FryHalftone_GetAlgorithmFingerprint", ctypes.c_char_p, []),
            ("FryHalftone_GetAlgorithmName", ctypes.c_char_p, []),
            ("FryHalftone_GetEngine", ctypes.c_char_p, []),
            ("FryHalftone_GetParamSchemaJson", ctypes.c_char_p, []),
            ("FryHalftone_GetWorkerPathUtf8", ctypes.c_char_p, []),
            ("FryHalftone_SetWorkerPathUtf8", ctypes.c_int, [ctypes.c_char_p]),
            ("FryHalftone_Cancel", ctypes.c_int, []),
            ("FryHalftone_SliceModelUtf8", ctypes.c_int,
             [ctypes.c_char_p, ctypes.c_char_p, ctypes.c_double, ProgressU8, ctypes.c_void_p, ctypes.c_char_p, ctypes.c_int]),
            ("FryHalftone_SliceModel", ctypes.c_int,
             [ctypes.c_wchar_p, ctypes.c_wchar_p, ctypes.c_double, ProgressW, ctypes.c_void_p, ctypes.c_wchar_p, ctypes.c_int]),
            ("FryHalftone_SliceModelJsonUtf8", ctypes.c_int,
             [ctypes.c_char_p, ctypes.c_char_p, ctypes.c_int, ProgressU8, ctypes.c_void_p, ctypes.c_char_p, ctypes.c_int]),
        ):
            fn = getattr(self.lib, name)
            fn.restype, fn.argtypes = restype, argtypes

    def version(self) -> str:
        return self.lib.FryHalftone_GetVersion().decode("utf-8")

    def fingerprint(self) -> str:
        return self.lib.FryHalftone_GetAlgorithmFingerprint().decode("utf-8")

    def algorithm(self) -> str:
        return self.lib.FryHalftone_GetAlgorithmName().decode("utf-8")

    def engine(self) -> str:
        return self.lib.FryHalftone_GetEngine().decode("utf-8")

    def schema(self) -> dict:
        return json.loads(self.lib.FryHalftone_GetParamSchemaJson().decode("utf-8"))

    def slice_utf8(self, model: Path, out: Path, target_mm: float = 0.0, on_progress=None) -> Tuple[int, str]:
        err = ctypes.create_string_buffer(4096)
        cb = ProgressU8(on_progress) if on_progress else ctypes.cast(None, ProgressU8)
        rc = self.lib.FryHalftone_SliceModelUtf8(str(model).encode("utf-8"), str(out).encode("utf-8"),
                                                 ctypes.c_double(target_mm), cb, None, err, len(err))
        return rc, err.value.decode("utf-8", "replace")

    def slice_wide(self, model: Path, out: Path, target_mm: float = 0.0) -> Tuple[int, str]:
        err = ctypes.create_unicode_buffer(2048)
        rc = self.lib.FryHalftone_SliceModel(str(model), str(out), ctypes.c_double(target_mm),
                                             ctypes.cast(None, ProgressW), None, err, len(err))
        return rc, err.value

    def slice_json(self, request: dict, on_progress=None, result_bytes: int = 16384) -> Tuple[int, dict, str]:
        res = ctypes.create_string_buffer(result_bytes)
        err = ctypes.create_string_buffer(4096)
        cb = ProgressU8(on_progress) if on_progress else ctypes.cast(None, ProgressU8)
        rc = self.lib.FryHalftone_SliceModelJsonUtf8(json.dumps(request, ensure_ascii=False).encode("utf-8"),
                                                     res, len(res), cb, None, err, len(err))
        raw = res.value.decode("utf-8", "replace")
        try:
            parsed = json.loads(raw) if raw else {}
        except Exception:                                                # noqa: BLE001
            parsed = {"_raw": raw}
        return rc, parsed, err.value.decode("utf-8", "replace")

    def cancel(self) -> int:
        return self.lib.FryHalftone_Cancel()


def count_bmp(d: Path) -> int:
    return len(list(d.glob("*.bmp")))


# 渐进式 JPEG 的最小「头」：SOI + SOF2（8 位、1×1、1 个分量）+ EOI —— 解码器读到 SOF2 就该判「暂不支持」
PROGRESSIVE_JPEG = b"\xff\xd8" + b"\xff\xc2\x00\x0b\x08\x00\x01\x00\x01\x01\x01\x11\x00" + b"\xff\xd9"
# 坏 JPEG：APP0 段长度写成 0 —— 不是「不支持」而是「文件坏了」，应返回 1（FAILED）
BROKEN_JPEG = b"\xff\xd8\xff\xe0" + b"\0" * 12 + b"\xff\xd9"
# 近刚体矩阵（列优先）：x 轴缩放 1+1e-7 ⇒ max|R·Rᵀ−I|≈2e-7 落在 (1e-13, 1e-5) —— trimesh 会用 SVD 修正，C++ 不复刻
NEAR_RIGID = [1.0 + 1e-7, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]


def write_glb(path: Path, *, image: Optional[bytes] = None, translate: bool = False, instanced: bool = False,
              matrix: Optional[list] = None) -> None:
    """手写一个最小 GLB（一个三角形）：image=带一张贴图（任意字节）；translate=节点带平移；
    instanced=同一个 mesh 节点挂在两个父节点下；matrix=节点矩阵（列优先 16 个数）。"""
    pos = struct.pack("<9f", 0, 0, 0, 1, 0, 0, 0, 1, 0)
    uv = struct.pack("<6f", 0, 0, 1, 0, 0, 1)
    idx = struct.pack("<3I", 0, 1, 2)
    jpeg = image is not None
    blobs = [pos, uv, idx] + ([image] if jpeg else [])
    views, off, binbuf = [], 0, b""
    for b in blobs:
        pad = (-len(binbuf)) % 4
        binbuf += b"\0" * pad
        off = len(binbuf)
        views.append({"buffer": 0, "byteOffset": off, "byteLength": len(b)})
        binbuf += b
    binbuf += b"\0" * ((-len(binbuf)) % 4)
    node = dict({"mesh": 0}, **({"translation": [1.0, 0.0, 0.0]} if translate else {}), **({"matrix": matrix} if matrix else {}))
    js = {"asset": {"version": "2.0"}, "scene": 0, "scenes": [{"nodes": [0]}], "nodes": [node],
          "buffers": [{"byteLength": len(binbuf)}], "bufferViews": views,
          "accessors": [{"bufferView": 0, "componentType": 5126, "count": 3, "type": "VEC3", "min": [0, 0, 0], "max": [1, 1, 0]},
                        {"bufferView": 1, "componentType": 5126, "count": 3, "type": "VEC2"},
                        {"bufferView": 2, "componentType": 5125, "count": 3, "type": "SCALAR"}],
          "meshes": [{"primitives": [dict({"attributes": {"POSITION": 0, "TEXCOORD_0": 1}, "indices": 2}, **({"material": 0} if jpeg else {}))]}]}
    if instanced:
        js.update({"scenes": [{"nodes": [0, 1]}], "nodes": [{"children": [2]}, {"children": [2]}, {"mesh": 0}]})
    if jpeg:
        js.update({"materials": [{"pbrMetallicRoughness": {"baseColorTexture": {"index": 0}}}], "textures": [{"source": 0}],
                   "images": [{"bufferView": 3, "mimeType": "image/jpeg"}]})
    jb = json.dumps(js).encode("utf-8")
    jb += b" " * ((-len(jb)) % 4)
    total = 12 + 8 + len(jb) + 8 + len(binbuf)
    path.write_bytes(struct.pack("<4sII", b"glTF", 2, total) + struct.pack("<II", len(jb), 0x4E4F534A) + jb +
                     struct.pack("<II", len(binbuf), 0x004E4942) + binbuf)


# ═══════════════════════════ 用例 ═══════════════════════════
def case_identity(sdk: Sdk, expect_version: Optional[str]) -> None:
    ver, algo, fp, eng = sdk.version(), sdk.algorithm(), sdk.fingerprint(), sdk.engine()
    print("  版本 %s ｜ 算法 %s ｜ 引擎 %s ｜ 指纹 %.16s…" % (ver, algo, eng, fp or "(空)"))
    assert algo == "water_transfer_depth", algo
    assert eng == "cpp", eng
    assert len(fp) == 64 and all(c in "0123456789abcdef" for c in fp), "算法指纹应当是 64 位十六进制（CMake 从 cpp.lock.json 读）：%r" % fp
    if expect_version:
        assert ver == expect_version, "自报版本 %r ≠ 期望 %r" % (ver, expect_version)
    names = [p["name"] for p in sdk.schema()["params"]]
    for must in ("target_height_mm", "target_longest_edge_mm", "use_black_k", "ink_k_um", "black_k_amount", "color_thickness_mm"):
        assert must in names, "参数白名单里缺 %s" % must
    assert sdk.lib.FryHalftone_GetWorkerPathUtf8() == b"" and sdk.lib.FryHalftone_SetWorkerPathUtf8(b"x") == OK


def case_run(sdk: Sdk, tmp: Path) -> None:
    out = tmp / "slices"
    seen = []
    rc, err = sdk.slice_utf8(BOX, out, 1.0, lambda p, s, u: seen.append((p, (s or b"").decode("utf-8", "replace"))))
    assert rc == OK, "返回码 %d：%s" % (rc, err)
    n = count_bmp(out)
    meta = json.loads((out / "slice_metadata.json").read_text(encoding="utf-8"))
    orient = json.loads((out / "_orient.json").read_text(encoding="utf-8"))
    print("  切片 %d 张 ｜ 进度 %d 条 ｜ 最后一条 %s ｜ 尺寸 %s" % (n, len(seen), seen[-1] if seen else "(无)", meta["size_dict"]))
    assert n > 0 and meta["slice_count_int"] == n
    assert meta["engine_str"] == "cpp" and meta["algorithm_str"] == "water_transfer_depth"
    assert meta["size_dict"]["rule_str"] == "z 高度" and abs(meta["size_dict"]["height_z_mm_float"] - 1.0) < 1e-9, meta["size_dict"]
    assert orient["output_width_px"] == meta["output_width_px_int"]
    assert len(seen) >= 5 and [p for p, _ in seen] == sorted(p for p, _ in seen) and seen[-1][0] == 100
    assert any("加网" in s for _, s in seen), "进度里没有中文阶段名 —— UTF-8 通道可能坏了"


def case_chinese_path(sdk: Sdk, tmp: Path) -> None:
    src = tmp / "模型 目录" / "长方体.glb"
    src.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(BOX, src)
    out = tmp / "中文 输出目录_测试"
    rc, err = sdk.slice_wide(src, out, 1.0)
    assert rc == OK, "宽字符接口返回 %d：%s" % (rc, err)
    assert count_bmp(out) > 0
    print("  中文路径（模型 + 输出）切片 %d 张 ✓" % count_bmp(out))


def case_json_params_take_effect(sdk: Sdk, tmp: Path) -> None:
    def run(name: str, params: dict) -> dict:
        rc, res, err = sdk.slice_json({"model": str(SPHERE), "out": str(tmp / name), "params": params})
        assert rc == OK, "%s 返回 %d：%s" % (name, rc, err)
        return res
    base = run("j_base", {"target_longest_edge_mm": 4.0})
    big = run("j_big", {"target_longest_edge_mm": 6.0})
    k1 = run("j_k1", {"target_longest_edge_mm": 4.0, "use_black_k": True, "ink_k_um": 400})
    k05 = run("j_k05", {"target_longest_edge_mm": 4.0, "use_black_k": True, "ink_k_um": 400, "black_k_amount": 0.5})
    thin = run("j_thin", {"target_longest_edge_mm": 4.0, "color_thickness_mm": 0.6})
    thick = run("j_thick", {"target_longest_edge_mm": 4.0, "color_thickness_mm": 2.4})
    print("  层数 4 mm→%d / 6 mm→%d ｜ 落墨 无K %d / K×1 %d / K×0.5 %d ｜ 色带 %.2f→%d / %.2f→%d / %.2f→%d"
          % (base["sliceCount"], big["sliceCount"], base["inkedVoxels"], k1["inkedVoxels"], k05["inkedVoxels"],
             base["bandThicknessMm"], base["inkedVoxels"], thin["bandThicknessMm"], thin["inkedVoxels"],
             thick["bandThicknessMm"], thick["inkedVoxels"]))
    assert big["sliceCount"] > base["sliceCount"] * 1.3, "尺寸参数没传下去"
    assert base["colorChannels"] == 3 and k1["colorChannels"] == 4, "use_black_k 没让通道数变成 4"
    assert base["bmpMd5"] != k1["bmpMd5"] != k05["bmpMd5"], "K 墨 / 替换强度没改变输出（在灰阶球上必须改变）"
    assert abs(base["bandThicknessMm"] - 1.2) < 1e-12 and abs(k1["bandThicknessMm"] - 1.6) < 1e-12, "默认色带厚度应 = 满喷之和"
    assert thin["bandThicknessMm"] == 0.6 and thick["bandThicknessMm"] == 2.4
    assert len({base["bmpMd5"], thin["bmpMd5"], thick["bmpMd5"]}) == 3, "色带厚度没改变输出"


def case_bad_input(sdk: Sdk, tmp: Path) -> None:
    checks = [
        ({"model": str(tmp / "根本不存在.glb"), "out": str(tmp / "n1"), "params": {"target_height_mm": 1}}, BAD_ARGUMENT, "找不到"),
        ({"model": str(BOX), "out": str(tmp / "n2"), "params": {"没有这个键": 1}}, BAD_ARGUMENT, "不认识"),
        ({"model": str(BOX), "out": str(tmp / "n3"), "params": {"target_height_mm": 1, "support_enable": "false"}}, BAD_ARGUMENT, "布尔"),
        ({"model": str(BOX), "out": str(tmp / "n4"), "params": {"target_height_mm": 1, "target_longest_edge_mm": 4}}, BAD_ARGUMENT, "只能给一个"),
        ({"model": str(BOX), "out": str(tmp / "n5"), "params": {}}, BAD_ARGUMENT, "必须给尺寸"),
        ({"model": str(BOX), "out": str(tmp / "n6"), "params": {"target_height_mm": 1, "use_black_k": True}}, BAD_ARGUMENT, "ink_k_um"),
        ({"model": str(BOX), "out": str(tmp / "n7"), "params": {"target_height_mm": 1, "black_k_amount": 1.5}}, BAD_ARGUMENT, "[0, 1]"),
        ({"model": str(BOX), "out": str(tmp / "n8"), "params": {"target_height_mm": 1, "output_width_px": 12.5}}, BAD_ARGUMENT, "整数"),
        ({"model": str(BOX), "out": str(tmp / "n9"), "params": {"target_height_mm": 1, "ink_c_um": 0, "ink_m_um": 0, "ink_y_um": 0}}, BAD_ARGUMENT, "都是 0"),
        ({"out": str(tmp / "n10")}, BAD_ARGUMENT, "model"),
        ({"model": str(BOX), "out": str(tmp / "n11"), "params": {"target_height_mm": 1, "output_width_px": 1}}, FAILED, "输出宽度 1 小于模型本身"),
    ]
    for req, want_rc, want_text in checks:
        rc, _res, err = sdk.slice_json(req)
        print("  rc=%d（期望 %d）%s" % (rc, want_rc, err.splitlines()[0] if err else "(没说话)"))
        assert rc == want_rc and want_text in err, (req, rc, err)
    for bad in (float("nan"), float("inf"), -1.0):
        rc, err = sdk.slice_utf8(BOX, tmp / "n12", bad)
        assert rc == BAD_ARGUMENT and err.strip(), (bad, rc, err)


def case_unsupported(sdk: Sdk, tmp: Path) -> None:
    for name, kw, want_rc, text in (("progressive.glb", {"image": PROGRESSIVE_JPEG}, UNSUPPORTED, "渐进式"),
                                    ("instanced.glb", {"instanced": True}, UNSUPPORTED, "实例化"),
                                    ("near_rigid.glb", {"matrix": NEAR_RIGID}, UNSUPPORTED, "SVD"),
                                    ("broken_jpeg.glb", {"image": BROKEN_JPEG}, FAILED, "JPEG")):
        p = tmp / name
        write_glb(p, **kw)
        rc, _res, err = sdk.slice_json({"model": str(p), "out": str(tmp / ("u_" + name)), "params": {"target_longest_edge_mm": 2}})
        print("  %s → rc=%d（期望 %d）：%s" % (name, rc, want_rc, err.splitlines()[0] if err else ""))
        assert rc == want_rc and text in err, (name, rc, err)
        assert not list((tmp / ("u_" + name)).glob("*.bmp")), "%s 失败了却留下了 BMP" % name
    for name, kw in (("plain.glb", {}), ("moved.glb", {"translate": True})):
        p = tmp / name
        write_glb(p, **kw)
        rc, res, err = sdk.slice_json({"model": str(p), "out": str(tmp / ("u_" + name)), "params": {"target_longest_edge_mm": 2}})
        print("  对照组 %s → rc=%d" % (name, rc))
        assert rc == OK, "对照组（同一个三角形；平移节点 384 起已支持）必须能跑：%s %d %s" % (name, rc, err)


def case_cancel(sdk: Sdk, tmp: Path) -> None:
    box: dict = {}
    started = threading.Event()

    def on_progress(percent: int, _stage, _user) -> None:
        if percent >= 5:
            started.set()
            time.sleep(0.05)

    def worker() -> None:
        box["rc"], box["err"] = sdk.slice_utf8(SPHERE, tmp / "cancelled", 3.0, on_progress)

    th = threading.Thread(target=worker, daemon=True)
    th.start()
    assert started.wait(120), "120 秒都没等到第一条进度"
    sdk.cancel()
    th.join(120)
    print("  中止后返回码 %s（期望 %d）" % (box.get("rc"), CANCELLED))
    assert box.get("rc") == CANCELLED, (box.get("rc"), box.get("err"))


def case_busy(sdk: Sdk, tmp: Path) -> None:
    started, release = threading.Event(), threading.Event()
    box: dict = {}

    def on_progress(percent: int, _stage, _user) -> None:
        if percent >= 5 and not started.is_set():
            started.set()
            release.wait(60)

    th = threading.Thread(target=lambda: box.update(rc=sdk.slice_utf8(BOX, tmp / "busy_a", 1.0, on_progress)[0]), daemon=True)
    th.start()
    assert started.wait(60)
    rc2, err2 = sdk.slice_utf8(BOX, tmp / "busy_b", 1.0)
    release.set()
    th.join(120)
    print("  第二个并发作业 rc=%d（期望 %d）：%s ｜ 第一个 rc=%s" % (rc2, BUSY, err2, box.get("rc")))
    assert rc2 == BUSY and box.get("rc") == OK


def case_small_result_buffer(sdk: Sdk, tmp: Path) -> None:
    rc, _res, err = sdk.slice_json({"model": str(BOX), "out": str(tmp / "tiny_buf"), "params": {"target_height_mm": 1}}, result_bytes=16)
    print("  resultJson 只给 16 字节 → rc=%d：%s" % (rc, err))
    assert rc == BAD_ARGUMENT and "字节" in err


def case_schema_defaults_are_real(sdk: Sdk, tmp: Path) -> None:
    schema = sdk.schema()
    problems = PS.schema_problems(schema)
    assert not problems, "参数说明形状不合格：%s" % problems
    defaults = PS.defaults_of(schema)
    size = {"target_height_mm": 1.0}

    def run(name: str, params: dict) -> dict:
        rc, res, err = sdk.slice_json({"model": str(BOX), "out": str(tmp / name), "params": params})
        assert rc == OK, "%s 返回 %d：%s" % (name, rc, err)
        return res
    # ★449 期望回显 / 「默认值全写出来」都由说明推出：only_when 不满足的键不许写（库返回 2），echo_omit_when 满足的键不回显
    omit = run("d_omit", size)
    full = run("d_full", PS.explicit_defaults(schema, size))
    wrong = run("d_wrong", dict(PS.explicit_defaults(schema, size), ink_c_um=defaults["ink_c_um"] + 100.0))
    print("  %s ｜ %d 个参数 ｜ 只给尺寸 md5 %.12s ｜ 默认值全写出 %.12s ｜ 写错一个默认值(ink_c_um+100) %.12s"
          % (schema["schema"], len(defaults), omit["bmpMd5"], full["bmpMd5"], wrong["bmpMd5"]))
    want = PS.expected_echo(schema, size)
    assert omit["params"] == want, "省略参数时库真正用的值 ≠ 说明写的默认值：%s" % {
        k: (omit["params"].get(k), want.get(k)) for k in set(want) | set(omit["params"]) if omit["params"].get(k) != want.get(k)}
    assert full["params"] == omit["params"] and full["bmpMd5"] == omit["bmpMd5"], "把默认值显式写出来，结果变了"
    assert wrong["bmpMd5"] != omit["bmpMd5"], "反向对照没响：写错一个默认值 md5 不变 ⇒ 这把尺子抓不到写错的默认值"
    # ★449 统一引擎（库认 wt_engine 才跑）：每个预设下「只开引擎 + 选预设」 = 「把该预设下许出现的默认值全写出来」
    names = {p["name"] for p in schema["params"]}
    if "wt_engine" not in names:
        print("  （这个库没有统一引擎 wt_engine：跳过统一引擎的默认值核对）")
        return
    spec_preset = next(p for p in schema["params"] if p["name"] == "wt_preset")
    md5s = {}
    for preset in spec_preset["choices"]:
        given = dict(size, wt_engine="unified", wt_preset=preset)
        o = run("u_omit_" + preset, given)
        f = run("u_full_" + preset, PS.explicit_defaults(schema, given))
        want = PS.expected_echo(schema, given)
        assert o["params"] == want, "统一引擎 %s：省略时回显 ≠ 说明推出的期望：%s" % (preset, {
            k: (o["params"].get(k), want.get(k)) for k in set(want) | set(o["params"]) if o["params"].get(k) != want.get(k)})
        assert f["params"] == o["params"] and f["bmpMd5"] == o["bmpMd5"], "统一引擎 %s：把默认值显式写出来，结果变了" % preset
        assert o["algorithm"] == ("water_transfer_unified" if preset == "custom" else "water_transfer_unified_" + preset), o["algorithm"]
        md5s[preset] = o["bmpMd5"]
    print("  统一引擎四个预设：省略 = 显式默认值（回显与 md5 都相同）｜ md5 %s" % " / ".join("%s %.8s" % kv for kv in md5s.items()))
    assert md5s.get("he500") == omit["bmpMd5"], "unified + he500 应与 legacy 逐字节相同（统一代码的 HE500 预设 = 原 HE500）"
    assert len({md5s[k] for k in ("he500", "he510", "he520")}) == 3, "反向对照：三个预设出的片应当各不相同 ⇒ 预设开关没生效"


def case_schema_ranges_are_real(sdk: Sdk, tmp: Path) -> None:
    """模型路径故意不存在：参数全过时库回「找不到模型文件」；参数被拒时回的原因里带参数名。收 / 拒的期望由说明推出（不写死）。"""
    schema = sdk.schema()
    missing = tmp / "不存在的模型.glb"
    n, bad = 0, []
    for spec in schema["params"]:
        for value in PS.boundary_probes(spec):
            params = PS.probe_params(schema, spec["name"], value)
            rc, _res, err = sdk.slice_json({"model": str(missing), "out": str(tmp / "probe"), "params": params})
            want_ok = not PS.value_problems(spec, value)
            got_ok = rc == BAD_ARGUMENT and err.startswith("找不到模型文件")
            got_reject = rc == BAD_ARGUMENT and spec["name"] in err
            n += 1
            if want_ok != got_ok or (not want_ok and not got_reject):
                bad.append("%s=%s：说明推出「%s」，库 rc=%d「%s」" % (spec["name"], json.dumps(value, ensure_ascii=False),
                                                           "收" if want_ok else "拒", rc, err[:60]))
    print("  压线探针 %d 个（%d 个参数）｜ 收拒与说明不一致 %d 个" % (n, len(schema["params"]), len(bad)))
    assert n >= 3 * len(schema["params"]), "探针太少（%d 个）：这道闸几乎没查" % n
    assert not bad, "\n    ".join(bad)


def run_all(lib_path: Path, expect_version: Optional[str]) -> int:
    sdk = Sdk(lib_path)
    tmp = Path(tempfile.mkdtemp(prefix="fry_sdk_abi_"))
    cases = (("① 自报家门", lambda: case_identity(sdk, expect_version)),
             ("② 正常跑通", lambda: case_run(sdk, tmp)),
             ("③ 中文路径", lambda: case_chinese_path(sdk, tmp)),
             ("④ JSON 参数真的生效", lambda: case_json_params_take_effect(sdk, tmp)),
             ("⑤ 反向 · 参数错", lambda: case_bad_input(sdk, tmp)),
             ("⑥ 反向 · 暂不支持", lambda: case_unsupported(sdk, tmp)),
             ("⑦ 反向 · 中止", lambda: case_cancel(sdk, tmp)),
             ("⑧ 反向 · 并发", lambda: case_busy(sdk, tmp)),
             ("⑨ 反向 · 结果缓冲太小", lambda: case_small_result_buffer(sdk, tmp)),
             ("⑩ 参数说明的默认值是真的", lambda: case_schema_defaults_are_real(sdk, tmp)),
             ("⑪ 参数说明的取值范围是真的", lambda: case_schema_ranges_are_real(sdk, tmp)))
    bad = 0
    for name, fn in cases:
        t0 = time.perf_counter()
        print("\n── %s" % name, flush=True)
        try:
            fn()
            print("  ✓ 通过（%.1f s）" % (time.perf_counter() - t0))
        except Exception as ex:                                          # noqa: BLE001
            bad += 1
            print("  ✗ 失败：%s: %s" % (type(ex).__name__, ex))
    shutil.rmtree(tmp, ignore_errors=True)
    print("\n%s C 接口用例 %d / %d 通过" % ("✓" if not bad else "✗", len(cases) - bad, len(cases)))
    return 1 if bad else 0


def test_c_abi() -> None:
    import pytest
    lib = default_lib()
    if lib is None or not lib.is_file():
        pytest.skip("还没出包：先跑 python tools/fry_build.py")
    assert run_all(lib, os.environ.get("FRY_HALFTONE_EXPECT_VERSION")) == 0


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    ap = argparse.ArgumentParser()
    ap.add_argument("--lib", default=None)
    ap.add_argument("--version", default=None)
    ns = ap.parse_args()
    path = Path(ns.lib) if ns.lib else default_lib()
    if path is None or not Path(path).is_file():
        raise SystemExit("✗ 找不到动态库；用 --lib 指一个，或先跑 python tools/fry_build.py")
    raise SystemExit(run_all(Path(path), ns.version))
