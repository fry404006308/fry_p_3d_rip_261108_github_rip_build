# -*- coding: utf-8 -*-
r"""test_delivery_version.py —— ★411 交付版本号（tools/fry_delivery_version.py + fry_release.resolve_version）。

① 规则：0.1.0 起；patch / minor / major 递增；0.0.0-dev 不许交付；只增不减；同一个版本号只对应一批字节（三个包的 sha256）；
② CHANGELOG：「未发布」挪到「## X.Y.Z（日期）」下；幂等（再跑不重复分节）；保留 CRLF；占位行不进版本节；空节写明「只是重新打包」；
③ fry_release.resolve_version：交付自动取下一个并分节；手填的必须是 X.Y.Z 且更大；正式版号必须大于已交付；
   只发版不交付不动 CHANGELOG；调试构建 = 0.0.0-dev。全部在临时仓里做（**不许碰真仓的 CHANGELOG / 交付记录**）。
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO / "tools"))
import fry_delivery_version as DV  # noqa: E402
import fry_release as R  # noqa: E402

CL = "# CHANGELOG\n\n## 未发布\n\n### ★新功能甲\n- 细节 1\n\n### ★修复乙\n- 细节 2\n\n## 0.0.9（2026-09-01）\n\n### 旧的\n- x\n"


def _state(*versions, packages=None) -> dict:
    return {"deliveries_list": [{"version_str": v, "packages_dict": packages or {"win32-x64": "a" * 64}} for v in versions]}


# ───────────────────────────── ① 规则 ─────────────────────────────
def test_first_version_and_bumps():
    assert DV.next_version({"deliveries_list": []}) == "0.1.0" == DV.FIRST_VERSION
    st = _state("0.1.0", "0.1.9", "0.1.10")                      # 按数字比较，不按字符串（0.1.10 > 0.1.9）
    assert DV.last_version(st) == "0.1.10"
    assert DV.next_version(st) == "0.1.11"
    assert DV.next_version(st, "minor") == "0.2.0" and DV.next_version(st, "major") == "1.0.0"
    assert DV.last_version(_state("0.0.0-dev")) is None           # 调试构建不算交付过


@pytest.mark.parametrize("v", ["0.0.0-dev", "v0.1.0", "0.1", "0.1.0.1", "", "1.2.x"])
def test_only_plain_xyz_is_deliverable(v):
    probs = DV.version_problems(v, {}, {"deliveries_list": []})
    assert probs and "X.Y.Z" in probs[0]


def test_monotonic_and_same_version_same_bytes():
    pk = {"win32-x64": "a" * 64, "linux-x64": "b" * 64, "verify-kit": "c" * 64}
    st = _state("0.1.0", "0.1.1", packages=pk)
    assert DV.version_problems("0.1.2", pk, st) == []
    assert "只能递增" in DV.version_problems("0.1.0", pk, _state("0.1.0", "0.1.1", packages=pk))[0]
    assert DV.version_problems("0.1.1", pk, st) == []                            # 同号同字节：允许重出目录
    other = dict(pk, **{"linux-x64": "d" * 64})
    probs = DV.version_problems("0.1.1", other, st)
    assert probs and "已经交付过" in probs[0] and "0.1.2" in probs[0]            # 同号换字节：拒绝，并给出下一个号


def test_record_appends_and_keeps_note(tmp_path):
    DV.record({"version_str": "0.1.0"}, tmp_path)
    DV.record({"version_str": "0.1.1"}, tmp_path)
    st = json.loads(DV.state_path(tmp_path).read_text(encoding="utf-8"))
    assert [d["version_str"] for d in st["deliveries_list"]] == ["0.1.0", "0.1.1"]
    assert "不要手改" in st["note_str"] and st["schema_str"] == "fry-halftone-deliveries/1"


# ───────────────────────────── ② CHANGELOG ─────────────────────────────
def test_stamp_moves_unreleased_under_version(tmp_path):
    p = tmp_path / "CHANGELOG.md"
    p.write_bytes(CL.encode("utf-8"))
    assert DV.stamp_changelog("0.1.1", "2026-09-23", p) is True
    text = p.read_text(encoding="utf-8")
    assert text.index("## 未发布") < text.index("## 0.1.1（2026-09-23）") < text.index("## 0.0.9（2026-09-01）")
    sec = DV.changelog_section(text, "0.1.1")
    assert "★新功能甲" in sec and "★修复乙" in sec and "旧的" not in sec
    unrel = text.split("## 未发布", 1)[1].split("## 0.1.1", 1)[0]
    assert "★新功能甲" not in unrel and DV.PLACEHOLDER in unrel                   # 未发布只剩占位行
    before = p.read_bytes()
    assert DV.stamp_changelog("0.1.1", "2026-09-24", p) is False and p.read_bytes() == before   # 幂等
    # 下一版：只有占位行 ⇒ 占位行不进版本节，写明「只是重新打包」
    assert DV.stamp_changelog("0.1.2", "2026-09-25", p) is True
    sec2 = DV.changelog_section(p.read_text(encoding="utf-8"), "0.1.2")
    assert "只是重新打包" in sec2 and DV.PLACEHOLDER not in sec2


def test_stamp_merges_new_entries_into_an_existing_undelivered_section(tmp_path):
    """上次出包分了节却没交付（中途失败），之后又在「未发布」记了新条目 ⇒ 并进同一节的开头，不能静默留在「未发布」。"""
    p = tmp_path / "CHANGELOG.md"
    p.write_bytes(CL.encode("utf-8"))
    DV.stamp_changelog("0.1.0", "2026-09-23", p)
    text = p.read_text(encoding="utf-8").replace(DV.PLACEHOLDER, DV.PLACEHOLDER + "\n\n### ★补记丙\n- 细节 3")
    p.write_text(text, encoding="utf-8", newline="\n")
    assert DV.stamp_changelog("0.1.0", "2026-09-24", p) is True
    text = p.read_text(encoding="utf-8")
    sec = DV.changelog_section(text, "0.1.0")
    assert sec.index("★补记丙") < sec.index("★新功能甲") and text.count("## 0.1.0") == 1
    assert "★补记丙" not in text.split("## 0.1.0", 1)[0]
    assert DV.stamp_changelog("0.1.0", "2026-09-25", p) is False              # 再跑：没有新条目 ⇒ 不动


def test_stamp_keeps_crlf(tmp_path):
    p = tmp_path / "CHANGELOG.md"
    p.write_bytes(CL.replace("\n", "\r\n").encode("utf-8"))
    DV.stamp_changelog("0.1.1", "2026-09-23", p)
    b = p.read_bytes()
    assert b.count(b"\r\n") == b.count(b"\n") and b"## 0.1.1" in b


def test_stamp_without_unreleased_refuses(tmp_path):
    p = tmp_path / "CHANGELOG.md"
    p.write_text("# CHANGELOG\n\n## 0.1.0\n", encoding="utf-8")
    with pytest.raises(SystemExit):
        DV.stamp_changelog("0.1.1", "2026-09-23", p)


def test_changelog_section_absent_is_empty():
    assert DV.changelog_section(CL, "9.9.9") == ""
    assert DV.changelog_section(CL, "0.0.9").startswith("### 旧的")


# ───────────────────────────── ③ fry_release.resolve_version（临时仓） ─────────────────────────────
@pytest.fixture()
def tmp_repo(tmp_path):
    (tmp_path / "CHANGELOG.md").write_bytes(CL.encode("utf-8"))
    return tmp_path


def test_bundle_takes_next_version_and_stamps(tmp_repo):
    v, stamped = R.resolve_version(None, None, True, repo=tmp_repo)
    assert (v, stamped) == ("0.1.0", True)
    assert "## 0.1.0（" in (tmp_repo / "CHANGELOG.md").read_text(encoding="utf-8")
    DV.record({"version_str": "0.1.0", "packages_dict": {}}, tmp_repo)
    assert R.resolve_version("auto", None, False, repo=tmp_repo)[0] == "0.1.1"          # --version auto 不带 --bundle 也一样
    assert R.resolve_version(None, None, True, bump="minor", repo=tmp_repo)[0] == "0.2.0"


def test_bundle_refuses_hand_written_bad_versions(tmp_repo):
    DV.record({"version_str": "0.2.0", "packages_dict": {}}, tmp_repo)
    with pytest.raises(RuntimeError, match="X.Y.Z"):
        R.resolve_version("0.0.0-dev", None, True, repo=tmp_repo)
    with pytest.raises(RuntimeError, match="只能递增"):
        R.resolve_version("0.1.9", None, True, repo=tmp_repo)
    assert R.resolve_version("0.3.0", None, True, repo=tmp_repo)[0] == "0.3.0"


def test_tag_must_exceed_delivered_and_stamps_only_with_bundle(tmp_repo):
    DV.record({"version_str": "0.2.0", "packages_dict": {}}, tmp_repo)
    with pytest.raises(RuntimeError, match="不大于已交付"):
        R.resolve_version(None, "v0.2.0", False, repo=tmp_repo)
    before = (tmp_repo / "CHANGELOG.md").read_bytes()
    assert R.resolve_version(None, "v0.3.0", False, repo=tmp_repo) == ("0.3.0", False)
    assert (tmp_repo / "CHANGELOG.md").read_bytes() == before                           # 只发版不交付：不动 CHANGELOG
    assert R.resolve_version(None, "v0.3.0", True, repo=tmp_repo) == ("0.3.0", True)    # 发版 + 全交付目录：分节


def test_plain_build_is_dev_and_touches_nothing(tmp_repo):
    before = (tmp_repo / "CHANGELOG.md").read_bytes()
    assert R.resolve_version(None, None, False, repo=tmp_repo) == ("0.0.0-dev", False)
    assert R.resolve_version("1.2.3", None, False, repo=tmp_repo) == ("1.2.3", False)   # 本地出包：给什么用什么
    assert (tmp_repo / "CHANGELOG.md").read_bytes() == before and not DV.state_path(tmp_repo).exists()


def test_real_repo_changelog_has_unreleased_section():
    """真仓的 CHANGELOG 必须一直有「## 未发布」（交付时要从它挪；没有它 stamp_changelog 会拒绝）。"""
    text = (REPO / "CHANGELOG.md").read_text(encoding="utf-8").replace("\r\n", "\n")
    assert (DV.UNRELEASED + "\n") in text


# ───────────────────────────── ④ ★412 残留节改号 + 自动定升哪一位 ─────────────────────────────
def test_is_leftover_section():
    assert DV.is_leftover_section("0.1.2", "0.2.0", None) is False             # 调用方没说交付过哪些 ⇒ 一律不改号（安全缺省）
    assert DV.is_leftover_section("0.1.2", "0.2.0", {"0.1.0", "0.1.1"}) is True
    assert DV.is_leftover_section("0.1.1", "0.2.0", {"0.1.0", "0.1.1"}) is False   # 交付过的节永远不动
    assert DV.is_leftover_section("0.2.0", "0.2.0", {"0.1.1"}) is False          # 就是这次的号
    assert DV.is_leftover_section("0.0.9", "0.1.0", set()) is False              # 编号版之前手写的旧节（比 0.1.0 小）
    assert DV.is_leftover_section("0.1.0", "0.2.0", set()) is True               # 第一次交付就中途失败过
    assert DV.is_leftover_section("0.1.0-rc1", "0.2.0", {"0.1.1"}) is False      # 不是 X.Y.Z 不认


LEFTOVER_CL = ("# CHANGELOG\n\n## 未发布\n\n### ★新记丁\n- 4\n\n## 0.1.2（2026-09-20）\n\n### ★残留戊\n- 5\n\n"
               "## 0.1.1（2026-09-10）\n\n### 已交付己\n- 6\n")


def test_stamp_renames_a_leftover_section_and_keeps_delivered_ones(tmp_path):
    """上次按修订号分了 0.1.2 的节、出包中途失败；这次按接口面判定升次版本 0.2.0 ⇒ 0.1.2 那一节改号成 0.2.0（内容原样），
    新记的条目并进来；已交付的 0.1.1 一个字不动。"""
    p = tmp_path / "CHANGELOG.md"
    p.write_bytes(LEFTOVER_CL.encode("utf-8"))
    assert DV.stamp_changelog("0.2.0", "2026-09-24", p, {"0.1.0", "0.1.1"}) is True
    text = p.read_text(encoding="utf-8")
    assert "## 0.1.2" not in text and text.count("## 0.2.0（2026-09-24）") == 1
    sec = DV.changelog_section(text, "0.2.0")
    assert sec.index("★新记丁") < sec.index("★残留戊")
    assert DV.changelog_section(text, "0.1.1") == "### 已交付己\n- 6"
    assert DV.stamp_changelog("0.2.0", "2026-09-25", p, {"0.1.0", "0.1.1"}) is False   # 幂等
    # 残留节改号、未发布里又没有新条目 ⇒ 只改号
    p.write_bytes(LEFTOVER_CL.replace("### ★新记丁\n- 4", DV.PLACEHOLDER).encode("utf-8"))
    assert DV.stamp_changelog("0.2.0", "2026-09-24", p, {"0.1.1"}) is True
    assert DV.changelog_section(p.read_text(encoding="utf-8"), "0.2.0") == "### ★残留戊\n- 5"
    # 反向：不给 delivered ⇒ 不改号（新号新开一节，残留节原样）
    p.write_bytes(LEFTOVER_CL.encode("utf-8"))
    assert DV.stamp_changelog("0.2.0", "2026-09-24", p) is True
    text = p.read_text(encoding="utf-8")
    assert "## 0.1.2（2026-09-20）" in text and "## 0.2.0（2026-09-24）" in text


def test_resolve_version_renames_leftover_when_level_goes_up(tmp_repo):
    DV.record({"version_str": "0.1.1", "packages_dict": {}}, tmp_repo)
    assert R.resolve_version(None, None, True, bump="patch", repo=tmp_repo) == ("0.1.2", True)   # 这一轮中途失败，没交付
    assert R.resolve_version(None, None, True, bump="minor", repo=tmp_repo) == ("0.2.0", True)
    text = (tmp_repo / "CHANGELOG.md").read_text(encoding="utf-8")
    assert "## 0.1.2" not in text and "★新功能甲" in DV.changelog_section(text, "0.2.0")
    assert "## 0.0.9（2026-09-01）" in text                                         # 旧节不动


def test_resolve_version_needs_a_concrete_level(tmp_repo):
    with pytest.raises(ValueError, match="decide_bump"):
        R.resolve_version(None, None, True, bump="auto", repo=tmp_repo)


SURF = {"api_list": ["int FryHalftone_Run(const char* j)"], "params_list": ["a:number"], "cli_list": ["run", "--out"]}
FACTS = {"algorithm_fingerprint_str": "a" * 64, "wrapper_sha256_str": "w" * 64, "surface_dict": SURF}


def _st(surface=True) -> dict:
    rec = {"version_str": "0.1.1", "algorithm_fingerprint_str": "a" * 64, "wrapper_sha256_str": "w" * 64}
    if surface:
        rec["surface_dict"] = SURF
    return {"deliveries_list": [dict(rec, version_str="0.1.0"), rec]}


def test_decide_bump_auto_and_explicit():
    assert R.decide_bump("auto", {"deliveries_list": []}, FACTS)[0] == "patch"           # 第一次交付（号由 next_version 定为 0.1.0）
    assert R.decide_bump("auto", _st(), FACTS)[0] == "patch"
    lvl, info = R.decide_bump("auto", _st(), dict(FACTS, algorithm_fingerprint_str="b" * 64))
    assert lvl == "minor" and info["last_version_str"] == "0.1.1" and "算法指纹变了" in info["required_dict"]["reasons_list"][0]
    lvl, info = R.decide_bump("auto", _st(), dict(FACTS, surface_dict=dict(SURF, cli_list=["run"])))   # 删了一个开关
    assert lvl == "minor" and info["required_dict"]["level_str"] == "major" and "SemVer" in info["zero_rule_note_str"]
    with pytest.raises(RuntimeError, match="不够"):
        R.decide_bump("patch", _st(), dict(FACTS, algorithm_fingerprint_str="b" * 64))
    assert R.decide_bump("major", _st(), FACTS)[0] == "major"                            # 人决定升 1.0.0：允许
    assert R.decide_bump("minor", _st(), FACTS)[0] == "minor"                            # 多升不拦


def test_decide_bump_unknown_needs_a_human():
    """上一版的记录没有接口面（0.1.0 / 0.1.1）而指纹变了 ⇒ auto 拒绝（大声，不猜），显式给就放行。"""
    changed = dict(FACTS, wrapper_sha256_str="v" * 64)
    with pytest.raises(RuntimeError, match="--bump"):
        R.decide_bump("auto", _st(surface=False), changed)
    assert R.decide_bump("patch", _st(surface=False), changed)[0] == "patch"
    lvl, info = R.decide_bump("auto", _st(surface=False), FACTS)                        # 指纹都没变 ⇒ 推断
    assert lvl == "patch" and info["required_dict"]["inferred_bool"] is True
