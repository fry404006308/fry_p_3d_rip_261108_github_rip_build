# -*- coding: utf-8 -*-
r"""test_payload_gate.py —— 载荷闸**两个方向**都要验：正常时不响 + 搞坏时必响；★384 加一条「换行符不算改」。

【为什么两个方向都要】「正常时不响」是闸最容易满足的性质 —— 一个 `return 0` 也满足。
  所以对**一份拷贝**做四种破坏（改一个字节 / 删一个文件 / 多一个文件 / 锁文件清空），每种都必须报红，
  并且破坏之后**先证明真的坏了**，再看闸响不响。

【★384 CI 失败的回归】流水线 #2854243250：Windows 工作区 CRLF 算的锁、Linux runner LF 检出 ⇒ 427 个文件全报「被改」。
  ⇒ 把载荷整个转成 CRLF / 整个转成 LF，闸都必须绿、指纹必须不变；而**真改一个字符**仍必须红（不能为了换行宽容把改动也放过）。

⚠ 全部在临时目录的拷贝上做，**绝不碰仓库里真的 cpp/**。
"""
from __future__ import annotations

import contextlib
import io
import json
import shutil
import sys
from pathlib import Path

import pytest

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO / "tools"))
import fry_payload  # noqa: E402


@pytest.fixture()
def sandbox(tmp_path, monkeypatch):
    if not fry_payload.LOCK_PATH.is_file():
        pytest.skip("还没同步过载荷：先跑 python tools/fry_payload.py sync --source <算法仓>")
    dst_payload = tmp_path / "cpp"
    shutil.copytree(fry_payload.PAYLOAD_DIR, dst_payload)
    dst_lock = tmp_path / "cpp.lock.json"
    shutil.copy2(fry_payload.LOCK_PATH, dst_lock)
    monkeypatch.setattr(fry_payload, "PAYLOAD_DIR", dst_payload)
    monkeypatch.setattr(fry_payload, "LOCK_PATH", dst_lock)
    return dst_payload, dst_lock


def run_check() -> tuple[int, str]:
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        rc = fry_payload.do_check()
    return rc, buf.getvalue()


def any_cpp(payload: Path) -> Path:
    return sorted(payload.rglob("*.cpp"))[0]


def convert_eol(payload: Path, to_crlf: bool) -> int:
    n = 0
    for p in payload.rglob("*"):
        if p.is_file() and fry_payload.is_text(p):
            data = p.read_bytes().replace(b"\r\n", b"\n")
            if to_crlf:
                data = data.replace(b"\n", b"\r\n")
            p.write_bytes(data)
            n += 1
    return n


def test_clean_copy_is_green(sandbox):
    rc, out = run_check()
    assert rc == 0, out
    assert "逐个 sha256 相同" in out and "锁里" in out            # 报通过时必须同时报查了多少个


def test_crlf_checkout_is_still_green(sandbox):
    """★384：Windows autocrlf 检出（全 CRLF）—— 这正是 CI 失败的另一半，必须绿。"""
    payload, _lock = sandbox
    n = convert_eol(payload, to_crlf=True)
    victim = any_cpp(payload)
    assert n > 0 and b"\r\n" in victim.read_bytes(), "没转成 CRLF —— 这条测试本身就是假的"
    rc, out = run_check()
    assert rc == 0, out


def test_lf_checkout_is_still_green(sandbox):
    """★384：Linux runner 检出（全 LF）。"""
    payload, _lock = sandbox
    convert_eol(payload, to_crlf=True)
    convert_eol(payload, to_crlf=False)
    assert b"\r\n" not in any_cpp(payload).read_bytes()
    rc, out = run_check()
    assert rc == 0, out


def test_fingerprint_independent_of_eol(tmp_path):
    a = tmp_path / "a.cpp"
    b = tmp_path / "b.cpp"
    a.write_bytes(b"int x = 1;\r\nint y = 2;\r\n")
    b.write_bytes(b"int x = 1;\nint y = 2;\n")
    assert fry_payload.sha256_of(a) == fry_payload.sha256_of(b)
    c = tmp_path / "c.cpp"
    c.write_bytes(b"int x = 1;\nint y = 3;\n")
    assert fry_payload.sha256_of(c) != fry_payload.sha256_of(b), "内容真改了，指纹必须变"


def test_one_byte_changed_is_red_even_with_crlf(sandbox):
    payload, _lock = sandbox
    convert_eol(payload, to_crlf=True)
    victim = any_cpp(payload)
    before = victim.read_bytes()
    victim.write_bytes(before + b"\r\n// tampered\r\n")
    assert victim.read_bytes() != before
    rc, out = run_check()
    assert rc == 1 and "被改" in out, out


def test_file_deleted_is_red(sandbox):
    payload, _lock = sandbox
    victim = any_cpp(payload)
    victim.unlink()
    assert not victim.exists()
    rc, out = run_check()
    assert rc == 1 and "缺失" in out, out


def test_file_added_is_red(sandbox):
    payload, _lock = sandbox
    extra = payload / "src" / "util" / "_sneaky_extra.cpp"
    extra.write_text("int sneaky = 1;\n", encoding="utf-8")
    assert extra.is_file()
    rc, out = run_check()
    assert rc == 1 and "多出" in out, out


def test_empty_lock_is_red(sandbox):
    """查了 0 个不算通过 —— 锁文件被清空时闸不能自动变绿。"""
    _payload, lock = sandbox
    data = json.loads(lock.read_text(encoding="utf-8"))
    data["files_dict"] = {}
    lock.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
    rc, out = run_check()
    assert rc == 1, out


def test_tree_fingerprint_is_order_independent():
    a = {"b.cpp": "1" * 64, "a.cpp": "2" * 64}
    b = {"a.cpp": "2" * 64, "b.cpp": "1" * 64}
    assert fry_payload.tree_sha256(a) == fry_payload.tree_sha256(b)
    c = {"a.cpp": "2" * 64, "b.cpp": "3" * 64}
    assert fry_payload.tree_sha256(a) != fry_payload.tree_sha256(c)


def test_gitattributes_forces_lf():
    """仓库层的第二道防线：.gitattributes 必须把文本写死成 LF（覆盖各机器的 core.autocrlf）。"""
    text = (REPO / ".gitattributes").read_text(encoding="utf-8")
    assert "* text=auto eol=lf" in text
    assert "*.glb binary" in text
