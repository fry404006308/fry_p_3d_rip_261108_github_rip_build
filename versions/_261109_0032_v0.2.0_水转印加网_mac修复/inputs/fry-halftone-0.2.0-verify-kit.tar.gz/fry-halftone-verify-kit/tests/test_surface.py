# -*- coding: utf-8 -*-
r"""test_surface.py —— ★412 对外接口面（tools/fry_surface.py）与「这一版该升哪一位」，两个方向都验。

① 解析器（尺子 A）在**真实源码**上 = 产物（尺子 B）：头文件的函数名 = 导出面闸认的名字；kSpecs = 库自报参数表；
   命令行源码 = 真跑 --help（产物不在就跳过 —— 出包时 fry_release 会再比一遍）；
② 判定矩阵：删 / 改 → 主版本（0.x 期间降为次版本）；加 / 算法指纹变 → 次版本；只有实现 / 文档 → 修订号；上一版没记接口面时
   两个指纹都没变 ⇒ 推断、变了 ⇒ unknown（要人给 --bump）；
③ ★ 反向：两把尺子不一致必须报（解析器漏看一项、导出表多一个名字）；升的位不够必须报。
"""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import pytest

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO / "tools"))
import fry_build  # noqa: E402
import fry_surface as SF  # noqa: E402

SDK = REPO / "out" / "sdk" / "fry-halftone-sdk"
API = ["const char* FryHalftone_GetVersion(void)", "int FryHalftone_Run(const char* json)"]
PARAMS = ["ink_c_um:number", "use_black_k:bool"]
CLI = ["run", "slice", "--json", "--out"]


def surf(api=API, params=PARAMS, cli=CLI) -> dict:
    return {"api_list": list(api), "params_list": list(params), "cli_list": list(cli)}


def rec(version="0.1.1", algo="a" * 64, wrap="w" * 64, surface=None) -> dict:
    r = {"version_str": version, "algorithm_fingerprint_str": algo, "wrapper_sha256_str": wrap}
    if surface is not None:
        r["surface_dict"] = surface
    return r


# ───────────────────────────── ① 真实源码上的两把尺子 ─────────────────────────────
def test_real_header_names_equal_export_gate_names():
    """头文件两种解析（本模块按 `ret name(args)`、导出面闸按名字）在真实头文件上一个不差 —— 导出面闸又证明了名字 = 库的导出表。"""
    s = SF.source_surface(REPO)
    assert len(s["api_list"]) >= 10
    assert SF.api_names(s["api_list"]) == fry_build.header_api_names()
    assert all(x.startswith(("int ", "const char* ", "void ")) for x in s["api_list"]), s["api_list"]


def test_real_params_and_cli_are_parsed():
    s = SF.source_surface(REPO)
    assert len(s["params_list"]) >= 10 and all(":" in p for p in s["params_list"])
    assert {"slice", "run", "--out", "--version", "--help"} <= set(s["cli_list"])
    assert "help" not in s["cli_list"]                              # 别名不算


@pytest.mark.skipif(not (SDK / "params_schema.json").is_file(), reason="还没出过 Windows 包（fry_release 出包时会再比一遍）")
def test_real_params_source_equals_library_schema():
    built = SF.params_from_schema(json.loads((SDK / "params_schema.json").read_text(encoding="utf-8")))
    assert built == SF.source_surface(REPO)["params_list"]
    assert all(not p.endswith(":None") for p in built)              # 412 第一版读错字段（type）时全是 None


@pytest.mark.skipif(not (SDK / "bin" / "fry-halftone-cli.exe").is_file(), reason="还没出过 Windows 包")
def test_real_cli_source_equals_real_help():
    help_text = subprocess.run([str(SDK / "bin" / "fry-halftone-cli.exe"), "--help"], capture_output=True).stdout.decode("utf-8", "replace")
    assert SF.cli_from_help(help_text) == SF.source_surface(REPO)["cli_list"]


def test_header_parser_does_not_swallow_the_macro_lines():
    """⚠ `#  define FRY_API …` 也含 FRY_API：不锚行首会把宏定义吞进第一个函数的返回类型。"""
    text = ('#  define FRY_API FRY_EXTERN_C __declspec(dllexport)\n#define FRY_CALL __cdecl\n'
            'FRY_API const char* FRY_CALL FryHalftone_GetVersion(void);\n'
            'FRY_API int FRY_CALL FryHalftone_Run(const char* json,\n                                   int n);\n')
    assert SF.api_from_header(text) == ["const char* FryHalftone_GetVersion(void)", "int FryHalftone_Run(const char* json, int n)"]
    # ★412 变异实验抓到：上面那段里宏定义带括号 / 下一行以 # 开头 ⇒ 字符类 [^;(#] 已经挡住，「锚行首」根本没被测到。
    #   宏定义没有括号、下一行紧跟声明（真实头文件第 65 行就是没括号的写法）⇒ 只有锚行首挡得住
    text2 = "#define FRY_API FRY_EXTERN_C\nFRY_API int FRY_CALL FryHalftone_Cancel(void);\n"
    assert SF.api_from_header(text2) == ["int FryHalftone_Cancel(void)"]


def test_params_and_cli_parsers_on_small_sources():
    src = 'const Spec kSpecs[] = {\n    {"ink_c_um", "number", 1},\n    {"use_black_k", "bool", 0},\n};\n'
    assert SF.params_from_source(src) == ["ink_c_um:number", "use_black_k:bool"]
    assert SF.params_from_source("没有表") == []
    cli = 'if (a[1] == "help" || a[1] == "--help") {}\nif (a[1] == "slice") {}\nif (k == "--out") {}\n'
    assert SF.cli_from_source(cli) == ["slice", "--help", "--out"]
    help_text = "Usage:\n  fry-halftone-cli slice <m> --out <d>\n  fry-halftone-cli --help\n"
    assert SF.cli_from_help(help_text) == ["slice", "--help", "--out"]


# ───────────────────────────── ② 两把尺子不一致必须报（反向）─────────────────────────────
def test_surface_mismatch_quiet_when_equal_and_loud_when_not():
    s = surf()
    assert SF.surface_mismatch(s, {"params_list": PARAMS, "cli_list": CLI, "api_names_list": SF.api_names(API)}) == []
    bad = SF.surface_mismatch(s, {"params_list": PARAMS[:1]})                     # 产物少一个参数
    assert len(bad) == 1 and "参数" in bad[0] and "use_black_k:bool" in bad[0]
    bad = SF.surface_mismatch(s, {"cli_list": CLI + ["--threads"]})               # 源码解析器漏看了一个开关
    assert len(bad) == 1 and "命令行" in bad[0] and "--threads" in bad[0]
    bad = SF.surface_mismatch(s, {"api_names_list": SF.api_names(API) + ["FryHalftone_New"]})   # 导出表多一个名字
    assert len(bad) == 1 and "导出表" in bad[0] and "FryHalftone_New" in bad[0]
    assert SF.surface_mismatch(s, {}) == []                                        # 只比两边都量了的清单


# ───────────────────────────── ③ 判定矩阵 ─────────────────────────────
def _level(prev, cur) -> str:
    return SF.required_bump(prev, cur)["level_str"]


def test_first_delivery_is_patch_level():
    r = SF.required_bump(None, rec(surface=surf()))
    assert r["level_str"] == "patch" and "第一次交付" in r["reasons_list"][0]


@pytest.mark.parametrize("cur, want, needle", [
    (rec(version="x", surface=surf()), "patch", "只有文档"),
    (rec(version="x", wrap="v" * 64, surface=surf()), "patch", "外壳"),
    (rec(version="x", algo="b" * 64, surface=surf()), "minor", "算法指纹变了"),
    (rec(version="x", surface=surf(api=API + ["int FryHalftone_New(void)"])), "minor", "C 接口加了"),
    (rec(version="x", surface=surf(cli=CLI + ["--threads"])), "minor", "命令行加了"),
    (rec(version="x", surface=surf(params=PARAMS + ["ink_k_um:number"])), "minor", "参数加了"),
    (rec(version="x", surface=surf(api=API[:1])), "major", "C 接口有不兼容的改动"),
    (rec(version="x", surface=surf(api=[API[0], "int FryHalftone_Run(const char* json, int n)"])), "major", "改了 ['FryHalftone_Run']"),
    (rec(version="x", surface=surf(params=["ink_c_um:string", PARAMS[1]])), "major", "参数有不兼容的改动"),
    (rec(version="x", surface=surf(cli=CLI[1:])), "major", "命令行有不兼容的改动"),
])
def test_required_bump_matrix(cur, want, needle):
    r = SF.required_bump(rec(surface=surf()), cur)
    assert r["level_str"] == want and not r["inferred_bool"]
    assert needle in "；".join(r["reasons_list"]), r["reasons_list"]


def test_breaking_change_plus_algorithm_change_reports_both_reasons():
    r = SF.required_bump(rec(surface=surf()), rec(algo="b" * 64, surface=surf(api=API[:1])))
    assert r["level_str"] == "major" and len(r["reasons_list"]) == 2


def test_previous_record_without_surface():
    """0.1.0 / 0.1.1 的记录里没有接口面：两个指纹都没变 ⇒ 接口面必然没变（推断）；变了 ⇒ unknown（大声，不猜）。"""
    r = SF.required_bump(rec(), rec(surface=surf()))
    assert r["level_str"] == "patch" and r["inferred_bool"] is True
    r = SF.required_bump(rec(), rec(algo="b" * 64, surface=surf()))
    assert r["level_str"] == "unknown" and "--bump" in r["reasons_list"][0] and "算法指纹" in r["reasons_list"][0]
    r = SF.required_bump(rec(), rec(wrap="v" * 64, surface=surf()))
    assert r["level_str"] == "unknown" and "外壳指纹" in r["reasons_list"][0]


def test_zero_major_rule_and_bump_level():
    assert SF.effective_level("major", "0.1.1")[0] == "minor" and "SemVer" in SF.effective_level("major", "0.1.1")[1]
    assert SF.effective_level("major", "1.2.3") == ("major", "")
    assert SF.effective_level("minor", "0.1.1") == ("minor", "")
    assert [SF.bump_level(a, b) for a, b in ((None, "0.1.0"), ("0.1.1", "0.1.1"), ("0.1.1", "0.1.2"), ("0.1.1", "0.2.0"),
                                            ("0.1.1", "1.0.0"))] == ["first", "none", "patch", "minor", "major"]


def test_bump_problems_gate():
    need_minor = {"level_str": "minor", "reasons_list": ["算法指纹变了"]}
    need_major = {"level_str": "major", "reasons_list": ["C 接口有不兼容的改动"]}
    assert SF.bump_problems("0.1.1", "0.2.0", need_minor) == []
    bad = SF.bump_problems("0.1.1", "0.1.2", need_minor)
    assert len(bad) == 1 and "只升了修订号" in bad[0] and "至少要升次版本" in bad[0]
    assert SF.bump_problems("0.1.1", "0.2.0", need_major) == []                  # 0.x：不兼容也只要次版本
    assert "0.x 期间" in SF.bump_problems("0.1.1", "0.1.2", need_major)[0]
    assert SF.bump_problems("1.2.3", "1.3.0", need_major) != []                  # 1.x：不兼容必须主版本
    assert SF.bump_problems("1.2.3", "2.0.0", need_major) == []
    assert SF.bump_problems(None, "0.1.0", need_major) == []                     # 第一次交付
    assert SF.bump_problems("0.1.1", "0.1.2", {"level_str": "unknown", "reasons_list": []}) == []
    assert SF.bump_problems("0.1.1", "0.1.1", need_minor) == []                  # 同号重出：由「同号同字节」那道闸管
