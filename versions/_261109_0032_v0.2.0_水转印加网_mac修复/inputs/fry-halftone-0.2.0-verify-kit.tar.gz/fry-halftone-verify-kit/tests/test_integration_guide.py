# -*- coding: utf-8 -*-
r"""test_integration_guide.py —— ★411 集成命令的唯一真源（tools/fry_integration_guide.py）与它的实测（tools/fry_integration_check.py）。

① 同步闸：交付说明里的命令只写一份 ⇒ `docs/SDK_使用说明.md` 第十一节、`examples/c/fry_halftone_demo.c` 开头注释里的命令
   必须与唯一真源**逐字一致**（410 的教训：注释里的编译命令照抄会失败，而且没人发现）；要点（NOTES）也逐条一致；
② 生成：render_guide 对三种实测状态（通过 / 失败 / 跳过）都标得对；「成功的样子」里的字面花括号不会让它崩；
③ 判定：verdict —— 跳过不算过；核心步骤（自检 / 版本 / 出片 / C 编译运行 / Python）两个平台都必须真跑过；
④ 脱敏：结果随交付给同事 ⇒ 临时解包目录的三种写法（原样 / JSON 转义 / 正斜杠）都要换掉。
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO / "tools"))
import fry_integration_check as IC  # noqa: E402
import fry_integration_guide as G  # noqa: E402

DOC = (REPO / "docs" / "SDK_使用说明.md").read_text(encoding="utf-8")
DEMO_C = (REPO / "examples" / "c" / "fry_halftone_demo.c").read_text(encoding="utf-8")


# ───────────────────────────── ① 同步闸 ─────────────────────────────
@pytest.mark.parametrize("plat", sorted(G.STEPS))
def test_usage_doc_has_every_command_verbatim(plat):
    sec = DOC.split("## 十一、", 1)[1].split("\n## ", 1)[0]
    for s in G.STEPS[plat]["steps"]:
        cmd = G.fill(s["cmd"], model="<模型.glb>")
        assert "`%s`" % cmd.replace("|", "\\|") in sec, (plat, s["key"], cmd)
    for note in G.NOTES[plat]:
        assert "- " + note in sec, (plat, note[:40])


def test_demo_c_header_commands_are_the_single_source():
    head = DEMO_C.split("*/", 1)[0]
    want = [(p, k) for p in ("win32-x64", "linux-x64", "darwin") for k in ("c_build", "c_run")]
    for plat, key in want:
        cmd = G.fill(next(s["cmd"] for s in G.STEPS[plat]["steps"] if s["key"] == key), model="<模型.glb>")
        assert cmd in head, (plat, key, cmd)
    assert "bin\\fry_halftone.lib" not in head.split("★411 以前")[0]            # 410 的错写法不许回来（注释里讲历史那句除外）


def test_every_step_is_well_formed():
    keys_all = set()
    for plat, spec in G.STEPS.items():
        keys = [s["key"] for s in spec["steps"]]
        assert len(keys) == len(set(keys)), plat
        keys_all |= set(keys)
        for s in spec["steps"]:
            assert s["title"] and s["cmd"] and s["expect"], (plat, s)
            assert s.get("needs", "") in ("", "msvc", "dotnet", "cc"), (plat, s)
    assert set(IC.CORE_KEYS) <= set(k for k in keys_all)
    for plat in ("win32-x64", "linux-x64"):
        assert set(IC.CORE_KEYS) <= {s["key"] for s in G.STEPS[plat]["steps"]}, plat


# ───────────────────────────── ② 生成 ─────────────────────────────
def test_render_marks_pass_fail_skip_and_survives_braces():
    tested = {s["key"]: {"ok": True, "note": "rc=0"} for s in G.STEPS["win32-x64"]["steps"]}
    tested["c_build"] = {"ok": False, "note": "rc=2"}
    tested["cs_run"] = {"ok": None, "note": "本机没有 .NET SDK"}
    tested["_where"] = "测试机"
    md = G.render_guide("win32-x64", "0.1.0", "`x.glb`", tested)          # cs_run 的「成功的样子」里有字面花括号
    assert "❌ rc=2" in md and "— 未实测：本机没有 .NET SDK" in md and md.count("✅") == len(G.STEPS["win32-x64"]["steps"]) - 2
    assert "通过 9 条 / 共 11 条，另有 1 条本机缺工具没跑" in md and "测试机" in md
    assert "就用 `x.glb`。" in md and "``" not in md                          # 反引号只加一层
    assert "{…结果 JSON…}" in md
    md0 = G.render_guide("darwin", "0.1.0", "`x.glb`", {})
    assert "还没有逐条实测" in md0 and "✅" not in md0


def test_fill_only_touches_known_placeholders():
    assert G.fill("a {model} b {version} {…结果 JSON…}", model="m", version="1.0.0") == "a m b 1.0.0 {…结果 JSON…}"


# ───────────────────────────── ③ 判定 ─────────────────────────────
def _res(win_over=None, lin_over=None) -> dict:
    win = {s["key"]: {"ok": True} for s in G.STEPS["win32-x64"]["steps"]}
    lin = {s["key"]: {"ok": True} for s in G.STEPS["linux-x64"]["steps"]}
    win.update(win_over or {})
    lin.update(lin_over or {})
    return {"windows": {"steps_dict": win}, "linux": {"steps_dict": lin}}


def test_verdict():
    assert IC.verdict(_res()) is True
    skip = {"ok": None, "skipped_bool": True, "why_str": "本机没有 .NET SDK"}
    assert IC.verdict(_res({k: skip for k in ("cs_new", "cs_copy", "cs_build", "cs_dll", "cs_run")})) is True   # C# 可以跳过
    assert IC.verdict(_res({"c_build": skip, "c_run": skip})) is False          # 核心步骤跳过 ≠ 通过
    assert IC.verdict(_res(lin_over={"py_run": {"ok": False}})) is False
    assert IC.verdict(_res({"cs_run": {"ok": False}})) is False                 # 跑了就必须过（哪怕不是核心步骤）
    r = _res()
    r["linux"]["steps_dict"].pop("verify")
    assert IC.verdict(r) is False                                               # 少一步 = 没跑全


# ───────────────────────────── ④ 脱敏 ─────────────────────────────
def test_scrub_all_three_spellings():
    w = Path(r"C:\Users\X\AppData\Local\Temp\fry_integ_win_abc")
    raw = str(w) + r"\fry-halftone\out_cli"
    js = json.dumps({"outputDirectory": raw})                                  # JSON 里是双反斜杠
    fwd = str(w).replace("\\", "/") + "/fry-halftone"
    out = IC.scrub(" | ".join([raw, js, fwd]), w)
    assert "Users" not in out and out.count("<解包目录>") == 3, out
