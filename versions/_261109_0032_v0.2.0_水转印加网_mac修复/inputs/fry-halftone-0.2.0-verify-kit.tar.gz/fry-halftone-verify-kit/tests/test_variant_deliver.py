# -*- coding: utf-8 -*-
r"""test_variant_deliver.py —— ★449 两件新东西的纯函数闸 + 真交付（出过包才跑），两个方向都验。

① 参数说明的 only_when / echo_omit_when 规则（tools/fry_param_schema.py）：
   推「省略 = 显式默认」的请求与回显 —— 规则满足 / 不满足各一组手算期望；规则写坏（引用不存在的键、取值不在选项里）⇒ 形状闸报出来
② 变体交付（tools/fry_deliver.py --variant）：目录名 = <平台>_<YYMMDD_HHMM>_<关键词>；中文 / 空格 / 坏时间戳 ⇒ 拒绝；
   fry_release 的时间戳取全交付目录名开头那段
④ ★449 仓库搬家（C: → E:）后 CMake 缓存记的旧源码目录 ⇒ 认得出来（出包时清掉重配，不再报错退出）
③ 真交付（out/sdk 有冒烟通过的包才跑）：交付进临时算法仓 ⇒ 新目录齐全、**原先那份一个字节没动**、同名再交付 ⇒ 拒绝
"""
from __future__ import annotations

import copy
import hashlib
import json
import subprocess
import sys
import time
from pathlib import Path

import pytest

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO / "tools"))
import fry_build  # noqa: E402
import fry_deliver  # noqa: E402
import fry_param_schema as PS  # noqa: E402
import fry_release  # noqa: E402


def _schema():
    """手写的小说明：engine=legacy|unified；preset 只在 unified 时许给；legacy 时回显不出现 engine/preset。"""
    return {"schema": PS.SCHEMA_ID_STR,
            "params": [{"name": "engine", "kind": "choice", "description": "e", "default": "legacy", "nullable": False,
                        "choices": ["legacy", "unified"]},
                       {"name": "preset", "kind": "choice", "description": "p", "default": "a", "nullable": False,
                        "choices": ["a", "b"]},
                       {"name": "threads", "kind": "int", "description": "t", "default": 0, "nullable": False, "min": 0, "max": 64}],
            "only_when": [{"params": ["preset"], "when": "engine", "equals": ["unified"]}],
            "echo_omit_when": [{"params": ["engine", "preset"], "when": "engine", "equals": ["legacy"]}]}


def test_only_when_and_echo_rules_hand_calculated():
    s = _schema()
    assert PS.schema_problems(s) == []
    # legacy（全省略）：preset 不许出现；回显里 engine / preset 都没有
    assert PS.inactive_names(s, PS.defaults_of(s)) == ["preset"]
    assert PS.explicit_defaults(s, {}) == {"engine": "legacy", "threads": 0}
    assert PS.expected_echo(s, {}) == {"threads": 0}
    # unified：preset 许出现且显式写出默认值；回显三个键都在
    assert PS.explicit_defaults(s, {"engine": "unified"}) == {"engine": "unified", "preset": "a", "threads": 0}
    assert PS.expected_echo(s, {"engine": "unified", "preset": "b"}) == {"engine": "unified", "preset": "b", "threads": 0}
    # 调用方自己给了不许给的键：explicit_defaults 不替他删（库会报错 —— 那正是要测的行为）
    assert "preset" in PS.explicit_defaults(s, {"preset": "b"})


@pytest.mark.parametrize("rule_key, mutate, needle", [
    ("only_when", lambda r: r.update(params=["nope"]), "nope"),
    ("only_when", lambda r: r.update(equals=["bogus"]), "bogus"),
    ("echo_omit_when", lambda r: r.update(when="nope"), "nope"),
    ("echo_omit_when", lambda r: r.update(equals=["bogus"]), "bogus"),
])
def test_broken_rules_are_reported(rule_key, mutate, needle):
    s = copy.deepcopy(_schema())
    mutate(s[rule_key][0])
    problems = PS.schema_problems(s)
    assert problems and any(needle in p for p in problems), problems


def test_variant_dir_name_and_refusals():
    assert fry_deliver.variant_dir_name("win32-x64", "wt_unified", "261027_0300") == "win32-x64_261027_0300_wt_unified"
    for kw, stamp in (("水转印", "261027_0300"), ("has space", "261027_0300"), ("", "261027_0300"), ("_lead", "261027_0300"),
                      ("x" * 49, "261027_0300"), ("ok", "2610270300"), ("ok", "26-10-27_03")):
        with pytest.raises(ValueError):
            fry_deliver.variant_dir_name("win32-x64", kw, stamp)


def test_release_variant_stamp_follows_bundle_dir():
    assert fry_release.variant_stamp(r"C:\x\out\全交付目录\_261027_0312_水转印统一引擎_v0.2.0_三平台交付") == "261027_0312"
    now = time.strptime("2026-10-27 04:05", "%Y-%m-%d %H:%M")
    assert fry_release.variant_stamp("", now) == "261027_0405"
    assert fry_release.variant_stamp("/x/没有时间戳的目录", now) == "261027_0405"


def _built_ok() -> bool:
    row = fry_build.plat()
    rep = REPO / "out" / "build_report.json"
    return (REPO / "out" / "sdk" / fry_build.SDK_NAME / "bin" / row["lib"]).is_file() and rep.is_file() and \
        bool(json.loads(rep.read_text(encoding="utf-8")).get("smoke_bool"))


@pytest.mark.skipif(not _built_ok(), reason="out/sdk 里没有冒烟通过的包（先 python tools/fry_build.py）")
def test_real_variant_delivery_leaves_original_untouched(tmp_path):
    """真交付进一个临时算法仓：原先那份是一个假 dll（内容 b'old'）——交付后它的 sha256 必须不变；新目录按 runtime 等级齐全。"""
    import shutil
    lock = json.loads((REPO / "cpp.lock.json").read_text(encoding="utf-8"))
    algo = tmp_path / "algo"
    shutil.copytree(REPO / "cpp", algo / "fry_project_components_cpp")        # 载荷 = 算法仓 C++ 源码的副本 ⇒ 指纹相同
    row = fry_build.plat()
    orig = algo / fry_deliver.TARGET_REL / row["tag"]
    orig.mkdir(parents=True)
    (orig / row["lib"]).write_bytes(b"old")
    before = hashlib.sha256(b"old").hexdigest()
    cmd = [sys.executable, str(REPO / "tools" / "fry_deliver.py"), "--algo-repo", str(algo), "--variant", "wt_unified",
           "--stamp", "261027_0300"]
    r = subprocess.run(cmd, capture_output=True)
    out = r.stdout.decode("utf-8", "replace")
    if r.returncode != 0 and "指纹" in out and lock.get("tree_sha256_str"):
        pytest.skip("out/sdk 里的包不是用当前载荷出的：%s" % out.strip()[-200:])
    assert r.returncode == 0, out
    var = algo / fry_deliver.TARGET_REL / ("%s_261027_0300_wt_unified" % row["tag"])
    assert (var / row["lib"]).is_file() and (var / "params_schema.json").is_file() and (var / "delivery_manifest.json").is_file()
    info = json.loads((var / "sdk_info.json").read_text(encoding="utf-8"))
    assert info["variant_str"] == "wt_unified" and info["delivered_dir_str"] == var.name
    assert hashlib.sha256((orig / row["lib"]).read_bytes()).hexdigest() == before and sorted(p.name for p in orig.iterdir()) == [row["lib"]]
    assert "一个字节没动" in out
    again = subprocess.run(cmd, capture_output=True)
    assert again.returncode == 1 and "已存在" in again.stdout.decode("utf-8", "replace")


def test_stale_cmake_cache_after_repo_move(tmp_path):
    """手算：没有缓存 / 缓存记的就是本仓 ⇒ None；记的是搬家前的路径 ⇒ 返回那个旧路径（出包会清掉重配）。"""
    repo = tmp_path / "repo"
    repo.mkdir()
    b = tmp_path / "cmake"
    b.mkdir()
    assert fry_build.stale_cmake_source(b, repo) is None
    (b / "CMakeCache.txt").write_text("FOO:STRING=1\nCMAKE_HOME_DIRECTORY:INTERNAL=%s\n" % repo.as_posix(), encoding="utf-8")
    assert fry_build.stale_cmake_source(b, repo) is None
    (b / "CMakeCache.txt").write_text("CMAKE_HOME_DIRECTORY:INTERNAL=C:/_260331_gitlab/old/repo\n", encoding="utf-8")
    assert fry_build.stale_cmake_source(b, repo) == "C:/_260331_gitlab/old/repo"
