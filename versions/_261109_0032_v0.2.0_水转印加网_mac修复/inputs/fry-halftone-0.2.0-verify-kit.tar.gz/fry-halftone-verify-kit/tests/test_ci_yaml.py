# -*- coding: utf-8 -*-
r"""test_ci_yaml.py —— 两份 CI 文件（gitlab.com 独立模式 / 内网 OPS-0027 模式）**口径一致**的闸。

【为什么需要】两份 CI 文件 = 两份真相（算法仓 B.1-16：副本不会自己更新，而且不报错）。
  现在只有独立模式在跑；内网那份要等「搬家」那天才第一次被执行 —— 如果这期间独立模式改了
  产物名或出包脚本，而内网那份没跟着改，**搬家当天才会红**，而且红在最忙的时候。
  ⇒ 把「两份必须一致的地方」写成测试，每次 check 阶段都核一遍。

【核对七件事】
  ① 两份都能解析（含 GitLab 的 `!reference` 自定义标签）
  ② 三个平台 job 都在，各自调**同一个**平台出包脚本
  ③ 产物文件名 = `${PACKAGE_NAME}-${VERSION}-<平台>.<后缀>`，平台与后缀和 tools/fry_build.py 的 PLATFORM_DICT 一致
  ④ 内网那份：include 模板 ref v1、**没有**自己写 workflow:（写了会静默覆盖模板）
  ⑤ 独立那份：普通 push **不起**流水线（自动提交程序推得很勤，起了就是白烧 CI 分钟数）
  ⑥ ★388 仓根 .gitlab-ci.yml 必须与 ci/standalone.gitlab-ci.yml、ci/internal.gitlab-ci.yml **之一**逐字节相同（换行规范化后）
     —— 两份变体都住在 ci/ 里，仓根只是「当前生效的那一份」的副本：切到内网 = 整份复制 internal，回退 = 整份复制 standalone。
     以前独立模式只有仓根一份：切到内网后它被覆盖，⑤ 和搞坏测试会跟着红，回退还得去翻 git 历史。
  ⑦ ★388 内网那份的 test:unit 与独立那份的 check **跑同一组测试文件 + 载荷闸**，且 test:unit 继承模板底座（等扳机）、不写 needs
     —— 否则搬到内网 = 本文件在内的纯函数闸只剩本机 pytest，CI 里静默少一道闸。
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

import pytest

yaml = pytest.importorskip("yaml")

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO / "tools"))
import fry_build  # noqa: E402

ACTIVE = REPO / ".gitlab-ci.yml"                          # 当前生效的那一份（GitLab 只认仓根这个文件）
STANDALONE = REPO / "ci" / "standalone.gitlab-ci.yml"      # gitlab.com 独立模式（★388 起住 ci/，仓根是它或 internal 的副本）
INTERNAL = REPO / "ci" / "internal.gitlab-ci.yml"          # 内网 OPS-0027 模板模式
PLATFORM_SCRIPT = {"linux-x64": "packaging/linux/build_linux_sdk.sh",
                   "win32-x64": "packaging/windows/build_windows_sdk.ps1",
                   "darwin-arm64": "packaging/macos/build_macos_sdk.sh"}


class GitLabLoader(yaml.SafeLoader):
    """认得 GitLab 的 `!reference [.job, script]` 标签（SafeLoader 默认不认，会直接报错）。"""


GitLabLoader.add_constructor("!reference",
                             lambda loader, node: ["!reference"] + loader.construct_sequence(node))


def load(path: Path) -> dict:
    return yaml.load(path.read_text(encoding="utf-8"), Loader=GitLabLoader)


def flat_script(job: dict) -> str:
    lines = []
    for key in ("before_script", "script"):
        for item in job.get(key) or []:
            lines.append(" ".join(str(x) for x in item) if isinstance(item, list) else str(item))
    return "\n".join(lines)


def expected_ext(tag: str) -> str:
    row = next(r for r in fry_build.PLATFORM_DICT.values() if r["tag"] == tag)
    return {"zip": ".zip", "tar.zst": ".tar.zst"}[row["archive"]]


@pytest.mark.parametrize("path", [STANDALONE, INTERNAL], ids=["standalone", "internal"])
def test_ci_file_is_consistent_with_build_script(path):
    doc = load(path)
    assert doc["variables"]["PACKAGE_NAME"] == fry_build.PACKAGE_NAME, "PACKAGE_NAME 与 fry_build.py 不一致"
    platforms_in_build = {r["tag"] for r in fry_build.PLATFORM_DICT.values()}
    for job_name, plat in (("build:linux", "linux-x64"), ("build:windows", "win32-x64"),
                           ("build:macos", "darwin-arm64")):
        assert job_name in doc, "%s 里没有 %s" % (path.name, job_name)
        job = doc[job_name]
        assert job["variables"]["ARTIFACT_PLATFORM"] == plat
        assert plat in platforms_in_build, "平台 %s 不在 fry_build.PLATFORM_DICT 里" % plat
        body = flat_script(job)
        assert PLATFORM_SCRIPT[plat] in body, "%s 的 %s 没有调 %s" % (path.name, job_name, PLATFORM_SCRIPT[plat])
        art = job["variables"].get("ARTIFACT_FILE") or ""
        if not art:                                      # 独立模式的 windows job 把文件名写在上传那行里
            m = re.search(r'out/\$env:PACKAGE_NAME-\$env:VERSION-(\S+?)(\.zip|\.tar\.zst)"', body)
            assert m, "%s 的 %s 找不到产物文件名" % (path.name, job_name)
            assert m.group(1) == plat and m.group(2) == expected_ext(plat)
        else:
            assert art.endswith("${PACKAGE_NAME}-${VERSION}-%s%s" % (plat, expected_ext(plat))), art


def test_packaging_scripts_all_call_the_same_pipeline():
    for rel in PLATFORM_SCRIPT.values():
        text = (REPO / rel).read_text(encoding="utf-8")
        assert "tools/fry_build.py" in text.replace("\\", "/"), "%s 没有调 tools/fry_build.py" % rel


def test_internal_uses_templates_and_no_workflow_override():
    doc = load(INTERNAL)
    inc = doc["include"][0]
    assert inc["project"] == "shared/ci-templates" and inc["ref"] == "v1"
    for f in ("templates/workflow/standard.yml", "templates/release/base.yml", "templates/release/promote.yml",
              "templates/release/publish.yml", "templates/release/notify.yml"):
        assert f in inc["file"], "内网 CI 少 include 了 %s" % f
    assert "workflow" not in doc, "🔴 include 了 standard.yml 还自己写 workflow: = 静默覆盖模板"
    for job_name in ("build:linux", "build:windows", "build:macos"):
        job = doc[job_name]
        assert job["extends"] == ".shared:build-job", "%s 必须 extends .shared:build-job（扳机从它的 needs 注入）" % job_name
        assert "needs" not in job, "%s 自己写了 needs ⇒ extends 是整体替换，扳机会失效且不报错" % job_name
        assert ".shared:publish-artifact" in flat_script(job)


def pytest_files(job: dict) -> set:
    """job 脚本里 pytest 那一行点名的测试文件集合（没有 pytest 行 ⇒ 空集）。"""
    for line in flat_script(job).splitlines():
        if "pytest" in line and "pip" not in line:
            return set(re.findall(r"tests/\S+\.py", line))
    return set()


def test_internal_unit_tests_match_standalone_check():
    std, internal = load(STANDALONE), load(INTERNAL)
    want = pytest_files(std["check"])
    assert want, "独立模式 check 任务里找不到 pytest 那一行 —— 这条测试本身失效了"
    assert "test:unit" in internal, "内网 CI 没有 test:unit ⇒ 搬家后纯函数闸只剩本机 pytest"
    job = internal["test:unit"]
    assert pytest_files(job) == want, "内网 test:unit 与独立 check 跑的测试文件不同：%s vs %s" % (sorted(pytest_files(job)), sorted(want))
    assert "tools/fry_payload.py check" in flat_script(job), "内网 test:unit 没跑载荷闸"
    assert job["extends"] == ".shared:build-job", "test:unit 必须 extends .shared:build-job（等扳机，自动提交程序每次推送不白跑）"
    assert "needs" not in job, "test:unit 自己写了 needs ⇒ extends 整体替换，扳机失效且不报错"
    assert "publish-artifact" not in flat_script(job), "test:unit 不产出包，不该调 publish-artifact"
    for path in (STANDALONE, INTERNAL):
        for rel in pytest_files(load(path)["check" if path == STANDALONE else "test:unit"]):
            assert (REPO / rel).is_file(), "%s 点名的 %s 不存在" % (path.name, rel)


def test_windows_jobs_do_not_use_bash_variables_in_pwsh():
    """🔴 pwsh 里 `$VERSION` 是它自己的变量（空串），必须写 `$env:VERSION` —— 写错不报错，产物名少一截。"""
    for path in (STANDALONE, INTERNAL):
        body = flat_script(load(path)["build:windows"])
        for line in body.splitlines():
            if "pwsh" in line and "-File" in line:
                continue                                  # 调脚本那一行不带变量
            bad = re.findall(r"\$(?!env:)(?:VERSION|PACKAGE_NAME|ARTIFACT_PLATFORM)\b", line)
            assert not bad, "%s 的 build:windows 有 bash 风格变量 %s：%s" % (path.name, bad, line)


@pytest.mark.parametrize("which,old,new,check", [
    ("internal", "packaging/linux/build_linux_sdk.sh", "packaging/linux/build_sdk_old.sh",
     lambda p: test_ci_file_is_consistent_with_build_script(p)),
    ("internal", "\nvariables:", "\nworkflow:\n  rules:\n    - when: always\n\nvariables:",
     lambda p: test_internal_uses_templates_and_no_workflow_override()),
    # ★449 单元测试清单末尾多了 test_variant_deliver.py ⇒ 搞坏的片段跟着换（仍是「内网少跑一个测试文件」）
    ("internal", " tests/test_cross_build.py tests/test_variant_deliver.py\n", " tests/test_cross_build.py\n",
     lambda p: test_internal_unit_tests_match_standalone_check()),
    ("internal", "test:unit:\n  extends: .shared:build-job", "test:unit:\n  extends: .shared:build-job\n  needs: [version]",
     lambda p: test_internal_unit_tests_match_standalone_check()),
    ("standalone", "    - when: never", "    - if: $CI_COMMIT_BRANCH",
     lambda p: test_standalone_does_not_run_on_every_push()),
    ("standalone", "-win32-x64.zip", "-windows.zip",
     lambda p: test_ci_file_is_consistent_with_build_script(p)),
])
def test_gate_fires_when_ci_file_is_broken(tmp_path, monkeypatch, which, old, new, check):
    """搞坏会响（算法仓 D.1-9：只验「正常时不响」= 只证明了一半）。在临时拷贝上搞坏，绝不碰真文件。"""
    src = INTERNAL if which == "internal" else STANDALONE
    text = src.read_text(encoding="utf-8")
    assert old in text, "要搞坏的片段 %r 在文件里找不到 —— 这条测试本身失效了" % old
    broken = tmp_path / src.name
    broken.write_text(text.replace(old, new, 1), encoding="utf-8")
    assert broken.read_text(encoding="utf-8") != text, "搞坏没生效"
    monkeypatch.setattr(sys.modules[__name__], "INTERNAL" if which == "internal" else "STANDALONE", broken)
    with pytest.raises(AssertionError):
        check(broken)


def active_mode(active: Path) -> str:
    """仓根文件是哪一份变体的副本（换行规范化后逐字节比）：standalone / internal / drift。"""
    data = active.read_bytes().replace(b"\r\n", b"\n")
    hits = [name for name, p in (("standalone", STANDALONE), ("internal", INTERNAL))
            if p.read_bytes().replace(b"\r\n", b"\n") == data]
    return hits[0] if len(hits) == 1 else "drift"


def test_active_ci_file_is_exactly_one_variant():
    mode = active_mode(ACTIVE)
    assert mode in ("standalone", "internal"), (
        "仓根 .gitlab-ci.yml 与 ci/standalone.gitlab-ci.yml、ci/internal.gitlab-ci.yml 都不相同 —— 改了其中一份忘了同步。"
        "切换 / 回退只许整份复制：copy /Y ci\\internal.gitlab-ci.yml .gitlab-ci.yml")


def test_active_gate_fires_on_hand_edit_and_accepts_switch(tmp_path):
    """两个方向：仓根副本被手改一行 ⇒ drift（响）；整份复制 internal ⇒ 认得出是 internal（切换后不误报）。"""
    edited = tmp_path / "edited.yml"
    edited.write_bytes(ACTIVE.read_bytes() + b"\n# hand edit\n")
    assert active_mode(edited) == "drift"
    switched = tmp_path / "switched.yml"
    switched.write_bytes(INTERNAL.read_bytes().replace(b"\n", b"\r\n"))      # Windows 检出成 CRLF 也要认得
    assert active_mode(switched) == "internal"


def test_standalone_does_not_run_on_every_push():
    rules = load(STANDALONE)["workflow"]["rules"]
    assert rules[-1] == {"when": "never"}, "独立模式最后一条 workflow 规则必须是 when: never"
    ifs = " ".join(str(r.get("if", "")) for r in rules)
    assert "CI_COMMIT_TAG" in ifs and '"web"' in ifs
    assert "CI_COMMIT_BRANCH" not in ifs, "按分支起流水线 = 每次自动提交都编三平台"
