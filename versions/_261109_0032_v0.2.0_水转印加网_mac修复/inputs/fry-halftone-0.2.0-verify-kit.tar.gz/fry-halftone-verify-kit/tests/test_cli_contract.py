# -*- coding: utf-8 -*-
r"""test_cli_contract.py —— ★409 对外命令行 bin/fry-halftone-cli 的**契约闸**（三平台同一份，Python 写、不依赖 bash）。

【为什么要有它】同事要的「CLI 编译包」= lmst 那种三平台都带 bin/<名字>-cli：桌面端网关与云端 slice-worker 都按
  **lmst-cli 的协议**调它（R\lmst\src\cli\main.cpp + tests/lmst_cli_contract.sh）。协议里任何一处不一样，
  对方都是「编得过、跑得通、解析不到」—— 不报错的错。⇒ 协议逐条钉成闸，出包冒烟时在**目标平台**真跑。

【查什么（每条都是 lmst 契约里有的，或本 SDK 的承诺）】
  ① `--version` 恰好是 `fry-halftone-cli <版本>`，版本 = 库自报（CI 注入的那个号）
  ② `--help` 写全了 slice 的用法与各个开关
  ③ 用法错误的退出码：无参数 2 ｜ 缺 --out 2（提示 "--out is required"）｜ 模型不存在 3 ｜ 负高度 2 ｜ 两个尺寸都给 2
     ｜ 输出目录非空 4（提示 "output directory must be empty"）｜ 开关与 --params 重复 2 ｜ 库拒收的参数 2
  ④ ★ golden 全部 N 件经 CLI（run 子命令）逐字节 == Python 生产线标准答案（BMP 总 md5 / 张数 / 落墨 / 色带厚度）
  ⑤ ★ 开关与 --params 合并出的请求 == 同一组参数直接调库（抽 2 件：slice 子命令 + --params 文件 + 尺寸走开关）
  ⑥ `--json`：stdout 若干 progress + 一个 result 信封（success / sliceCount = 目录里的张数 / outputDirectory）；
     stderr 仍然有 `slices=N`（云端 worker 的契约，两种模式都不能丢）
  ⑦ 中文输出路径能用；`info --json` 的指纹 = 库自报；`schema` = 库自报的参数白名单（= 包里的 params_schema.json）

【怎么跑】python tests/test_cli_contract.py --cli <bin/fry-halftone-cli[.exe]> [--version 0.0.0-dev] [--quick]
         pytest：环境变量 FRY_HALFTONE_CLI（没设就找 out/sdk/fry-halftone-sdk/bin/，没出包则 skip）
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

HERE = Path(__file__).resolve().parent
DATA = HERE / "data"
CLI_NAME = "fry-halftone-cli"


def default_cli() -> Optional[Path]:
    env = os.environ.get("FRY_HALFTONE_CLI", "")
    if env:
        return Path(env)
    exe = CLI_NAME + (".exe" if os.name == "nt" else "")
    p = HERE.parent / "out" / "sdk" / "fry-halftone-sdk" / "bin" / exe
    return p if p.is_file() else None


def bmp_md5(d: Path) -> str:
    h = hashlib.md5()
    for f in sorted(d.glob("*.bmp")):
        h.update(f.read_bytes())
    return h.hexdigest()


def run(cli: Path, args: List[str], timeout: int = 600) -> Tuple[int, str, str]:
    r = subprocess.run([str(cli)] + args, capture_output=True, timeout=timeout)
    return r.returncode, r.stdout.decode("utf-8", "replace"), r.stderr.decode("utf-8", "replace")


class Checker:
    def __init__(self) -> None:
        self.bad: List[str] = []
        self.n = 0

    def ok(self, cond: bool, what: str, detail: str = "") -> bool:
        self.n += 1
        print("  %s %s%s" % ("✓" if cond else "✗", what, "" if cond or not detail else "\n      " + detail[-600:]))
        if not cond:
            self.bad.append(what)
        return cond


def check_all(cli: Path, want_version: Optional[str], quick: bool = False) -> int:
    c = Checker()
    tmp = Path(tempfile.mkdtemp(prefix="fry_cli_contract_"))
    doc = json.loads((DATA / "golden.json").read_text(encoding="utf-8"))
    cases = doc["case_list"]
    try:
        print("命令行契约：%s" % cli)
        # ① 版本（= 库自报；给了 --version 时还要等于它）
        rc, out, err = run(cli, ["info", "--json"])
        info = json.loads(out.strip().splitlines()[-1]) if rc == 0 and out.strip() else {}
        c.ok(rc == 0 and info.get("name") == CLI_NAME and len(info.get("algorithmFingerprint", "")) == 64,
             "info --json：名字 / 版本 / 64 位算法指纹", out + err)
        rc, out, err = run(cli, ["--version"])
        lib_ver = info.get("version", "?")
        c.ok(rc == 0 and out.strip() == "%s %s" % (CLI_NAME, lib_ver), "--version 恰好是 `%s %s`（= 库自报）" % (CLI_NAME, lib_ver), out + err)
        if want_version:
            c.ok(lib_ver == want_version, "版本 = 本次出包的版本 %s" % want_version, "库自报 %s" % lib_ver)
        # ② 帮助
        rc, out, err = run(cli, ["--help"])
        need = ["fry-halftone-cli slice <input-model>", "--target-height <mm>", "--out <directory>", "--layer-height <mm>",
                "--no-auto-orient", "--json", "--params <file.json>", "slices=N"]
        c.ok(rc == 0 and all(n in out for n in need), "--help 写全了 slice 用法与开关", out + err)
        # ③ 用法错误的退出码
        m = str(DATA / "vertex_gray_box.glb")
        cases_bad = [
            ([], 2, "", "无参数"),
            (["slice", m, "--target-height", "1"], 2, "--out is required", "缺 --out"),
            (["slice", str(DATA / "no_such_model.glb"), "--target-height", "1", "--out", str(tmp / "x1")], 3, "", "模型不存在"),
            (["slice", m, "--target-height", "-1", "--out", str(tmp / "x2")], 2, "", "负高度"),
            (["slice", m, "--target-height", "1", "--target-longest-edge", "2", "--out", str(tmp / "x3")], 2, "", "两个尺寸都给"),
            (["slice", m, "--out", str(tmp / "x4")], 2, "", "一个尺寸都不给"),
            (["bogus"], 2, "", "不认识的命令"),
        ]
        for args, want_rc, want_text, what in cases_bad:
            rc, out, err = run(cli, args)
            c.ok(rc == want_rc and (want_text in err), "退出码 %d：%s" % (want_rc, what), "rc=%d %s" % (rc, err))
        busy = tmp / "非空目录"
        busy.mkdir()
        (busy / ".preexisting").write_text("x", encoding="utf-8")
        rc, out, err = run(cli, ["slice", m, "--target-height", "1", "--out", str(busy)])
        c.ok(rc == 4 and "output directory must be empty" in err, "退出码 4：输出目录非空（含隐藏文件）", "rc=%d %s" % (rc, err))
        pf = tmp / "p_dup.json"
        pf.write_text(json.dumps({"target_height_mm": 1.0}), encoding="utf-8")
        rc, out, err = run(cli, ["slice", m, "--target-height", "1", "--params", str(pf), "--out", str(tmp / "x5")])
        c.ok(rc == 2 and "重复" in err, "退出码 2：开关与 --params 里的同一个键重复", "rc=%d %s" % (rc, err))
        pf2 = tmp / "p_bad.json"
        pf2.write_text(json.dumps({"band_uninked_fill": "black"}), encoding="utf-8")
        rc, out, err = run(cli, ["slice", m, "--target-height", "1", "--params", str(pf2), "--out", str(tmp / "x6"), "--json"])
        last = out.strip().splitlines()[-1] if out.strip() else "{}"
        c.ok(rc == 2 and '"success":false' in last and '"code":2' in last, "退出码 2：库拒收的参数值（JSON 信封 success=false, code=2）",
             "rc=%d %s %s" % (rc, last, err))
        # ④ golden 全部经 CLI 的 run 子命令
        n_ok = 0
        for case in (cases[:3] if quick else cases):
            out_dir = tmp / ("g_" + case["name_str"])
            req = tmp / ("req_" + case["name_str"] + ".json")
            req.write_text(json.dumps({"model": str(DATA / case["model_str"]), "out": str(out_dir), "params": case["params_dict"]},
                                      ensure_ascii=False), encoding="utf-8")
            t0 = time.perf_counter()
            rc, out, err = run(cli, ["run", str(req)])
            dt = time.perf_counter() - t0
            res = json.loads(out.strip().splitlines()[-1]) if rc == 0 and out.strip() else {}
            got = {"bmp_md5_str": bmp_md5(out_dir) if out_dir.is_dir() else "", "slice_count_int": res.get("sliceCount"),
                   "inked_voxel_int": res.get("inkedVoxels"), "band_thickness_mm_float": res.get("bandThicknessMm")}
            want = {k: case[k] for k in got}
            stamp = "slices=%s" % got["slice_count_int"]
            good = rc == 0 and got == want and stamp in err
            n_ok += good
            c.ok(good, "golden %-28s %s ｜ %s 张 ｜ %.2f s" % (case["name_str"], got["bmp_md5_str"][:12], got["slice_count_int"], dt),
                 "rc=%d 期望 %s 实际 %s ｜ %s" % (rc, want, got, err))
        print("  ── golden 经 CLI：%d / %d 件逐字节一致" % (n_ok, len(cases[:3] if quick else cases)))
        # ⑤ slice 子命令：尺寸走开关、其余走 --params 文件 ⇒ 与标准答案一致（证明合并出来的请求没丢键、没改值）
        picked = [k for k in cases if "target_height_mm" in k["params_dict"] or "target_longest_edge_mm" in k["params_dict"]][:2]
        for case in picked:
            p = dict(case["params_dict"])
            flags: List[str] = []
            for key, flag in (("target_height_mm", "--target-height"), ("target_longest_edge_mm", "--target-longest-edge")):
                if p.get(key) is not None:
                    flags += [flag, repr(float(p.pop(key)))]
                else:
                    p.pop(key, None)
            pfile = tmp / ("slice_params_" + case["name_str"] + ".json")
            pfile.write_text(json.dumps(p, ensure_ascii=False), encoding="utf-8")
            out_dir = tmp / ("s_" + case["name_str"])
            rc, out, err = run(cli, ["slice", str(DATA / case["model_str"]), "--out", str(out_dir), "--params", str(pfile)] + flags)
            c.ok(rc == 0 and bmp_md5(out_dir) == case["bmp_md5_str"],
                 "slice 子命令（开关 + --params 合并）%s == 标准答案" % case["name_str"], "rc=%d %s" % (rc, err))
        # ⑥ --json 事件流 + 中文路径 + stderr 的 slices=N
        out_dir = tmp / "中文 输出" / "切片"
        rc, out, err = run(cli, ["slice", m, "--target-height", "1", "--out", str(out_dir), "--json"])
        lines = [json.loads(x) for x in out.strip().splitlines() if x.strip()]
        prog = [x for x in lines if x.get("type") == "progress"]
        result = [x for x in lines if x.get("type") == "result"]
        n_files = len([f for f in out_dir.glob("*.bmp") if len(f.stem) == 6 and f.stem.isdigit()]) if out_dir.is_dir() else -1
        r0 = (result[-1] if result else {}).get("result", {})
        c.ok(rc == 0 and len(prog) >= 3 and len(result) == 1 and r0.get("success") is True and r0.get("sliceCount") == n_files > 0,
             "--json：%d 条 progress + 1 个 result 信封，sliceCount = 目录里 %d 张（中文路径）" % (len(prog), n_files), out[-800:] + err)
        c.ok("slices=%d" % n_files in err, "--json 模式下 stderr 仍有 `slices=N`（云端 worker 的契约）", err[-400:])
        c.ok(Path(str(r0.get("outputDirectory", ""))).resolve() == out_dir.resolve() and (out_dir / "slice_metadata.json").is_file(),
             "--json 结果信封的 outputDirectory 与 slice_metadata.json", json.dumps(r0, ensure_ascii=False)[:400])
        # ⑦ schema = 库自报白名单
        rc, out, err = run(cli, ["schema"])
        sch = json.loads(out) if rc == 0 else {}
        c.ok(rc == 0 and sch.get("schema", "").startswith("fry-halftone-params/") and len(sch.get("params", [])) >= 10,
             "schema：库自报的参数白名单（%s，%d 个参数）" % (sch.get("schema"), len(sch.get("params", []))), out[:300] + err)
        pkg_schema = cli.parent.parent / "params_schema.json"
        if pkg_schema.is_file():
            c.ok(json.loads(pkg_schema.read_text(encoding="utf-8")) == sch, "schema == 包里的 params_schema.json")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    print("%s 命令行契约：%d 项，%d 项没过%s" % ("✓" if not c.bad else "✗", c.n, len(c.bad),
                                         "" if not c.bad else "：" + "；".join(c.bad)))
    return 1 if c.bad else 0


def test_cli_contract() -> None:
    import pytest
    cli = default_cli()
    if cli is None or not cli.is_file():
        pytest.skip("还没出包：先跑 python tools/fry_build.py")
    assert check_all(cli, None, quick=True) == 0


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    ap = argparse.ArgumentParser()
    ap.add_argument("--cli", default=None)
    ap.add_argument("--version", default=None, help="期望的版本号（出包时传本次的版本）")
    ap.add_argument("--quick", action="store_true", help="golden 只跑前 3 件")
    ns = ap.parse_args()
    path = Path(ns.cli) if ns.cli else default_cli()
    if path is None or not path.is_file():
        raise SystemExit("✗ 找不到 %s；用 --cli 指一个，或先跑 python tools/fry_build.py" % CLI_NAME)
    raise SystemExit(check_all(path, ns.version, ns.quick))
