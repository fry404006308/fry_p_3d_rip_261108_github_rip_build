# -*- coding: utf-8 -*-
r"""test_build_helpers.py —— 出包流水线里几道「纯函数」闸，两个方向都验。

① 导出面闸：库导出的名字必须 == 头文件声明的 C 接口（多 = 内部符号漏出；少 = 消费方链接失败）
② 头文件解析：从 include/fry_halftone.h 读出来的接口名（头文件就是跨仓契约，是导出面的唯一真源）
③ 真库（出过包才跑）：本机有 dumpbin / nm 时，真去读一次导出表
④ ★387 参数说明（tools/fry_param_schema.py）：形状闸 / 值判定 / 压线探针 / 人读版 / 包内说明闸 —— 正常时静、搞坏时响；
   真库（出过包才跑）：库自报的 14 个默认值 = 手写期望，包里的 params_schema.json = 库现场自报
⑤ ★409 跨平台纯函数：Mach-O 符号名（只去一个 _、剔链接器标记）｜最低系统实测（ELF 最高 GLIBC_x.y / Mach-O minos）
   ｜平台标签跟着机器走（linux-arm64 / darwin-x64）｜验收包的「指纹闸」（预编件指纹 = 锁文件）
"""
from __future__ import annotations

import copy
import hashlib
import json
import struct
import sys
from pathlib import Path

import pytest

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO / "tools"))
import fry_build  # noqa: E402
import fry_param_schema as PS  # noqa: E402

# ★384：9 个老接口保持不变（ABI 兼容）+ 新增 GetEngine / GetParamSchemaJson
EXPECTED_ELEVEN = sorted([
    "FryHalftone_Cancel", "FryHalftone_GetAlgorithmFingerprint", "FryHalftone_GetAlgorithmName",
    "FryHalftone_GetEngine", "FryHalftone_GetParamSchemaJson",
    "FryHalftone_GetVersion", "FryHalftone_GetWorkerPathUtf8", "FryHalftone_SetWorkerPathUtf8",
    "FryHalftone_SliceModel", "FryHalftone_SliceModelJsonUtf8", "FryHalftone_SliceModelUtf8"])


def test_header_declares_exactly_the_eleven_c_apis():
    """手写期望：头文件里 11 个 FRY_API 函数（改头文件 = 改契约，这里必须跟着改）。"""
    assert fry_build.header_api_names() == EXPECTED_ELEVEN


def test_export_surface_quiet_when_equal():
    assert fry_build.export_surface_problems(list(EXPECTED_ELEVEN), EXPECTED_ELEVEN) == []


def test_export_surface_fires_on_leaked_internal_symbol():
    leaked = EXPECTED_ELEVEN + ["?run_job@fry@@YAHAEBUJobRequest@1@"]      # 一个 C++ 内部符号漏出来
    problems = fry_build.export_surface_problems(leaked, EXPECTED_ELEVEN)
    assert len(problems) == 1 and "多导出" in problems[0]


def test_export_surface_fires_on_missing_api():
    problems = fry_build.export_surface_problems(EXPECTED_ELEVEN[:-1], EXPECTED_ELEVEN)
    assert len(problems) == 1 and "没导出" in problems[0] and EXPECTED_ELEVEN[-1] in problems[0]


def test_real_library_export_table_if_built():
    row = fry_build.plat()
    lib = REPO / "out" / "sdk" / "fry-halftone-sdk" / "bin" / row["lib"]
    if not lib.is_file():
        pytest.skip("还没出包")
    exported = fry_build.list_exports(lib)
    if exported is None:
        pytest.skip("本机没有导出表工具（dumpbin / nm）")
    assert fry_build.export_surface_problems(exported, fry_build.header_api_names()) == [], exported


def test_cmake_keeps_float_discipline():
    """★384 逐位一致的编译纪律不许被人顺手删掉：GCC/Clang 必须 -ffp-contract=off，MSVC 必须 /fp:precise。"""
    text = (REPO / "CMakeLists.txt").read_text(encoding="utf-8")
    assert "-ffp-contract=off" in text and "/fp:precise" in text
    assert "fp:fast" not in text.replace("/fp:fast 允许", "") and "-ffast-math" not in text.replace("-ffast-math /", "")
    assert "ucrt.lib" in text, "Windows 必须动态链系统 UCRT（pow/atan2 与 Python 同一份实现）"


# ================================================================== ★387 参数说明
# 手写的小说明（形状 = C++ param_schema_json v3）：五种字段组合各一条 + 两条跨参数规则
SCHEMA_FIXTURE = {
    "schema": "fry-halftone-params/3",
    "params": [
        {"name": "target_height_mm", "kind": "number_or_null", "description": "z 高度", "default": None, "nullable": True,
         "min": 0.0, "min_exclusive": False},
        {"name": "target_longest_edge_mm", "kind": "number_or_null", "description": "最长边", "default": None, "nullable": True,
         "min": 0.0, "min_exclusive": True},
        {"name": "ink_k_um", "kind": "number_or_null", "description": "K 满喷", "default": None, "nullable": True, "min": 0.0, "min_exclusive": False},
        {"name": "use_black_k", "kind": "bool", "description": "用 K", "default": False, "nullable": False},
        {"name": "black_k_amount", "kind": "unit_interval", "description": "替换强度", "default": 1.0, "nullable": False,
         "min": 0.0, "min_exclusive": False, "max": 1.0},
        {"name": "band_uninked_fill", "kind": "choice_fill", "description": "填充", "default": "transparent", "nullable": False,
         "choices": ["transparent", "white"]},
        {"name": "output_width_px", "kind": "int_or_null", "description": "宽度", "default": None, "nullable": True, "integer": True,
         "min": 1, "min_exclusive": False},
        {"name": "voxel_mm", "kind": "vec3_positive", "description": "墨滴", "default": [0.137, 0.035, 0.01], "nullable": False,
         "length": 3, "item_min": 0.0, "item_min_exclusive": True},
    ],
    "one_of_required": [["target_height_mm", "target_longest_edge_mm"]],
    "requires": [{"when": "use_black_k", "equals": True, "then_required": "ink_k_um"}],
}
# 手写期望：库自报的 14 个默认值（= C++ pipeline/params.h 的 PipelineParams 初值 + JobRequest 的「没给」）
REAL_DEFAULTS_DICT = {"target_height_mm": None, "target_longest_edge_mm": None, "ink_c_um": 400.0, "ink_m_um": 500.0, "ink_y_um": 300.0,
                      "ink_k_um": None, "use_black_k": False, "black_k_amount": 1.0, "color_thickness_mm": None,
                      "band_uninked_fill": "transparent", "support_enable": True, "output_width_px": None,
                      "voxel_mm": [0.137, 0.035, 0.01], "threads": None,
                      # ★392 加网方向：省略这四个键 = 老行为（按边长自动摆正）
                      "orient_mode": "auto_extent", "orient_up": "+short", "orient_front": "+mid", "orient_yaw_deg": 0.0,
                      # ★449 水转印统一引擎 9 个：省略 = legacy（老行为）；其余默认值 = 算法仓 HA100 / HE520 的默认（强度 0.5、λ 4 /mm）
                      "wt_engine": "legacy", "wt_preset": "he500", "wt_outward_columns": "normal", "wt_outward_strength": 0.5,
                      "wt_outward_attenuation_mm_inv": 4.0, "wtu_columns": "normal", "wtu_ray_origin": "voxel", "wtu_move": "optical",
                      "wtu_dither": "blue_noise"}


def _spec(name):
    return next(p for p in SCHEMA_FIXTURE["params"] if p["name"] == name)


def test_value_problems_hand_calculated():
    """手算：> 0 不收 0；≥ 0 收 0；整数不收 1.5；null 只给 nullable；枚举只认列出的；数组长度与逐项下限都查。"""
    assert PS.value_problems(_spec("target_longest_edge_mm"), 0.0) and not PS.value_problems(_spec("target_longest_edge_mm"), 0.5)
    assert not PS.value_problems(_spec("target_height_mm"), 0.0) and PS.value_problems(_spec("target_height_mm"), -0.5)
    assert PS.value_problems(_spec("output_width_px"), 1.5) and PS.value_problems(_spec("output_width_px"), 0)
    assert not PS.value_problems(_spec("output_width_px"), 1) and not PS.value_problems(_spec("output_width_px"), None)
    assert PS.value_problems(_spec("use_black_k"), None) and PS.value_problems(_spec("use_black_k"), 1)
    assert PS.value_problems(_spec("band_uninked_fill"), "White") and not PS.value_problems(_spec("band_uninked_fill"), "white")
    assert PS.value_problems(_spec("black_k_amount"), 1.0000001) and not PS.value_problems(_spec("black_k_amount"), 1.0)
    assert PS.value_problems(_spec("voxel_mm"), [0.0, 0.1, 0.1]) and PS.value_problems(_spec("voxel_mm"), [0.1, 0.1])
    assert not PS.value_problems(_spec("voxel_mm"), [0.1, 0.1, 0.1])


def test_schema_problems_quiet_on_good_schema():
    assert PS.schema_problems(SCHEMA_FIXTURE) == []


@pytest.mark.parametrize("breaker, needle", [
    (lambda s: s.update(schema="fry-halftone-params/2"), "schema 版本"),
    (lambda s: s.update(params=[]), "一个参数都没有"),
    (lambda s: s["params"][0].pop("default"), "缺字段 default"),
    (lambda s: s["params"].append(copy.deepcopy(s["params"][3])), "参数名重复"),
    (lambda s: s["params"][4].update(default=1.5), "black_k_amount 的默认值 1.5"),
    (lambda s: s["params"][5].update(default="gray"), "band_uninked_fill 的默认值"),
    (lambda s: s["requires"][0].update(then_required="ink_q_um"), "requires 提到了不存在的参数 ink_q_um"),
])
def test_schema_problems_fires_when_broken(breaker, needle):
    broken = copy.deepcopy(SCHEMA_FIXTURE)
    breaker(broken)
    problems = PS.schema_problems(broken)
    assert any(needle in p for p in problems), problems


def test_boundary_probes_are_two_sided_for_every_param():
    """探针若只产合法值（或只产非法值），⑪ 那道行为闸就是单向的 —— 每个参数都必须既有「该收」也有「该拒」。"""
    for spec in SCHEMA_FIXTURE["params"]:
        verdicts = [not PS.value_problems(spec, v) for v in PS.boundary_probes(spec)]
        assert True in verdicts and False in verdicts, (spec["name"], PS.boundary_probes(spec))


def test_probe_params_keep_cross_rules_satisfied():
    assert PS.probe_params(SCHEMA_FIXTURE, "target_height_mm", None) == {"target_height_mm": None, "target_longest_edge_mm": 1.0}
    assert PS.probe_params(SCHEMA_FIXTURE, "target_longest_edge_mm", 0.0) == {"target_longest_edge_mm": 0.0}
    assert PS.probe_params(SCHEMA_FIXTURE, "use_black_k", True) == {"use_black_k": True, "target_height_mm": 1.0, "ink_k_um": 1.0}
    assert PS.probe_params(SCHEMA_FIXTURE, "voxel_mm", None) == {"voxel_mm": None, "target_height_mm": 1.0}


def test_render_markdown_has_a_row_per_param_and_the_library_sha():
    doc = PS.render_markdown(SCHEMA_FIXTURE, "1.2.3", "win32-x64", "ab" * 32)
    for p in SCHEMA_FIXTURE["params"]:
        assert "| `%s` |" % p["name"] in doc
    assert "ab" * 32 in doc and "`1.2.3`" in doc and "> 0.0 或 `null`" in doc and "整数 ≥ 1 或 `null`" in doc
    assert "`transparent` / `white`" in doc and "3 个数，每个 > 0.0" in doc and "`use_black_k` = `true` 时**必须同时给** `ink_k_um`" in doc


def _fake_package(tmp_path: Path) -> Path:
    sdk = tmp_path / "sdk"
    (sdk / "bin").mkdir(parents=True)
    lib = sdk / "bin" / "fry_halftone.dll"
    lib.write_bytes(b"not really a dll, but bytes are bytes")
    sha = hashlib.sha256(lib.read_bytes()).hexdigest()
    schema_path = sdk / PS.SCHEMA_FILE_NAME_STR
    schema_path.write_text(json.dumps(SCHEMA_FIXTURE, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
    (sdk / PS.DOC_FILE_NAME_STR).write_text(PS.render_markdown(SCHEMA_FIXTURE, "1.2.3", "win32-x64", sha), encoding="utf-8")
    (sdk / "sdk_info.json").write_text(json.dumps({
        "library_sha256_str": sha, "params_schema_sha256_str": hashlib.sha256(schema_path.read_bytes()).hexdigest(),
        "param_count_int": len(SCHEMA_FIXTURE["params"])}), encoding="utf-8")
    return sdk


def test_package_problems_quiet_when_consistent(tmp_path):
    sdk = _fake_package(tmp_path)
    assert PS.package_problems(sdk, "bin/fry_halftone.dll", "", json.dumps(SCHEMA_FIXTURE)) == []


def test_package_problems_fires_on_swapped_dll_stale_schema_and_missing_row(tmp_path):
    sdk = _fake_package(tmp_path)
    (sdk / "bin" / "fry_halftone.dll").write_bytes(b"someone swapped the dll")          # ① 只换了 dll
    live = copy.deepcopy(SCHEMA_FIXTURE)
    live["params"][4]["default"] = 0.5                                                  # ② 库自报与包里的说明不一样
    doc = sdk / PS.DOC_FILE_NAME_STR
    doc.write_text(doc.read_text(encoding="utf-8").replace("| `voxel_mm` |", "| voxel |"), encoding="utf-8")   # ③ 人读版少一行
    problems = PS.package_problems(sdk, "bin/fry_halftone.dll", "", json.dumps(live))
    text = "\n".join(problems)
    assert "library_sha256_str" in text and "与库现场自报的参数说明不一致" in text and "没有参数 voxel_mm 那一行" in text, problems


def test_real_library_schema_if_built():
    """真库（出过包才跑）：库自报 14 个参数、默认值 = 手写期望；包里的 params_schema.json = 库现场自报。"""
    row = fry_build.plat()
    sdk = REPO / "out" / "sdk" / "fry-halftone-sdk"
    lib = sdk / "bin" / row["lib"]
    if not lib.is_file() or not (sdk / PS.SCHEMA_FILE_NAME_STR).is_file():
        pytest.skip("还没出过 ★387 之后的包")
    live = json.loads(PS.read_schema_text(lib))
    assert PS.schema_problems(live) == []
    assert {p["name"]: p["default"] for p in live["params"]} == REAL_DEFAULTS_DICT
    assert json.loads((sdk / PS.SCHEMA_FILE_NAME_STR).read_text(encoding="utf-8")) == live


# ───────────────────────────── ⑤ ★409 跨平台纯函数
def test_macho_names_strip_exactly_one_underscore_and_drop_linker_markers():
    raw = ["_FryHalftone_GetVersion", "__Znwm", "___dso_handle", "__mh_dylib_header"]
    # 以前 lstrip("_") 会把 __Znwm 削成 Znwm：闸照样红，但报出来的名字对不上任何东西
    assert fry_build.macho_names_from_nm(raw) == ["FryHalftone_GetVersion", "_Znwm"]


def _fake_elf(glibc_list):
    """最小 ELF 头（e_ident 16 字节 + e_type + e_machine=x86-64）+ 几个 GLIBC_x.y 字符串。"""
    return b"\x7fELF" + b"\x02\x01\x01" + b"\0" * 9 + struct.pack("<HH", 3, 0x3E) + b"\0" * 64 + b"\0".join(glibc_list)


def test_measured_min_os_takes_the_highest_glibc(tmp_path):
    p = tmp_path / "lib.so"
    p.write_bytes(_fake_elf([b"GLIBC_2.2.5", b"GLIBC_2.17", b"GLIBC_2.14"]))
    s = fry_build.measured_min_os(p)
    assert s.startswith("glibc ≥ 2.17") and "x86-64" in s, s
    p.write_bytes(_fake_elf([b"GLIBC_2.38", b"GLIBC_2.2.5"]))        # 409 实测：Debian 13 原生编要 2.38
    assert fry_build.measured_min_os(p).startswith("glibc ≥ 2.38")


def test_measured_min_os_reads_macho_minos(tmp_path):
    hdr = struct.pack("<IiiIIII", 0xFEEDFACF, 0x0100000C, 0, 6, 1, 24, 0) + b"\0" * 4
    lc = struct.pack("<IIIIII", 0x32, 24, 1, 13 << 16, (26 << 16) | (4 << 8), 0)   # LC_BUILD_VERSION minos 13.0
    p = tmp_path / "lib.dylib"
    p.write_bytes(hdr + lc)
    s = fry_build.measured_min_os(p)
    assert s.startswith("macOS ≥ 13.0") and "arm64" in s, s


@pytest.mark.parametrize("sysname,machine,tag", [("Linux", "x86_64", "linux-x64"), ("Linux", "aarch64", "linux-arm64"),
                                                 ("Darwin", "arm64", "darwin-arm64"), ("Darwin", "x86_64", "darwin-x64"),
                                                 ("Windows", "AMD64", "win32-x64")])
def test_platform_tag_follows_the_machine(monkeypatch, sysname, machine, tag):
    monkeypatch.setattr(fry_build.platform, "system", lambda: sysname)
    monkeypatch.setattr(fry_build.platform, "machine", lambda: machine)
    assert fry_build.plat()["tag"] == tag
    assert fry_build.DC.platform_names()["tag"] == tag            # 出包与交付清单同一口径（两处不一致 = 包名对不上）


def test_prebuilt_fingerprint_gate_two_sided():
    lock = {"tree_sha256_str": "a" * 64}
    assert fry_build.prebuilt_fingerprint_problem({"algorithm_fingerprint_str": "a" * 64}, lock) == ""
    assert "≠" in fry_build.prebuilt_fingerprint_problem({"algorithm_fingerprint_str": "b" * 64}, lock)
    assert "≠" in fry_build.prebuilt_fingerprint_problem({}, lock)                # 没写指纹 = 不认
    assert fry_build.prebuilt_fingerprint_problem({"algorithm_fingerprint_str": ""}, {"tree_sha256_str": ""})


def _fake_wrapper_repo(root: Path) -> Path:
    for rel in fry_build.WRAPPER_INPUT_LIST:
        p = root / rel
        if Path(rel).suffix:
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_bytes(b"// %s\r\nline2\r\n" % rel.encode())
        else:
            (p / "x").mkdir(parents=True, exist_ok=True)
            (p / "x" / "a.cpp").write_bytes(b"int a;\r\n")
    return root


def test_wrapper_fingerprint_two_sided(tmp_path):
    """★410 外壳指纹：换行符不同（Windows CRLF / WSL LF）不许变；内容改一个字节、多一个文件必须变；缺一项 = 空串。"""
    a = _fake_wrapper_repo(tmp_path / "a")
    fa = fry_build.wrapper_fingerprint(a)
    assert len(fa) == 64
    b = _fake_wrapper_repo(tmp_path / "b")
    for p in b.rglob("*"):
        if p.is_file():
            p.write_bytes(p.read_bytes().replace(b"\r\n", b"\n"))
    assert fry_build.wrapper_fingerprint(b) == fa                                 # 只差换行符 ⇒ 相同
    (b / "src" / "x" / "a.cpp").write_bytes(b"int b;\n")
    assert fry_build.wrapper_fingerprint(b) != fa                                 # 改内容 ⇒ 变
    c = _fake_wrapper_repo(tmp_path / "c")
    (c / "include" / "x" / "new.h").write_bytes(b"")
    assert fry_build.wrapper_fingerprint(c) != fa                                 # 多一个文件 ⇒ 变
    (c / "CMakeLists.txt").unlink()
    assert fry_build.wrapper_fingerprint(c) == ""                                 # 缺一项 ⇒ 算不出（验收包里就是这样）


def test_prebuilt_wrapper_gate_two_sided():
    w, v = "a" * 64, "b" * 64
    assert fry_build.prebuilt_wrapper_problem(w, w) == ""                          # 记录 = 当前源码
    assert fry_build.prebuilt_wrapper_problem(w, "") == ""                         # 验收包：没有源码，信记录
    assert "≠" in fry_build.prebuilt_wrapper_problem(w, v)                         # 源码改过没重编
    assert "没记" in fry_build.prebuilt_wrapper_problem("", w)                      # 旧产物
    assert "没记" in fry_build.prebuilt_wrapper_problem("", "")


def test_wrapper_inputs_cover_every_cmake_input():
    """★410 闭包闸：CMakeLists.txt 里引用的每个仓库内输入，要么在 cpp/（算法指纹管），要么在外壳指纹的清单里。
    漏一个 = 改它不会让外壳指纹变 ⇒ 全交付目录的「各平台同一份外壳」这道闸对它失明（不报错）。"""
    import re
    text = (REPO / "CMakeLists.txt").read_text(encoding="utf-8")
    refs = set(re.findall(r"\$\{CMAKE_CURRENT_SOURCE_DIR\}/([\w./-]+)", text))
    refs |= set(re.findall(r"(?<![\w/$}])((?:src|tools|examples|packaging|include)/[\w./-]+\.(?:cpp|cc|c|hpp|h|in|map|txt))(?![\w.])",
                           text))
    refs = {r.rstrip("/") for r in refs if not r.startswith(("cpp/", "cpp.lock.json"))}
    assert refs, "一个引用都没解析出来 —— 解析规则失效了（这道闸会永远绿）"
    covered = fry_build.WRAPPER_INPUT_LIST

    def is_covered(r: str) -> bool:
        return any(r == c or r.startswith(c + "/") for c in covered)
    missing = sorted(r for r in refs if not is_covered(r))
    assert not missing, "这些编译输入不在外壳指纹里：%s" % missing
    for c in covered:                                                            # 清单里的每一项在仓库里都真存在
        assert (REPO / c).exists(), c


def test_smoke_keeps_fingerprint_gate_and_cli_contract():
    """静态查：冒烟里「库自报指纹 = 锁文件」与「命令行契约」两步不许被删（删了没有别的闸会红）。"""
    src = (REPO / "tools" / "fry_build.py").read_text(encoding="utf-8")
    assert 'read_lib_text(lib, "FryHalftone_GetAlgorithmFingerprint")' in src
    assert "test_cli_contract.py" in src
