# -*- coding: utf-8 -*-
r"""test_intranet_preflight.py —— ★388 内网搬家体检（tools/fry_intranet_preflight.py）的纯函数闸，两个方向都验。

① URL 打码：账号 / 口令 / 令牌不许进报告
② CI 模式：仓根与两份变体比对（CRLF 也认得）；手改一行 ⇒ drift
③ 内网 CI 形状：真文件没问题；写了 workflow: / 缺 include / build job 自己写 needs / 没 extends 底座 / 缺 test:unit / test:unit 写 needs ⇒ 各自点名
④ 历史体积：多出不到阈值 ⇒ ok；超过 ⇒ warn 并建议干净快照
⑤ runner 要求：Windows 必须查 pwsh 7 与 node ≥ 18（模板脚本是 Node 写的）
⑥ 真仓（能跑 git 时）：体检产出 CI / 载荷 / git / 交付物几类行，查了 0 项算红
"""
from __future__ import annotations

import shutil
import sys
from pathlib import Path

import pytest

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO / "tools"))
import fry_intranet_preflight as PF  # noqa: E402

INTERNAL_TEXT = (REPO / "ci" / "internal.gitlab-ci.yml").read_text(encoding="utf-8")


def test_mask_url_hides_credentials():
    assert PF.mask_url("http://oauth2:glpat-abc@192.168.110.250/g/fry-halftone.git") == "http://***@192.168.110.250/g/fry-halftone.git"
    assert PF.mask_url("https://gitlab.com/fanrenyi33/x.git") == "https://gitlab.com/fanrenyi33/x.git"
    assert "secret" not in PF.mask_url("origin\thttps://user:secret@host/x.git (push)")


def test_ci_mode_matches_variants_and_detects_drift():
    std, internal = b"a: 1\nb: 2\n", b"include: x\n"
    assert PF.ci_mode(std, std, internal) == "standalone"
    assert PF.ci_mode(internal.replace(b"\n", b"\r\n"), std, internal) == "internal"
    assert PF.ci_mode(std + b"# hand edit\n", std, internal) == "drift"
    assert PF.ci_mode(None, std, internal) == "missing"


def test_internal_shape_quiet_on_real_file():
    assert PF.internal_shape_problems(INTERNAL_TEXT, "fry-halftone") == []


@pytest.mark.parametrize("old,new,needle", [
    ("\nvariables:", "\nworkflow:\n  rules:\n    - when: always\n\nvariables:", "workflow"),
    ("  - project: shared/ci-templates", "  - project: someone/else", "shared/ci-templates"),
    ("build:linux:\n  extends: .shared:build-job", "build:linux:\n  extends: .shared:build-job\n  needs: [version]", "needs"),
    ("build:macos:\n  extends: .shared:build-job", "build:macos:\n  extends: .my-own-job", "extends"),
    ("PACKAGE_NAME: fry-halftone", "PACKAGE_NAME: fry-halftone-sdk", "PACKAGE_NAME"),
    ("test:unit:\n  extends: .shared:build-job", "unit-renamed:\n  extends: .shared:build-job", "test:unit"),
    ("test:unit:\n  extends: .shared:build-job", "test:unit:\n  extends: .shared:build-job\n  needs: [version]", "needs"),
])
def test_internal_shape_fires_when_broken(old, new, needle):
    assert old in INTERNAL_TEXT, "要搞坏的片段 %r 不在文件里 —— 这条测试本身失效了" % old
    problems = PF.internal_shape_problems(INTERNAL_TEXT.replace(old, new, 1), "fry-halftone")
    assert any(needle in p for p in problems), problems


def test_history_advice_threshold():
    mb = 1048576
    assert PF.history_advice(22 * mb, 3 * mb)[0] == "ok"            # 多出 19 MB
    level, text = PF.history_advice(285 * mb, 3 * mb)                # 多出 282 MB（本仓 382 误提交的构建产物）
    assert level == "warn" and "干净快照" in text and "282.0" in text


def test_version_tuple_and_runner_requirements():
    assert PF.version_tuple("v18.19.0") == (18, 19, 0)
    assert PF.version_tuple("cmake version 3.20.6") == (3, 20, 6)
    assert PF.version_tuple("PowerShell 7.4.6") == (7, 4, 6)
    names = {r["name_str"]: r for r in PF.runner_requirements("windows")}
    assert names["pwsh"]["min_tuple"] == (7,) and names["node"]["min_tuple"] == (18,)
    assert {"git", "cmake", "python", "vs_cpp"} <= set(names)
    mac = {r["name_str"] for r in PF.runner_requirements("macos")}
    assert {"node", "zstd", "xcode_clt"} <= mac


@pytest.mark.skipif(shutil.which("git") is None, reason="没有 git")
def test_real_repo_report_has_all_sections():
    rep = PF.run_checks(REPO)
    names = [r["name_str"] for r in rep["rows_list"]]
    assert rep["row_int"] == len(names) > 0
    for must in ("CI 模式", "内网 CI 形状", "载荷闸", ".gitignore 管住 out/", "对接方文档"):
        assert must in names, names
    mode_row = next(r for r in rep["rows_list"] if r["name_str"] == "CI 模式")
    assert mode_row["level_str"] == "ok", mode_row
