# SDK 发布与 CI 操作手册（给自己看：改完算法怎么重新出包 / 怎么发版 / 怎么搬到内网）

> 一句话：**算法在算法仓改，打包在打包仓做；两仓之间靠一份带指纹的载荷副本连接，副本有闸守着。**
> ★384 起载荷是 **C++ 源码**（算法仓 `fry_project_components_cpp/` → 本仓 `cpp/` + `cpp.lock.json`），不再冻结 Python。
> ⚠ 改算法的顺序：**先改算法仓 Python（正本）→ 再改 C++ → 算法仓全量对账（`c384_regress_all.py`）→ 重出 golden → 本仓出包**。

```mermaid
flowchart LR
    P["算法仓 rip_components/<br/>Python 生产线（正本）"] -->|"c384_make_sdk_goldens.py<br/>跑出标准答案 md5"| G["打包仓 tests/data/golden.json"]
    A["算法仓<br/>fry_project_components_cpp/<br/>C++ 复刻（逐字节对账）"] -->|"fry_payload.py sync<br/>逐文件 sha256（CRLF→LF）→ cpp.lock.json"| B["打包仓<br/>cpp/（副本）"]
    B -->|"fry_build.py 五步"| C["out/fry-halftone-版本-平台.zip|tar.zst"]
    G -->|"冒烟：golden 逐字节"| C
    C -->|"fry_deliver.py"| H["算法仓界面 HS200_halftone_dll/_bin/"]
    B -->|"git tag vX.Y.Z + push"| D["GitLab CI<br/>三平台各编一次"]
    D --> E["Package Registry<br/>+ manifest.json + Release 页"]
    E --> F["桌面端 / 云服务<br/>按版本号 + sha256 取包"]
```

---

## 一、改完算法后重新出包（最常用）

### 方式 1：界面一键（推荐）

1. 双击 `fry_bats\ZA100_flows\ZA105_rip_gui.bat` 打开界面
2. 左侧功能选 **「打包水转印加网 SDK(dll / dylib / so)」**
3. 输出文件夹随便选一个（只放作业日志）
4. 点 **开始处理**（默认：算法有变化才同步 → 出包 → 真跑模型冒烟 → 压缩）
5. 看到 `✓ 出包成功 fry-halftone-0.0.0-dev-win32-x64.zip` 即完成；点「打开输出文件夹」

### 方式 2：命令行（与界面完全等价，界面调的就是这条）

```bat
cd /d C:\_260331_gitlab\fry_production\fry_p_3d_rip\fry_p_3d_rip_260915_auto_build_dll
C:\_260330_Software\anaconda3\envs\fry_3d_main\python.exe tools\fry_release.py --algo-repo C:\_260331_gitlab\fry_production\fry_p_3d_rip\fry_py_260604_c180_depth_dither_more
```

### 它每一步在干什么

| 步 | 做什么 | 失败时说明什么 |
| --- | --- | --- |
| 查 | 算法仓 `fry_project_components_cpp/` 与 `cpp.lock.json` 逐文件 sha256 比对（文本先 CRLF→LF） | —— |
| 同步 | 有变化才拷进 `cpp/`，重写锁文件（记录算法仓 commit；算法仓有未提交改动会 ⚠） | 算法仓路径不对 |
| ① 载荷闸 | `cpp/` 与锁文件必须逐文件一致 | 有人手改了 `cpp/` |
| ② 编译 | CMake 编 `fry_halftone` 动态库 + 版本探针 + 纯 C 示例 + 命令行版；指纹由 CMake 从锁文件读进 dll | 没装 C++ 工具链 / 源码编不过 |
| ③ 装配 | `bin/` + `lib/` + `include/` + `examples/` + 说明 + `VERSION` + `sdk_info.json`（★387 含 dll 的 sha256）+ ★387 `params_schema.json`（向刚编好的 dll 要）+ `SDK_参数说明.md`（由它生成） | dll 自报的参数说明不合格（版本不对 / 缺字段 / 默认值超出自己写的范围） |
| ④ ★冒烟 | 导出面闸（11 个名字）→ ★409 指纹闸（库自报的算法指纹 = 锁文件）→ ★387 包内说明闸（sha256 / 说明 = dll 现场自报 / 人读版每参数一行）→ 版本探针 → C 接口十一条（★387 ⑩ 默认值真跑、⑪ 75 个压线值真跑）→ ★golden 逐字节（标准答案 = Python 生产线）→ 纯 C 示例真跑 → ★409 命令行契约 34 项（golden 全部经命令行再比一遍）→ 交付清单闸 | **包不能用、与 Python 不一致、或说明与 dll 行为不符**（这一步过了才出 zip） |
| ⑤ 压缩 | Windows 出 `.zip`，其余 `.tar.zst` | —— |

> ★409 起**本机能一次出齐三个平台**（见下面「一·五」）：Linux 包在本机 WSL2 的真 Linux 里真跑 golden（可交付）；
> macOS 只能出「验收包」—— Windows 上没有合法的 macOS 运行环境，可交付的 macOS 包要在一台 Mac 上跑一条命令（或 CI 的 macos runner）。
> 原因不变：C++ 的机器码、系统库、可执行格式三平台都不同，而「逐字节一致」必须在**目标系统自己的数学库**上验。
> 本机出包后跑 `python tools\fry_deliver.py --algo-repo <算法仓>` 把 dll 交付给算法仓界面（「C++ 加网出片」功能）；
> ★387 连 `params_schema.json` / `SDK_参数说明.md` 一起交付 —— 算法仓 HS200 的测试读它核对「界面参数全列出 + 界面默认值 = dll 默认值 + dll 是用当前 C++ 源码编的」，
> ⚠ 改了 C++ 却没重新出包交付，HS200 的 `test_delivered_dll_is_built_from_current_cpp_source` 会红。

## 一·五、★409 本机一次出齐三个平台（WSL 真验收 Linux + macOS 验收包）

```mermaid
flowchart LR
    W["Windows 本机<br/>MSVC 编 + 冒烟"] --> WZ["win32-x64.zip ✓可交付"]
    Z["zig 交叉编<br/>linux-x64 / macos-arm64 / macos-x64<br/>+ 静态闸"] --> PB["out/cross/&lt;目标&gt;/prebuilt/"]
    PB -->|"WSL2 Debian：fry_build.py --prebuilt-dir<br/>真跑 golden"| LZ["linux-x64.tar.zst ✓可交付<br/>glibc ≥ 2.17"]
    S["源码复制进 WSL"] -->|"gcc 原生编 + 同一套冒烟"| LN["linux-x64.tar.zst ✓可交付<br/>glibc ≥ 2.38"]
    PB -->|"fry_target_kit.py"| K["verify-kit.tar.gz<br/>⚠不是交付件"]
    K -->|"拷到任意一台 Mac<br/>bash run_on_target.sh"| MZ["darwin-arm64 / x64.tar.zst ✓可交付"]
```

| 要什么 | 界面（HS100「打包水转印加网 SDK」） | 命令行 | 产物 |
| --- | --- | --- | --- |
| Windows 包 | 默认就出 | `fry_release.py --algo-repo <算法仓>` | `out/fry-halftone-<版本>-win32-x64.zip` |
| Linux 包（推荐 zig 版） | 「★Linux 包」选 prebuilt / native / both | `… --linux prebuilt`（或 `native` / `both`） | `out/linux/<模式>/fry-halftone-<版本>-linux-x64.tar.zst` |
| macOS 验收包 | 勾「★macOS 验收包」 | `… --mac-kit` | `out/kit/fry-halftone-<版本>-verify-kit.tar.gz` |

**Linux 的前提**（一次性）：管理员 PowerShell `wsl --install -d Debian`（要重启），进 Debian 后
`sudo apt-get install -y build-essential cmake ninja-build python3 zstd`。没有 WSL 时脚本会找 Docker；两个都没有 ⇒ 打印安装办法并**失败**（不假装成功）。

**macOS 的最后一步**（在 Mac 上，一条命令）：

```bash
tar -xzf fry-halftone-<版本>-verify-kit.tar.gz
bash fry-halftone-verify-kit/run_on_target.sh            # Apple Silicon 上加 --also-x64 顺带用 Rosetta 2 验 Intel 版
```

它做的与 WSL 里完全相同（`fry_build.py --prebuilt-dir`：指纹闸 → 装配 → 冒烟含 golden 逐字节 → 出包），
全过后 `results/<目标>/` 里的 `.tar.zst` 才是可交付的 macOS 包，连同 `SHA256SUMS.txt`（★410）/ `build_report.json` / `verify.log` / `target_env.txt` 一起发回来。
需要：`xcode-select --install`、`brew install zstd`。验收包**不带算法源码**（`cpp/` `src/`），只有二进制 + 判据。

| 为什么 zig 版（prebuilt）是 Linux 首选 | 数字（409 实测） |
| --- | --- |
| 能跑的系统更多 | 引用的最高 glibc 符号版本 2.17（gcc 原生版 2.38：Ubuntu 22.04 / Debian 12 都加载不了） |
| 包更小 | 0.60 MB（gcc 版 1.20 MB）；zig 预编 libc++ 的调试信息在**链接时**剥掉（不剥 4.05 MB） |
| 与 Windows 逐字节相同 | 54 个真实模型 × 两个尺寸，逐张 BMP 与 Windows / gcc 版相同 |

## 一·六、★410 全交付目录：给同事的一整包

| 要什么 | 界面（HS100） | 命令行 | 产物 |
| --- | --- | --- | --- |
| 三平台 + 命令行 + 说明 + Mac 验收步骤 | 勾「★三平台全交付目录」 | `fry_release.py --algo-repo <算法仓> --bundle` | `out/全交付目录/_YYMMDD_HHMM_水转印加网SDK_三平台交付/` + 同名 `.zip` |
| 只重打交付目录（产物已在 out/） | — | `python tools/fry_delivery_bundle.py [--parity-json 实验.json]` | 同上（每次新建，不覆盖） |

打之前**过闸**（任何一条不过就不打）：同一版本 ｜ 同一算法指纹（`cpp/`）｜ **同一外壳指纹**（`src/` `include/` `CMakeLists.txt` 导出表 探针 示例；
算法指纹管不到它们）且 = 当前源码 ｜ Windows / Linux 冒烟都过 ｜ 验收包 sha256 = kit_info、带两个 macOS 目标、自称「未验证」｜
参数说明各平台逐字节相同 ｜（附一致性实验时）全一致且**跑的就是交付的那份库**（库 sha256 逐个核对）。打完按 `SHA256SUMS.txt` 复查、zip 重开复查。

同事拿到后：先读 `00_先读我_交付说明.md`；macOS 按 `03_macOS_需在Mac上验收/macOS验收步骤.md` 在 Mac 上跑一条命令，
「成功标准」写在那一页（退出码 0、`✓ macos-arm64：可交付`、`results/<目标>/` 5 个文件、`verify.log` 的 ✓ 行、`build_report.json` 的指纹）。

## 二、发正式版（三平台，交给对接方）

> ★ 顺序：**先不打 tag 验证**（网页 New pipeline，可反复跑）→ 三个平台的 build job 都绿 → **最后才推 tag**（tag 不可移动）。
> 逐步图解、本机体检结果、排错表见算法仓 `docs/K_工程重构/_260916_1612_385_推tag触发CI与注册Windows_Mac_runner/`。

### 前提（一次性）

| 平台 | 在哪编 | 要做的事 |
| --- | --- | --- |
| linux-x64 | gitlab.com 共享 runner（`debian:bookworm`） | 无（开箱即用） |
| win32-x64 | **你自己的 Windows 电脑** | ① 装 **PowerShell 7**：`winget install --id Microsoft.PowerShell --source winget`（runner 在 Windows 上默认用 pwsh，job 也显式调 pwsh；Windows PowerShell 5.1 会把无 BOM 的中文 ps1 读坏，本机实测第 32 行解析错）② 项目 **Settings → CI/CD → Runners → Create project runner**：操作系统选 Windows，Tags 填 `windows`，**不勾** Run untagged → Create runner，页面会给一条带 `glrt-` 令牌的 register 命令（令牌只显示一次，只贴进 runner 机器的终端）③ 下载官方 `gitlab-runner-windows-amd64.exe`，改名 `gitlab-runner.exe` 放 `C:\GitLab-Runner\`，在该目录执行那条 register，executor 填 `shell` ④ 编辑同目录 `config.toml`，在 `[[runners]]` 下加 `environment = ["FRY_SDK_PYTHON=C:/_260330_Software/anaconda3/envs/fry_3d_main/python.exe"]`（本机 PATH 上的 `python` 是商店占位）⑤ 先前台 `.\gitlab-runner.exe run` 验证；要常驻再 `.\gitlab-runner.exe install` + `start` |
| darwin-arm64 | **一台 Apple Silicon Mac** | ① `xcode-select --install`；`brew install cmake zstd` ② 同上建 runner：操作系统选 macOS，Tags 填 `macos` ③ 官方二进制装到 `/usr/local/bin/gitlab-runner`（GitLab 不维护 Homebrew 版），`gitlab-runner register …`，executor 填 `shell` ④ `cd ~ && gitlab-runner install && gitlab-runner start`（LaunchAgent：**该用户要一直登录图形界面、别让 Mac 睡眠**） |
| 两个 CI/CD 变量 | 项目 **Settings → CI/CD → Variables → Add variable** | `FRY_WINDOWS_RUNNER=1`、`FRY_MACOS_RUNNER=1`：Visibility 选 **Visible**（Masked 要求值至少 8 个字符，`1` 会被拒）；⚠ **Protect variable 不勾**，或把 `v*` 设成受保护 tag（Settings → Repository → Protected tags）——否则 tag 流水线里看不到变量，Windows / macOS job **静默不生成** |

没加变量的平台 job **根本不生成**（不会挂住整条流水线，也**不报错** —— 流水线照样绿，只是少了平台）⇒ **发版前数一数 build job 是不是 3 个**。

### 发版步骤

1. **先验证（不打 tag）**：GitLab 网页 **Build → Pipelines → New pipeline**（17.7 前叫 Run pipeline）→ 分支选 `main` → New pipeline。
   看 `check`（载荷闸）、`build:linux` / `build:windows` / `build:macos`（每个都含 golden 逐字节）、`publish`（候选包 manifest）是否全绿。
2. **再发版**（三个 build job 都绿之后）：
   - **界面**：同步方式选「强制重新同步」，勾「⚠ 发正式版」，tag 填 `v0.1.0`（必须手填），点开始
   - **命令行**：`python tools\fry_release.py --algo-repo <算法仓> --sync always --tag v0.1.0 --push`
   - ★ 第一次发版用 `--sync always`：当前锁文件记录的来源 commit（`266ea208`）里还没有 C++ 目录（同步时 C++ 尚未提交）；强制重同步会改记成真正含 C++ 的 commit，文件相同 ⇒ 载荷指纹不变
   - 推送时终端若出现 `fatal: unable to connect to cache daemon` —— 那是 git 的 `cache` 凭据助手在报错，git 本身返回 0（385 实测 `ls-remote` 照常成功），不影响发版

脚本会：出包 + 冒烟 → 提交载荷（`cpp/` + `cpp.lock.json`）→ **核对「要打 tag 的 commit 里的载荷指纹 == 刚冒烟通过的包」** → 打 tag → 推送。
GitLab 看到 tag 就起流水线：`version → check → build:linux/windows/macos → publish（manifest.json + Release 页）`。

### 为什么普通 push 不起流水线

这台机器上有自动提交程序，几分钟推一次。每推一次都编三平台 = 白烧 CI 分钟数（gitlab.com 免费额度每月 400 分钟）。
所以 `.gitlab-ci.yml` 只认三种触发：**推 tag**、**网页上点 New pipeline**（17.7 前叫 Run pipeline，出候选包）、API。

### 版本号规则（不许手改）

| 触发 | 版本号 |
| --- | --- |
| tag `v1.2.3` | `1.2.3` |
| 网页 New pipeline | `<最近正式 tag 修订号+1>-p<流水线号>.g<短sha>`（候选包；一个 tag 都没有时从 `0.1.0` 起） |
| 本机 | `0.0.0-dev` |

## 三、内网 GitLab 能进之后（搬家）

> ★388 按同事的 OPS-0027 / lmst 文档与模板仓 v1.21.2 重写。逐步讲解、每步为什么、本地彩排证据、排错表：
> 算法仓 `docs/K_工程重构/_260916_2223_388_内网GitLab建仓后怎么做_三平台出包迁移指南/`。下面是**命令清单**（全部在临时副本上彩排过）。

### 第 0 步：准备（你自己，10 分钟）

1. 等桌面上的自动提交程序（范仁多Git管理V19）把最后的改动**提交并推到 gitlab.com**，然后**暂停**它（切分支的中途它若提交，提交会落到意想不到的分支上）
2. 体检，没有 ✗ 才往下走（想拿这台电脑当 Windows runner 再加 `--runner windows`）：

```bat
cd /d C:\_260331_gitlab\fry_production\fry_p_3d_rip\fry_p_3d_rip_260915_auto_build_dll
C:\_260330_Software\anaconda3\envs\fry_3d_main\python.exe tools\fry_intranet_preflight.py
```

### 第 1 步：建空仓 + 推一份干净快照（你自己）

- 优先建在 **`riemann` 组**下（模板仓交接文档写明其 job token 白名单已整组覆盖，不用另外申请）；没有该组权限就建在个人空间，**然后找 Ferry 把本仓加进 `shared/ci-templates` 的 job token 白名单**（lmst 就在个人空间 `ZoeZhao/lmst`）。名字 `fry-halftone`，**不要**勾「用 README 初始化」（下面命令里的 `riemann` 换成实际所在的组或用户名）
- 为什么不推整段历史：历史里有 382 误提交的 282 MB 构建产物，整段推内网仓会有**约 145 MB**，干净快照只有**约 1.6 MB**，文件树哈希完全相同（彩排实测，数字随工作区略有浮动）

```bat
git remote add internal http://192.168.110.250/riemann/fry-halftone.git
git checkout --orphan snapshot
git commit -m "init: fry-halftone SDK（gitlab.com 仓的干净快照）"
git push internal snapshot:main
git branch -M main
git remote rename origin gitlab-com
git remote rename internal origin
git fetch origin
git branch --set-upstream-to=origin/main main
```

### 第 2 步：换 CI 文件（你自己）

```bat
copy /Y ci\internal.gitlab-ci.yml .gitlab-ci.yml
git commit -am "ci: 切到内网 OPS-0027 模板"
git push
```

回退（内网 CI 出问题、要先回 gitlab.com 出包）：`copy /Y ci\standalone.gitlab-ci.yml .gitlab-ci.yml`（`tests/test_ci_yaml.py` 两种状态都认）。

内网 CI 比 gitlab.com 那份少了自己的 `version` / `check` / `publish`（交给模板），但**保留了单元测试**：`test:unit` 与三个 build 并排，
点 `package:trigger` 后才跑（自动提交程序每次推送不白跑），tag / MR 流水线自动跑；它红了整条不绿，`release:tag` 会被绿灯闸拦住。

### 第 3 步：项目设置（你是 Maintainer 就自己做；否则找 Zoe / Ferry）

| 设置 | 位置 | 值 |
| --- | --- | --- |
| 保护分支 | Settings → Repository → Protected branches | `main`：Maintainer 可合并 / 推送（发版按钮要 Maintainer） |
| 保护 tag | Settings → Repository → Protected tags | **`v*.*.*`**（只能三段式），仅 Maintainer 可创建 —— mac runner 只接受受保护 ref，不设则 tag 流水线的 mac 一格永远 pending |
| `SHARED_RELEASE_TOKEN` | Settings → CI/CD → Variables | Project access token（角色 Maintainer、scope `write_repository`），**Protected + Masked**；到期前轮换 |
| `FEISHU_WEBHOOK_URL`（+`FEISHU_SIGN_SECRET`） | 同上 | 可选，不配就不发卡片；发到哪个群问对接方（对方说「通知这块到时候再说」） |
| 给对接方的 deploy token | Settings → Repository → Deploy tokens | scope **只勾 `read_package_registry`**（拿得到包、碰不到源码；OPS-0027：跨仓拉包必须用 deploy token） |
| gitlab.com 旧仓 | Settings → General → Advanced → Archive | 建议归档（只读、不再跑 CI）。若还要往那边推：仓根 CI 已换成内网模板，那边每条流水线都会报找不到 `shared/ci-templates` |

### 第 4 步：三台 runner

| 平台 | 做法 | 机器要装 |
| --- | --- | --- |
| linux-x64 | 管理员把 Linux runner 开给本项目：测试池 `linux`（算版本号、扳机、通知）、打包池 `local-linux-package`（本仓 build:linux）、action 池 `local-linux-action`（发版、上传 manifest）—— 模板注释说现在三个 tag 挂在同一台机器上 | 无（docker 镜像里现装） |
| win32-x64 | 管理员启用公司 Windows 构建机（tag `windows`），或本机注册 project runner（shell executor） | **PowerShell 7**、git、**node ≥ 18**、VS C++、CMake ≥ 3.20、Python（config.toml 设 `FRY_SDK_PYTHON`）；本机现缺 pwsh 7 |
| darwin-arm64 | Ferry 把 mac runner（tag `macos`，只接受受保护 ref）启用到本项目 | Xcode CLT、git、node ≥ 18、python3、cmake、zstd |

### 第 5 步：第一次出包 → 发版（GitLab 网页）

1. Build → Pipelines → 最新一条（灰色 **Blocked** 是在等人点，不是坏了）→ 点 **`package:trigger`**
2. 三平台候选包 `0.1.0-p<流水线号>.g<sha>` 进 Deploy → Package registry；下载 zip 自己验一遍
3. **整条绿了之后**，在**同一条**流水线上点 **`release:tag`** → 打出 `v0.1.0` → 自动起 tag 流水线重新构建 → Release 页
4. ⚠ 本地 `fry_release.py --tag` 在内网模式下会被拒绝（388 的闸）——发版只点按钮

### 第 6 步：交给对接方

包名 `fry-halftone`；清单地址 `http://192.168.110.250/api/v4/projects/<项目ID>/packages/generic/fry-halftone/<版本>/manifest.json`；
deploy token（只读 registry）；接口文档 = 包里的 `SDK_使用说明.md`、`SDK_README_EN.md`、`SDK_参数说明.md`、`params_schema.json`。

> ⚠ 自动提交程序：内网模板对**每次 push** 都起一条只算版本号的流水线（约 10 秒、停在 Blocked）。
> 自动提交程序几分钟推一次 ⇒ 流水线列表会堆满灰色 Blocked。建议对本仓「只提交不推送」，要出包时手动 `git push`。

## 四、常见问题

| 现象 | 原因 / 处理 |
| --- | --- |
| 载荷闸红：「被改 N 个」 | 有人直接改了 `cpp/` —— **只在算法仓改**，然后重新同步 |
| ★载荷闸在 CI 上红、本机绿，而且「被改」的是全部文件 | 换行符：检查 `tools/fry_payload.py` 的 CRLF→LF 规范化与 `.gitattributes` 是否还在（#2854243250 就是这个） |
| golden 闸红：md5 不同 | C++ 与 Python 不一致了：① 算法仓 Python 改过但 C++ 没跟 ② C++ 改动改了末位（浮点顺序 / FMA）③ 编译选项被改（`-ffp-contract=off` / `/fp:precise`）。先在算法仓跑 `c384_regress_all.py` 定位是哪一步的哪个数组 |
| golden 闸只在 macOS 红 | 99% 是浮点收缩：确认 CMake 里 `-ffp-contract=off` 对 `fry_wt_core` 生效 |
| golden 闸只在 Linux 红 | 查 `pow` / `atan2`：glibc 与 Windows ucrt 的 libm 理论上可能差 1 ulp（384 的 ±1 ulp 扰动实验 6 件未改变输出，但不是证明） |
| C 接口用例 ⑥ 红：某种模型「本该 7 却 0」 | C++ 新支持了这个特性 —— 改用例（换一个仍不支持的特性），别删用例 |
| 发版被拒：「载荷指纹对不上」 | 这正是闸在起作用：tag 所在 commit 里不是刚冒烟通过的载荷 —— 重跑一次发版命令 |
| 发版被拒：「tag 已存在」 | 正式 tag 不可移动，换下一个版本号 |
