# build_windows_sdk.ps1 —— Windows 出包入口（CI 的 build:windows 和本机手工出包共用）
#
# 这是一层**薄壳**：真正的五步流水线在 tools/fry_build.py（三平台同一份）。
# ★384 起算法是 C++：**不再需要** venv / pip / PyInstaller —— 出包脚本只用 Python 标准库。
#
# 机器要求：Visual Studio C++ 工具链（CMake 自动找到）+ CMake ≥ 3.20 + Python 3（任意 3.8+）
#
# 用法：
#   CI    ：pwsh -NoProfile -ExecutionPolicy Bypass -File packaging/windows/build_windows_sdk.ps1
#   本机  ：$env:FRY_SDK_PYTHON = "C:\_260330_Software\anaconda3\envs\fry_3d_main\python.exe"
#           pwsh -File packaging/windows/build_windows_sdk.ps1
#
# 🔴 pwsh 下必须写 $env:VAR（bash 的 $VAR 在 pwsh 里是未定义的 shell 变量，会静默变空串）。
$ErrorActionPreference = "Stop"
$Repo = (Resolve-Path (Join-Path $PSScriptRoot "..\..")).Path
Set-Location $Repo

$Version = if ($env:VERSION) { $env:VERSION } else { "0.0.0-dev" }
Write-Host "== 水转印加网 SDK · Windows 出包（C++）· 版本 $Version =="

# ① Python：显式指定 > py 启动器 > PATH 里的 python
$PyExe = $null
$PyArgs = @()
if ($env:FRY_SDK_PYTHON) {
    $PyExe = $env:FRY_SDK_PYTHON
} elseif (Get-Command py -ErrorAction SilentlyContinue) {
    $PyExe = "py"
    $PyArgs = @("-3")
} elseif (Get-Command python -ErrorAction SilentlyContinue) {
    $PyExe = "python"
} else {
    throw "缺 Python 3：出包脚本 tools/fry_build.py 需要它（只用标准库）"
}
Write-Host "Python：$PyExe $PyArgs"

foreach ($tool in @("cmake")) {
    if (-not (Get-Command $tool -ErrorAction SilentlyContinue)) { throw "缺 $tool：请先安装并加入 PATH" }
}

# ② 五步流水线（载荷闸 → 编译 → 装配 → 冒烟 → 打包）
& $PyExe @PyArgs (Join-Path $Repo "tools\fry_build.py") --version $Version
if ($LASTEXITCODE -ne 0) { throw "fry_build.py 失败（返回码 $LASTEXITCODE）" }

$Artifact = Join-Path $Repo "out\fry-halftone-$Version-win32-x64.zip"
if (-not (Test-Path $Artifact)) { throw "出包说成功了，但找不到产物 $Artifact" }
Write-Host "产物：$Artifact"
