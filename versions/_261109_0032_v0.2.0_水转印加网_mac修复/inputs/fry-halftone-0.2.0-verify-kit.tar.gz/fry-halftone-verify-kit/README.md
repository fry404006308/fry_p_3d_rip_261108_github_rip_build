# fry-halftone —— 水转印加网 SDK 打包仓

把算法仓 `fry_py_260604_c180_depth_dither_more` 里的**水转印加网**（`water_transfer_depth`）编成
**Windows dll / macOS dylib / Linux so**，交给桌面端和云服务调用；不含其它加网算法，不含模拟仿真。

> ★384 起：算法是 **C++**（算法仓 `fry_project_components_cpp/`，与 Python 生产线逐字节一致），在调用方进程内跑；
> 382/383 的「PyInstaller 冻结 Python + 子进程」已整体退役。包从 95.5 MB 变成 **0.35 MB**（dll 0.53 MB）。

| 我想…… | 看 |
| --- | --- |
| 调用这个 SDK（对接方） | [docs/SDK_使用说明.md](docs/SDK_使用说明.md) ｜ [English](docs/SDK_README_EN.md) |
| 改完算法重新出包 / 发版 / 搬到内网 | [docs/SDK_发布与CI.md](docs/SDK_发布与CI.md) |
| 理解为什么这样设计 | 算法仓 `docs/K_工程重构/` 下 382（打包）/ 383（参数）/ ★384（C++ 版）文档包 |

## 一条命令出包（本机）

```bat
python tools\fry_release.py --algo-repo <算法仓目录>
python tools\fry_release.py --algo-repo <算法仓目录> --linux prebuilt --mac-kit     ★409 顺带出 Linux 包 + macOS 验收包
python tools\fry_release.py --algo-repo <算法仓目录> --bundle                        ★410 三平台 + out\全交付目录\_YYMMDD_HHMM_主题\（给同事的一整包）
```

★409 三平台现状：**Windows** 本机出包 ✓ ｜ **Linux** 本机 WSL2 真 Linux 里真跑 golden ✓（zig 交叉版 glibc ≥ 2.17 / gcc 原生版 ≥ 2.38）｜
**macOS** 本机只能出「验收包」（`out/kit/…verify-kit.tar.gz`），拷到任意一台 Mac 上 `bash run_on_target.sh` 一条命令出可交付包。
每个包都带命令行 `bin/fry-halftone-cli`（协议与 lmst-cli 同构）。

## 目录

```
├── include/fry_halftone.h        C 接口（跨仓契约，改它 = 改大版本号）
├── src/dll/fry_halftone_dll.cpp  C 壳：参数 / 路径编码 / 回调 / 取消 / 忙锁 / 异常 → 返回码（一行算法都没有）
├── src/dll/fry_hidden_new_delete.cpp ★409 只在 zig 交叉编 macOS 时编入：zig 不认导出白名单 ⇒ 隐藏 new/delete 压住 libc++ 的弱定义
├── src/cli/fry_halftone_cli.cpp  ★409 对外命令行 bin/fry-halftone-cli（只调公开 C 接口；lmst-cli 同构协议）
├── cpp/ + cpp.lock.json          ★算法 C++ 源码副本 + 逐文件 sha256 指纹（副本必须配闸；换行符规范化后再哈希）
├── tools/
│   ├── fry_payload.py            sync / check / status / info（载荷 = cpp/）
│   ├── fry_build.py              五步出包：载荷闸 → CMake 编译 → 装配（★387 含参数说明 + dll sha256）→ ★冒烟（导出面 / 包内说明 / C 接口 / golden 逐字节 / 纯 C 示例）→ 压缩
│   ├── fry_param_schema.py       ★387 参数说明：dll 自报 → params_schema.json + SDK_参数说明.md；形状闸 / 压线探针 / 包内说明闸（纯函数）
│   ├── fry_deliver.py            把本机出的 dll（+ 参数说明）交付进算法仓界面组件 HS200_halftone_dll/_bin/<平台>/
│   ├── fry_release.py            一键：查 → 同步 → 出包 →（可选）提交 + tag + 推送（★388 内网模式下拒绝本地 --tag：发版改点 release:tag）
│   │                             ★409 --linux native|prebuilt|both（WSL 真验收）/ --mac-kit（macOS 验收包）
│   ├── fry_cross_build.py        ★394 zig 交叉编 Linux / macOS；★409 四个二进制 + prebuilt/ + 静态闸（格式 / 架构 / rpath / 签名 / 装载路径）
│   ├── fry_build_linux_native.py ★409 在 WSL2 / Docker 的真 Linux 里出包：native（gcc）或 prebuilt（zig 产物真验收）
│   ├── fry_target_kit.py         ★409 目标机验收包：预编二进制 + 判据 + run_on_target.sh（不带算法源码；本身不是交付件）
│   ├── fry_delivery_bundle.py    ★410 全交付目录：过闸（版本 / 算法指纹 / 外壳指纹 / 冒烟 / 验收包 sha256）→ out/全交付目录/_YYMMDD_HHMM_主题/ + zip
│   ├── fry_intranet_preflight.py ★388 搬到内网前后的只读体检：CI 模式 / 载荷 / git / 历史体积 / 交付物 /（--runner）本机 runner 条件
│   ├── fry_version.py            gitlab.com 阶段的版本号计算
│   ├── fry_publish.py            gitlab.com 阶段的 registry 上传 / manifest / Release
│   └── FryVersionProbe.cpp       CI 冒烟探针（按消费方姿势 dlopen）
├── packaging/{windows,linux,macos}/   三个平台的薄壳入口
├── examples/c/fry_halftone_demo.c     纯 C 消费方示例（冒烟时真跑）
├── tests/                        载荷闸 / CI 口径 / 发版闸 / 出包纯函数 / 小件尺寸 / C 接口十一条（★387 ⑩⑪ 参数说明真跑）/ ★golden 八件
│   └── data/golden.json          标准答案：算法仓 Python 生产线跑出来的 BMP md5（c384_make_sdk_goldens.py 生成）
├── .gitattributes                文本一律 LF（★384 修 CI #2854243250）
├── .gitlab-ci.yml                当前生效的 CI（= ci/ 里两份之一的逐字节副本；现在是 gitlab.com 独立模式）
├── ci/standalone.gitlab-ci.yml   ★388 gitlab.com 独立模式（搬家后靠它回退）
└── ci/internal.gitlab-ci.yml     搬到内网后用：OPS-0027 模板模式（切换 = copy /Y ci\internal.gitlab-ci.yml .gitlab-ci.yml；★388 含 test:unit = check 的内网版）
```

## 验收（★384 C++ 版，Windows）

| 项 | 结果 |
| --- | --- |
| 出包 | `fry-halftone-0.0.0-dev-win32-x64.zip` **0.35 MB**（dll 0.53 MB，382 版 95.5 MB）；五步约 **19 s**（382 版 135~150 s） |
| 导出面 | dll 导出 11 个 C 函数 = 头文件声明，无 C++ 内部符号 |
| C 接口用例 | **9 / 9**（自报家门 / 正常跑 / 中文路径 / K 墨与色带厚度真的生效 / 参数错 / 暂不支持返回 7、坏 JPEG 返回 1 / 中止 / 并发 BUSY / 结果缓冲太小）+ 纯 C 示例真跑；★387 起 **11 / 11**（⑩ 说明里的默认值 = 省略时真正用的值，⑪ 75 个压线探针收拒与说明一致） |
| ★387 参数说明 | 包里 `params_schema.json`（dll 自报，schema v3：14 个参数的类型 / 默认值 / 取值范围）+ `SDK_参数说明.md`；`sdk_info.json` 写 `library_sha256_str` |
| ★golden 逐字节（标准答案 = Python 生产线） | **10 / 10**（★391 +2）：半球 z3、长方体（最长边 4 / K 墨 / 层高 20 µm）、灰阶球（K 墨 0.5 + 色带 0.8 / 填白无支撑宽 64 / 墨厚 300·600·200）、JPEG 贴图 + TRS 节点球（色带 1.6）、★白 factor × 顶点色立方体（LMST 同构）、★上色方式全家桶（23 种 glTF 上色 / 编码写法） |
| 算法仓全量对账 | 21 个模型 × 23 项（22 个中间数组 + 全部 BMP）逐字节相同；半球 16.851 mm：C++ 4.0 s vs Python 99 s |
| 坏文件体检 | PNG / JPEG / GLB 随机弄坏，进程 0 崩溃（见算法仓 384 文档包 `results/384_坏文件体检fuzz.json`） |
| ★409 Linux | WSL2 Debian 13（glibc 2.41）真出包两种：native 1.20 MB（glibc ≥ 2.38）/ prebuilt 0.60 MB（glibc ≥ 2.17）；golden 13/13 + 命令行契约 34 项 + 交付清单 17 项 |
| ★409 跨平台一致性 | 54 个真实模型 × 两个尺寸：Windows / Linux gcc / Linux zig 三者逐张 BMP 逐字节相同 |
| ⚠ 未验证 | macOS 真跑（验收包在 WSL 里端到端验过机制；Mac 上的那一次要有 Mac）、GitLab CI 真跑 |

## 历史验收（382 / 383，Python 子进程版，已退役）

| 项 | 结果 |
| --- | --- |
| 382 出包 | 95.5 MB，七步 135~150 s；半球 852 / 852 张 BMP 与算法仓相同 |
| 383 参数契约 | 尺寸二选一（z 高度 ≡ lmst `targetHeightMm` ｜ 最长边 ≡ `TARGET_MM`）、严格类型；⚠ 383 曾删掉 `color_thickness_mm` / `use_black_k`，★384 按需求恢复并实现（K 墨为将来保留、色带厚度可调明度） |
