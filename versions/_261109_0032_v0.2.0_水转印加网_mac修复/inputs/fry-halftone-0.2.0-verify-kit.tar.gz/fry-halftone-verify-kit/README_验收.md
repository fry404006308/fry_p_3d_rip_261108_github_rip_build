# 水转印加网 SDK · 目标机验收包（0.2.0）

> ⚠ **这个包本身不是交付件**：里面的二进制是在 Windows 上用 zig **交叉编译**的，还没在目标系统上跑过 golden。
> 跑完下面这一条命令、全部通过后，`results/<目标>/` 里的 `.tar.zst` **才是**可交付的 SDK 包。

## 一条命令

```bash
bash run_on_target.sh             # 验本机这个架构
bash run_on_target.sh --also-x64  # Apple Silicon 上顺带用 Rosetta 2 验 Intel 版
```

| 本机 | 验哪个 | 需要 |
|---|---|---|
| Apple Silicon Mac | macos-arm64（+ `--also-x64` 时 macos-x64） | `xcode-select --install`；`brew install zstd` |
| Intel Mac | macos-x64 | 同上 |
| Linux x86_64 | linux-x64 | python3、binutils（nm）、zstd |
| Linux aarch64 | linux-arm64 | 同上 |

## 它做了什么

1. 指纹闸：预编件的算法指纹 = `cpp.lock.json`（二进制与这份验收包是同一次出的）
2. 装配：与正式出包同一份 `tools/fry_build.py`（`--prebuilt-dir`）
3. 冒烟：导出面 → 指纹（库自报）→ 包内说明 → 版本探针 → C 接口用例 → **golden 13 例逐字节** → 纯 C 示例 → 命令行契约 → 交付清单
4. 出包：`results/<目标>/fry-halftone-0.2.0-<平台>.tar.zst` + `SHA256SUMS.txt` + `build_report.json` + `verify.log` + `target_env.txt`

## 包含的目标

- `linux-arm64`：aarch64-linux-gnu.2.28 ｜ 最低系统（实测）glibc 2.17 ｜ zig 0.16.0 交叉编译（Windows 宿主）-target aarch64-linux-gnu.2.28
- `linux-x64`：x86_64-linux-gnu.2.28 ｜ 最低系统（实测）glibc 2.17 ｜ zig 0.16.0 交叉编译（Windows 宿主）-target x86_64-linux-gnu.2.28
- `macos-arm64`：aarch64-macos-none ｜ 最低系统（实测）macOS 13.0 ｜ zig 0.16.0 交叉编译（Windows 宿主）-target aarch64-macos-none
- `macos-x64`：x86_64-macos-none ｜ 最低系统（实测）macOS 13.0 ｜ zig 0.16.0 交叉编译（Windows 宿主）-target x86_64-macos-none

---

# Verify kit (English)

This kit is **not** a deliverable. Run `bash run_on_target.sh` on the target machine; only when every check passes is
`results/<target>/*.tar.zst` a deliverable SDK package (verified byte-for-byte against the golden set on that machine).
