#!/usr/bin/env bash
# run_on_target.sh —— ★409 目标机验收：认出本机 → 用包里预编的二进制跑 fry_build.py --prebuilt-dir
#   （指纹闸 → 装配 → 冒烟：导出面 / 指纹 / 说明 / 探针 / C 接口 / golden 逐字节 / 纯 C 示例 / 命令行契约 / 交付清单 → 出包）
# 用法：bash run_on_target.sh             验本机这个架构
#       bash run_on_target.sh --also-x64  Apple Silicon 上顺带用 Rosetta 2 验 Intel 版（darwin-x64）
# 退出码：0 全过（results/ 里是可交付的包）｜ 1 验收没过（不是交付件）｜ 2 参数错 ｜ 3 缺工具（会打印安装命令）
set -euo pipefail
KIT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$KIT"
PY="${FRY_SDK_PYTHON:-python3}"
ALSO_X64=0
for a in "$@"; do
  case "$a" in
    --also-x64) ALSO_X64=1 ;;
    -h|--help) sed -n '2,7p' "$0"; exit 0 ;;
    *) echo "不认识的参数：${a}（只认 --also-x64）" >&2; exit 2 ;;
  esac
done
OS="$(uname -s)"
if [ "$OS" = "Darwin" ]; then
  export PATH="/opt/homebrew/bin:/usr/local/bin:$PATH"
  xcode-select -p >/dev/null 2>&1 || { echo "缺 Xcode 命令行工具（nm / python3）：xcode-select --install" >&2; exit 3; }
fi
missing=""
for t in "$PY" nm tar zstd; do command -v "$t" >/dev/null 2>&1 || missing="$missing $t"; done
SHA=""          # 出包后给包写 SHA256SUMS.txt：Linux 用 sha256sum，macOS 自带 shasum
if command -v sha256sum >/dev/null 2>&1; then SHA="sha256sum"
elif command -v shasum >/dev/null 2>&1; then SHA="shasum -a 256"
else missing="$missing sha256sum"; fi
if [ -n "$missing" ]; then
  if [ "$OS" = "Darwin" ]; then hint="xcode-select --install ；brew install zstd"
  else hint="sudo apt-get install -y python3 binutils zstd（或发行版对应的包）"; fi
  echo "缺工具：$missing —— 装好再跑：$hint" >&2
  exit 3
fi
"$PY" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 8) else 1)' || { echo "python3 要 ≥ 3.8" >&2; exit 3; }
VERSION="$("$PY" -c 'import json; print(json.load(open("kit_info.json", encoding="utf-8"))["version_str"])')"

HW="$(uname -m)"
if [ "$OS" = "Darwin" ] && [ "$(sysctl -n hw.optional.arm64 2>/dev/null || echo 0)" = "1" ]; then
  HW="arm64"      # Rosetta 里开的终端会谎报 x86_64 ⇒ 以硬件为准
fi
case "$OS-$HW" in
  Darwin-arm64) NATIVE=macos-arm64 ;;
  Darwin-x86_64) NATIVE=macos-x64 ;;
  Linux-x86_64) NATIVE=linux-x64 ;;
  Linux-aarch64|Linux-arm64) NATIVE=linux-arm64 ;;
  *) echo "不支持的平台：$OS $HW" >&2; exit 3 ;;
esac
tag_of() {
  case "$1" in macos-arm64) echo darwin-arm64 ;; macos-x64) echo darwin-x64 ;; *) echo "$1" ;; esac
}

if [ "$OS" = "Darwin" ]; then
  # 浏览器 / 聊天工具下载的文件带隔离属性：未公证的 dylib 会被 Gatekeeper 拦下（dlopen 失败）
  echo "· 清除本目录的下载隔离属性（com.apple.quarantine；只动 $KIT 里的文件）"
  xattr -dr com.apple.quarantine "$KIT" 2>/dev/null || true
fi
mkdir -p "$KIT/results"

env_note() {   # 这台机器是谁：随结果一起带回去（验收证据的一部分）
  {
    echo "date: $(date '+%Y-%m-%d %H:%M:%S %z')"
    echo "uname: $(uname -a)"
    if [ "$OS" = "Darwin" ]; then sw_vers 2>/dev/null || true; echo "hw.optional.arm64: $(sysctl -n hw.optional.arm64 2>/dev/null || echo 0)"
    else cat /etc/os-release 2>/dev/null | grep -E '^(PRETTY_NAME|VERSION_ID)=' || true; ldd --version 2>&1 | head -1 || true; fi
    echo "python: $("$@" -c 'import platform, sys; print(sys.version.split()[0], platform.machine())')"
  }
}

RESULT_ROWS=""
verify_one() {   # $1 = 目标；其余 = 跑 python 的命令（可带 arch 前缀）
  local tgt="$1"; shift
  local pre="$KIT/prebuilt/$tgt" dst="$KIT/results/$tgt" rc=0 tag
  tag="$(tag_of "$tgt")"
  if [ ! -d "$pre" ]; then
    echo "✗ 包里没有 $tgt 的预编二进制" >&2
    RESULT_ROWS="$RESULT_ROWS\n  ✗ ${tgt}：包里没有"
    return 1
  fi
  chmod +x "$pre"/* 2>/dev/null || true
  rm -rf "$dst" && mkdir -p "$dst"
  echo
  echo "================ 验收 ${tgt}（版本 ${VERSION}）================"
  env_note "$@" > "$dst/target_env.txt"
  "$@" tools/fry_build.py --version "$VERSION" --prebuilt-dir "$pre" 2>&1 | tee "$dst/verify.log" || rc=$?
  cp -f out/build_report.json "$dst/" 2>/dev/null || true
  if [ "$rc" = "0" ] && [ -f "out/fry-halftone-$VERSION-$tag.tar.zst" ]; then
    mv -f "out/fry-halftone-$VERSION-$tag.tar.zst" "$dst/"
    # 收包的人在 results/<目标>/ 里跑 `shasum -a 256 -c SHA256SUMS.txt`（或 sha256sum -c）就能核对包在路上没坏
    (cd "$dst" && $SHA "fry-halftone-$VERSION-$tag.tar.zst") > "$dst/SHA256SUMS.txt"
    RESULT_ROWS="$RESULT_ROWS\n  ✓ ${tgt}：可交付 → results/$tgt/fry-halftone-$VERSION-$tag.tar.zst"
    return 0
  fi
  RESULT_ROWS="$RESULT_ROWS\n  ✗ ${tgt}：验收没过（rc=${rc}）→ 看 results/$tgt/verify.log"
  return 1
}

FAIL=0
if [ "$OS" = "Darwin" ] && [ "$NATIVE" = "macos-arm64" ]; then
  verify_one macos-arm64 arch -arm64 "$PY" || FAIL=1
  if [ "$ALSO_X64" = "1" ]; then
    if arch -x86_64 "$PY" -c 'import platform, sys; sys.exit(0 if platform.machine() == "x86_64" else 1)' 2>/dev/null; then
      verify_one macos-x64 arch -x86_64 "$PY" || FAIL=1
    else
      echo "⚠ 跳过 macos-x64：需要 Rosetta 2（softwareupdate --install-rosetta）+ universal2 的 python3（Xcode 命令行工具自带的 /usr/bin/python3 就是）" >&2
      RESULT_ROWS="$RESULT_ROWS\n  ⚠ macos-x64：没验（本机跑不了 x86_64 的 python3）"
    fi
  fi
else
  verify_one "$NATIVE" "$PY" || FAIL=1
fi
echo
echo "================ 验收结果 ================"
printf "%b\n" "$RESULT_ROWS"
echo "（把 results/ 整个目录发回来：里面有可交付的包、SHA256SUMS.txt、build_report.json、verify.log、target_env.txt）"
exit "$FAIL"
